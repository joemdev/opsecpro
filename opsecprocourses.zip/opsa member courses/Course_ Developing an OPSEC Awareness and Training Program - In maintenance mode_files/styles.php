#fitem_id_availabilityconditionsjson .availability_grade input[type=text]{width:3em}.que.calculated
.answer{padding:0.3em;width:auto;display:inline}.que.calculated .answer input[type="text"]{width:30%}#page-question-type-calculated.dir-rtl input[name^="answer"],
#page-question-type-calculated.dir-rtl input[name^="unit"],
#page-question-type-calculated.dir-rtl input[name^="multiplier"],
#page-question-type-calculated.dir-rtl input[name^="calcmax"],
#page-question-type-calculated.dir-rtl input[name^="calcmin"],
#page-question-type-calculated.dir-rtl input[name^="number"],
#page-question-type-calculated.dir-rtl input[name^="tolerance"]{direction:ltr;text-align:left}body#page-question-type-calculated div[id^=fgroup_id_][id*=answeroptions_],
body#page-question-type-calculatedmulti div[id^=fgroup_id_][id*=answeroptions_]{background:#EEE;margin-top:0;margin-bottom:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-bottom:0}body#page-question-type-calculated div[id^=fgroup_id_][id*=answeroptions_] .fgrouplabel label,
body#page-question-type-calculatedmulti div[id^=fgroup_id_][id*=answeroptions_] .fgrouplabel
label{font-weight:bold}body#page-question-type-calculated div[id^=fgroup_id_][id*=answeroptions_] label[for^='id_answer_'],
body#page-question-type-calculated div[id^=fgroup_id_][id*=answertolerance_] label[for^='id_tolerance_'],
body#page-question-type-calculated div[id^=fgroup_id_][id*=answerdisplay_] label[for^='id_correctanswerlength_'],
body#page-question-type-calculatedmulti div[id^=fgroup_id_][id*=answeroptions_] label[for^='id_answer_'],
body#page-question-type-calculatedmulti div[id^=fgroup_id_][id*=answerdisplay_] label[for^='id_correctanswerlength_']{position:absolute;left:-10000px;font-weight:normal;font-size:1em}body#page-question-type-calculated div[id^=fgroup_id_][id*=answertolerance_],
body#page-question-type-calculated div[id^=fgroup_id_][id*=answerdisplay_],
body#page-question-type-calculatedmulti div[id^=fgroup_id_][id*=answertolerance_],
body#page-question-type-calculatedmulti div[id^=fgroup_id_][id*=answerdisplay_]{background:#EEE;margin-bottom:0;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0;border-bottom:0}body#page-question-type-calculated div[id^=fitem_id_][id*=feedback_],
body#page-question-type-calculatedmulti div[id^=fitem_id_][id*=feedback_]{background:#EEE;margin-bottom:2em;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0}.que.calculatedmulti .answer
.specificfeedback{display:inline;padding:0
0.7em;background:#FFF3BF}.que.calculatedmulti .answer .specificfeedback
*{display:inline;background:#FFF3BF}.que.calculatedmulti .answer .specificfeedback
script{display:none}.que.calculatedmulti .answer div.r0,
.que.calculatedmulti .answer
div.r1{padding:0.3em}.que.calculatedsimple
.answer{padding:0.3em;width:auto;display:inline}.que.calculatedsimple .answer input[type="text"]{width:30%}body#page-question-type-calculatedsimple div[id^=fgroup_id_][id*=answeroptions_]{background:#EEE;margin-top:0;margin-bottom:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-bottom:0}body#page-question-type-calculatedsimple div[id^=fgroup_id_][id*=answeroptions_] .fgrouplabel
label{font-weight:bold}body#page-question-type-calculatedsimple div[id^=fgroup_id_][id*=answeroptions_] label[for^='id_answer_'],
body#page-question-type-calculatedsimple div[id^=fgroup_id_][id*=answertolerance_] label[for^='id_tolerance_'],
body#page-question-type-calculatedsimple div[id^=fgroup_id_][id*=answerdisplay_] label[for^='id_correctanswerlength_']{position:absolute;left:-10000px;font-weight:normal;font-size:1em}body#page-question-type-calculatedsimple div[id^=fgroup_id_][id*=answertolerance_],
body#page-question-type-calculatedsimple div[id^=fgroup_id_][id*=answerdisplay_]{background:#EEE;margin-bottom:0;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0;border-bottom:0}body#page-question-type-calculatedsimple div[id^=fitem_id_][id*=feedback_]{background:#EEE;margin-bottom:2em;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0}.que.ddimageortext
.qtext{margin-bottom:0.5em;display:block}.que.ddimageortext div.droparea img, form.mform fieldset#id_previewareaheader div.droparea
img{border:1px
solid #000;max-width:none}.que.ddimageortext .draghome, form.mform fieldset#id_previewareaheader
.draghome{vertical-align:top;margin:5px;visibility:hidden}.que.ddimageortext div.draghome, form.mform fieldset#id_previewareaheader
div.draghome{border:1px
solid black;cursor:move;background-color:#B0C4DE;display:inline-block;height:auto;width:auto;zoom:1}.que.ddimageortext .group1, form.mform fieldset#id_previewareaheader
.group1{background-color:#FFF}.que.ddimageortext .group2, form.mform fieldset#id_previewareaheader
.group2{background-color:#B0C4DE}.que.ddimageortext .group3, form.mform fieldset#id_previewareaheader
.group3{background-color:#DCDCDC}.que.ddimageortext .group4, form.mform fieldset#id_previewareaheader
.group4{background-color:#D8BFD8}.que.ddimageortext .group5, form.mform fieldset#id_previewareaheader
.group5{background-color:#87CEFA}.que.ddimageortext .group6, form.mform fieldset#id_previewareaheader
.group6{background-color:#DAA520}.que.ddimageortext .group7, form.mform fieldset#id_previewareaheader
.group7{background-color:#FFD700}.que.ddimageortext .group8, form.mform fieldset#id_previewareaheader
.group8{background-color:#F0E68C}.que.ddimageortext .drag, form.mform fieldset#id_previewareaheader
.drag{border:1px
solid black;cursor:move;z-index:2}.que.ddimageortext .dragitems.readonly
.drag{cursor:auto}.que.ddimageortext div.ddarea, form.mform fieldset#id_previewareaheader
div.ddarea{text-align:center}.que.ddimageortext .dropbackground, form.mform fieldset#id_previewareaheader
.dropbackground{margin:0
auto}.que.ddimageortext
.dropzone{border:1px
solid black;position:absolute;z-index:1}.que.ddimageortext .dropzone:focus,
.que.ddimageortext .dropzone.yui3-dd-drop-over.yui3-dd-drop-active-valid{border-color:#0a0;box-shadow:0 0 5px 5px rgba(255, 255, 150, 1)}.que.ddimageortext div.dragitems div.draghome, .que.ddimageortext div.dragitems div.drag,
form.mform fieldset#id_previewareaheader div.draghome, form.mform fieldset#id_previewareaheader
div.drag{font:13px/1.231 arial,helvetica,clean,sans-serif}form.mform fieldset#id_previewareaheader div.drag.yui3-dd-dragging,
.que.ddimageortext div.drag.yui3-dd-dragging{z-index:3;box-shadow:3px 3px 4px #000}body#page-question-type-ddimageortext div[id^=fgroup_id_][id*=drags_]{background:#EEE;margin-top:0;margin-bottom:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-bottom:0}body#page-question-type-ddimageortext div[id^=fgroup_id_][id*=drags_] .fgrouplabel
label{font-weight:bold}body#page-question-type-ddimageortext div[id^=fitem_id_][id*=dragitem_]{background:#EEE;margin-bottom:0;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0;border-bottom:0}body#page-question-type-ddimageortext div[id^=fitem_id_][id*=draglabel_]{background:#EEE;margin-bottom:2em;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0}.que.ddmarker
.qtext{margin-bottom:0.5em;display:block}.que.ddmarker div.droparea img, form.mform fieldset#id_previewareaheader div.droparea
img{border:1px
solid #000;max-width:none}.que.ddmarker .draghome img, .que.ddmarker .draghome
span{visibility:hidden}.que.ddmarker .dragitems
.dragitem{cursor:move;position:absolute;z-index:2}.que.ddmarker .dragitems
.draghome{margin:10px}.que.ddmarker
.dragitems{margin-top:10px}.que.ddmarker .dragitems.readonly
.dragitem{cursor:auto}.que.ddmarker div.ddarea, form.mform fieldset#id_previewareaheader
div.ddarea{text-align:center}form.mform fieldset#id_previewareaheader div.ddarea
.markertexts{min-height:80px}.que.ddmarker .dropbackground, form.mform fieldset#id_previewareaheader
.dropbackground{margin:0
auto}.que.ddmarker div.dragitems div.draghome, .que.ddmarker div.dragitems div.dragitem,
form.mform fieldset#id_previewareaheader div.draghome, form.mform fieldset#id_previewareaheader
div.drag{font:13px/1.231 arial,helvetica,clean,sans-serif}.que.ddmarker div.dragitems span.markertext,
.que.ddmarker div.markertexts span.markertext,
form.mform fieldset#id_previewareaheader div.markertexts
span.markertext{margin:0
5px;z-index:3;background-color:white;border:2px
solid black;padding:5px;display:inline-block;zoom:1;border-radius:10px}.que.ddmarker div.markertexts
span.markertext{z-index:2;background-color:yellow;border-style:solid;border-width:2px;border-color:khaki}.que.ddmarker
span.wrongpart{background-color:yellow;border-style:solid;border-width:2px;border-color:khaki;padding:5px;border-radius:10px;filter:alpha(opacity=60);opacity:0.6;margin:5px;display:inline-block}.que.ddmarker div.dragitems
img.target{position:absolute;left:-7px;top:-7px}.que.ddmarker div.dragitems div.draghome
img.target{display:none}.que.ddmarker .dragitem.yui3-dd-dragging
span.markertext{z-index:3;box-shadow:3px 3px 4px #000}#page-question-type-ddmarker .ddarea
.grid{position:absolute;background:url(/academy/theme/image.php?theme=lambda&component=qtype_ddmarker&rev=1533780117&image=grid) repeat scroll 0 0}body#page-question-type-ddmarker div[id^=fitem_id_][id*=hint_]{background:#EEE;margin-top:0;margin-bottom:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-bottom:0}body#page-question-type-ddmarker div[id^=fitem_id_][id*=hint_] .fitemtitle{font-weight:bold}body#page-question-type-ddmarker div[id^=fitem_id_][id*=hintoptions_],
body#page-question-type-ddmarker div[id^=fitem_id_][id*=hintshownumcorrect_]{background:#EEE;margin-bottom:0;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0;border-bottom:0}body#page-question-type-ddmarker div[id^=fitem_id_][id*=hintclearwrong_]{background:#EEE;margin-bottom:2em;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0}body#page-question-type-ddmarker
#fitem_id_penalty{margin-bottom:2em}.que.ddwtos
.qtext{margin-bottom:0.5em;display:block}.que.ddwtos
.draghome{margin-bottom:1em}.que.ddwtos
.answertext{margin-bottom:0.5em}.que.ddwtos
.drop{display:inline-block;text-align:center;border:1px
solid #000;margin-bottom:2px}.que.ddwtos .draghome, .que.ddwtos
.drag{display:inline-block;text-align:center;background:transparent;border:0}.que.ddwtos .draghome, .que.ddwtos
.drag.unplaced{border:1px
solid #000}.que.ddwtos
.draghome{visibility:hidden}.que.ddwtos
.drag{z-index:2}.que.ddwtos .drag.yui3-dd-dragging{z-index:3;box-shadow:3px 3px 4px #000}.que.ddwtos .drop:focus,
.que.ddwtos .drop.yui3-dd-drop-over.yui3-dd-drop-active-valid{border-color:#0a0;box-shadow:0 0 5px 5px rgba(255, 255, 150, 1)}.que.ddwtos .notreadonly
.drag{cursor:move}.que.ddwtos .readonly
.drag{cursor:default}.que.ddwtos
span.incorrect{background-color:#faa}.que.ddwtos
span.correct{background-color:#afa}.que.ddwtos
.group1{background-color:#FFF}.que.ddwtos
.group2{background-color:#DCDCDC}.que.ddwtos
.group3{background-color:#B0C4DE}.que.ddwtos
.group4{background-color:#D8BFD8}.que.ddwtos
.group5{background-color:#87CEFA}.que.ddwtos
.group6{background-color:#DAA520}.que.ddwtos
.group7{background-color:#FFD700}.que.ddwtos
.group8{background-color:#F0E68C}.que.ddwtos sub,
.que.ddwtos
sup{font-size:80%;position:relative;vertical-align:baseline}.que.ddwtos
sup{top:-0.4em}.que.ddwtos
sub{bottom:-0.2em}.que.essay
textarea.qtype_essay_response{width:100%}.que.essay
textarea.qtype_essay_response.qtype_essay_plain{white-space:pre-wrap;font:inherit}.que.essay
textarea.qtype_essay_response.qtype_essay_monospaced{white-space:pre;font-family:Andale Mono,Monaco,Courier New,DejaVu Sans Mono,monospace}.que.essay
.qtype_essay_response{min-height:3em}.que.essay
.qtype_essay_response.readonly{background-color:white}.que.essay div.qtype_essay_response
textarea{width:100%}.que.gapselect
.qtext{line-height:2em;margin-top:1px;margin-bottom:0.5em;display:block}.que.gapselect
.answercontainer{line-height:2em;margin-bottom:1em;display:block}.que.gapselect
.answertext{padding-bottom:0.5em}.que.sddl
.control{padding:0.2em}body#page-question-type-match div[id^=fitem_id_][id*=subquestions_]{background:#EEE;margin-top:0;margin-bottom:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-bottom:0}body#page-question-type-match div[id^=fitem_id_][id*=subquestions_] .fitemtitle{font-weight:bold}body#page-question-type-match div[id^=fitem_id_][id*=subanswers_]{background:#EEE;margin-bottom:2em;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0}.que.multianswer
.feedbackspan{display:block;max-width:70%;background:#fff3bf;padding:0.5em;margin-top:1em;box-shadow:0.5em 0.5em 1em #000}body.ie6 .que.multianswer .feedbackspan,
body.ie7 .que.multianswer .feedbackspan,
body.ie8 .que.multianswer .feedbackspan,
body.ie9 .que.multianswer
.feedbackspan{width:70%}.que.multianswer .answer
.specificfeedback{display:inline;padding:0
0.7em;background:#FFF3BF}.que.multianswer .answer .specificfeedback
*{display:inline;background:#FFF3BF}.que.multianswer .answer .specificfeedback
script{display:none}.que.multianswer .answer div.r0,
.que.multianswer .answer
div.r1{padding:0.3em}.que.multianswer
table.answer{margin-bottom:0;width:100%}.que.multichoice .answer
.specificfeedback{display:inline;padding:0
0.7em;background:#FFF3BF}.que.multichoice .answer div.r0,
.que.multichoice .answer
div.r1{padding:0.3em 0 0.3em 25px;text-indent:-25px}.que.multichoice .answer div.r0 label,
.que.multichoice .answer div.r1 label,
.que.multichoice .answer div.r0 div.specificfeedback,
.que.multichoice .answer div.r1
div.specificfeedback{text-indent:0}.que.multichoice .answer div.r0 input,
.que.multichoice .answer div.r1
input{margin:0
5px;padding:0;width:15px}.dir-rtl .que.multichoice .answer div.r0,
.dir-rtl .que.multichoice .answer
div.r1{padding:0.3em 25px 0.3em 0}body#page-question-type-multichoice div[id^=fitem_id_][id*=answer_]{background:#EEE;margin-top:0;margin-bottom:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-bottom:0}body#page-question-type-multichoice div[id^=fitem_id_][id*=answer_] .fitemtitle{font-weight:bold}body#page-question-type-multichoice div[id^=fitem_id_] .fitemtitle{margin-left:0px;margin-right:0px;padding-left:6px;padding-right:0px}body.dir-rtl#page-question-type-multichoice div[id^=fitem_id_] .fitemtitle{margin-left:0px;margin-right:0px;padding-left:0px;padding-right:6px}body#page-question-type-multichoice div[id^=fitem_id_][id*=fraction_]{background:#EEE;margin-bottom:0;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0;border-bottom:0}body#page-question-type-multichoice div[id^=fitem_id_][id*=feedback_]{background:#EEE;margin-bottom:2em;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0}.que.numerical
.answer{padding:0.3em;width:auto;display:inline}.que.numerical .answer input[type="text"]{width:30%}#page-question-type-numerical.dir-rtl input[name="unitpenalty"],
#page-question-type-numerical.dir-rtl input[name^="answer"],
#page-question-type-numerical.dir-rtl input[name^="tolerance"],
#page-question-type-numerical.dir-rtl input[name^="multiplier"],
#page-question-type-numerical.dir-rtl input[name^="unit"]{direction:ltr;text-align:left}body#page-question-type-numerical div[id^=fgroup_id_][id*=answeroptions_]{background:#EEE;margin-top:0;margin-bottom:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-bottom:0}body#page-question-type-numerical div[id^=fgroup_id_][id*=answeroptions_] .fgrouplabel
label{font-weight:bold}body.path-question-type div#fgroup_id_penaltygrp label[for^=id_unitpenalty],
body.path-question-type div[id^=fgroup_id_units_] label[for^='id_unit_'],
body#page-question-type-numerical div[id^=fgroup_id_][id*=answeroptions_] label[for^='id_answer_']{position:absolute;left:-10000px;font-weight:normal;font-size:1em}body#page-question-type-numerical div[id^=fitem_id_][id*=fraction_]{background:#EEE;margin-bottom:0;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0;border-bottom:0}body#page-question-type-numerical div[id^=fitem_id_][id*=feedback_]{background:#EEE;margin-bottom:2em;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0}.que.shortanswer
.answer{padding:0.3em;width:auto;display:inline}.que.shortanswer .answer
input{width:80%}body#page-question-type-shortanswer div[id^=fgroup_id_][id*=answeroptions_]{background:#EEE;margin-top:0;margin-bottom:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-bottom:0}body#page-question-type-shortanswer div[id^=fgroup_id_][id*=answeroptions_] .fgrouplabel
label{font-weight:bold}body#page-question-type-shortanswer div[id^=fgroup_id_][id*=answeroptions_] label[for^='id_answer_']{position:absolute;left:-10000px;font-weight:normal;font-size:1em}body#page-question-type-shortanswer div[id^=fitem_id_][id*=fraction_]{background:#EEE;margin-bottom:0;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0;border-bottom:0}body#page-question-type-shortanswer div[id^=fitem_id_][id*=feedback_]{background:#EEE;margin-bottom:2em;margin-top:0;padding-bottom:5px;padding-top:5px;border:1px
solid #BBB;border-top:0}.que.truefalse .answer div.r0,
.que.truefalse .answer
div.r1{padding:0.3em}.path-mod-assign div.gradingnavigation
div{float:left;margin-left:2em}.path-mod-assign div.submissionstatustable,
.path-mod-assign div.submissionfull,
.path-mod-assign div.submissionlinks,
.path-mod-assign div.usersummary,
.path-mod-assign div.feedback,
.path-mod-assign
div.gradingsummary{margin-bottom:5em}.path-mod-assign div.submissionstatus .generaltable,
.path-mod-assign div.submissionlinks .generaltable,
.path-mod-assign div.feedback .generaltable,
.path-mod-assign div.submissionsummarytable .generaltable,
.path-mod-assign div.attempthistory table,
.path-mod-assign div.gradingsummary
.generaltable{width:100%}.path-mod-assign table.generaltable table
td{border:0px
none}.path-mod-assign .gradingsummarytable,
.path-mod-assign .feedbacktable,
.path-mod-assign .lockedsubmission,
.path-mod-assign
.submissionsummarytable{margin-top:1em}.path-mod-assign div.submissionsummarytable table tbody tr
td.c0{width:30%}.path-mod-assign
.submittedlate{color:red;font-weight:900}.path-mod-assign.jsenabled .gradingoptionsform
.fsubmit{display:none}.path-mod-assign.jsenabled .gradingtable .c1
select{display:none}.path-mod-assign .quickgradingform .mform
fieldset{margin:0px;padding:0px}.path-mod-assign .gradingbatchoperationsform .mform
fieldset{margin:0px;padding:0px}.path-mod-assign td.submissionstatus,
.path-mod-assign div.submissionstatus,
.path-mod-assign a:link.submissionstatus{color:black;background-color:#efefef}.path-mod-assign td.submissionstatusdraft,
.path-mod-assign div.submissionstatusdraft,
.path-mod-assign a:link.submissionstatusdraft{color:black;background-color:#efefcf}.path-mod-assign td.submissionstatussubmitted,
.path-mod-assign div.submissionstatussubmitted,
.path-mod-assign a:link.submissionstatussubmitted{color:black;background-color:#cfefcf}.path-mod-assign td.submissionlocked,
.path-mod-assign
div.submissionlocked{color:black;background-color:#efefcf}.path-mod-assign td.submissionreopened,
.path-mod-assign
div.submissionreopened{color:black;background-color:#efefef}.path-mod-assign td.submissiongraded,
.path-mod-assign
div.submissiongraded{color:black;background-color:#cfefcf}.path-mod-assign td.submissionnotgraded,
.path-mod-assign
div.submissionnotgraded{color:black;background-color:#efefef}.path-mod-assign td.latesubmission,
.path-mod-assign a:link.latesubmission,
.path-mod-assign
div.latesubmission{color:black;background-color:#efcfcf}.path-mod-assign td.earlysubmission,
.path-mod-assign
div.earlysubmission{color:black;background-color:#cfefcf}.path-mod-assign .gradingtable
.c0{display:none}.path-mod-assign.jsenabled .gradingtable
.c0{display:table-cell}.path-mod-assign
.gradingbatchoperationsform{display:none}.path-mod-assign.jsenabled
.gradingbatchoperationsform{display:block}.path-mod-assign .gradingtable tr.selectedrow
td{background-color:#fec}.path-mod-assign .gradingtable tr.unselectedrow
td{background-color:white}.path-mod-assign .gradingtable .c0
div.selectall{margin-left:7px}.path-mod-assign .gradingtable .yui3-menu
ul{margin:0px}.path-mod-assign .gradingtable .yui3-menu-label{padding-left:0px;line-height:12px}.path-mod-assign .gradingtable .yui3-menu-label
img{padding:0
3px}.path-mod-assign .gradingtable .yui3-menu
li{list-style-type:none}.path-mod-assign.jsenabled .gradingtable .yui3-loading{display:none}.path-mod-assign .gradingtable .yui3-menu .yui3-menu-content{border:0px;padding-top:0}.path-mod-assign div.gradingtable tr
.quickgrademodified{background-color:#FC9}.path-mod-assign
td.submissioneditable{color:red}.path-mod-assign
.expandsummaryicon{cursor:pointer;display:none}.path-mod-assign.jsenabled
.expandsummaryicon{display:inline}.path-mod-assign
.hidefull{display:none}.path-mod-assign .quickgradingform form .commentscontainer input,
.path-mod-assign .quickgradingform form .commentscontainer
textarea{display:none}.path-mod-assign.jsenabled .quickgradingform form .commentscontainer input,
.path-mod-assign.jsenabled .quickgradingform form .commentscontainer
textarea{display:inline}.path-mod-assign
.previousfeedbackwarning{font-size:140%;font-weight:bold;text-align:center;color:#500}.path-mod-assign
.submissionhistory{background-color:#b0b0b0}.path-mod-assign .submissionhistory
.cell.historytitle{background-color:#808080}.path-mod-assign .submissionhistory
.cell{background-color:#d0d0d0}.path-mod-assign.jsenabled .mod-assign-history-link{display:block;cursor:pointer;margin-bottom:7px}.path-mod-assign.jsenabled .mod-assign-history-link
h4{display:inline}.path-mod-assign.jsenabled .attempthistory
h4{margin-bottom:7px;text-align:left}.path-mod-assign.jsenabled.dir_rtl .attempthistory
h4{text-align:right}.path-mod-assign.dir-rtl.jsenabled .mod-assign-history-link
h4{text-align:right}.path-mod-assign.jsenabled .mod-assign-history-link-open{padding:0
5px 0 20px;background:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fexpanded) 2px center no-repeat}.path-mod-assign.jsenabled .mod-assign-history-link-closed{padding:0
5px 0 20px;background:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fcollapsed) 2px center no-repeat}.path-mod-assign.dir-rtl.jsenabled .mod-assign-history-link-closed{padding:0
20px 0 5px;background:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fcollapsed_rtl) 2px center no-repeat}.path-mod-assign
.submithelp{padding:1em}.path-mod-assign
.feedbacktitle{font-weight:bold}.path-mod-assign .submitconfirm,
.path-mod-assign .submissionlinks,
.path-mod-assign
.submissionaction{text-align:center}.path-mod-assign .submissionsummarytable .c0,
.path-mod-assign .mod-assign-history-panel
.c0{width:150px}.path-mod-assign .gradingtable .moodle-actionmenu{white-space:nowrap}.path-mod-assign .gradingtable .moodle-actionmenu[data-enhanced].show .menu
a{padding-left:12px;padding-right:12px}.path-mod-assign .gradingtable .menu-action
img{display:none}.path-mod-assign .editsubmissionform input[name="submissionstatement"]{vertical-align:top}.path-mod-assign .editsubmissionform label[for="id_submissionstatement"]{display:inline-block}.path-mod-assign.layout-option-nonavbar{padding-top:0px}.path-mod-assign [data-region="user-selector"] select{margin-bottom:0px}.path-mod-assign [data-region="user-selector"] .alignment{float:right;width:320px;text-align:center;margin-top:7px}.path-mod-assign [data-region="user-selector"] [data-action="previous-user"],
.path-mod-assign [data-region="user-selector"] [data-action="next-user"]{font-size:26px}.path-mod-assign [data-region="user-selector"] [data-action="next-user"]{margin-left:-10px}.dir-rtl.path-mod-assign [data-region="user-selector"] [data-action="next-user"]{margin-right:-10px}.dir-rtl.path-mod-assign [data-region="user-selector"] .alignment{float:left}.path-mod-assign [data-region="user-selector"] .alignment
input{margin-bottom:5px}.path-mod-assign [data-region="user-selector"] .alignment .form-autocomplete-downarrow{top:0}.path-mod-assign [data-region="user-selector"] .form-autocomplete-selection{display:none}.path-mod-assign [data-region="user-selector"] .form-autocomplete-suggestions{text-align:left}.path-mod-assign [data-region="user-selector"] .form-autocomplete-suggestions{margin-left:48px}.dir-rtl.path-mod-assign [data-region="user-selector"] .form-autocomplete-suggestions{margin-right:64px}.path-mod-assign [data-region="user-filters"]{font-size:small}.path-mod-assign [data-region="configure-filters"]{display:none;text-align:left;width:auto;background-color:#fff;background-clip:padding-box;box-shadow:0 5px 10px rgba(0, 0, 0, 0.2);border-radius:6px;position:absolute;margin-top:28px;margin-left:-140px;padding:10px
0;z-index:1}.path-mod-assign [data-region="configure-filters"]::before,
.path-mod-assign [data-region="configure-filters"]::after{position:absolute;left:auto;display:inline-block;content:'';border-style:solid;border-color:transparent;border-top:none}.path-mod-assign [data-region="configure-filters"]::before{top:-7px;right:12px;border-width:7px;border-bottom-color:rgba(0, 0, 0, 0.2)}.path-mod-assign [data-region="configure-filters"]::after{top:-6px;right:13px;border-width:6px;border-bottom-color:#fff}.path-mod-assign.dir-rtl [data-region="configure-filters"]{text-align:right;margin-left:0;margin-right:-140px}.path-mod-assign [data-region="configure-filters"] label{padding:3px
20px}.path-mod-assign .alignment [data-region="configure-filters"] input{margin-bottom:0}.path-mod-assign [data-region="grading-navigation-panel"]{position:absolute;top:0;left:0;width:100%;height:6em;margin:0;border-bottom:1px solid #ddd}.path-mod-assign [data-region="grading-navigation"]{padding:1em}.path-mod-assign [data-region="assignment-info"]{white-space:nowrap;overflow-x:hidden;text-overflow:ellipsis}.path-mod-assign [data-region="assignment-info"] small[data-region="assignment-tooltip"]{margin-left:0.5em}.path-mod-assign [data-region="user-info"]{height:60px}.path-mod-assign [data-region="user-info"] a{text-decoration:none}.path-mod-assign [data-region="user-info"] .img-rounded{display:block;float:left;margin-top:-3px;margin-right:10px}.dir-rtl.path-mod-assign [data-region="user-info"] .img-rounded{float:right;margin-left:10px}.path-mod-assign [data-region="user-info"] em{display:block;font-style:normal}.path-mod-assign [data-region="grading-actions-form"] label{display:inline-block}.path-mod-assign.pagelayout-embedded{overflow:hidden}.path-mod-assign [data-region="review-panel"]{position:absolute;top:85px;bottom:60px;left:0;right:30%;width:auto;box-sizing:border-box;-webkit-transition:right 0.5s, left 0.5s;-moz-transition:right 0.5s, left 0.5s;transition:right 0.5s, left 0.5s}.path-mod-assign [data-region="review-panel"].grade-panel-collapsed{right:30px}.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"]{display:none;height:30px;width:30px;position:absolute;top:0;right:0;left:auto;box-sizing:border-box;border-radius:0 0 0 4px;border:1px
solid #ccc;border-top:none;background-color:#fff;z-index:99999}.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"] .expand-icon,
.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"] .collapse-icon{width:100%;height:100%;text-align:center;line-height:30px}.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"] .expand-icon .toggle-text,
.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"] .collapse-icon .toggle-text{visibility:hidden;opacity:0;height:0;overflow:hidden}.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"] img{height:100%;float:right}.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"] .expand-icon{display:none}.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"] .collapse-icon{display:block}.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"] .collapse-icon.full-width{display:none}.path-mod-assign [data-region="review-panel"] .pageheader{border-right:1px solid #ddd}.path-mod-assign [data-region="review-panel"] + [data-region="grade-panel"] [data-region="grade"]{margin-left:auto;margin-right:auto;max-width:100%;-webkit-transition:max-width 0.5s;-moz-transition:max-width 0.5s;transition:max-width 0.5s}.path-mod-assign [data-region="review-panel"] .drawingregion{left:0;right:0;border-color:#ddd}.path-mod-assign [data-region="review-panel"].collapsed{left:calc(30px - 70%);right:calc(100% - 30px);-webkit-transition:right 0.5s, left 0.5s;-moz-transition:right 0.5s, left 0.5s;transition:right 0.5s, left 0.5s}.path-mod-assign [data-region="review-panel"].collapsed [data-region="review-panel-content"]{visibility:hidden;-webkit-transition:visibility 0s 0.5s;-moz-transition:visibility 0s 0.5s;transition:visibility 0s 0.5s}.path-mod-assign [data-region="review-panel"].collapsed [data-region="review-panel-toggle"] .expand-icon{display:block}.path-mod-assign [data-region="review-panel"].collapsed [data-region="review-panel-toggle"] .collapse-icon{display:none}.path-mod-assign [data-region="review-panel"].collapsed+[data-region="grade-panel"]{position:absolute;left:30px;right:0;width:calc(100% - 30px);overflow:auto;-webkit-transition:width 0.5s, right 0.5s, left 0.5s;-moz-transition:width 0.5s, right 0.5s, left 0.5s;transition:width 0.5s, right 0.5s, left 0.5s}.path-mod-assign [data-region="review-panel"].collapsed + [data-region="grade-panel"] [data-region="grade"],
.path-mod-assign [data-region="grade-panel"].fullwidth [data-region="grade"]{max-width:800px;margin-left:auto;margin-right:auto}.path-mod-assign [data-region="grade-panel"]{position:absolute;top:85px;bottom:60px;right:0;left:70%;width:30%;overflow:auto;box-sizing:border-box;background-color:#f5f5f5;padding:15px;padding-top:0px;-webkit-transition:width 0.5s, right 0.5s, left 0.5s;-moz-transition:width 0.5s, right 0.5s, left 0.5s;transition:width 0.5s, right 0.5s, left 0.5s}.path-mod-assign [data-region="grade-panel"].collapsed{left:calc(100% - 30px);right:calc(30px - 100%);visibility:hidden;-webkit-transition:right 0.5s, left 0.5s, visibility 0s 0.5s;-moz-transition:right 0.5s, left 0.5s, visibility 0s 0.5s;transition:right 0.5s, left 0.5s, visibility 0s 0.5s}.path-mod-assign [data-region="grade-panel"].fullwidth{left:0;width:100%;overflow:auto}.path-mod-assign [data-region="grade-panel"] h3{font-size:18px;font-weight:500}.path-mod-assign [data-region="grade-panel"] div.submissionstatustable{margin-bottom:2em}.path-mod-assign [data-region="grade-panel"] .submissionsummarytable{margin-left:5px;margin-right:5px}.path-mod-assign [data-region="grade-panel"] .submissionsummarytable table.generaltable
td{padding:8px
0;background-color:transparent}.path-mod-assign [data-region="grade-panel"] .submissionsummarytable .generaltable tbody > tr:nth-child(2n+1) > td,
.path-mod-assign [data-region="grade-panel"] .submissionsummarytable .generaltable tbody tr:hover>td{background-color:transparent}.path-mod-assign [data-region="grade-panel"] div.submissionsummarytable table tbody tr
td.c0{width:auto}.path-mod-assign [data-region="grade-panel"] div.submissionsummarytable table tbody tr.lastrow td.c0,
.path-mod-assign [data-region="grade-panel"] div.submissionsummarytable table tbody tr.lastrow
td.c1{border-bottom:1px solid #ddd}.path-mod-assign [data-region="grade-panel"] td.submissionnotgraded,
.path-mod-assign [data-region="grade-panel"] div.submissionnotgraded{color:red;background-color:transparent}.path-mod-assign [data-region="grade-panel"] #id_gradeheader{display:table-cell;min-width:0}.path-mod-assign [data-region="grade-panel"] #id_gradeheader>legend{visibility:hidden;height:0;margin-bottom:0}.path-mod-assign [data-region="grade-panel"] .comment-area textarea[cols]{width:100%;box-sizing:border-box}.path-mod-assign [data-region="grade-panel"] .mform .fitem.fitem_ftext,
.path-mod-assign [data-region="grade-panel"] .mform .fitem.fitem_f,
.path-mod-assign [data-region="grade-panel"] .mform .fitem.fitem_feditor,
.path-mod-assign [data-region="grade-panel"] .mform
.fitem.fitem_ffilemanager{background-color:#fff;border:1px
solid #ddd;margin-bottom:20px}.path-mod-assign [data-region="grade-panel"] .mform .fitem.fitem_ftext .fitemtitle,
.path-mod-assign [data-region="grade-panel"] .mform .fitem.fitem_f .fitemtitle,
.path-mod-assign [data-region="grade-panel"] .mform .fitem.fitem_feditor .fitemtitle,
.path-mod-assign [data-region="grade-panel"] .mform .fitem.fitem_ffilemanager
.fitemtitle{padding-left:5px;padding-right:5px}.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fcontainer .fitem.fitem_ftext .felement,
.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fcontainer .fitem.fitem_f .felement,
.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fcontainer .fitem.fitem_feditor .felement,
.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fcontainer .fitem.fitem_ffilemanager
.felement{padding:6px
10px 10px;box-sizing:border-box}.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fitem.fitem_ftext .fitemtitle,
.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fitem.fitem_f .fitemtitle,
.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fitem.fitem_feditor .fitemtitle,
.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fitem.fitem_ffilemanager
.fitemtitle{border-bottom:1px solid #ddd;box-shadow:0 1px 1px rgba(0,0,0,0.05);padding:6px
10px 3px;box-sizing:border-box}.path-mod-assign #page-content [data-region="grade-panel"] [data-region="popout-button"] img{margin-left:2px;margin-right:2px;margin-top:-2px}.path-mod-assign #page-content [data-region="grade-panel"] .popout [data-region="popout-button"] img{margin-left:-6px;margin-right:-6px;margin-top:4px}.path-mod-assign [data-region="grade-panel"] .fitem .fstaticlabel,
.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fitem .fitemtitle
label{font-weight:500}.path-mod-assign [data-region="grade-panel"] .mform
#fitem_id_grade.fitem{padding-top:5px}.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) #fitem_id_grade.fitem
.fitemtitle{display:inline-block;width:auto;border-bottom:none;box-shadow:none}.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) #fitem_id_grade.fitem
.felement{width:auto;float:right}.path-mod-assign #page-content .mform:not(.unresponsive) #fitem_id_grade.fitem .felement
input{width:80px;margin-bottom:0}.path-mod-assign [data-region="grade-panel"] .gradingform_rubric{padding-bottom:0;max-width:none}.path-mod-assign [data-region="grade-panel"] .gradingform_rubric .criterion
.description{font-weight:500;min-width:150px}.path-mod-assign [data-region="grade-panel"] .gradingform_rubric .criterion
.levels{background-color:#fff}.path-mod-assign [data-region="grade-panel"] .gradingform_rubric .criterion,
.path-mod-assign [data-region="grade-panel"] .gradingform_rubric
.criterion.even{background-color:transparent}.path-mod-assign [data-region="grade-panel"] .gradingform_rubric.evaluate .criterion .levels .level:hover{background-color:#dff0d8}.path-mod-assign [data-region="grade-panel"] .gradingform_rubric .criterion .levels
.level.checked{background-color:#dff0d8;border:none;border-left:1px solid #ddd}.path-mod-assign [data-region="grade-panel"] .gradingform_rubric .criterion .levels .level
.score{color:#468847;font-weight:500;font-style:normal;margin-top:20px}.path-mod-assign [data-region="grade-panel"] .gradingform_rubric .criterion .remark
textarea{margin-bottom:0}.path-mod-assign [data-region="grade-panel"] .gradingform_guide{margin-bottom:10px}.path-mod-assign [data-region="grade-panel"] .gradingform_guide .descriptionreadonly,
.path-mod-assign [data-region="grade-panel"] .gradingform_guide .remark,
.path-mod-assign [data-region="grade-panel"] .gradingform_guide
.score{display:block}.path-mod-assign [data-region="grade-panel"] .gradingform_guide
.descriptionreadonly{padding-top:10px}.path-mod-assign [data-region="grade-panel"] .gradingform_guide
.criteriondescription{margin-top:5px}.path-mod-assign [data-region="grade-panel"] .gradingform_guide
.criteriondescriptionmarkers{width:auto;margin-top:5px}.path-mod-assign [data-region="grade-panel"] .gradingform_guide
.markingguideremark{margin-bottom:10px}.path-mod-assign [data-region="grade-panel"] .gradingform_guide .remark
.commentchooser{float:right;margin-top:2px;margin-left:0}.path-mod-assign [data-region="grade-panel"] .gradingform_guide
.score{float:left;padding-bottom:8px}.path-mod-assign [data-region="grade-panel"] .gradingform_guide .score input,
.path-mod-assign [data-region="grade-panel"] .gradingform_guide .score
div{display:inline-block}.path-mod-assign [data-region="grade-panel"] .gradingform_guide .criterion,
.path-mod-assign [data-region="grade-panel"] .gradingform_guide
.criterion.even{background-color:transparent;border-width:0 0 1px 0;padding:8px
0}.path-mod-assign [data-region="grade-panel"] .showmarkerdesc,
.path-mod-assign [data-region="grade-panel"] .showstudentdesc{background-color:#f5f5f5;padding:10px}.path-mod-assign [data-region="grade-panel"] .fitem.fitem_ffilemanager{margin-bottom:0}.path-mod-assign [data-region="grade-panel"] .fitem.popout{position:fixed;left:20%;right:20%;top:20%;bottom:20%;z-index:1000;border:1px
solid rgba(0, 0, 0, 0.3);border-radius:6px;box-shadow:0 3px 7px rgba(0, 0, 0, 0.3)}.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fcontainer .fitem.popout
.fitemtitle{text-align:center;padding-left:15px;padding-right:15px;height:45px}.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fcontainer .fitem.popout .fitemtitle
label{font-size:16px;line-height:30px}.path-mod-assign #page-content [data-region="grade-panel"] [data-region="popout-button"]{float:right}.dir-rtl.path-mod-assign #page-content [data-region="grade-panel"] [data-region="popout-button"]{float:left}.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fitem.popout .fitemtitle [data-region="popout-button"] img{margin-top:-10px;margin-right:-7px}.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fcontainer .fitem.popout
.felement{padding:10px
15px 15px;height:calc(100% - 54px);overflow:auto}.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) .fcontainer .fitem.popout .felement
.gradingform_rubric{overflow:visible}.path-mod-assign [data-region="grade-panel"] #id_attemptsettings>legend{font-size:18px;font-weight:500;line-height:40px;border-bottom:0;margin-bottom:10px}.path-mod-assign [data-region="grade-panel"] #id_attemptsettings
.fcontainer{display:table;width:100%;padding-left:5px;padding-right:5px;margin-bottom:10px;box-sizing:border-box}.path-mod-assign [data-region="grade-panel"] .mform #id_attemptsettings
.fitem{display:table-row}.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) #id_attemptsettings .fitem .fitemtitle,
.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) #id_attemptsettings .fitem
.felement{display:table-cell;float:none;border-top:1px solid #ddd;padding:8px
0}.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) #id_attemptsettings .fitem:last-of-type .fitemtitle,
.path-mod-assign #page-content [data-region="grade-panel"] .mform:not(.unresponsive) #id_attemptsettings .fitem:last-of-type
.felement{border-bottom:1px solid #ddd}.path-mod-assign [data-region="grade-panel"] #id_attemptsettings .fitem .fstaticlabel,
.path-mod-assign [data-region="grade-panel"] .mform:not(.unresponsive) #id_attemptsettings .fitem .fitemtitle
label{font-weight:400}.path-mod-assign [data-region="grade-panel"] .mform:not(.unresponsive) #id_attemptsettings .fitem .felement
select{margin-bottom:0}.path-mod-assign [data-region="grade-panel"] [data-region="attempt-chooser"]{margin-bottom:10px;vertical-align:text-bottom}.path-mod-assign [data-region="grade-actions-panel"]{border-top:1px solid #ddd;position:absolute;bottom:0;left:0;width:100%;height:60px}.path-mod-assign [data-region="grade-actions-panel"] [data-region="grade-actions"] .collapse-buttons{position:absolute;top:0;left:auto;right:15px;margin:0;height:100%;line-height:60px;direction:ltr}.path-mod-assign [data-region="grade-actions"]{padding:1em;text-align:center}.path-mod-assign [data-region="submissions-list"]{text-align:inherit}.path-mod-assign [data-region="submissions-list"] label.radio
input{margin-top:4px;min-width:inherit}.path-mod-assign [data-region="overlay"]{display:none;z-index:100;position:absolute;top:0em;left:0;width:100%;overflow:auto;bottom:0em;background-color:#ddd;opacity:0.4;padding-top:4em;text-align:center}@media (max-width: 767px){.path-mod-assign.pagelayout-embedded{overflow:auto}.path-mod-assign [data-region="assignment-info"]{border-bottom:1px solid #ddd;padding-bottom:5px}.path-mod-assign .page-context-header .page-header-headings{margin-top:13px}.path-mod-assign [data-region="grade-actions-panel"] [data-region="grade-actions"] .collapse-buttons{display:none}.path-mod-assign [data-region="grading-navigation-panel"],
.path-mod-assign [data-region="review-panel"],
.path-mod-assign [data-region="grade-panel"],
.path-mod-assign [data-region="review-panel"].collapsed + [data-region="grade-panel"],
.path-mod-assign [data-region="grade-actions-panel"]{position:inherit;width:100%;top:0;left:0;right:auto;overflow:auto;height:auto;margin-bottom:1em}.path-mod-assign [data-region="grade-panel"].collapsed{visibility:visible}.path-mod-assign [data-region="grading-navigation"]{padding:0;text-align:center}.path-mod-assign [data-region="grade-panel"]{margin-bottom:2em}.path-mod-assign [data-region="grade-panel"] [data-region="popout-button"]{display:none}.path-mod-assign [data-region="review-panel"]{position:relative;max-height:2000px;-webkit-transition:max-height 0.25s linear;-moz-transition:max-height 0.25s linear;transition:max-height 0.25s linear}.path-mod-assign [data-region="review-panel"] .pageheader{border-right:none;padding-right:20px;padding-left:40px}.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"]{display:block;height:20px;width:20px;position:absolute;top:0;left:0;right:auto;box-sizing:border-box;border:1px
solid #ccc;border-radius:0 0 4px 0;background-color:#fff;z-index:99999}.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"] .expand-icon,
.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"] .collapse-icon{width:100%;height:100%;text-align:center;line-height:30px}.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"] .ltr-icon,
.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"] .rtl-icon{height:100%}.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"] .ltr-icon{float:left}.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"] .rtl-icon{float:right}.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"] .expand-icon .toggle-text,
.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"] .collapse-icon .toggle-text{line-height:20px;visibility:visible;opacity:1;height:auto;-webkit-transition:visibility 0s 0.25s, opacity 0s 0.25s;-moz-transition:visibility 0s 0.25s, opacity 0s 0.25s;transition:visibility 0s 0.25s, opacity 0s 0.25s}.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"] .expand-icon .rtl-icon{display:none}.path-mod-assign [data-region="review-panel"].collapsed{max-height:20px;top:0;left:0;overflow:hidden;-webkit-transition:max-height 0.25s linear;-moz-transition:max-height 0.25s linear;transition:max-height 0.25s linear}.path-mod-assign [data-region="review-panel"].collapsed [data-region="review-panel-toggle"]{width:100%;border-radius:0 0 0 0;-webkit-transition:all 0s 0.25s;-moz-transition:all 0s 0.25s;transition:all 0s 0.25s}.path-mod-assign [data-region="review-panel"].collapsed [data-region="review-panel-toggle"] img{height:100%}.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"] .collapse-icon{display:block}.path-mod-assign [data-region="review-panel"].collapsed [data-region="review-panel-toggle"] .collapse-icon{display:none}.path-mod-assign.pagelayout-popup{overflow:inherit}.path-mod-assign [data-region="grading-navigation"] [data-region="user-info"]{text-align:left;width:auto;display:inline-block;margin:0
auto}.path-mod-assign [data-region="user-selector"] .alignment{float:none;margin:0
auto 10px}.dir-rtl.path-mod-assign [data-region="review-panel"] .pageheader{padding-right:40px;padding-left:20px}.dir-rtl.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"]{left:auto;right:0;border-radius:0 0 0 4px}.dir-rtl.path-mod-assign [data-region="review-panel"].collapsed{right:0;left:auto}.dir-rtl.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"] .expand-icon .ltr-icon{display:none}.dir-rtl.path-mod-assign [data-region="review-panel"] [data-region="review-panel-toggle"] .expand-icon .rtl-icon{display:block}.dir-rtl.path-mod-assign [data-region="review-panel"].collapsed [data-region="review-panel-toggle"] .collapse-icon{display:none}.dir-rtl.path-mod-assign [data-region="review-panel"].collapsed [data-region="review-panel-toggle"] .expand-icon{display:block}}.path-mod-assign [data-region="grade-panel"] .mform .fitem
.fitemtitle{display:block;margin-top:4px;margin-bottom:4px;text-align:left;width:100%}.path-mod-assign [data-region="grade-panel"] .mform .fitem
.felement{margin-left:0;width:100%;float:left;padding-left:0;padding-right:0}.path-mod-assign [data-region="grade-panel"] .mform .fitem .fstatic:empty{display:none}.path-mod-assign [data-region="grade-panel"] .mform .fitem .fcheckbox > span,
.path-mod-assign [data-region="grade-panel"] .mform .fitem .fradio > span,
.path-mod-assign [data-region="grade-panel"] .mform .fitem .fgroup>span{margin-top:4px}.path-mod-assign [data-region="grade-panel"] .mform .femptylabel
.fitemtitle{display:inline-block;width:auto;margin-right:8px}.path-mod-assign [data-region="grade-panel"] .mform .femptylabel
.felement{display:inline-block;margin-top:4px;padding-top:5px;width:auto}.path-mod-assign [data-region="grade-panel"] .mform .fitem_fcheckbox .fitemtitle,
.path-mod-assign [data-region="grade-panel"] .mform .fitem_fcheckbox
.felement{display:inline-block;width:auto}.path-mod-assign [data-region="grade-panel"] .mform .fitem_fcheckbox
.felement{padding:6px}.dir-rtl.path-mod-assign [data-region="grade-panel"] .mform .femptylabel
.fitemtitle{margin-right:0px;margin-left:8px}.dir-rtl.path-mod-assign [data-region="grade-panel"] .mform .fitem
.fitemtitle{text-align:right}.dir-rtl.path-mod-assign [data-region="grade-panel"] .mform .fitem
.felement{margin-right:0;float:right;padding-right:0;padding-left:0}.dir-rtl.path-mod-assign [data-region="grade-panel"] .mform .fitem_checkbox
.felement{float:right}.path-mod-assign #page,
.path-mod-assign #page-content{position:inherit}.path-mod-book .navtop img.icon,
.path-mod-book .navbottom
img.icon{margin-right:4px;margin-left:4px;border:0;padding:0}.path-mod-book .navbottom,
.path-mod-book
.navtop{text-align:right}.dir-rtl.path-mod-book .navbottom,
.dir-rtl.path-mod-book
.navtop{text-align:left}.path-mod-book
.navtop{margin-bottom:0.5em}.path-mod-book
.navbottom{margin-top:0.5em}.path-mod-book .block_book_toc
ul{margin:0
0 0 5px;padding-left:0;padding-right:0}.dir-rtl.path-mod-book .block_book_toc
ul{margin:0
5px 0 0}.path-mod-book .block_book_toc
li{clear:both;list-style:none;margin-top: .5em}.path-mod-book .block_book_toc li
li{list-style:none}.path-mod-book .block_book_toc .action-list{float:right}.dir-rtl.path-mod-book .block_book_toc .action-list{float:left}.path-mod-book .block_book_toc .action-list
img.smallicon{margin:0
3px}.path-mod-book .book_toc_none ul ul,
.dir-rtl.path-mod-book .book_toc_none ul
ul{margin-left:0;margin-right:0}.path-mod-book .book_toc_bullets ul
ul{margin-left:20px}.dir-rtl.path-mod-book .book_toc_bullets ul
ul{margin-left:0;margin-right:20px}.path-mod-book .book_toc_bullets li
li{list-style:circle}.path-mod-book .book_toc_bullets li li:before{display:none}.path-mod-book .book_toc_indented
ul{margin-left:5px}.dir-rtl.path-mod-book .book_toc_indented
ul{margin-left:0;margin-right:5px}.path-mod-book .book_toc_indented ul
ul{margin-left:15px}.dir-rtl.path-mod-book .book_toc_indented ul
ul{margin-left:0;margin-right:15px}.path-mod-book .book_toc_indented li
li{list-style:none}.navtop.navtext .chaptername,
.navbottom.navtext
.chaptername{font-weight:bolder}.navtop.navtext a,
.navbottom.navtext
a{display:inline-block;max-width:45%}.navtop.navtext a.bookprev,
.navbottom.navtext
a.bookprev{float:left;text-align:left}.dir-rtl .navtop.navtext a.bookprev,
.dir-rtl .navbottom.navtext
a.bookprev{float:right;text-align:right}@media (max-width: 480px){.path-mod-book .navbottom,
.path-mod-book .navtop,
.dir-rtl.path-mod-book .navbottom,
.dir-rtl.path-mod-book
.navtop{text-align:center}.navtop.navtext a,
.navbottom.navtext
a{display:block;max-width:100%;margin:auto}.navtop.navtext a.bookprev,
.navbottom.navtext a.bookprev,
.dir-rtl .navtop.navtext a.bookprev,
.dir-rtl .navbottom.navtext
a.bookprev{float:none}}.path-mod-chat .chat-event .picture,
.path-mod-chat .chat-message
.picture{width:40px}.path-mod-chat .chat-event
.text{text-align:left}.path-mod-chat #messages-list,
.path-mod-chat #users-list{list-style-type:none;padding:0;margin:0}.path-mod-chat #chat-header{overflow:hidden}.path-mod-chat #chat-input-area table.generaltable
td.cell{padding:1px}@media all and (max-device-width: 320px){.path-mod-chat #input-message{width:150px}}@media all and (min-device-width: 321px) and (max-device-width: 640px){.path-mod-chat #input-message{width:175px}}#page-mod-chat-view .chatcurrentusers
.chatuserdetails{vertical-align:middle}#page-mod-chat-gui_basic #participants
ul{margin:0;padding:0;list-style-type:none}#page-mod-chat-gui_basic #participants ul
li{list-style-type:none;display:inline;margin-right:10px}#page-mod-chat-gui_basic #participants ul li
.userinfo{display:inline}#page-mod-chat-gui_basic
#messages{padding:0;margin:0}#page-mod-chat-gui_basic #messages
dl{padding:0;margin:6px
0}#page-mod-chat-gui_basic #messages
dt{margin-left:0;margin-right:5px;padding:0;display:inline}#page-mod-chat-gui_basic #messages
dd{padding:0;margin:0}#page-mod-chat-gui_header_js-jsupdate .chat-event,
#page-mod-chat-gui_header_js-jsupdate .chat-message{width:100%}.path-mod-chat .yui-layout-unit-top{background:#FFE39D}.path-mod-chat .yui-layout-unit-right{background:#FFD46B}.path-mod-chat .yui-layout-unit-bottom{background:#FFCB44}.path-mod-chat .yui-layout .yui-layout-hd{border:0}.path-mod-chat .yui-layout .yui-layout-unit div.yui-layout-bd{border:0;background:transparent}.path-mod-chat .yui-layout .yui-layout-unit div.yui-layout-unit-right{background:white}.path-mod-choice
.results{border-collapse:separate}.path-mod-choice .results
.data{vertical-align:top;white-space:nowrap}.path-mod-choice
.button{text-align:center}.path-mod-choice
.attemptcell{width:5px;white-space:nowrap}.path-mod-choice .anonymous,
.path-mod-choice
.names{margin-left:auto;margin-right:auto;width:80%}.path-mod-choice
.downloadreport{border-width:0;margin-left:10%}.path-mod-choice
.choiceresponse{width:100%}.path-mod-choice .choiceresponse
.picture{width:10px;white-space:nowrap}.path-mod-choice .choiceresponse
.fullname{width:100%;white-space:nowrap}.path-mod-choice
.responseheader{width:100%;text-align:center;margin-top:10px}.path-mod-choice .choices .option
label{vertical-align:top}.path-mod-choice .choices .option
input{vertical-align:middle}.path-mod-choice .horizontal,
.path-mod-choice
.vertical{margin-left:10%;margin-right:10%}.path-mod-choice .horizontal .choices
.option{padding-right:20px;display:inline-block;white-space:normal}.path-mod-choice .horizontal .choices
.button{margin-top:10px}.path-mod-choice ul.choices
li{list-style:none}.path-mod-choice
.results{text-align:center}.path-mod-choice .results.anonymous
.graph.horizontal{vertical-align:middle;text-align:left;width:70%}.path-mod-choice .results.anonymous .graph.vertical,
.path-mod-choice
.cell{vertical-align:bottom;text-align:center}.path-mod-choice .results.anonymous
th.header{border:1px
solid inherit}.path-mod-choice .results.names
.header{width:10%;white-space:normal}.path-mod-choice .results.names
.cell{vertical-align:top;text-align:left}.path-mod-choice .results.names .user,
.path-mod-choice
#yourselection{padding:5px}.path-mod-choice .results.names .user .attemptaction,
.path-mod-choice .results.names .user .image,
.path-mod-choice .results.names .user
.fullname{float:left}.path-mod-choice .results.names .user
.fullname{padding-left:5px}.path-mod-choice .results
.data.header{width:10%}.path-mod-choice
.responseaction{text-align:center}.path-mod-choice .results
.option{white-space:normal}.path-mod-choice
.response{overflow:auto}.path-mod-choice .results .option,
.path-mod-choice .results .numberofuser,
.path-mod-choice .results
.percentage{font-weight:bold;font-size:108%}#page-mod-choice-report .downloadreport ul
li{list-style:none;padding:0
20px;display:inline;float:left}.path-mod-choice
.clearfloat{float:none;clear:both}.path-mod-choice.dir-rtl .horizontal .choices
.option{padding-right:0px;padding-left:20px;float:right}.path-mod-choice.dir-rtl .results.anonymous
.graph.horizontal{text-align:right}.path-mod-choice.dir-rtl
.results.anonymous{text-align:center}.path-mod-choice.dir-rtl .results.names
.cell{text-align:right}.path-mod-choice.dir-rtl .results.names .user .attemptaction,
.path-mod-choice.dir-rtl .results.names .user .image,
.path-mod-choice.dir-rtl .results.names .user .fullname,
.path-mod-choice.dir-rtl .results.names .user
.fullname{padding-left:0px;padding-right:5px}.path-mod-choice.dir-rtl
.downloadreport{margin-left:0;margin-right:25%}#page-mod-choice-report.dir-rtl .downloadreport ul
li{float:right}#page-mod-choice-view.dir-rtl
.reportlink{text-align:left}#page-mod-customcert-edit
.deletebutton{text-align:right}#page-mod-customcert-edit
#id_replace{margin-left:10px}#page-mod-customcert-report
.centre{margin-left:auto;margin-right:auto}#page-mod-customcert-rearrange .savepositionsbtn,
#page-mod-customcert-rearrange .applypositionsbtn,
#page-mod-customcert-rearrange
.cancelbtn{float:left}#page-mod-customcert-rearrange
.element{display:inline-block;position:absolute;word-wrap:break-word}#page-mod-customcert-rearrange .element:before{background-image:url(/academy/theme/image.php?theme=lambda&component=mod_customcert&rev=1533780117&image=target);background-repeat:no-repeat;content:"";display:block;float:left;height:9px;width:100%}#page-mod-customcert-rearrange .element:hover{cursor:move}#page-mod-customcert-rearrange .element.refpoint-left:before{background-position:left top;margin:-4px -5px -5px -4px}#page-mod-customcert-rearrange .element.refpoint-center:before{background-position:center top;margin:-4px 0 -5px 0}#page-mod-customcert-rearrange .element.refpoint-right:before{background-position:right top;margin:-4px -5px -5px 4px}#page-mod-customcert-rearrange
#pdf{border-style:solid;border-width:1px;clear:both}#page-mod-customcert-rearrange
div#leftmargin{border-left:1px dotted black}#page-mod-customcert-rearrange
div#rightmargin{border-right:1px dotted black}.moodle-dialogue #editelementform
fieldset.hidden{display:block}.path-mod-data .fieldadd,
.path-mod-data .sortdefault,
.path-mod-data .defaulttemplate,
#page-mod-data-view .datapreferences,
#page-mod-data-preset
.presetmapping{text-align:center}.path-mod-data-field .c0,
#page-mod-data-view #sortsearch
.c0{text-align:right}#page-mod-data-view .approve
img.icon{width:34px;height:34px}#page-mod-data-view
img.list_picture{border:0px}#page-mod-data-view
div.search_none{display:none}#page-mod-data-view div.search_inline,
#page-mod-data-view
form#latlongfieldbrowse{display:inline}#page-mod-data-view
div#data_adv_form{margin-left:auto;margin-right:auto}#page-mod-data-edit
.basefieldinput{width:300px}#page-mod-data-preset .presetmapping
table{text-align:left;margin-left:auto;margin-right:auto}#page-mod-data-preset
.overwritesettings{margin-bottom:1em}#page-mod-data-preset
table.presets{margin-left:auto;margin-right:auto}#page-mod-data-view .datapreferences
label{display:inline-block}.path-mod-data-field .fieldadd,
.path-mod-data-field
.sortdefault{margin:1em
0}.path-mod-data-field .fieldadd select,
.path-mod-data-field .sortdefault
select{margin-left:1em}.path-mod-data-field .fieldname,
.path-mod-data-field
.fielddescription{width:300px}.path-mod-data-field
textarea.optionstextarea{width:300px;height:150px}.path-mod-data-field
input.textareafieldsize{width:50px}.path-mod-data-field
input.picturefieldsize{width:70px}.path-mod-data .action-icon img.portfolio-add-icon{margin-left:0}#page-mod-data-export #notice
span{padding:0
10px}#page-mod-data-edit input[id*="url"]{text-align:left;direction:ltr}.mod-data-default-template
td{vertical-align:top}.mod-data-default-template .template-field{text-align:right}.mod-data-default-template .template-token{text-align:left}.mod-data-default-template
.controls{text-align:center}.mod-data-default-template
searchcontrols{text-align:right}.mod-data-default-template.notapproved{background-color:#FCC}#page-mod-data-templates td.save_template,
#page-mod-data-templates
.template_heading{text-align:center}#page-mod-data-templates
#availabletags_wrapper{max-width:250px}.dir-rtl .mod-data-default-template .template-field{text-align:left}.dir-rtl .mod-data-default-template .template-token{text-align:right}.dir-rtl .mod-data-default-template
searchcontrols{text-align:left}#page-mod-data-edit
.req{cursor:help}#page-mod-data-edit .inline-req
.req{position:absolute}#page-mod-data-edit .inline-req{text-align:left}#page-mod-data-edit .mod-data-input{margin-left:10px}.dir-rtl#page-mod-data-edit .inline-req{text-align:right}.dir-rtl#page-mod-data-edit .mod-data-input{margin-left:0px;margin-right:10px}.path-mod-feedback
span.feedback_info{font-weight:bold}.path-mod-feedback
div.feedback_is_dependent{background:#DDD}.path-mod-feedback
span.feedback_depend{color:#f00}.path-mod-feedback
hr.feedback_pagebreak{height:4px;color:#aaa;background-color:#aaa;border:0;margin:0}.path-mod-feedback
.drag_target_active{opacity: .25}.path-mod-feedback
.drag_item_active{opacity: .5}.path-mod-feedback
.feedback_bar_image{height:10px}.path-mod-feedback #analysis-form
label{display:inline}.path-mod-feedback .mform.feedback_form .fitem
.fitemtitle{display:block;margin-top:4px;margin-bottom:4px;text-align:left;width:100%}.path-mod-feedback .mform.feedback_form .fitem
.felement{margin-left:0;width:100%;float:left;padding-left:0;padding-right:0}.path-mod-feedback .mform.feedback_form .fitem .fstatic:empty{display:none}.path-mod-feedback .mform.feedback_form .fitem .fcheckbox > span,
.path-mod-feedback .mform.feedback_form .fitem .fradio > span,
.path-mod-feedback .mform.feedback_form .fitem .fgroup>span{margin-top:4px}body.path-mod-feedback #region-main .mform.feedback_form .femptylabel
.fitemtitle{display:inline-block;width:auto;margin-right:0}.path-mod-feedback .mform.feedback_form .femptylabel
.felement{display:inline-block;margin-top:4px;padding-top:5px;width:auto}body.path-mod-feedback #region-main .mform.feedback_form .feedback-item-pagebreak
.felement{width:100%}.path-mod-feedback .mform.feedback_form .fitem_fcheckbox .fitemtitle,
.path-mod-feedback .mform.feedback_form .fitem_fcheckbox
.felement{display:inline-block;width:auto}.path-mod-feedback .mform.feedback_form .fitem_fcheckbox
.felement{padding:6px}body.dir-rtl.path-mod-feedback #region-main .mform.feedback_form .femptylabel
.fitemtitle{margin-right:0px;margin-left:0}.dir-rtl.path-mod-feedback .mform.feedback_form .fitem
.fitemtitle{text-align:right}.dir-rtl.path-mod-feedback .mform.feedback_form .fitem
.felement{margin-right:0;float:right;padding-right:0;padding-left:0}.dir-rtl.path-mod-feedback .mform.feedback_form .fitem_fcheckbox
.felement{float:right}.path-mod-feedback .mform.feedback_form#feedback_viewresponse_form .fitem.feedback_hasvalue:not(.feedback-item-captcha) .felement{background:#FBFBF1;min-height:1em;box-sizing:border-box;padding:3px;border:1px
solid #ddd}.path-mod-feedback .mform.feedback_form .fitem.feedback_hasvalue .fstatic:empty{display:inherit}.path-mod-feedback .mform.feedback_form#feedback_edit_form .fitem:hover{background:#f5f5f5}.path-mod-feedback .mform.feedback_form#feedback_edit_form .fitem .fitemtitle
label{width:100%}.path-mod-feedback .mform.feedback_form#feedback_edit_form .fitem .fitemtitle
.itemtitle{position:relative;width:100%}.path-mod-feedback .mform.feedback_form#feedback_edit_form .fitem .fitemtitle .itemtitle .itemdd,
.path-mod-feedback .mform.feedback_form#feedback_edit_form .fitem .fitemtitle .itemtitle
.itemname{float:left}.path-mod-feedback .mform.feedback_form#feedback_edit_form .fitem .fitemtitle .itemtitle
.itemactions{float:right}.path-mod-feedback .templateslist td.cell.action,
.path-mod-feedback .templateslist
th.header.action{width:10%}.path-mod-feedback
table.analysis{width:100%;border-top:1px solid #aaa;margin-top:10px}.path-mod-feedback table.analysis tr:first-child
th{padding-top:10px}.path-mod-feedback table.analysis tr:hover{background:#f5f5f5}.path-mod-feedback table.analysis td.singlevalue:before,
.path-mod-feedback table.analysis td.optionname:before{content:'- '}.path-mod-feedback table.analysis.itemtype_textarea
td{padding:4px
0}.path-mod-feedback table.analysis
tr.isempty{display:none}.path-mod-feedback #showentrytable td.cell.completed_timemodified,
.path-mod-feedback #showentryanontable
td.cell.random_response{font-weight:bold}.path-mod-feedback #showentrytable td.cell.userpic,
.path-mod-feedback #showentrytable td.cell.deleteentry,
.path-mod-feedback #showentryanontable
td.cell.deleteentry{width:10px}.path-mod-feedback
.response_navigation{margin: .5em 0}.path-mod-feedback .response_navigation
a{display:inline-block}.path-mod-feedback .response_navigation
a.back_to_list{margin:auto;float:right;left:-50%;position:relative}.dir-rtl.path-mod-feedback .response_navigation .next_response:after,
.path-mod-feedback .response_navigation .prev_response:before{content:' ◄ '}.dir-rtl.path-mod-feedback .response_navigation .prev_response:before,
.path-mod-feedback .response_navigation .next_response:after{content:' ► '}.dir-rtl.path-mod-feedback .response_navigation .prev_response,
.path-mod-feedback .response_navigation
.next_response{float:right}.dir-rtl.path-mod-feedback .response_navigation .next_response,
.path-mod-feedback .response_navigation
.prev_response{float:left}.forumpost{display:block;position:relative;margin:0
0 1em 0;padding:0;border:1px
solid #000;max-width:100%}.forumpost
.row{width:100%;position:relative}.forumpost .row
.left{float:left;width:43px;overflow:hidden}.forumpost .row .left .grouppictures
a{text-align:center;display:block;margin:6px
2px 0 2px}.forumpost .row .left
.grouppicture{width:20px;height:20px}.forumpost .row .topic,
.forumpost .row .content-mask,
.forumpost .row
.options{margin-left:43px}.forumpost .picture
img{margin:4px}.forumpost .options .commands,
.forumpost .content .attachments,
.forumpost .options .footer,
.forumpost .options
.link{text-align:right}.forumpost .options .forum-post-rating{float:left}.forumpost .content
.posting{overflow:auto;max-width:100%}.forumpost .content .attachedimages
img{max-width:100%}.forumpost .post-word-count{font-size: .85em;font-style:italic}.forumpost .shortenedpost .post-word-count{display:inline;padding:0
.3em}.dir-rtl .forumpost .row .topic,
.dir-rtl .forumpost .row .content-mask,
.dir-rtl .forumpost .row
.options{margin-right:43px;margin-left:0}.dir-rtl .forumpost .row
.left{float:right}.dir-rtl.path-mod-forum
.indent{margin-right:3%;margin-left:0}.path-mod-forum .forumolddiscuss,
#page-mod-forum-search
.c0{text-align:right}.path-mod-forum
.indent{margin-left:3%}.path-mod-forum
.forumheaderlist{width:100%;border-width:1px;border-style:solid;border-collapse:separate;margin-top:10px}.path-mod-forum .forumheaderlist
td{border-width:1px 0px 0px 1px;border-style:solid}.path-mod-forum .forumheaderlist th.header.replies
.iconsmall{margin:0
.3em}.path-mod-forum .forumheaderlist
.picture{width:35px}.path-mod-forum .forumheaderlist .discussion
.starter{vertical-align:middle}.path-mod-forum .forumheaderlist .discussion .pinned
img{padding:5px}.path-mod-forum .forumheaderlist .discussion
.lastpost{white-space:nowrap;text-align:right}.path-mod-forum .forumheaderlist .replies,
.path-mod-forum .forumheaderlist .discussion
.author{white-space:nowrap}.path-mod-forum .forumheaderlist thead
.discussionsubscription{text-align:center}#page-mod-forum-subscribers .subscriberdiv,
#page-mod-forum-subscribers
.subscribertable{width:100%;vertical-align:top}#page-mod-forum-subscribers .subscribertable tr
td{vertical-align:top}#page-mod-forum-subscribers .subscribertable tr
td.actions{width:16%;padding-top:3em}#page-mod-forum-subscribers .subscribertable tr td.actions
.actionbutton{margin:0.3em 0;padding:0.5em 0;width:100%}#page-mod-forum-subscribers .subscribertable tr td.existing,
#page-mod-forum-subscribers .subscribertable tr
td.potential{width:42%}#page-mod-forum-discuss
.discussioncontrols{width:100%;margin:5px}#page-mod-forum-discuss .discussioncontrols
.controlscontainer{width:100%;float:right}#page-mod-forum-discuss .discussioncontrols
.discussioncontrol{float:left}#page-mod-forum-discuss
.discussioncontrol.exporttoportfolio{text-align:left}#page-mod-forum-discuss
.discussioncontrol.displaymode{padding-right:10px}#page-mod-forum-discuss
.discussioncontrol.movediscussion{padding-right:10px}#page-mod-forum-discuss .discussioncontrol.movediscussion
.movediscussionoption{}#page-mod-forum-view
.forumaddnew{margin-bottom:20px}#page-mod-forum-view
.groupmenu{float:left;text-align:left;white-space:nowrap}#page-mod-forum-index .subscription,
#page-mod-forum-view
.subscription{float:right;text-align:right;white-space:nowrap;margin:5px
0}#page-mod-forum-search
.introcontent{padding:15px;font-weight:bold}#page-mod-forum-index .unread a:first-child,
#page-mod-forum-view .unread a:first-child{padding-right:10px}#page-mod-forum-index .unread img,
#page-mod-forum-view .unread
img{margin-left:5px}#page-mod-forum-view .unread
img{margin-left:5px}.dir-rtl#page-mod-forum-view .unread
img{margin-right:5px;margin-left:0}#email
.unsubscribelink{margin-top:20px}#page-mod-forum-view .unread,
.forumpost.unread .row.header,
.path-course-view .unread,span.unread{background-color:#FFD}.forumpost.unread
.row.header{border-bottom:1px solid #DDD}.path-mod-forum :target~.forumpost:before{display:block;content:'';width:4px;position:absolute;background:#0070a8;left:-1px;top:-1px;bottom:-1px}.path-mod-forum .discussion-nav{margin: .5em 0}.path-mod-forum .discussion-nav
ul{margin:0;list-style:none}.dir-rtl.path-mod-forum .discussion-nav .next-discussion:after,
.path-mod-forum .discussion-nav .prev-discussion:before{content:' ◄ '}.dir-rtl.path-mod-forum .discussion-nav .prev-discussion:before,
.path-mod-forum .discussion-nav .next-discussion:after{content:' ► '}.dir-rtl.path-mod-forum .discussion-nav .prev-discussion,
.path-mod-forum .discussion-nav .next-discussion{float:right}.dir-rtl.path-mod-forum .discussion-nav .next-discussion,
.path-mod-forum .discussion-nav .prev-discussion{float:left}.path-mod-forum .preload-subscribe{background:url(/academy/theme/image.php?theme=lambda&component=mod_forum&rev=1533780117&image=t%2Fsubscribed) no-repeat -9999px -9999px}.path-mod-forum .preload-unsubscribe{background:url(/academy/theme/image.php?theme=lambda&component=mod_forum&rev=1533780117&image=t%2Funsubscribed) no-repeat -9999px -9999px}.path-mod-forum
.discussionsubscription{margin-top:-10px;text-align:right;margin-bottom:10px}.path-mod-forum .discussionsubscription>a>img{width:12px;padding:0
4px}.dir-rtl .path-mod-forum
.discussionsubscription{text-align:left}#page-mod-forum-view
img.timedpost{margin-right:5px}.dir-rtl#page-mod-forum-view
img.timedpost{margin:3px
0 0 5px;float:right}.path-mod-glossary
.glossarypost{width:95%;border-collapse:separate;margin:0px
auto;text-align:left}.path-mod-glossary
.glossarypost.entrylist{border-width:0px}.path-mod-glossary .glossarypost.continuous
.concept{display:inline}.path-mod-glossary .glossarypost
.commands{width:200px;white-space:nowrap}.path-mod-glossary .glossarypost
td.picture{width:35px}.path-mod-glossary .glossarypost .entrylowersection
.aliases{text-align:center}.path-mod-glossary .glossarypost .entrylowersection
.icons{text-align:right;padding-right:5px}.path-mod-glossary .glossarypost .entrylowersection
.ratings{text-align:right;padding-right:5px;padding-bottom:2px}.path-mod-glossary .glossarypost .glossary-hidden-note{margin:0
.45em}.path-mod-glossary
.glossarydisplay{margin-left:auto;margin-right:auto}.path-mod-glossary .glossarydisplay
.tabs{width:100%;margin-bottom:0px}.path-mod-glossary .glossarydisplay .tabs
.side{border-style:none;border-width:0px;width:auto}.path-mod-glossary .glossarydisplay
.separator{width:4px}.path-mod-glossary
table.glossarypopup{width:95%}.path-mod-glossary .entrybox, .path-mod-glossary table.glossaryapproval,
.path-mod-glossary .glossarypost .entrylowersection
table{width:100%;margin-bottom:0em}.glossary-activity-picture{float:left}.glossary-activity-content{margin-left:40px}#page-mod-glossary-view
.glossarycontrol{float:right;text-align:right;white-space:nowrap;margin:5px
0}#page-mod-glossary-view table.glossarycategoryheader,
#page-mod-glossary-import
table.glossaryimportexport{margin-left:auto;margin-right:auto}#page-mod-glossary-view
table.glossarycategoryheader{margin-bottom:0em}#page-mod-glossary-view table.glossarycategoryheader
th{padding:0px}#page-mod-glossary-view td.glossarysearchbox
label{display:inline-block}#page-mod-glossary-showentry #page-content{min-width:600px}#page-mod-glossary-print .mod-glossary-entrylist .mod-glossary-entry{vertical-align:top}#page-mod-glossary-print .displayprinticon,
.path-mod-glossary.dir-rtl
.glossarypost{text-align:right}#page-mod-glossary-print
.displaydate{text-align:right;font-size:0.75em}#page-mod-glossary-print
.strong{font-weight:bold}.path-mod-glossary
.printicon{background:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fprint) no-repeat scroll 2px center transparent;padding-left:20px}body.path-course-view div.hotpotrecentactivity
p{margin:0px}body.path-course-view div.hotpotrecentactivity
ul{font-size:0.8em;margin:0em
0em 0em 1em;padding:0em
0em 0em 1em}#page-mod-hotpot-mod #reviewoptionshdr
.fitem{clear:none;float:left;margin-left:48px;width:20%}#page-mod-hotpot-mod #reviewoptionshdr
.fitemtitle{font-weight:bold;margin-left:0;text-align:left;width:100%}#page-mod-hotpot-mod #reviewoptionshdr
fieldset.fgroup{margin-left:0;text-align:left;width:100%}#page-mod-hotpot-mod #reviewoptionshdr
fieldset.fgroup{clear:left;margin:0
0 1em}#page-mod-hotpot-mod #reviewoptionshdr fieldset.fgroup>span{clear:left;float:left;line-height:1.7}#page-mod-hotpot-mod #reviewoptionshdr fieldset.fgroup span
label{margin-left:0.4em}#page-mod-hotpot-mod.dir-rtl #reviewoptionshdr
.fitem{float:right}#page-mod-hotpot-mod.dir-rtl #reviewoptionshdr
.fitemtitle{text-align:right}#page-mod-hotpot-mod.dir-rtl #reviewoptionshdr fieldset.fgroup
span{float:right;clear:right}#page-mod-hotpot-view .region-content{text-align:center}#page-mod-hotpot-view .region-content ul.hotpotwarnings,
#page-mod-hotpot-view .region-content table.hotpotentryoptions,
#page-mod-hotpot-view .region-content table.hotpotattempts,
#page-mod-hotpot-view .region-content table.hotpotattemptssummary,
#page-mod-hotpot-view .region-content
table.hotpotdeleteattempts{margin-left:auto;margin-right:auto}#page-mod-hotpot-view .region-content table.hotpotentryoptions
td.c0{font-weight:bold;text-align:right}#page-mod-hotpot-view .region-content table.hotpotentryoptions
td.c1{font-weight:normal;text-align:left}#page-mod-hotpot-attempt
div.hotpotstopbutton{position:absolute;right:0px;top:0.8em}#page-mod-hotpot-attempt div.hotpotstopbutton .FuncButton,
#page-mod-hotpot-attempt div.hotpotstopbutton .FuncButtonUp,
#page-mod-hotpot-attempt div.hotpotstopbutton
.FuncButtonDown{margin-right:18px}#page-mod-hotpot-attempt input,
#page-mod-hotpot-attempt
textarea{width:auto}#page-mod-hotpot-submit .region-content{text-align:center}#page-mod-hotpot-submit .region-content ul.hotpotexitfeedback,
#page-mod-hotpot-submit .region-content p.hotpotwhatnext,
#page-mod-hotpot-submit .region-content ul.hotpotexitfeedback
li{list-style-type:none}#page-mod-hotpot-submit .region-content
li.hotpotexitencouragement{font-size:1.2em;margin-top:6px;margin-bottom:6px}#page-mod-hotpot-submit .region-content
table.hotpotexitlinks{margin-left:auto;margin-right:auto}#page-mod-hotpot-submit .region-content table.hotpotexitlinks
td.c0{font-weight:bold;text-align:right}#page-mod-hotpot-submit .region-content table.hotpotexitlinks
td.c1{font-weight:normal;text-align:left}#page-mod-hotpot-index .region-content{text-align:center}#page-mod-hotpot-index .region-content
table{margin-left:auto;margin-right:auto}#page-mod-hotpot-report
div#commands{text-align:center}#page-mod-hotpot-report
table#attempts{clear:both;margin-left:auto;margin-right:auto}#page-mod-hotpot-report table#attempts.analysis
td.c0{font-weight:bold}#page-mod-hotpot-report table#attempts.analysis td.c0:after{content:":"}#page-mod-hotpot-report table.flexible
tr.emptyrow{display:none}#page-mod-hotpot-report #page-content{overflow:visible}#page-mod-hotpot-report #page-content #region-main-box #region-post-box #region-main-wrap #region-main{overflow:visible}#page-mod-hotpot-report #page-content #region-main-box #region-post-box #region-main-wrap #region-main div.region-content{overflow:visible}#page-mod-hotpot-report #page-content #region-main-box #region-post-box #region-main-wrap #region-main div.region-content #attemptsform div.no-overflow{overflow:visible}#page-mod-hotpot-report
ul.response{text-align:left;padding:0px;margin-top:0px;text-indent:-6px}#page-mod-hotpot-report ul.response
li{list-style:none;text-align:left}#page-mod-hotpot-report ul.response
li.correct{color:green;list-style-image:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=i%2Ftick_green_small)}#page-mod-hotpot-report ul.response
li.ignored{color:grey;list-style-image:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=i%2Fshow)}#page-mod-hotpot-report ul.response
li.wrong{color:red;list-style-image:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=i%2Fcross_red_small)}#page-mod-hotpot-report ul.response
li.score{color:inherit;list-style-image:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=i%2Fitem)}#page-mod-hotpot-report ul.response
li.hintsclueschecks{color:#666;list-style-image:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=i%2Fitem)}#page-mod-hotpot-review
table#responses{clear:both;margin-left:auto;margin-right:auto}#page-mod-hotpot-review table#responses td.c0,
#page-mod-hotpot-review table#responses td.c2,
#page-mod-hotpot-review table#responses td.c4,
#page-mod-hotpot-review table#responses
td.c6{font-weight:bold;text-align:right}#page-mod-hotpot-review table#responses td.c1,
#page-mod-hotpot-review table#responses td.c3,
#page-mod-hotpot-review table#responses td.c5,
#page-mod-hotpot-review table#responses
td.lastcol{font-weight:normal;text-align:left}#page-mod-hotpot-review table#responses td.c0:after,
#page-mod-hotpot-review table#responses td.c2:after,
#page-mod-hotpot-review table#responses td.c4:after,
#page-mod-hotpot-review table#responses td.c6:after{content:":"}#page-mod-hotpot-review table#responses td.lastcol:after{content:""}#page-mod-imscp-view
#imscp_nav{text-align:center;margin-bottom:5px;margin-top:10px}#page-mod-imscp-view #imscp_toc .ygtv-highlight1{font-weight:bold}#page-mod-imscp-view .yui-layout-hd{background-image:none;background-color:#DDD}#page-mod-imscp-view .yui-layout-hd
h2{color:black}.path-mod-imscp
#imscp_child_list{margin-left:1em;width:auto;height:auto}#page-mod-journal-view
.feedbackbox{width:75%;border-collapse:separate}#page-mod-journal-view
.entrycontent{padding:3px}#page-mod-journal-view
.picture{width:35px}#page-mod-journal-view
.info{margin-bottom:5px;text-align:right}#page-mod-journal-view .journalstart,
#page-mod-journal-report
.feedbacksave{text-align:center}#page-mod-journal-view .lastedit,
#page-mod-journal-view
.editend{font-size:0.7em;margin:5px;text-align:center}#page-mod-journal-view
.author{font-size:1em;font-weight:bold}#page-mod-journal-view
.time{font-size:0.7em;font-style:italic}#page-mod-journal-view
.grade{font-weight:bold;font-style:italic;text-align:right}#page-mod-journal-index
.cell{font-size:0.8em}#page-mod-journal-view .feedbackbox .left,
#page-mod-journal-view .feedbackbox
.entryheader{background-color:#ddd}#page-mod-journal-view
.feedbackbox{-moz-border-radius-bottomleft:15px;-moz-border-radius-bottomright:15px;border-spacing:0;margin:0
auto}#page-mod-journal-view .feedbackbox
.side{-moz-border-radius-bottomleft:15px}#page-mod-journal-view .feedbackbox
.entrycontent{-moz-border-radius-bottomright:15px}#page-mod-journal-report
.journaluserentry{border:1px
solid #000;border-collapse:collapse;border-spacing:0}#page-mod-journal-report .journaluserentry
td{padding:10px;vertical-align:top;width:100%}#page-mod-journal-report .journaluserentry
td.userpix{width:35px}#page-mod-journal-report .journaluserentry
td.userfullname{white-space:nowrap}#page-mod-journal-report .journaluserentry td
.lastedit{font-size:0.76em;margin-left:10px}.path-mod-lesson .contents,
.path-mod-lesson .standardtable,
.path-mod-lesson .mform .box.contents,
.path-mod-lesson .invisiblefieldset.fieldsetfix
tr{text-align:left}.path-mod-lesson #layout-table{width:100%}.path-mod-lesson .edit_buttons form,
.path-mod-lesson .edit_buttons
input{display:inline}.path-mod-lesson .userinfotable .cell,
.path-mod-lesson .userinfotable
.userpicture{vertical-align:middle}.path-mod-lesson
.invisiblefieldset.fieldsetfix{display:block}.path-mod-lesson
.slideshow{overflow:auto;padding:15px}.path-mod-lesson .menu
.menuwrapper{max-height:400px;overflow:auto;vertical-align:top;margin-bottom:10px}.path-mod-lesson .menu
ul{list-style:none;padding:5px
0px 0px 5px;margin:0px}.path-mod-lesson .menu ul
li{padding-bottom:5px}.path-mod-lesson
.skip{position:absolute;top:-1000em;width:20em}.path-mod-lesson .branchbuttoncontainer.horizontal div,
.path-mod-lesson .branchbuttoncontainer.horizontal
form{display:inline}.path-mod-lesson
.firstpageoptions{width:30%;margin-left:35%;margin-top:1em}.path-mod-lesson .progress_bar_table,
.path-mod-lesson .progress_bar_completed,
.path-mod-lesson
.progress_bar_todo{padding:0;margin:0}.path-mod-lesson
.progress_bar_token{height:20px;width:5px;padding:0;margin:0}.path-mod-lesson .edit_pages_box
.addlinks{margin:0;margin-bottom:1em}.path-mod-lesson
.progress_bar_completed{background-color:green;text-align:right;vertical-align:middle;color:#FFF}.path-mod-lesson
.resourcecontent{text-align:center}.path-mod-lesson .answeroption .fcheckbox>span{position:relative;float:left}.path-mod-lesson .answeroptiongroup .fgroup>span{position:relative;width:100%}.path-mod-lesson .answeroption .fcheckbox input,
.path-mod-lesson .answeroptiongroup
input{position:absolute;top:2px;margin-top:0px;left:0}.path-mod-lesson .answeroption .fcheckbox label,
.path-mod-lesson .mform .fitem.answeroptiongroup fieldset.fgroup
label{padding-left:20px;float:left}.path-mod-lesson .answeroption .felement label p:last-child,
.path-mod-lesson .answeroptiongroup .felement label p:last-child{margin-bottom:0px}.path-mod-lesson.dir-rtl .answeroption .fcheckbox>span{float:right}.path-mod-lesson.dir-rtl .answeroption .fcheckbox input,
.path-mod-lesson.dir-rtl .answeroptiongroup .fgroup
input{left:inherit;right:0}.path-mod-lesson.dir-rtl .answeroption .fcheckbox label,
.path-mod-lesson.dir-rtl .mform .fitem.answeroptiongroup fieldset.fgroup
label{padding-left:0;padding-right:20px;float:right}#page-mod-lesson-view .password-form
.submitbutton{display:inline}.path-mod-lesson
.reviewessay{width:40%;border:1px
solid #DDD;background-color:#EEE}.path-mod-lesson.dir-rtl .contents,
.path-mod-lesson.dir-rtl .standardtable,
.path-mod-lesson.dir-rtl .mform .box.contents,
.path-mod-lesson.dir-rtl .invisiblefieldset.fieldsetfix
tr{text-align:right}#lesson-timer{text-align:center}.path-mod-lesson
.essayungraded{background-color:#efcfcf}.path-mod-lesson
.essaygraded{background-color:#efefcf}.path-mod-lesson
.essaysent{background-color:#cfefcf}.lightbox-gallery .lightbox-gallery-image-container{display:inline-block;margin:10px}.dir-rtl .lightbox-gallery .lightbox-gallery-image-container{display:inline-block;margin:10px}.lightbox-gallery .lightbox-gallery-image-frame{background-color:#fff;display:inline-block;margin:10px
auto;text-align:center;width:174px;border:1px
solid #ccc;border-radius:5px;transition:box-shadow 150ms, border-color 150ms, background-color 150ms, color 150ms;-webkit-transition:box-shadow 150ms, border-color 150ms, background-color 150ms, color 150ms;color:#696969}.lightbox-gallery .lightbox-gallery-image-container .lightbox-gallery-image-frame:hover{transition:box-shadow 150ms, border-color 150ms;text-decoration:none;box-shadow:0 0 15px #ccc;-webkit-box-shadow:0 0 15px #ccc;border-color:#999;background-color:#f6f6f6;color:#333}.lightbox-gallery .lightbox-gallery-image-container .lightbox-gallery-image-frame:active{box-shadow:0 0 15px #666;-webkit-box-shadow:0 0 15px #666}.lightbox-gallery .lightbox-gallery-image-thumbnail{display:block;margin:5px
5px 2px;vertical-align:middle;width:95%;border:1px
solid #ccc;border-radius:5px}.lightbox-gallery .lightbox-gallery-image-caption,
.lightbox-gallery .lightbox-gallery-image-extinfo{font-family:'Verdana','Lucida Grande',sans-serif;font-size:11px;margin-bottom:3px;text-decoration:none}.lightbox-gallery .lightbox-gallery-image-caption{font-weight:bold;word-wrap:break-word}.lightbox-gallery .lightbox-gallery-image-caption.top{margin-bottom:-3px}#mod-lightboxgallery-view .generalbox,
#mod-lightboxgallery-search
.generalbox{overflow:auto}#mod-lightboxgallery-view .thumb,
#mod-lightboxgallery-search
.thumb{position:relative;z-index:5;border:1px
solid #ccc;background-color:#fff;text-align:center;margin:2px;padding:3px}#mod-lightboxgallery-view .thumb .image,
#mod-lightboxgallery-search .thumb
.image{position:relative;z-index:10;border:1px
solid #ccc;background-color:#000;height:105px;width:120px;margin-bottom:2px}#mod-lightboxgallery-view .thumb .overlay img,
#mod-lightboxgallery-search .thumb .overlay
img{border:0}#mod-lightboxgallery-view .lightbox-edit-select{margin:12px}#mod-lightboxgallery-imageedit .generaltable img,
#mod-lightboxgallery-imageadd .generaltable
img{border:1px
solid #ddd}#mod-lightboxgallery-imageedit
.menubar{margin-top:14px;text-align:center}#mod-lightboxgallery-imageedit .tag-head{border-bottom:1px solid #ddd;background-color:#f9fafa;display:block;padding:2px
0;margin:3px
1px}#mod-lightboxgallery-imageedit .tag-exists{color:#aaa;text-decoration:line-through}#mod-lightboxgallery-imageedit .tag-exists
input{display:none}#mod-lightboxgallery-imageadd
#messages{margin:0
6px 0 12px;padding:0}#mod-lightboxgallery-search
.generalbox{margin-bottom:10px}#page-mod-lightboxgallery-view
#overlay{z-index:4032}#page-mod-lightboxgallery-view
#lightbox{z-index:4033}#page-mod-lightboxgallery-view #imageData
#bottomNavDownload{float:right;width:104px;height:22px;background:url(/academy/theme/image.php?theme=lambda&component=lightboxgallery&rev=1533780117&image=download) no-repeat;padding-bottom:0.7em;padding-right:0.5em;margin-right: .5em;outline:none}#page-mod-lightboxgallery-view #imageData
#imageDetails{width:65%}#page-mod-lightboxgallery-view #outerImageContainer,
#page-mod-lightboxgallery-view
#imageDataContainer{min-width:200px}.path-mod-lti
.ltiframe{position:relative;width:100%;height:100%}.path-mod-lti .userpicture,
.path-mod-lti .picture.user,
.path-mod-lti
.picture.teacher{width:35px;height:35px;vertical-align:top}.path-mod-lti .feedback .files,
.path-mod-lti .feedback .grade,
.path-mod-lti .feedback .outcome,
.path-mod-lti .feedback
.finalgrade{float:right}.path-mod-lti .feedback
.disabledfeedback{width:500px;height:250px}.path-mod-lti .feedback
.from{float:left}.path-mod-lti .files
img{margin-right:4px}.path-mod-lti .files
a{white-space:nowrap}.path-mod-lti
.late{color:red}.path-mod-lti
.message{text-align:center}.path-admin-mod-lti .mform .fitem
.fitemtitle{min-width:18em;padding-right:1em}.path-mod-lti .mform .fitem
.fitemtitle{min-width:14em;padding-right:1em}#page-mod-lti-instructor_edit_tool_type .mform .fitem
.fitemtitle{min-width:18em;padding-right:1em}#registration-choice-container .buffer-text{margin:20px}#choice-list{list-style:none;border-bottom:1px solid #e3e3e3;padding-bottom:1em;margin-left:0}#choice-list>li{display:inline-block}#external-registration-container
iframe{border:1px
solid #e5e5e5;border-radius:10px;width:100%;min-height:800px}.loading-screen{text-align:center;padding:3em}.loading-screen .loading-text{font-size:2em}.loading-screen
.loader{margin-left:auto;margin-right:auto;margin-bottom:1em;height:2em;width:2em;font-size:2em}#registration-submit{min-width:140px}#registration-form-container{min-height:260px}#registration-form-container
.well{margin-bottom:0}#registration-form-container .control-group:last-child{margin-bottom:0}#registration-choice-container
.well{text-align:center}#registration-choice-container .btn-toolbar{margin-bottom:0}#registration-choice-container p:last-child{margin-top:20px}#tool-type-capabilities-container .registration-loading-container{display:none}#tool-type-capabilities-container.loading .registration-loading-container{display:block}#tool-type-capabilities-container.loading #tool-type-capabilities-template-container{display:none}.centered-menu{max-width:70%;margin-left:auto;margin-right:auto}.btn-text{display:block}.btn-loader{display:none}.loading .btn-text{display:none}.loading .btn-loader{display:block}.btn
.loader{margin-left:auto;margin-right:auto}.btn .loader
img{height:1.5em}#tool-list-container
h3{display:inline-block}#tool-list-loader-container{display:inline-block}#tool-list-loader-container
.loader{display:none}#tool-list-loader-container .loader
img{height:2em}.loading #tool-list-loader-container
.loader{display:block}.loading #tool-notools-text{display:none}.tool-card{display:inline-block;width:250px;height:300px;border:1px
solid #e5e5e5;border-radius:10px;margin:5px;position:relative;box-sizing:border-box;vertical-align:top}.tool-card:hover,.tool-card:focus{border-color:#08c;box-shadow:0 1px 4px rgba(0, 105, 214, 0.25);-webkit-transition:border linear 0.2s, box-shadow linear 0.2s;-moz-transition:border linear 0.2s, box-shadow linear 0.2s;-o-transition:border linear 0.2s, box-shadow linear 0.2s;transition:border linear 0.2s, box-shadow linear 0.2s}.tool-card .overlay-container{background-color:rgba(255, 255, 255, 0.8);border-radius:10px;display:none;height:100%;left:0;position:absolute;text-align:center;top:0;width:100%;z-index:100;box-sizing:border-box;padding:10px}.tool-card .overlay-container .img-container{position:absolute;top:115px;left:90px;display:block;width:70px;height:70px}.tool-card .overlay-container .img-container
img{height:100%;width:100%}.tool-card.announcement>.overlay-container{display:block}.tool-card.announcement .overlay-container
.loader{display:none}.tool-card.announcement.loading .overlay-container
.loader{display:block;width:100%;height:100%}.tool-card.announcement .overlay-container .success-icon-container{display:none}.tool-card.announcement.success .overlay-container .success-icon-container{display:block}.tool-card.announcement .overlay-container .fail-icon-container{display:none}.tool-card.announcement.fail .overlay-container .fail-icon-container{display:block}.tool-card.announcement .overlay-container .capabilities-container{display:none}.tool-card.announcement.capabilities .overlay-container .capabilities-container{display:block}.tool-card.announcement.capabilities .overlay-container{background-color:rgb(255, 255, 255)}.tool-card.announcement.capabilities .overlay-container .img-container{display:none}.tool-card-content{z-index:1}.tool-card-header{text-align:center;background-color:#f5f5f5;padding:10px;border-top-left-radius:10px;border-top-right-radius:10px;box-sizing:border-box;height:125px}.tool-card-subheader{margin-bottom:10px;text-align:left}.dir-rtl .tool-card-subheader{text-align:right}.tool-card-header .tool-card-icon{width:35px;height:35px}.tool-card-header
.name{margin-bottom:0;white-space:nowrap}.tool-card-header .tool-card-actions{float:right}.dir-rtl .tool-card-header .tool-card-actions{float:left}.tool-card-header .tool-card-actions
img{width:15px;height:15px;margin-left:7px}.dir-rtl .tool-card-header .tool-card-actions
img{margin-left:0px;margin-right:7px}.tool-card-body{border-top:1px solid #e5e5e5;box-sizing:border-box;padding:5px;height:125px}.tool-card-body
.description{max-height:100px;word-wrap:break-word}.tool-card-footer{height:50px;text-align:center;padding-top:10px;box-sizing:border-box}.tool-card .contenteditable-container{position:relative}.tool-card [contenteditable=true]{border:1px
solid transparent;padding:0.25em;position:relative;z-index:1;overflow:auto}.tool-card [contenteditable=true]:hover{border-radius:4px;box-shadow:inset 0 1px 1px rgba(0, 0, 0, 0.075);background-color:#fff;border:1px
solid #e3e3e3;-webkit-transition:border linear 0.2s, box-shadow linear 0.2s;-moz-transition:border linear 0.2s, box-shadow linear 0.2s;-o-transition:border linear 0.2s, box-shadow linear 0.2s;transition:border linear 0.2s, box-shadow linear 0.2s;cursor:text}.tool-card [contenteditable=true]:focus{outline:0;border-radius:4px;box-shadow:inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px rgba(82, 168, 236, 0.6);background-color:#fff;border:1px
solid rgba(82, 168, 236, 0.8);-webkit-transition:border linear 0.2s, box-shadow linear 0.2s;-moz-transition:border linear 0.2s, box-shadow linear 0.2s;-o-transition:border linear 0.2s, box-shadow linear 0.2s;transition:border linear 0.2s, box-shadow linear 0.2s;cursor:text}.tool-card [contenteditable=true].loading+.overlay-container{border-radius:4px;display:block}.tool-card [contenteditable=true] + .overlay-container
.loader{display:inline-block;vertical-align:middle}#contentframe{border:1px
solid #ddd;border-radius:4px}.path-mod-quiz
.statedetails{display:block;font-size:0.7em}#page-mod-quiz-attempt #page .controls,
#page-mod-quiz-summary #page .controls,
#page-mod-quiz-review #page
.controls{text-align:center;margin:8px
auto}#page-mod-quiz-attempt .submitbtns,
#page-mod-quiz-review
.submitbtns{clear:left;text-align:left;padding-top:1.5em}#page-mod-quiz-attempt.dir-rtl .submitbtns,
#page-mod-quiz-review.dir-rtl
.submitbtns{text-align:right}#page-mod-quiz-attempt .submitbtns .mod_quiz-next-nav,
#page-mod-quiz-review .submitbtns .mod_quiz-next-nav{float:right}#page-mod-quiz-attempt.dir-rtl .submitbtns .mod_quiz-next-nav,
#page-mod-quiz-review.dir-rtl .submitbtns .mod_quiz-next-nav{float:left}.path-mod-quiz .mod_quiz-redo_question_button{margin:0}.path-mod-quiz input[type="submit"].mod_quiz-redo_question_button{padding:2px
0.8em;font-size:1em}#page-mod-quiz-attempt .mod_quiz-blocked_question_warning .que .formulation,
#page-mod-quiz-review .mod_quiz-blocked_question_warning .que
.formulation{background:#eee;border:1px
solid #dcdcdc}body.jsenabled
.questionflagcheckbox{display:none}#page-mod-quiz-attempt #connection-ok,
#page-mod-quiz-attempt #connection-error{position:fixed;top:0;width:80%;left:10%;color:#555;border-radius:0 0 10px 10px;box-shadow:5px 5px 20px 0 #666;padding:1em
1em 0;z-index:10000}#page-mod-quiz-attempt #connection-error{background-color:#fcc}#page-mod-quiz-attempt #connection-ok{background-color:#cfb;width:60%;left:20%}.generalbox#passwordbox{width:70%;margin-left:auto;margin-right:auto}#passwordform{margin:1em
0}#quiznojswarning{color:red}#quiznojswarning{font-size:0.7em;line-height:1.1}.jsenabled
#quiznojswarning{display:none}.path-mod-quiz #user-picture{margin:0.5em 0}.path-mod-quiz #user-picture
img{width:auto;height:auto;vertical-align:bottom}.path-mod-quiz #mod_quiz_navblock h3.mod_quiz-section-heading{padding:0.7em 0 0;margin:0;clear:both}.path-mod-quiz #mod_quiz_navblock h3.mod_quiz-section-heading:first-child{padding-top:0}.path-mod-quiz
.qnbutton{display:block;position:relative;float:left;width:1.5em;height:1.5em;overflow:hidden;margin:0.3em 0.3em 0.3em 0;padding:0;border:1px
solid #bbb;background:#ddd;text-align:center;vertical-align:middle;line-height:1.5em;font-weight:bold;text-decoration:none}.path-mod-quiz.dir-rtl
.qnbutton{float:right}.path-mod-quiz .qnbutton:visited:hover,
.path-mod-quiz .qnbutton:link:hover{text-decoration:underline}.path-mod-quiz .qnbutton .trafficlight,
.path-mod-quiz .qnbutton
.thispageholder{display:block;position:absolute;top:0;bottom:0;left:0;right:0}.path-mod-quiz
.qnbutton.thispage{border-color:#666}.path-mod-quiz .qnbutton.thispage
.thispageholder{border:1px
solid #666}.path-mod-quiz .qnbutton.flagged
.trafficlight{background:url(/academy/theme/image.php?theme=lambda&component=quiz&rev=1533780117&image=navflagged) no-repeat top right}.path-mod-quiz .qnbutton.blocked,
.path-mod-quiz .qnbutton.notyetanswered,
.path-mod-quiz .qnbutton.requiresgrading,
.path-mod-quiz
.qnbutton.invalidanswer{background-color:white}.path-mod-quiz
.qnbutton.correct{background-color:#cfc}.path-mod-quiz .qnbutton.correct
.trafficlight{border-bottom:3px solid #080}.path-mod-quiz
.qnbutton.partiallycorrect{background-color:#ffa}.path-mod-quiz .qnbutton.notanswered,
.path-mod-quiz
.qnbutton.incorrect{background-color:#fcc}.path-mod-quiz
.qnbutton.blocked{color:#999}.path-mod-quiz .qnbutton.notanswered .trafficlight,
.path-mod-quiz .qnbutton.incorrect
.trafficlight{border-top:3px solid #800}.path-mod-quiz
.othernav{clear:both;margin:0.5em 0}.path-mod-quiz .othernav a,
.path-mod-quiz .othernav
input{display:block;margin:0.5em 0}#quiz-timer{display:none;margin-top:1em}#quiz-time-left{font-weight:bold}#quiz-timer.timeleft15{background:#fff}#quiz-timer.timeleft14{background:#fee}#quiz-timer.timeleft13{background:#fdd}#quiz-timer.timeleft12{background:#fcc}#quiz-timer.timeleft11{background:#fbb}#quiz-timer.timeleft10{background:#faa}#quiz-timer.timeleft9{background:#f99}#quiz-timer.timeleft8{background:#f88}#quiz-timer.timeleft7{background:#f77}#quiz-timer.timeleft6{background:#f66}#quiz-timer.timeleft5{background:#f55}#quiz-timer.timeleft4{background:#f44}#quiz-timer.timeleft3{background:#f33}#quiz-timer.timeleft2{background:#f22}#quiz-timer.timeleft1{background:#f11}#quiz-timer.timeleft0{background:#f00}#page-mod-quiz-mod #id_reviewoptionshdr
.fitem{width:23%;margin-left:10px}#page-mod-quiz-mod #id_reviewoptionshdr
fieldset.fgroup{width:100%;text-align:left;margin-left:0}#page-mod-quiz-mod #id_reviewoptionshdr
.fitem{float:left;width:23%;clear:none}#page-mod-quiz-mod.dir-rtl #id_reviewoptionshdr
.fitem{float:right}#page-mod-quiz-mod #id_reviewoptionshdr
.fitemtitle{width:100%;font-weight:bold;text-align:left;height:2.5em;margin-left:0}#page-mod-quiz-mod.dir-rtl #id_reviewoptionshdr
.fitemtitle{text-align:right}#page-mod-quiz-mod #id_reviewoptionshdr
fieldset.fgroup{clear:left;margin:0
0 1em}#page-mod-quiz-mod #id_reviewoptionshdr fieldset.fgroup>span{float:left;clear:left;line-height:1.7}#page-mod-quiz-mod.dir-rtl #id_reviewoptionshdr fieldset.fgroup>span{float:right;clear:right}#page-mod-quiz-mod #id_reviewoptionshdr fieldset.fgroup span
label{margin-left:0.4em}#page-mod-quiz-view .quizinfo,
#page-mod-quiz-view #page .quizgradefeedback,
#page-mod-quiz-view #page
.quizattempt{text-align:center}#page-mod-quiz-view #page .quizattemptsummary td
p{margin-top:0}#page-mod-quiz-view table.quizattemptsummary tr.bestrow
td{border-color:#bce8f1;background-color:#d9edf7}table.quizattemptsummary
.noreviewmessage{color:gray}#page-mod-quiz-view
.generaltable.quizattemptsummary{margin-left:auto;margin-right:auto}#page-mod-quiz-view
.generalbox#feedback{width:70%;margin-left:auto;margin-right:auto;padding-bottom:15px}#page-mod-quiz-view .generalbox#feedback
h2{margin:0}#page-mod-quiz-view .generalbox#feedback
h3{text-align:left}#page-mod-quiz-view.dir-rtl .generalbox#feedback
h3{text-align:center}#page-mod-quiz-view .generalbox#feedback
.overriddennotice{text-align:center;font-size:0.7em}.quizstartbuttondiv.quizsecuremoderequired
input{display:none}.jsenabled .quizstartbuttondiv.quizsecuremoderequired
input{display:inline}.quizattempt
#mod_quiz_preflight_form{display:none}#mod_quiz_preflight_form .femptylabel
.fitemtitle{display:none}#mod_quiz_preflight_form .femptylabel
.felement{margin:0;padding:0}.moodle-dialogue-base .moodle-dialogue.mod_quiz_preflight_popup{width:600px}.moodle-dialogue-base .moodle-dialogue.mod_quiz_preflight_popup .moodle-dialogue-wrap{overflow:hidden}.moodle-dialogue-base .moodle-dialogue.mod_quiz_preflight_popup .moodle-dialogue-bd{padding:0}.moodle-dialogue-base .moodle-dialogue.mod_quiz_preflight_popup .moodle-dialogue-bd #mod_quiz_preflight_form
legend{padding:0
10px;margin:0;border:0
none}.moodle-dialogue-base .moodle-dialogue.mod_quiz_preflight_popup .moodle-dialogue-bd #mod_quiz_preflight_form
.fitem{margin-left:10px}.moodle-dialogue-base .moodle-dialogue.mod_quiz_preflight_popup .moodle-dialogue-bd #mod_quiz_preflight_form
#fgroup_id_buttonar{padding:10px
0 0;margin:0}.moodle-dialogue-base .moodle-dialogue.mod_quiz_preflight_popup .moodle-dialogue-content .moodle-dialogue-ft{margin:0}.moodle-dialogue-bd #mod_quiz_preflight_form
fieldset.hidden{display:inherit;visibility:inherit}body.path-mod-quiz .gradedattempt,
body.path-mod-quiz table tbody tr.gradedattempt>td{border-color:#bce8f1;background-color:#d9edf7}.quizattemptcounts{clear:left;text-align:center;display:inline;margin-left:20%}.dir-rtl
.quizattemptcounts{margin-left:0;margin-right:20%}#page-mod-quiz-view .quizattemptcounts,
.dir-rtl #page-mod-quiz-view
.quizattemptcounts{display:block;margin-left:0;margin-right:0}#page-mod-quiz-summary
#content{text-align:center}#page-mod-quiz-summary
.questionflag{vertical-align:text-bottom}#page-mod-quiz-summary #quiz-timer{text-align:center;margin-top:1em}#page-mod-quiz-summary
.submitbtns{margin-top:1.5em}@media
print{.quiz-secure-window
*{display:none !important}}table.quizreviewsummary{width:100%}table.quizreviewsummary
th.cell{padding:1px
0.5em 1px 1em;font-weight:bold;text-align:right;width:10em;background:#f0f0f0}table.quizreviewsummary
td.cell{padding:1px
1em 1px 0.5em;text-align:left;background:#fafafa}.dir-rtl table.quizreviewsummary
td.cell{text-align:right}#page-mod-quiz-comment
.mform{width:100%}#page-mod-quiz-comment .mform
fieldset{margin:0}#page-mod-quiz-comment
.que{margin:0}#page-mod-quiz-report
h2.main{clear:both}#page-mod-quiz-report div#commands,
#page-mod-quiz-report
.controls{text-align:center}#page-mod-quiz-report
.dubious{background-color:#fcc}#page-mod-quiz-report
.highlight{border:1px
solid #bce8f1;background-color:#d9edf7}#page-mod-quiz-report
.negcovar{border:medium solid pink}#page-mod-quiz-report
.toggleincludeauto{text-align:center}#page-mod-quiz-report
.gradetheselink{font-size:0.8em}#page-mod-quiz-report .mform fieldset.fgroup span
label{margin-right:14px}#page-mod-quiz-report table
th{white-space:normal}#page-mod-quiz-report table#attempts td,
#page-mod-quiz-report table.quizresponseanalysis
td{word-wrap:break-word;max-width:20em}#page-mod-quiz-report table.titlesleft
td.c0{font-weight:bold}#page-mod-quiz-report table
.numcol{text-align:center;vertical-align:middle !important}#page-mod-quiz-report
table#attempts{clear:both;width:80%;margin:0.2em auto}#page-mod-quiz-report table#attempts .header,
#page-mod-quiz-report table#attempts
.cell{padding:4px}#page-mod-quiz-report table#attempts .header
.commands{display:inline}#page-mod-quiz-report table#attempts
.picture{width:40px}#page-mod-quiz-report table#attempts
td{border-left-width:1px;border-right-width:1px;border-left-style:solid;border-right-style:solid;vertical-align:middle}#page-mod-quiz-report table#attempts
.header{text-align:left}#page-mod-quiz-report table#attempts
.picture{text-align:center !important}#page-mod-quiz-report table#attempts.grades span.que,
#page-mod-quiz-report table#attempts
span.avgcell{white-space:nowrap}#page-mod-quiz-report table#attempts span.que
.requiresgrading{white-space:normal}#page-mod-quiz-report table#attempts
.questionflag{vertical-align:text-bottom;padding-left:6px}.dir-rtl#page-mod-quiz-report table#attempts
.questionflag{padding-right:6px;padding-left:0}#page-mod-quiz-report .graph.flexible-wrap{text-align:center;overflow:auto}#page-mod-quiz-report
#cachingnotice{margin-bottom:1em;padding:0.2em}#page-mod-quiz-report #cachingnotice
.singlebutton{margin:0.5em 0 0}#page-mod-quiz-report .bold
.reviewlink{font-weight:normal}#page-mod-quiz-report
tr.lastrowforattempt{border-bottom:lightgrey solid 0.2em}#page-mod-quiz-edit
.statusbar{margin:0.6em 0.4em}#page-mod-quiz-edit
.statusdisplay{background-color:#ffc;clear:both;margin:0.3em 0;padding:1px
10px}#page-mod-quiz-edit .statusdisplay
p{margin:4px
0}#page-mod-quiz-edit .maxgrade,
#page-mod-quiz-edit
.totalpoints{display:block;float:right;margin:-2.85em 0 0;padding: .2em}#page-mod-quiz-edit.dir-rtl .maxgrade,
#page-mod-quiz-edit.dir-rtl
.totalpoints{float:left}#page-mod-quiz-edit .maxgrade
label{display:inline}#page-mod-quiz-edit li.activity > div,
#page-mod-quiz-edit
li.pagenumber{position:relative}#page-mod-quiz-edit ul.section li.pagenumber:first-child .add-menu-outer ul.menu li:first-child,
#page-mod-quiz-edit .last-add-menu .add-menu-outer ul.menu li:first-child{display:none}#page-mod-quiz-edit .last-add-menu{position:relative;height:1.5em;margin:0
20px}#page-mod-quiz-edit .add-menu-outer{position:absolute;right:0}#page-mod-quiz-edit.dir-rtl .add-menu-outer{right:auto;left:0}#page-mod-quiz-edit
.slotnumber{background-color:#D3D3D3;text-align:center;margin:0.1em 0.5em;min-width:2em;display:inline-block}#page-mod-quiz-edit .section-heading{font-size:24px;margin-left:20px;margin-bottom:0;height:40px}#page-mod-quiz-edit .section-heading
.instancesectioncontainer{display:inline}#page-mod-quiz-edit .section-heading .instancesectioncontainer
h3{display:inline;color:#999}#page-mod-quiz-edit .section-heading .editing_section,
#page-mod-quiz-edit .section-heading
.editing_delete{margin-left:10px}#page-mod-quiz-edit .section-heading
.sectioninstance{position:relative}#page-mod-quiz-edit .section-heading
.instancesection{white-space:nowrap;max-width:72%;display:inline-block;text-overflow:ellipsis;overflow:hidden;vertical-align:bottom}#page-mod-quiz-edit .section-heading
form{display:inline;position:relative;top:3px;left:-7px}#page-mod-quiz-edit .section-heading form
input{font-size:24px;font-weight:bold;width:50%}#page-mod-quiz-edit .section-heading
.instanceshufflequestions{float:right;margin:0.3em 20px 0 0}#page-mod-quiz-edit
ul.section{margin:0;padding:0
20px}#page-mod-quiz-edit
ul.slots{margin:0}#page-mod-quiz-edit ul.slots
li.section{border:0}#page-mod-quiz-edit ul.slots li.section
.content{background-color:#FAFAFA;padding:1px
0}#page-mod-quiz-edit ul.slots
li.section{list-style:none;margin:0;padding:0}#page-mod-quiz-edit ul.slots li.section
li.activity{background:#E6E6E6;margin:3px
0;padding:0.2em}#page-mod-quiz-edit ul.slots li.section
li.activity.page{background:transparent}#page-mod-quiz-edit ul.slots li.section li.activity.page
h4{display:inline;font-weight:normal;font-size:1em}#page-mod-quiz-edit ul.slots li.section li.activity
.instancemaxmarkcontainer{background:white;padding:0.2em;margin:0.4em}#page-mod-quiz-edit ul.slots li.section li.activity .instancemaxmarkcontainer
.editicon{width:13px}#page-mod-quiz-edit ul.slots li.section li.activity
.instancemaxmarkcontainer.infoitem{background:transparent}#page-mod-quiz-edit ul.slots li.section li.activity .instancemaxmarkcontainer
form{display:inline}#page-mod-quiz-edit ul.slots li.section li.activity .instancemaxmarkcontainer form
input{margin:0;padding:0.2em;height:1em}#page-mod-quiz-edit ul.slots li.section li.activity
.instancemaxmark{display:inline-block;text-align:right}#page-mod-quiz-edit.dir-rtl ul.slots li.section li.activity
.instancemaxmark{text-align:left}#page-mod-quiz-edit ul.slots li.section li.activity
.page_split_join_wrapper{position:absolute}#page-mod-quiz-edit ul.slots li.section li.activity
.page_split_join{position:relative;left:-20px;top:-7px}#page-mod-quiz-edit.dir-rtl ul.slots li.section li.activity
.page_split_join{left:auto;right:-20px}#page-mod-quiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_0{min-width:1.3em}#page-mod-quiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_1{min-width:2em}#page-mod-quiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_2{min-width:2.6em}#page-mod-quiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_3{min-width:3.2em}#page-mod-quiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_4{min-width:3.7em}#page-mod-quiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_5{min-width:4.3em}#page-mod-quiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_6{min-width:4.8em}#page-mod-quiz-edit ul.slots li.section li.activity
.instancemaxmark.decimalplaces_7{min-width:5.45em}#page-mod-quiz-edit ul.slots li.section li.activity .edit_icon,
#page-mod-quiz-edit ul.slots li.section li.activity a.preview,
#page-mod-quiz-edit ul.slots li.section li.activity .editing_delete,
#page-mod-quiz-edit ul.slots li.section li.activity
.editing_maxmark{margin:0
2px}#page-mod-quiz-edit ul.slots li.section.only-has-one-slot li.activity .editing_move,
#page-mod-quiz-edit ul.slots li.section.only-has-one-slot li.activity
.editing_delete{visibility:hidden}#page-mod-quiz-edit ul.slots.only-one-section li.section.only-has-one-slot li.activity
.editing_delete{visibility:visible}#page-mod-quiz-edit ul.slots li.section li.activity
.question_dependency_wrapper{position:absolute;top:0;right:0}#page-mod-quiz-edit.dir-rtl ul.slots li.section li.activity
.question_dependency_wrapper{left:0;right:auto}#page-mod-quiz-edit ul.slots li.section li.activity
.question_dependency_wrapper.question_dependency_cannot_depend{display:none}#page-mod-quiz-edit ul.slots li.section li.activity .question_dependency_wrapper .currentlink,
#page-mod-quiz-edit ul.slots li.section li.activity .question_dependency_wrapper .cm-edit-action{position:relative;left:20px;top:-1em}#page-mod-quiz-edit.dir-rtl ul.slots li.section li.activity .question_dependency_wrapper .currentlink,
#page-mod-quiz-edit.dir-rtl ul.slots li.section li.activity .question_dependency_wrapper .cm-edit-action{right:20px;left:auto}#page-mod-quiz-edit ul.slots li.section li.activity
.activityinstance{display:block;min-height:1.7em;position:absolute;top:0;left:5em;width:100%}#page-mod-quiz-edit.dir-rtl ul.slots li.section li.activity
.activityinstance{left:auto;right:5em}#page-mod-quiz-edit ul.slots li.section li.activity .mod-indent-outer{padding-left:22px}#page-mod-quiz-edit.dir-rtl ul.slots li.section li.activity .mod-indent-outer{padding-left:0;padding-right:22px}#page-mod-quiz-edit ul.slots .activityinstance
form{display:inline}#page-mod-quiz-edit
span.editinstructions{right:0}#page-mod-quiz-edit.dir-rtl
span.editinstructions{left:0;right:auto}#page-mod-quiz-edit ul.slots .activityinstance
span.instancename{overflow-x:hidden;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;word-break:break-word;width:70%;display:inline-block;height:20px}#page-mod-quiz-edit ul.slots .activityinstance span.instancename
img{margin:0
0.2em}#page-mod-quiz-edit #categoryquestions .questionname,
#page-mod-quiz-edit ul.slots li.activity div.activityinstance
.questionname{font-weight:bold;color:#555}#page-mod-quiz-edit ul.slots li.activity div.activityinstance
.questiontext{color:#555}#page-mod-quiz-edit ul.slots li.activity div.activityinstance
.mod_quiz_random_qbank_link{font-size:0.8em}#page-mod-quiz-edit ul.slots .activityinstance
img.activityicon{float:left;margin: .2em 0 0;padding:0}#page-mod-quiz-edit.dir-rtl ul.slots .activityinstance
img.activityicon{float:right}#page-mod-quiz-edit .section .activity
.actions{white-space:nowrap;background:#e6e6e6;padding:0.1em 0}#page-mod-quiz-edit
.mod_quiz_edit_forms{display:none}#categoryquestions>tbody>tr:nth-of-type(even){background:#e4e4e4}#categoryquestions>tbody>tr:nth-of-type(even).highlight{background-color:#AFA}#categoryquestions
.header{text-align:center;padding:0
2px;border:0
none}#categoryquestions th.modifiername .sorters,
#categoryquestions th.creatorname
.sorters{font-weight:normal;font-size:0.8em}#categoryquestions td.modifiername,
#categoryquestions
td.creatorname{line-height:1em}#categoryquestions td.modifiername span.date,
#categoryquestions td.creatorname
span.date{font-weight:normal;font-size:0.8em}table#categoryquestions{width:100%;overflow:hidden;table-layout:fixed}#categoryquestions
.iconcol{width:15px;text-align:center;padding:0}#categoryquestions
.checkbox{width:19px;text-align:center;padding:0}#categoryquestions
.qtype{text-align:center}#categoryquestions
.qtype{width:28px;padding:0}#categoryquestions
.questiontext{position:relative;zoom:1;padding-left:0.3em;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.dir-rtl #categoryquestions
.questiontext{padding-left:0;padding-right:0.3em}#categoryquestions
.questionname{white-space:nowrap;overflow:hidden;zoom:1;position:relative}#categoryquestions .questiontext
p{margin:0}#page-mod-quiz-edit table#categoryquestions td,
#page-mod-quiz-edit table#categoryquestions
th{overflow:hidden;white-space:nowrap}.mod_quiz_qbank_dialogue{width:80%;min-height:200px}.mod_quiz_qbank_dialogue.moodle-dialogue-fullscreen{width:100%}.mod_quiz_qbank_dialogue
.questionbankloading{position:absolute;top:30px;bottom:0;left:0;right:0;background:#fff;text-align:center;opacity:0.5;padding-top:50px}.mod_quiz_qbank_dialogue #advancedsearch
label{font-size:100%}.modulespecificbuttonscontainer{padding-left:0.3em;padding-right:0.3em}.quizquestionlistcontrols{text-align:center}.categoryinfo{padding:0.3em}.path-mod-quiz
.gradingdetails{font-size:small}#page-mod-quiz-edit div#repaginatedialog
.mform{margin-left:auto;margin-right:auto}#page-mod-quiz-edit div.container
div.generalbox{position:relative;display:block;border:0
none;margin:0;padding:0}#page-mod-quiz-edit
.paging{margin-top:0;margin-bottom:0;padding:0.1em 0.3em;display:block;background-color:#ddd}#page-mod-quiz-edit #page-footer{clear:both;padding-top:1em}#page-mod-quiz-edit
.categoryinfofield{font-style:italic}#page-mod-quiz-edit
.categorynamefield{font-weight:bold}#page-mod-quiz-edit
.questionsortoptions{background-color:#ddd}#page-mod-quiz-edit div.questionbank
.categorysortopotionscontainer{padding-top:0.5em;margin-top:0.3em}#page-mod-quiz-edit div.questionbank .categoryquestionscontainer,
.questionbank .categorysortopotionscontainer,
.questionbank .categorypagingbarcontainer,
.questionbank
.categoryselectallcontainer{background-color:#FFF}#page-mod-quiz-edit ul.slots li.section
ul.section{list-style:none}@media
print{#page-mod-quiz-attempt header.navbar,
#page-mod-quiz-review
header.navbar{display:none}#page-mod-quiz-attempt #dock,
#page-mod-quiz-review
#dock{display:none}#page-mod-quiz-attempt #page #page-header h1,
#page-mod-quiz-review #page #page-header
h1{display:none}#page-mod-quiz-attempt #region-main,
#page-mod-quiz-review #region-main{width:100%}#page-mod-quiz-attempt #block-region-side-pre,
#page-mod-quiz-attempt #block-region-side-post,
#page-mod-quiz-review #block-region-side-pre,
#page-mod-quiz-review #block-region-side-post{display:none}#page-mod-quiz-attempt #page-footer,
#page-mod-quiz-review #page-footer{display:none}#page-mod-quiz-attempt .editquestion,
#page-mod-quiz-review .editquestion,
#page-mod-quiz-attempt .questionflag,
#page-mod-quiz-review
.questionflag{display:none}#page-mod-quiz-attempt .submitbtns,
#page-mod-quiz-review
.submitbtns{display:none}#page-mod-quiz-review .que
.commentlink{display:none}#page-mod-quiz-attempt .que,
#page-mod-quiz-review
.que{page-break-inside:avoid}}@media only screen and (max-width:565px){#page-mod-quiz-edit
.rpcontainerclass{margin-top:3em}#page-mod-quiz-edit
.maxgrade{margin-top:0.1em}#page-mod-quiz-edit
.statusbar{padding:0}}.path-mod-resource
.resourcecontent{text-align:center}.path-mod-resource
.resourcedetails{font-size:0.8em;color:#555}.resourcelinkdetails{font-size:0.8em;color:#555}.path-mod-scorm
.top{vertical-align:top}.path-mod-scorm .scorm-left{text-align:left}.path-mod-scorm .scorm-center{text-align:center}.path-mod-scorm .scorm-right{text-align:right}.path-mod-scorm
.scoframe{position:relative;width:100%;height:100%}.ios #scormpage
#scorm_content{-webkit-overflow-scrolling:touch;overflow:scroll}#page-mod-scorm-player
#scormtop{position:relative;width:100%;height:30px}#page-mod-scorm-player
#scormbrowse{position:absolute;left:5px;top:0px}#page-mod-scorm-player
#scormnav{position:absolute;right:5px;text-align:center;top:3px;width:100%}#page-mod-scorm-player
#scormbox{width:74%;height:100%;position:absolute;right:0px;top:0px}#page-mod-scorm-player
#scormpage{position:relative;width:100%;height:100%}#page-mod-scorm-player #scormpage
#toctree{position:relative;width:100%}#page-mod-scorm-player
#tocbox{position:relative;left:0px;width:100%;height:100%;font-size:0.8em}#page-mod-scorm-player
#toctree{overflow:visible}#page-mod-scorm-player
#tochead{position:relative;text-align:center;top:3px;height:30px}#page-mod-scorm-player #scormpage
.scoframe{frameborder:0}#page-mod-scorm-player #scormpage
#scorm_object{border:none;width:98%;height:98%}#page-mod-scorm-player #scormpage
#scorm_object.scorm_nav_under_content{height:95%}#page-mod-scorm-player #scormpage
#scorm_content{height:100%}#page-mod-scorm-player #scormpage
#scorm_toc{position:relative}#page-mod-scorm-player #scormpage
#scorm_toc_title{font-size:1.2em;font-weight:bold}#page-mod-scorm-player #scormpage
#scorm_tree{border-right:5px solid rgb(239, 245, 255)}#page-mod-scorm-player #scormpage
#scorm_navpanel{text-align:center}#page-mod-scorm-player .toc,
#page-mod-scorm-player .no-toc{width:100%}#page-mod-scorm-player
.structlist{list-style-type:none;white-space:nowrap}#page-mod-scorm-player
.structurelist{position:relative;list-style-type:none;width:96%;margin:0;padding:0}#page-mod-scorm-player .structurelist
ul{padding-left:0.5em;margin-left:0.5em}#page-mod-scorm-player #scormpage #scorm_toc.disabled,
#page-mod-scorm-player #scormpage #scorm_toc.loading,
#page-mod-scorm-player #scormpage #scorm_toc_toggle.disabled,
#page-mod-scorm-player #scormpage
#scorm_toc_toggle.loading{display:none}#page-mod-scorm-view
.structurelist{list-style-type:none;white-space:nowrap}#page-mod-scorm-view
.structurelist{list-style-type:none;white-space:nowrap}#page-mod-scorm-view
.exceededmaxattempts{color:#c00}#page-mod-scorm-player
#altfinishlink{font-size:140%;border:0px;padding:0px}#page-mod-scorm-player
#scormmode{float:left;border:0px}#page-mod-scorm-player.pagelayout-popup #page-content .region-content{padding:0px}#page-mod-scorm-player.pagelayout-popup #page-wrapper{width:100%}#page-mod-scorm-player .yui-layout-scroll div.yui-layout-bd{overflow:visible}#page-mod-scorm-player .yui-layout-unit-left div.yui-layout-bd{overflow:auto}.path-mod-scorm.forcejavascript .scorm-center{display:none}.path-mod-scorm.forcejavascript
.toc{display:none}.path-mod-scorm.forcejavascript #scormpage
#tocbox{display:none}.path-mod-scorm.jsenabled
.forcejavascriptmessage{display:none}.path-mod-scorm.jsenabled .scorm-center{display:block}.path-mod-scorm.jsenabled
.toc{display:block}.path-mod-scorm.jsenabled #scormpage
#tocbox{display:block}#page-mod-scorm-report-userreporttracks table
.c1{word-wrap:break-word;word-break:break-all}#page-mod-scorm-report
.scormattemptcounts{clear:left;text-align:center;display:inline;margin-left:20%}#page-mod-scorm-player #scormpage span.yui3-treeview-icon{display:none}#page-mod-scorm-player #scormpage li.yui3-treeview-has-children>div.yui3-treeview-row>span.yui3-treeview-icon{display:block}#page-mod-scorm-player #scormpage div.yui3-u-1,
#page-mod-scorm-player #scormpage div.yui3-u-3-4,
#page-mod-scorm-player #scormpage div.yui3-u-1-5,
#page-mod-scorm-player #scormpage div.yui3-u-1-24{display:inline-block;*display:inline;zoom:1;letter-spacing:normal;word-spacing:normal;vertical-align:top;text-rendering:auto}#page-mod-scorm-player #scormpage div.yui3-u-1{display:block}#page-mod-scorm-player #scormpage div.yui3-u-3-4{width:75%}#page-mod-scorm-player #scormpage div.yui3-u-1-5{width:20%}#page-mod-scorm-player #scormpage div.yui3-u-1-24{width:4.1666%}#page-mod-scorm-player #scormpage div.yui3-g-r{*letter-spacing:normal;*word-spacing:-0.43em}#scorm_layout{margin-bottom:50px}#page-mod-scorm-player .opera-only :-o-prefocus,
#page-mod-scorm-player #scormpage div.yui3-g-r
img{max-width:100%}.dir-rtl#page-mod-scorm-player #scormpage span.yui3-treeview-icon{float:right}.path-mod-survey
.smalltext{font-size:0.75em}.path-mod-survey .surveytable .rblock
label{display:block}.path-mod-survey .surveytable .foundthat,
.path-mod-survey .surveytable
.preferthat{white-space:nowrap}.path-mod-survey .surveytable
.buttoncell{width:5%}.path-mod-survey .surveytable .optioncell,
.path-mod-survey .surveytable
.questioncell{width:50%;vertical-align:top}.path-mod-survey .surveytable
.whitecell{background-color:white}.path-mod-survey #surveyform
th{font-weight:normal;text-align:left}.path-mod-survey #surveyform
th.hresponse{text-align:center;width:9%}#page-mod-survey-report
.fullnamecell{width:10%;vertical-align:top;white-space:nowrap}.path-mod-url
.resourcecontent{text-align:center}.wiki_contentbox{width:80%;margin:auto;min-width:200px;min-height:100px}.wiki_editor{width:50%;margin:auto;margin-top:10px;margin-bottom:10px}.wiki_previewbox{width:50%;margin:auto;border:thin solid blue}.wiki_button{margin:5px}.wiki_warning{color:red}.emptycomments{color:red;display:inline}.wiki-toc{border:1px
solid #BBB;background:#EEE;margin:16px;padding:8px}.wiki-toc-title{color:#666;font-size:1.1em;font-variant:small-caps;text-align:center}.wiki-toc-section{padding:0;margin:2px
8px}.wiki-toc-section-2{padding-left:12px}.wiki-toc-section-3{padding-left:24px}.wiki_form-button{margin-left:0%}.wiki-form-center{text-align:center;margin:auto;width:320px}.wiki-upload-table{margin:8px
auto;clear:both}.wiki-upload-table
table{margin:auto}.wiki-upload-table
h3{margin:4px
0px;text-align:center}.wiki-upload-section{border:1px
solid #EEE;width:400px;margin:8px
auto}.wiki-upload-section
legend{font-weight:bold;font-size:0.9em;margin-left:16px}.wiki-tags{text-align:right}.wiki_modifieduser
p{line-height:35px}.wiki_modifieduser
img{border:thin solid black}.wiki_restore_yes, .wiki_deletecomment_yes,
.dir-rtl .wiki_restore_no, .dir-rtl
.wiki_deletecomment_no{float:left}.wiki_restore_no, .wiki_deletecomment_no,
.dir-rtl .wiki_restore_yes, .dir-rtl
.wiki_deletecomment_yes{float:right}.wiki_restoreform,.wiki_deletecommentform{width:10%;margin:auto}.wiki_versionuser{float:left}.wiki_diffuserleft,.wiki_diffuserright{font-weight:normal;padding-top:1%}.wiki_diffuserleft{float:right}.dir-rtl
.wiki_diffuserleft{float:left}.wiki_diffuserright{float:left}.wiki_compareheading{font-weight:normal}.wiki_restore,.wiki_diffview,.wiki_difftime,.wiki_headingtime{font-size:0.8em;font-weight:normal}.wiki_difftime,.wiki_headingtime{font-style:oblique;text-align:center}.wiki_diff_oldpaging{float:left;width:40%;min-width:200px;margin-left:5%}.wiki_diff_newpaging{float:right;width:40%;min-width:200px;margin-right:5%}.wiki_diff_old,.wiki_diff_new{float:left;min-width:200px;width:40%}.wiki_difftable
td{width:50%;float:left}.wiki_histdate{text-align:left}.wiki_histnewdate{border-top:1px dotted gray}.ouw_deleted{background:#FFA;color:red;text-decoration:line-through}.ouw_added{background:#CFC;color:red}a.wiki_newentry:link,a.wiki_newentry:visited{color:red;font-style:italic}.wiki_newentry
a{color:red;font-style:italic}#intro.generalbox{margin-top:10px;padding:5px}.wiki_navigation_container{margin:0
auto}.wiki_navigation_from{float:left;width:40%;min-width:200px;margin-left:5%}.wiki_navigation_to{float:left;width:40%;min-width:200px;margin-right:5%}.wiki_headingtitle{text-align:center}.wiki_clear{clear:both}.wiki_right{text-align:right}.wiki_index{text-align:right}.notunderlined{text-decoration:none}a.wiki_edit_section{font-size:0.6em;vertical-align:top;position:relative;float:right}.midpad{text-align:center;margin-top:0.4em;margin-bottom:0.4em}.block_wiki_search
ul{margin-top:0.5em;margin-bottom:3px}.wiki-attachment:before{content:url("/mod/wiki/pix/attachment.png");padding-right:2px}#wiki_printable_content{text-align:left}.dir-rtl
#wiki_printable_content{text-align:right}#wiki_printable_content
a{color:black}#wiki_printable_title{font-size:2.2em;text-decoration:underline}.wiki_diff_boxes{width:100%;clear:both}.wiki_diff_paging{width:100%;clear:both}.wiki_grayline{color:gray}.wikisearchresults{padding-left:50px;padding-top:20px}.wiki-diff-container{width:95%;margin:10px
auto}.wiki-diff-container .wiki-diff-leftside,
.wiki-diff-container .wiki-diff-rightside{width:49.5%;margin:0;padding:0;float:left}.wiki-diff-container .wiki-diff-rightside{margin-left:1%}.wiki-diff-container .wiki-diff-heading,
.wiki-diff-container .no-overflow{padding:10px;border:1px
solid #DDD}.wiki-diff-container .wiki-diff-rightside
.wiki_diffversion{text-align:right}.wikieditor-toolbar
img{width:22px;height:22px;vertical-align:middle}.path-mod-wiki
.printicon{background:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fprint) no-repeat scroll 2px center transparent;padding-left:20px}#page-mod-wiki-prettyview
.displayprinticon{text-align:right}.path-mod-workshop
.collapsibleregion{margin-bottom:0.75em}.path-mod-workshop
.collapsibleregioncaption{font-weight:bold;font-size:120%}.path-mod-workshop
div.singlebutton{text-align:center;margin:0.75em auto}.path-mod-workshop #workshop-viewlet-assignedassessments div.singlebutton,
.path-mod-workshop #workshop-viewlet-allexamples div.singlebutton,
.path-mod-workshop #workshop-viewlet-examples
div.singlebutton{text-align:left}.path-mod-workshop
.groupwidget{text-align:center;margin:0.75em auto}.path-mod-workshop
.perpagewidget{text-align:center;margin:0.75em auto}.path-mod-workshop .submission-summary{position:relative;margin-bottom:10px}.path-mod-workshop .submission-summary .title,
.path-mod-workshop .submission-summary .author,
.path-mod-workshop .submission-summary .author .fullname,
.path-mod-workshop .submission-summary .author
.picture{display:inline}.path-mod-workshop .submission-summary .title,
.path-mod-workshop .submission-summary .userdate,
.path-mod-workshop .submission-summary .grade-status{margin:0px
0px 0px 40px}.path-mod-workshop .submission-summary
.author{margin-left:1ex}.path-mod-workshop .submission-summary.anonymous .title,
.path-mod-workshop .submission-summary.anonymous .author,
.path-mod-workshop .submission-summary.anonymous .userdate,
.path-mod-workshop .submission-summary.anonymous .grade-status{margin:0px
0px 0px 5px}.path-mod-workshop .submission-summary
.userdate{font-size:x-small;color:#333}.path-mod-workshop .submission-summary .userdate
span{font-style:italic}.path-mod-workshop .submission-summary .author
.picture{position:absolute;top:0px;left:0px}.path-mod-workshop .submission-full{border:1px
solid #ddd;margin:0px
0px 1em 0px}.path-mod-workshop .submission-full
.header{position:relative;background-color:#ddd;padding:3px;min-height:67px}.path-mod-workshop .submission-full .header .title,
.path-mod-workshop .submission-full .header .author,
.path-mod-workshop .submission-full .header
.userdate{margin:0px
0px 0px 80px}.dir-rtl.path-mod-workshop .submission-full .header .title,
.dir-rtl.path-mod-workshop .submission-full .header .author,
.dir-rtl.path-mod-workshop .submission-full .header
.userdate{margin:0px
80px 0px 0px}.path-mod-workshop .submission-full.anonymous .header .title,
.path-mod-workshop .submission-full.anonymous .header .author,
.path-mod-workshop .submission-full.anonymous .header
.userdate{margin:0px
0px 0px 5px}.path-mod-workshop .submission-full .header
.userdate.created{padding-right:10px}.path-mod-workshop .submission-full .header
.userdate.modified{padding-left:10px;margin-left:0px;border-left:1px solid #000}.path-mod-workshop .submission-full .header
.userdate{font-size:x-small;color:#333;display:inline}.path-mod-workshop .submission-full .header .userdate
span{font-style:italic}.path-mod-workshop .submission-full .header .author
.picture{position:absolute;top:3px;left:3px}.dir-rtl.path-mod-workshop .submission-full .header .author
.picture{right:3px;left:auto}.path-mod-workshop .submission-full .content,
.path-mod-workshop .submission-full
.attachments{padding:5px
10px}.path-mod-workshop .submission-full .attachments .files
img.icon{margin-right:5px}.path-mod-workshop .submission-full .attachments .images
div{display:inline-block;margin:5px;padding:5px;border:1px
solid #ddd}.path-mod-workshop .submission-summary.example .title,
.path-mod-workshop .submission-summary.example
.userdate{margin:0px
0px 0px 0px}.path-mod-workshop .submission-full.example
.header{min-height:0px}.path-mod-workshop .submission-full.example .header
.title{margin:0px
0px 0px 0px}.path-mod-workshop
.message{padding:5px
5em 5px 15px;margin:0px
auto 20px auto;width:100%;font-size:80%;position:relative}.path-mod-workshop .message
.singlebutton{text-align:left;margin:0px}.path-mod-workshop
.message.ok{color:#547c22;background-color:#e7f1c3}.path-mod-workshop
.message.error{color:#dd0221;background-color:#ffd3d9}.path-mod-workshop
.message.info{color:#1666a9;background-color:#d2ebff}.path-mod-workshop .allocation-init-results{margin:10px
auto;width:100%;font-size:80%}.path-mod-workshop .allocation-init-results
.indent{margin-left:20px}.path-mod-workshop .allocation-init-results
.ok{color:#547c22;background-color:#e7f1c3}.path-mod-workshop .allocation-init-results
.error{color:#dd0221;background-color:#ffd3d9}.path-mod-workshop .allocation-init-results
.info{color:#1666a9;background-color:#d2ebff}.path-mod-workshop .allocation-init-results
.debug{color:black;background-color:#ddd}.path-mod-workshop
.userplan{width:100%;margin:1em
auto 1em auto;font-size:80%;border:1px
solid #ddd}.path-mod-workshop .userplan
th{vertical-align:bottom;white-space:normal;color:#999;border-top:1px solid #ddd;border-bottom:1px solid #ddd;padding:3px}.path-mod-workshop .userplan
th.active{vertical-align:top;color:black;font-size:140%;border:1px
solid #ddd;border-bottom:0;background:#e7f1c3}.path-mod-workshop .userplan
td{width:20%;vertical-align:top;border-right:1px solid #ddd;background-color:#f5f5f5}.path-mod-workshop .userplan td,
.path-mod-workshop .userplan td a,
.path-mod-workshop .userplan td a:link,
.path-mod-workshop .userplan td a:hover,
.path-mod-workshop .userplan td a:visited,
.path-mod-workshop .userplan td a:active{color:#999}.path-mod-workshop .userplan td.active,
.path-mod-workshop .userplan td.active a,
.path-mod-workshop .userplan td.active a:link,
.path-mod-workshop .userplan td.active a:hover,
.path-mod-workshop .userplan td.active a:visited,
.path-mod-workshop .userplan td.active a:active{color:black}.path-mod-workshop .userplan
td.lastcol{border-right:0}.path-mod-workshop .userplan
td.active{border-left:1px solid #ddd;border-right:1px solid #ddd;background-color:#e7f1c3}.path-mod-workshop .userplan th
.actions{display:inline}.path-mod-workshop .userplan tr.phasetasks
li{background-image:url(/academy/theme/image.php?theme=lambda&component=mod_workshop&rev=1533780117&image=userplan%2Ftask-todo);background-position:top left;background-repeat:no-repeat;list-style-type:none;min-height:16px;margin: .3em 0}.dir-rtl.path-mod-workshop .userplan tr.phasetasks
li{background-position:top right}.path-mod-workshop .userplan tr.phasetasks
li.completed{background-image:url(/academy/theme/image.php?theme=lambda&component=mod_workshop&rev=1533780117&image=userplan%2Ftask-done)}.path-mod-workshop .userplan tr.phasetasks
li.fail{background-image:url(/academy/theme/image.php?theme=lambda&component=mod_workshop&rev=1533780117&image=userplan%2Ftask-fail)}.path-mod-workshop .userplan tr.phasetasks
li.info{background-image:url(/academy/theme/image.php?theme=lambda&component=mod_workshop&rev=1533780117&image=userplan%2Ftask-info)}.path-mod-workshop .userplan tr.phasetasks
.tasks{list-style:none;margin:3px;padding:0px}.path-mod-workshop .userplan tr.phasetasks
.title{padding:0px
10px 0px 20px}.dir-rtl.path-mod-workshop .userplan tr.phasetasks
.title{padding:0px
20px 0px 10px}.path-mod-workshop .userplan tr.phasetasks
.details{padding:0px
10px 0px 25px;font-size:80%}.dir-rtl.path-mod-workshop .userplan tr.phasetasks
.details{padding:0px
25px 0px 10px}.path-mod-workshop .assessment-full{border:1px
solid #ddd;margin:0px
auto 1em auto}.path-mod-workshop .assessment-full
.header{position:relative;background-color:#ddd;padding:3px;min-height:35px}.path-mod-workshop .assessment-full .header
.title{font-weight:bold}.path-mod-workshop .assessment-full .header .title,
.path-mod-workshop .assessment-full .header .reviewer,
.path-mod-workshop .assessment-full .header .grade,
.path-mod-workshop .assessment-full .header
.weight{margin:0px
0px 0px 40px}.dir-rtl.path-mod-workshop .assessment-full .header .title,
.dir-rtl.path-mod-workshop .assessment-full .header .reviewer,
.dir-rtl.path-mod-workshop .assessment-full .header .grade,
.dir-rtl.path-mod-workshop .assessment-full .header
.weight{margin:0px
40px 0px 0px}.path-mod-workshop .assessment-full.anonymous .header .title,
.path-mod-workshop .assessment-full.anonymous .header .reviewer,
.path-mod-workshop .assessment-full.anonymous .header .grade,
.path-mod-workshop .assessment-full.anonymous .header
.weight{margin:0px
0px 0px 5px}.path-mod-workshop .assessment-full .header .reviewer
.picture{position:absolute;top:3px;left:3px}.dir-rtl.path-mod-workshop .assessment-full .header .reviewer
.picture{right:3px;left:auto}.path-mod-workshop .assessment-full .header
.actions{position:absolute;top:5px;right:5px;text-align:right}.path-mod-workshop .assessment-full .header .actions .singlebutton,
.path-mod-workshop .assessment-full .header .actions .singlebutton form,
.path-mod-workshop .assessment-full .header .actions .singlebutton form
div{display:inline}.path-mod-workshop .assessment-full .assessment-form-wrapper,
.path-mod-workshop .assessment-full .overall-feedback-wrapper{margin-top:0.5em;padding:0px
1em}.path-mod-workshop .assessment-summary.graded .singlebutton input[type="submit"],
.path-mod-workshop .example-summary.graded .singlebutton input[type="submit"]{background-color:#e7f1c3}.path-mod-workshop .assessment-summary.notgraded .singlebutton input[type="submit"],
.path-mod-workshop .example-summary.notgraded .singlebutton input[type="submit"]{background-color:#ffd3d9}.path-mod-workshop .assessment-full .overallfeedback .content,
.path-mod-workshop .assessment-full .overallfeedback
.attachments{padding:5px
10px}.path-mod-workshop .assessment-full .overallfeedback .attachments .files
img.icon{margin-right:5px}.path-mod-workshop .assessment-full .overallfeedback .attachments .images
div{display:inline-block;margin:5px;padding:5px;border:1px
solid #ddd}.path-mod-workshop .assessmentform
.description{margin:0px
1em}.path-mod-workshop .grading-report{width:100%;margin:1em
auto 1em auto;font-size:80%;border:1px
solid #ddd}.path-mod-workshop .grading-report
.userpicture{margin:0px
3px;vertical-align:middle}.path-mod-workshop .grading-report
del{color:red;font-size:90%;text-decoration:line-through}.path-mod-workshop .grading-report
ins{color:green;font-weight:bold;text-decoration:underline}.path-mod-workshop .grading-report
th{white-space:normal}.path-mod-workshop .grading-report
td{vertical-align:top;border:1px
solid #ddd}.path-mod-workshop .grading-report tr.published
td.submission{background-color:#d2ebff}.path-mod-workshop .grading-report tr.published td.submission
a{font-weight:bold}.path-mod-workshop .grading-report
.assessmentdetails{white-space:nowrap}.path-mod-workshop .grading-report .receivedgrade span.grade,
.path-mod-workshop .grading-report .givengrade
span.gradinggrade{font-weight:bold}.path-mod-workshop .grading-report .submissiongrade.cell,
.path-mod-workshop .grading-report
.gradinggrade.cell{text-align:center;font-size:200%;white-space:nowrap}.path-mod-workshop .grading-report .givengrade.null .user,
.path-mod-workshop .grading-report .receivedgrade.null
.user{color:#e00}.path-mod-workshop #workshop-viewlet-yourgrades
.finalgrades{text-align:center}.path-mod-workshop #workshop-viewlet-yourgrades .finalgrades
.grade{border:1px
solid #ddd;margin:1em;padding:2em;display:inline-block;-webkit-border-radius:15px;-moz-border-radius:15px;border-radius:15px}.path-mod-workshop #workshop-viewlet-yourgrades .finalgrades
.grade.submissiongrade{background-color:#d2ebff}.path-mod-workshop #workshop-viewlet-yourgrades .finalgrades
.grade.assessmentgrade{background-color:#eee}.path-mod-workshop #workshop-viewlet-yourgrades .finalgrades .grade
.gradevalue{font-weight:bold;font-size:x-large;margin:10px}#mod-workshop-editform fieldset.fgroup
*{vertical-align:top}.path-mod-workshop
.feedback{border:1px
solid #ddd;margin:0px
auto 1em auto;width:100%}.path-mod-workshop .feedback
.header{position:relative;background-color:#ddd;padding:3px;min-height:35px}.path-mod-workshop .feedback .header
.title{margin:0px
0px 0px 40px}.path-mod-workshop .feedback .header
.picture{position:absolute;top:3px;left:3px}.path-mod-workshop .feedback
.content{padding:5px
10px}.path-mod-workshop
div.buttonsbar{text-align:center}.path-mod-workshop div.buttonsbar
.singlebutton{display:inline}.path-mod-workshop
.toolboxaction{margin-right:1em}.path-mod-workshop .toolboxaction,
.path-mod-workshop .toolboxaction .singlebutton,
.path-mod-workshop .toolboxaction .singlebutton form,
.path-mod-workshop .toolboxaction .singlebutton form
div{display:inline}.path-mod-workshop div.buttonwithhelp
div{display:inline}.path-mod-workshop
#evaluationmethodchooser{margin:2em
auto;text-align:center}.path-mod-workshop
.lastmodified{line-height:1.0em}.path-mod-workshop
.nothingfound{font-size:150%;color:#FF4500}.path-mod-workshop .workshop-risk-dataloss{vertical-align:text-bottom}.block_activity_results{text-align:center}.block_activity_results
h1{margin:4px;font-size:1.1em}.block_activity_results
table.grades{text-align:left;width:100%}.block_activity_results table.grades
.number{text-align:left;width:10%}.block_activity_results table.grades
.name{text-align:left;width:77%}.block_activity_results table.grades
.grade{text-align:right}.block_activity_results table.grades
caption{font-weight:bold;font-size:18px}.dir-rtl .block_activity_results
table.grades{text-align:right}.dir-rtl .block_activity_results table.grades
.number{text-align:right}.dir-rtl .block_activity_results table.grades
.name{text-align:right}.block_blog_tags
.s20{font-size:1.5em;font-weight:bold}.block_blog_tags
.s19{font-size:1.5em}.block_blog_tags
.s18{font-size:1.4em;font-weight:bold}.block_blog_tags
.s17{font-size:1.4em}.block_blog_tags
.s16{font-size:1.3em;font-weight:bold}.block_blog_tags
.s15{font-size:1.3em}.block_blog_tags
.s14{font-size:1.2em;font-weight:bold}.block_blog_tags
.s13{font-size:1.2em}.block_blog_tags .s12,
.block_blog_tags
.s11{font-size:1.1em;font-weight:bold}.block_blog_tags .s10,
.block_blog_tags
.s9{font-size:1.1em}.block_blog_tags .s8,
.block_blog_tags
.s7{font-size:1em;font-weight:bold}.block_blog_tags .s6,
.block_blog_tags
.s5{font-size:1em}.block_blog_tags .s4,
.block_blog_tags
.s3{font-size:0.9em;font-weight:bold}.block_blog_tags .s2,
.block_blog_tags
.s1{font-size:0.9em}#page-blocks-community-communitycourse
.hubscreenshot{float:left}#page-blocks-community-communitycourse
.hubtitlelink{color:#999}#page-blocks-community-communitycourse
.hubsmalllogo{padding-left:3px;padding-right:7px;float:left}#page-blocks-community-communitycourse
.hubtext{display:block;width:68%;padding-left:165px}#page-blocks-community-communitycourse
.hubimgandtext{display:table}#page-blocks-community-communitycourse
.hubimage{float:left;display:block;width:100px}#page-blocks-community-communitycourse
.hubdescriptiontext{}#page-blocks-community-communitycourse
.hubstats{padding-top:10px}#page-blocks-community-communitycourse .hubstats
.iconhelp{float:left;padding-right:3px}#page-blocks-community-communitycourse
.hubadditionaldesc{color:#666;font-size:90%;display:block}#page-blocks-community-communitycourse
.hubscreenshot{margin-right:10px}#page-blocks-community-communitycourse
.hubnottrusted{}#page-blocks-community-communitycourse
.hubtrusted{display:inline}#page-blocks-community-communitycourse
.hubnottrusted{}#page-blocks-community-communitycourse
.trustedtr{background-color:#ffe1c3}#page-blocks-community-communitycourse
.prioritisetr{background-color:#ffd4ff}#page-blocks-community-communitycourse
.blockdescription{font-size:80%;color:#555}#page-blocks-community-communitycourse
.trusted{font-size:90%;color:#063;font-weight:normal;font-style:italic}#page-blocks-community-communitycourse
.additionaldesc{font-size:80%;color:#8B8989}#page-blocks-community-communitycourse .comment-link{font-size:80%;color:#555}#page-blocks-community-communitycourse
.coursescreenshot{text-align:center;cursor:pointer}#page-blocks-community-communitycourse
.hubcourseinfo{margin-left:15px}#page-blocks-community-communitycourse
.coursesitelink{}#page-blocks-community-communitycourse
.pagingbar{text-align:center}#page-blocks-community-communitycourse
.coursecomment{float:right}#page-blocks-community-communitycourse
.courseoperations{margin-top:9px;text-align:center}#page-blocks-community-communitycourse .hubcoursedownload:hover{background-color:#CDC9C9}#page-blocks-community-communitycourse
.courselinks{float:right;width:180px}#page-blocks-community-communitycourse
.ratingaggregate{float:left;padding-right:4px}#page-blocks-community-communitycourse
.hubcourserating{padding-top:3px;font-size:80%;color:#555}#page-blocks-community-communitycourse
.coursedescription{width:70%;float:left}#page-blocks-community-communitycourse
.fullhubcourse{margin-bottom:20px}#page-blocks-community-communitycourse
.hubcoursetitlepanel{margin-bottom:6px}#page-blocks-community-communitycourse
.hubcourseresult{background:none repeat scroll 0 0 #FFF;clear:both;margin:30px
auto 0;z-index:90;width:95%;padding:10px
10px 10px 10px;border-style:solid;border-width:1px}#page-blocks-community-communitycourse
.hubcoursetitle{-webkit-box-shadow:rgba(0, 0, 0, 0.546875) 0px 0px 4px;-moz-box-shadow:rgba(0, 0, 0, 0.546875) 0px 0px 4px;background:#8B8989;left:-15px;position:relative;z-index:0;border:0px;margin:0px;outline:0px;padding:0px;vertical-align:baseline;color:#fff;padding-top:6px;padding-bottom:6px;text-shadow:1px 1px 2px rgba(0,0,0,0.2);text-align:left;font-style:italic;font-weight:normal;line-height:1.2em;font-size:140%;width:102%;text-indent:15px}#page-blocks-community-communitycourse
.hubcoursedownload{display:inline-block;padding:5px
8px 6px;color:black;text-decoration:none;-moz-border-radius:6px;-webkit-border-radius:6px;-moz-box-shadow:0 1px 3px rgba(0,0,0,0.6);-webkit-box-shadow:0 1px 3px rgba(0,0,0,0.6);border-bottom:1px solid rgba(0,0,0,0.25);position:relative;cursor:pointer;background-color:#EEE9E9;margin-left:6px;font-size:95%;margin-bottom:9px}#page-blocks-community-communitycourse .comment-list
li{background-color:#FFFAFA !important;-moz-border-radius:6px;-webkit-border-radius:6px;padding-right:4px;padding-bottom:2px}#page-blocks-community-communitycourse
.ratingcount{color:#8B8989;font-size:80%;vertical-align:top}#page-blocks-community-communitycourse
.norating{font-weight:bold;color:#8B8989;font-size:80%}#page-blocks-community-communitycourse .star-rating{list-style:none;margin:4px
0 4px;padding:0px;width:100px;height:20px;position:relative;background:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=i%2Fstar-rating) top left repeat-x;float:left}#page-blocks-community-communitycourse .star-rating
li{padding:0px;margin:0px;height:20px;width:20px;float:left}#page-blocks-community-communitycourse .star-rating li.current-rating{background:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=i%2Fstar-rating) left bottom;position:absolute;height:20px;display:block;text-indent:-9000px;z-index:1}#page-blocks-community-communitycourse
.nocomments{font-weight:bold;color:#8B8989;font-size:80%}#page-blocks-community-communitycourse
.hubcommentator{float:left;font-weight:bold}#page-blocks-community-communitycourse
.hubcommentdate{font-weight:bold}#page-blocks-community-communitycourse
.hubcommenttext{margin-bottom:10px}#page-blocks-community-communitycourse
.hubnoscriptcoursecomments{margin-left:5px}#page-blocks-community-communitycourse .yui3-overlay-loading{top:-1000em;left:-1000em;position:absolute;z-index:1000}#page-blocks-community-communitycourse
.hubcoursecomments{display:inline-block;padding:3px
3px 3px 3px;color:white;text-decoration:none;-moz-border-radius:6px;-webkit-border-radius:6px;position:relative;cursor:pointer;background-color:#8B8989;margin-left:0px;font-size:80%;margin-top:15px}#page-blocks-community-communitycourse
.hubrateandcomment{font-size:80%}#page-blocks-community-communitycourse
.hubcourseoutcomes{}#page-blocks-community-communitycourse
.nextlink{text-align:center;margin-top:6px}#page-blocks-community-communitycourse
.textinfo{text-align:center}#ss-mask{z-index:10;position:fixed;top:0;left:0;bottom:0;right:0;opacity:0.35;filter:alpha(opacity=35);background:#000}.hiddenoverlay{display:none;text-align:center}.imagearrow{font-size:120%;display:inline;cursor:pointer}.imagetitle{display:inline;cursor:pointer}#page-blocks-community-communitycourse .moodle-dialogue-base .moodle-dialogue{-moz-border-radius:12px 12px 12px 12px;-moz-box-shadow:0 1px 3px rgba(0, 0, 0, 0.6);-webkit-border-radius:12px 12px 12px 12px;-webkit-box-shadow:0 1px 3px rgba(0, 0, 0, 0.6);border-width:0 0 0 0}#page-blocks-community-communitycourse .moodle-dialogue-base .moodle-dialogue-wrap{-moz-border-radius:12px 12px 0px 0px;-webkit-border-radius:12px 12px 0px 0px;background-color:#FFF;border:1px
solid #555}#page-blocks-community-communitycourse .moodle-dialogue-base .moodle-dialogue-hd{-moz-border-radius:12px 12px 0 0;-webkit-border-radius:12px 12px 0 0;background-color:#F6F6F6;border:1px
solid #CCC;overflow:auto;padding:7px
6px}#page-blocks-community-communitycourse .moodle-dialogue-base .moodle-dialogue-bd{padding:0px;margin-bottom:-5px}#page-blocks-community-communitycourse .moodle-dialogue-base
.closebutton{margin-top:4px;margin-right:4px}.block_course_list
.footer{margin-top:5px}.block_course_list .content
li{margin-bottom: .3em}.block_course_overview
.coursechildren{font-weight:normal;font-style:italic}.block_course_overview
.categorypath{text-align:right}.dir-rtl .block_course_overview
.categorypath{text-align:left}.block_course_overview
.content{margin:0
20px}.block_course_overview .content
.notice{margin:5px
0}.block_course_overview
.coursebox{padding:15px;width:auto}.block_course_overview
.profilepicture{float:left}.dir-rtl.block_course_overview
.profilepicture{float:right}.block_course_overview
.welcome_area{width:100%;padding-bottom:5px}.block_course_overview
.welcome_message{float:left;padding:10px;vertical-align:middle;border-collapse:separate;clear:none}.dir-rtl .block_course_overview
.welcome_message{float:right}.block_course_overview .content
h2.title{float:left;margin:0
0 .5em 0;position:relative}.dir-rtl .block_course_overview .content
h2.title{float:right}.block_course_overview
.course_title{position:relative}.editing .block_course_overview .coursebox
.cursor{cursor:move;margin-bottom:2px}.editing .block_course_overview
.move{float:left;padding:2px
10px 0 0}.dir-rtl.editing .block_course_overview
.move{float:right;padding:2px
10px}.block_course_overview
.course_list{width:100%}.block_course_overview
div.flush{clear:both}.block_course_overview
.activity_info{clear:both}.dir-rtl .block_course_overview
.activity_info{margin-right:25px}.block_course_overview
.activity_overview{padding:2px}.block_course_overview .activity_overview
img.iconlarge{vertical-align:text-bottom;margin-right:6px}.dir-rtl .block_course_overview .activity_overview
img.iconlarge{margin-left:6px;margin-right:0}.block_course_overview
.singleselect{text-align:left;margin:0}.dir-rtl .block_course_overview
.singleselect{text-align:right}.block_course_overview .content .course_list
.movehere{margin-bottom:15px}.block_course_summary
.content{padding:10px}.block_course_summary
.editbutton{text-align:right}.block_globalsearch
.searchform{text-align:center}.block_globalsearch
.footer{text-align:center}.block_lp.block .content
h3{padding:0;text-transform:none}.block_lp .sub-content{padding:0
15px}.block_lp
ul{list-style:none;margin:0}.block_lp ul
.more{padding-top:10px}.block_messages
.content{text-align:left;padding-top:5px}.block_messages .content .list
li.listentry{clear:both}.block_messages .content .list li.listentry
.user{float:left;position:relative}.block_messages .content .list li.listentry
.message{float:right}.block_messages .content
.info{text-align:center}.block_messages .content
.footer{clear:both}.dir-rtl .block_messages .content .list li.listentry
.user{float:right}.dir-rtl .block_messages .content .list li.listentry
.message{float:left}.block_myprofile
img.profilepicture{height:100px;width:100px}.block_myprofile
.myprofileitem.fullname{font-size:1.5em;font-weight:bold}.block_myprofile
.myprofileitem.edit{text-align:right}.block_navigation .block_tree .depth_1>.tree_item.branch{padding-left:0;background-image:none}.block_navigation .block_tree .depth_1>ul{margin:0}.block_navigation .block_tree
ul{margin-left:18px}.block_navigation .block_tree
p.hasicon{text-indent:-21px;padding-left:21px}.block_navigation .block_tree p.hasicon
img{width:16px;height:16px;margin-top:3px;margin-right:5px;vertical-align:top}.block_navigation .block_tree
p.hasicon.visibleifjs{display:block}.block_navigation .block_tree
.tree_item{cursor:pointer;padding-left:0;margin:3px
0px;background-position:0 50%;background-repeat:no-repeat}.block_navigation .block_tree
.tree_item.branch{padding-left:21px}.block_navigation .block_tree
.active_tree_node{font-weight:bold}.block_navigation .block_tree [aria-expanded="true"]{background-image:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fexpanded')}.block_navigation .block_tree [aria-expanded="false"]{background-image:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fcollapsed')}.block_navigation .block_tree [aria-expanded="true"].emptybranch{background-image:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fcollapsed_empty')}.block_navigation .block_tree [aria-expanded="false"].loading{background-image:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=i%2Floading_small')}.block_navigation .block_tree [aria-hidden="false"]{display:block}.block_navigation .block_tree  [aria-hidden="true"]{display:none}.ie6 .block_navigation .block_tree
.tree_item{width:100%}.dir-rtl .block_navigation .block_tree
p.hasicon{padding-left:0px;padding-right:21px}.dir-rtl .block_navigation .block_tree
.tree_item{background-position:100% 50%}.dir-rtl .block_navigation .block_tree
.tree_item.branch{padding-right:21px;padding-left:0}.dir-rtl .block_navigation .block_tree [aria-expanded="false"]{background-image:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fcollapsed_rtl')}.dir-rtl .block_navigation .block_tree [aria-expanded="true"].emptybranch{background-image:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fcollapsed_empty_rtl')}.dir-rtl .block_navigation .block_tree [aria-expanded="false"].loading{background-image:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=i%2Floading_small')}.dir-rtl .block_navigation .block_tree .tree_item
img{margin-right:0;margin-left:5px}.dir-rtl .block_navigation .block_tree
ul{margin:0
16px 0 0}.block_online_users .content .list
li.listentry{clear:both}.block_online_users .content .list li.listentry
.user{float:left;position:relative}.block_online_users .content .list li.listentry .user
.userpicture{vertical-align:text-bottom}.block_online_users .content .list li.listentry
.message{float:right;margin-top:3px}.block_online_users .content
.info{text-align:center}.dir-rtl .block_online_users .content .list li.listentry
.user{float:right}.dir-rtl .block_online_users .content .list li.listentry
.message{float:left}.block_private_files .content
table{table-layout:fixed;width:100%}.block_private_files .content
.footer{padding:10px
0 0;margin-top: .5em}.block_recent_activity .activitydate,
.block_recent_activity
.activityhead{text-align:center}.block_recent_activity .unlist
li{margin-bottom:1em}.block_recent_activity li .head
.date{float:right}.dir-rtl .block_recent_activity .content
h3{text-align:right}.block_rss_client .list li:first-child{border-top-width:0}.block_rss_client .list
li{border-top:1px solid;padding:5px}.block_search_forums
.searchform{text-align:center}.block_search_forums .searchform
img{vertical-align:middle}.block_search_forums .searchform
img.resize{width:1em;height:1.1em}.block_search_forums
.invisiblefieldset{display:block}.block_settings .block_tree
ul{margin-left:18px}.block_settings .block_tree
p.hasicon{text-indent:-21px;padding-left:21px}.block_settings .block_tree p.hasicon
img{width:16px;height:16px;margin-top:3px;margin-right:5px;vertical-align:top}.block_settings .block_tree
p.hasicon.visibleifjs{display:block}.block_settings .block_tree
.tree_item.branch{padding-left:21px}.block_settings .block_tree
.tree_item{cursor:pointer;margin:3px
0px;background-position:0 50%;background-repeat:no-repeat}.block_settings .block_tree
.active_tree_node{font-weight:bold}.block_settings .block_tree [aria-expanded="true"]{background-image:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fexpanded')}.block_settings .block_tree [aria-expanded="false"]{background-image:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fcollapsed')}.block_settings .block_tree [aria-expanded="true"].emptybranch{background-image:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fcollapsed_empty')}.block_settings .block_tree [aria-expanded="false"].loading{background-image:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=i%2Floading_small')}.block_settings .block_tree [aria-hidden="false"]{display:block}.block_settings .block_tree  [aria-hidden="true"]{display:none}.ie6 .block_settings .block_tree
.tree_item{width:100%}.dir-rtl .block_settings .block_tree
p.hasicon{padding-left:0px;padding-right:21px}.dir-rtl .block_settings .block_tree
.tree_item{background-position:100% 50%}.dir-rtl .block_settings .block_tree
.tree_item.branch{padding-right:21px;padding-left:0}.dir-rtl .block_settings .block_tree [aria-expanded="false"]{background-image:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fcollapsed_rtl')}.dir-rtl .block_settings .block_tree [aria-expanded="true"].emptybranch{background-image:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fcollapsed_empty_rtl')}.dir-rtl .block_settings .block_tree [aria-expanded="false"].loading{background-image:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=i%2Floading_small')}.dir-rtl .block_settings .block_tree .tree_item
img{margin-right:0;margin-left:5px}.dir-rtl .block_settings .block_tree
ul{margin:0
16px 0 0}.block_site_main_menu
li{clear:both}.block_site_main_menu.block.list_block .unlist>li>.column{width:100%;display:table}.block_site_main_menu li
.buttons{float:right;margin:0;padding:0;border:0;background-color:inherit}.dir-rtl .block_site_main_menu li
.buttons{float:left}.block_site_main_menu li .buttons a
img{vertical-align:text-bottom}.block_site_main_menu
.footer{margin-top:1em}.block_site_main_menu .section_add_menus noscript
div{display:inline}.block_site_main_menu .mod-indent,
.block_site_main_menu .main-menu-content{display:table-cell}.block_social_activities
li{clear:both}.block_social_activities li
.column{width:100%}.block_social_activities li
.buttons{float:right;margin:0}.dir-rtl .block_social_activities li
.buttons{float:left}.block_social_activities li .buttons a
img{vertical-align:text-bottom}.block_tag_flickr .flickr-photos{padding:3px}.block_tag_youtube .youtube-thumb{padding:3px;padding-bottom:0.5em;display:block;float:left}.block_tag_youtube .yt-video-entry
li{clear:left}#glossaryfilteroverlayprogress{position:fixed;top:50%;width:100%;text-align:center}.jsenabled
#MathJax_ZoomFrame{position:absolute}.mediaplugin_html5audio,.mediaplugin_html5video,.mediaplugin_swf,.mediaplugin_flv,.mediaplugin_real,.mediaplugin_youtube,.mediaplugin_vimeo,.mediaplugin_wmp,.mediaplugin_qt{display:block;margin-top:5px;margin-bottom:5px;text-align:center}.mediaplugin.mediaplugin_mp3
object{display:inline;height:15px;width:180px;margin-left:0.5em}.mp3flowplayer_backgroundColor{color:#000}.editor_atto_content_wrap{background-color:white;color:#333}.editor_atto_content{padding:4px;resize:vertical;overflow:auto}.editor_atto_content_wrap,.editor_atto+textarea{width:100%;padding:0;border:1px
solid #BBB;border-top:none}.editor_atto+textarea{border-radius:0;resize:vertical;margin-top:-1px}div.editor_atto_toolbar{display:block;background:#F2F2F2;min-height:35px;border:1px
solid #BBB;width:100%;padding:0
0 9px 0}div.editor_atto_toolbar
button{padding:4px
9px;background:none;border:0;margin:0;border-radius:0;cursor:pointer;line-height:initial}div.editor_atto_toolbar button+button{border-left:1px solid #CCC}div.editor_atto_toolbar button[disabled]{opacity: .45;background:none;cursor:default}.editor_atto_toolbar button:hover{background-image:radial-gradient(ellipse at center, #fff 60%,#dfdfdf 100%);background-color:#ebebeb}.editor_atto_toolbar button:active, .editor_atto_toolbar
button.highlight{background-image:radial-gradient(ellipse at center, #fff 40%,#dfdfdf 100%);background-color:#dfdfdf}div.editor_atto_toolbar button::-moz-focus-inner{border:0;padding:0}div.editor_atto_toolbar button
img.icon{padding:0px;margin:2px
0;vertical-align:text-bottom;width:auto;height:auto}div.editor_atto_toolbar
div.atto_group{display:inline-block;border:1px
solid #CCC;border-bottom:1px solid #B3B3B3;border-radius:4px;margin:9px
0 0 9px;background:#FFF}.editor_atto_content
img{resize:both;overflow:auto}.atto_hasmenu{white-space:nowrap}.atto_menuentry
img{width:16px;height:16px}.atto_menuentry{clear:left}.atto_menuentry h1,
.atto_menuentry h2,
.atto_menuentry
p{margin:4px}.atto_form
label.sameline{display:inline-block;min-width:10em}.atto_form textarea.fullwidth,
.atto_form
input.fullwidth{width:100%}.atto_form{padding-left:30px;padding-right:30px}.atto_form
label{display:block;margin:0
0 5px 0}body.dir-rtl div.editor_atto_toolbar button+button{border-left:0;border-right:1px solid #CCC}body.dir-rtl div.editor_atto_toolbar
img.icon{padding:0}body.dir-rtl div.editor_atto_toolbar
div.atto_group{margin:9px
9px 0 0}.atto_control{position:absolute;right:-6px;bottom:-6px;display:none;cursor:pointer}.atto_control
img{background-color:white}div.editor_atto_content:focus .atto_control,
div.editor_atto_content:hover
.atto_control{display:block}.editor_atto_menu.yui3-menu-hidden{display:none}.editor_atto_content img:-moz-broken{-moz-force-broken-image-icon:1;min-width:24px;min-height:24px}.moodle-dialogue-base .editor_atto_menu .moodle-dialogue-content .moodle-dialogue-bd{padding:0;z-index:1000}.editor_atto_menu .dropdown-menu>li>a{padding:3px
14px}.editor_atto_menu .open ul.dropdown-menu{padding-top:5px;padding-bottom:5px}.editor_atto_wrap{position:relative}.dir-rtl .editor_atto_wrap
textarea{direction:ltr}.editor_atto_notification{position:absolute;bottom:-1.5em;height:1.5em;margin-top:1px;cursor:pointer}.editor_atto_notification .atto_info,
.editor_atto_notification
.atto_warning{display:inline-block;background-color:#F2F2F2;padding:0.5em;padding-left:1em;padding-right:1em;border-bottom-left-radius:1em;border-bottom-right-radius:1em}.editor_atto_notification
.atto_info{background-color:#F2F2F2}.editor_atto_notification
.atto_warning{background-color:#FFD700}.editor_atto_toolbar,.editor_atto_content_wrap,.editor_atto+textarea{box-sizing:border-box}.dir-rtl .editor_atto_notification .atto_info,
.dir-rtl .editor_atto_notification
.atto_warning{border-bottom-right-radius:1em;border-bottom-left-radius:1em}.dir-ltr
.editor_atto_notification{right:0}.dir-rtl
.editor_atto_notification{left:0}@media (max-width: 480px){.mceToolbar
td{float:left;display:inline-block}.moodleSkin .mceLayout .mceToolbar
.mceWrap{clear:left;width:100%;height:4px}.moodleSkin .mceLayout .mceToolbar
.mceNoWrap{clear:none;width:0px}.o2k7Skin tr.mceLast .mceToolbar tr td.mceWrap,
.o2k7Skin tr.mceFirst .mceToolbar tr
td.mceWrap{margin-left:-3px}.dir-rtl .o2k7Skin tr.mceLast .mceToolbar tr td.mceWrap,
.dir-rtl .o2k7Skin tr.mceFirst .mceToolbar tr
td.mceWrap{margin-left:0px}}.format-singleactivity .tree_item.orphaned
a{color:red}.course-content
ul.topics{margin:0}.course-content ul.topics
li.section{list-style:none;margin:0
0 5px 0;padding:0}.course-content ul.topics li.section
.content{margin:0
40px}.course-content ul.topics li.section .left,
.course-content ul.topics li.section
.right{width:40px;padding:0
6px}.course-content ul.topics li.section .right
img.icon{padding:0
0 4px 0}.course-content ul.topics li.section
.left{padding-top:22px;text-align:right}.jsenabled .course-content ul.topics li.section .left,
.jsenabled .course-content ul.topics li.section
.right{width:auto}.course-content ul.topics li.section .left .section-handle
img.icon{padding:0;vertical-align:baseline}.course-content ul.topics li.section .section_action_menu .textmenu,
.course-content ul.topics li.section .section_action_menu .menu-action-text{white-space:nowrap}.course-content
ul.weeks{margin:0}.course-content ul.weeks
li.section{list-style:none;margin:0
0 5px 0;padding:0}.course-content ul.weeks li.section
.content{margin:0
40px}.course-content ul.weeks li.section .left,
.course-content ul.weeks li.section
.right{width:40px;padding:0
6px}.course-content ul.weeks li.section .right
img.icon{padding:0
0 4px 0}.course-content ul.weeks li.section
.left{padding-top:22px;text-align:right}.jsenabled .course-content ul.weeks li.section .left,
.jsenabled .course-content ul.weeks li.section
.right{width:auto}.course-content ul.weeks li.section .left .section-handle
img.icon{padding:0;vertical-align:baseline}.course-content ul.weeks li.section .section_action_menu .textmenu,
.course-content ul.weeks li.section .section_action_menu .menu-action-text{white-space:nowrap}.dir-rtl.path-report-competency [data-region="competency-breakdown-report"] .row-fluid [class*="span"]{float:right}.dir-rtl.path-report-competency .pull-left{float:right}.dir-rtl.path-report-competency .pull-right{float:left}.dir-rtl.path-report-competency
dd{margin-right:10px}.dir-rtl.path-report-competency
ul.inline{margin-right:0}.dir-rtl.path-report-competency .table th,
.dir-rtl.path-report-competency .table
td{text-align:right}#page-report-completion-index table#completion-progress{margin-top:20px;margin-bottom:30px}#page-report-completion-index .export-actions{text-align:center;list-style:none}#page-report-completion-index.dir-rtl #completion-progress th
svg{direction:ltr}.report-eventlist-name{color:#888;font-size:0.75em}.report-eventlist-datatable-table>div>table{width:100%}#page-admin-report-eventlist-index
dt{float:left;text-align:right;width:20em}#page-admin-report-eventlist-index
dd{display:block;text-align:left;margin-left:21em}#page-admin-report-eventlist-index dd+dd{clear:left}@media (max-width : 767px){#page-admin-report-eventlist-index
dt{width:100%;text-align:left}#page-admin-report-eventlist-index
dd{margin-left:0}#page-admin-report-eventlist-index dd+dd{margin-left:0}}#page-admin-report-eventlist-index.dir-rtl
dt{float:right;text-align:left;width:20em}#page-admin-report-eventlist-index.dir-rtl
dd{display:block;text-align:right;margin-right:22em}#page-admin-report-eventlist-index.dir-rtl dd+dd{clear:right}@media (max-width : 767px){#page-admin-report-eventlist-index.dir-rtl
dt{width:100%;text-align:right}#page-admin-report-eventlist-index.dir-rtl
dd{margin-right:0em}#page-admin-report-eventlist-index.dir-rtl dd+dd{margin-right:0em}}#page-report-log-index
.info{margin:10px}#page-report-log-index
.logselectform{margin:10px
auto}#page-report-log-user
.info{margin:10px;text-align:center}#page-report-log-user
.graph{text-align:center}#page-report-loglive-index
.info{margin:10px}table.flexible>tbody>tr:nth-child(n).newrow>td{background:#D4D4D4}#page-report-outline-index
td.numviews{text-align:right}#page-report-outline-index
tr.section{text-align:center}#page-report-outline-index
td.lastaccess{font-size:0.8em}#page-report-outline-user .section
.content{margin-left:30px;margin-right:30px}#page-report-outline-user .section
h2{margin-top:0}#page-report-outline-user
.section{margin-left:30px;margin-right:30px;margin-bottom:20px}#page-report-outline-user
.section{border-width:1px;border-style:solid;padding:10px}#page-report-participation-index
.participationselectform{margin:10px
auto}#page-report-participation-index .participationselectform
label{margin-left:15px;margin-right:5px}#page-report-progress-index #completion-progress th,
#page-report-progress-index #completion-progress
td{padding:2px
4px;font-weight:normal;border-right:1px solid #EEE}#page-report-progress-index .progress-actions{text-align:center;list-style:none}#page-report-progress-index
.completion_pagingbar{margin:1em
0;text-align:center}#page-report-progress-index
.completion_prev{display:inline;margin-right:2em}#page-report-progress-index .completion_pagingbar
p{display:inline;margin:0}#page-report-progress-index
.completion_next{display:inline;margin-left:2em}#page-report-progress-index.dir-rtl #completion-progress th
svg{direction:ltr}#page-report-stats-index
.graph{margin-bottom:1em}.gradeimport_data_area{margin:0px
0px 10px;width:475px;height:209px}.path-grade-report-grader
.gradeparent{position:relative}.path-grade-report-grader .gradeparent .grader-information-tooltip{min-width:200px}.path-grade-report-grader .gradeparent
.graderreportoverlay{background-color:white;width:auto;padding:10px;font-size:12px;border:1px
solid #ccc;border-radius:4px}.path-grade-report-grader .gradeparent
table{border:1px
solid #ccc;border-collapse:separate;border-spacing:0;border-bottom-width:0;border-right-width:0;margin-bottom:2em}.dir-rtl.path-grade-report-grader .gradeparent
table{border-left-width:0;border-right-width:1px;max-width:initial}.path-grade-report-grader .gradeparent
.cell{border:1px
solid #ccc;border-top-width:0;border-left-width:0;padding:4px
5px;vertical-align:middle;text-align:right;white-space:nowrap}.dir-rtl.path-grade-report-grader .gradeparent
.cell{border-left-width:1px;border-right-width:0;text-align:left}.path-grade-report-grader .gradeparent tr:nth-of-type(even) .cell{background-color:#f9f9f9}.path-grade-report-grader .gradeparent
.floater{display:none}.path-grade-report-grader .gradeparent
.floating{display:block}.path-grade-report-grader .gradeparent .heading .cell,
.path-grade-report-grader .gradeparent .avg .cell,
.path-grade-report-grader .gradeparent
.user.cell{font-size:14px;font-weight:normal;text-align:left}.dir-rtl.path-grade-report-grader .gradeparent .heading .cell,
.dir-rtl.path-grade-report-grader .gradeparent .avg .cell,
.dir-rtl.path-grade-report-grader .gradeparent
.user.cell{text-align:right}.path-grade-report-grader .gradeparent .floater
.cell{background-color:#f9f9f9}.path-grade-report-grader .gradeparent
.user.cell{min-width:200px;width:200px;white-space:normal;vertical-align:top}.path-grade-report-grader .gradeparent .user.cell
.userpicture{margin:0
4px;border:none;vertical-align:middle}.path-grade-report-grader .gradeparent
.userfield{font-weight:normal;text-align:left}.dir-rtl.path-grade-report-grader .gradeparent
.userfield{text-align:right}.path-grade-report-grader .gradeparent .range .header,
.path-grade-report-grader .gradeparent .avg
.header{font-weight:bold}.path-grade-report-grader .gradeparent .avg.floating
.cell{border-top-width:1px}.path-grade-report-grader .gradeparent .avg
.cell{text-align:right}.dir-rtl.path-grade-report-grader .gradeparent .avg
.cell{text-align:left}.path-grade-report-grader .gradeparent .heading .cell
.iconsmall{padding-top:0;padding-bottom:0}.path-grade-report-grader .gradeparent
.sorticon{margin-left:3px}.dir-rtl.path-grade-report-grader .gradeparent
.sorticon{margin-left:0;margin-right:3px}.path-grade-report-grader .gradeparent
.gradevalue{display:inline-block}.path-grade-report-grader
span.gradepass{color:#298721}.path-grade-report-grader
span.gradefail{color:#890d0d}.path-grade-report-grader .gradeparent tr:nth-child(n) td.overridden:nth-child(n){background-color:#efd9a4}.path-grade-report-grader .gradeparent tr:nth-child(n) td.ajaxoverridden:nth-child(n){background-color:#ffe3a0}.path-grade-report-grader .gradeparent
.excludedfloater{font-weight:bold;color:red;font-size:9px;float:left}.dir-rtl.path-grade-report-grader .gradeparent
.excludedfloater{float:right}.path-grade-report .gradeparent .floater .controls.cell,
.path-grade-report-grader .gradeparent
.controls{background-color:#f3ead8}.path-grade-report-grader .gradeparent
.category{text-align:left}.dir-rtl.path-grade-report-grader .gradeparent
.category{text-align:right}.path-grade-report-grader .gradeparent
select{margin:0;padding:0}.path-grade-report-grader .gradeparent
.text{border:1px
solid #666;width:auto;margin:0;padding:0;text-align:center}.path-grade-report-grader .gradeparent
.quickfeedback{border:1px
dashed #000;width:auto;margin:0;padding:0;margin-left:10px}.dir-rtl.path-grade-report-grader .gradeparent
.quickfeedback{margin-left:0;margin-right:10px}.path-grade-report-grader .yui3-overlay{border:0;background:none;background-color:initial;min-width:200px}.path-grade-report-grader .yui3-overlay{background-color:white;width:auto;padding:10px;font-size:12px;border:1px
solid #ccc;border-radius:4px}.path-grade-report-history
div.gradeparent{overflow-x:scroll}.path-grade-report-history .singlebutton div,
.path-grade-report-history .singlebutton div input[type="button"]{margin:0}.yui3-gradereport_history_usp-hidden{display:none}.gradereport_history_usp .usp-content{position:relative}.gradereport_history_usp .usp-ajax-content{overflow:auto;border-top:1px solid #ccc;border-bottom:1px solid #ccc}.gradereport_history_usp .usp-ajax-content,
.gradereport_history_usp .usp-loading-lightbox{height:375px}.gradereport_history_usp .usp-loading-lightbox{background-color:#fff;opacity: .5;position:absolute;text-align:center;width:100%;top:0;left:0}.gradereport_history_usp .usp-loading-lightbox
img{margin-top:100px;opacity:1}.gradereport_history_usp .usp-search{text-align:center}.gradereport_history_usp .usp-user{width:100%;text-align:left;border-top:1px solid #eee}.gradereport_history_usp .usp-user:nth-child(odd){background-color:#f9f9f9}.gradereport_history_usp .usp-first-added{border-top:1px solid #bbb}.gradereport_history_usp .usp-checkbox{text-align:center;float:left;padding:11px
6px 0 6px}.gradereport_history_usp .usp-checkbox input[type=checkbox]{margin:0}.gradereport_history_usp .usp-picture{margin:6px
3px 0 3px;float:left}.gradereport_history_usp .usp-userpicture{cursor:pointer}.gradereport_history_usp .usp-user
.details{margin-left:67px;padding:3px
6px 0 6px;word-wrap:break-word}.gradereport_history_usp .usp-user .details
label{margin:0}.gradereport_history_usp .usp-more-results{padding:5px;border-top:1px solid #bbb}.gradereport_history_usp .usp-finish{padding-top:1em;text-align:center}.gradereport_history_usp .usp-finish
input{margin:0}.dir-rtl .gradereport_history_usp .usp-search-results .usp-user{text-align:right}.dir-rtl .gradereport_history_usp .usp-picture,
.dir-rtl .gradereport_history_usp .usp-checkbox{float:right}.dir-rtl .gradereport_history_usp .usp-user
.details{margin-right:67px;margin-left:0}.dir-rtl .gradereport_history_usp input.usp-search-btn{margin-right:5px}.path-grade-report-singleview
div.reporttable{text-align:center}.path-grade-report-singleview div.groupselector,
.path-grade-report-singleview div.reporttable form div.singleview_buttons,
.path-grade-report-singleview
div.selectitems{display:block;text-align:right;clear:both}.dir-rtl.path-grade-report-singleview div.groupselector,
.dir-rtl.path-grade-report-singleview div.reporttable form div.singleview_buttons,
.dir-rtl.path-grade-report-singleview
div.selectitems{text-align:left}.path-grade-report-singleview div.singleselect+div.singleselect select,
.path-grade-report-singleview div.groupselector
select{margin-right:0px}dir-rtl.path-grade-report-singleview div.singleselect+div.singleselect select,
dir-rtl.path-grade-report-singleview div.groupselector
select{margin-right:10px;margin-left:0px}.path-grade-report-singleview div.reporttable div.singleselect form
div{text-align:center}.path-grade-report-singleview div.reporttable
table.reporttable{margin:0
auto 15px auto}.path-grade-report-singleview div.reporttable form
div{text-align:center}.path-grade-report-singleview
.singleview_buttons{padding:10px
0}.path-grade-report-singleview div.reporttable
h2{text-align:center}.path-grade-report-singleview input[name^="finalgrade"]{width:50px}.path-grade-report-singleview .reporttable tbody th,
.path-grade-report-singleview .reporttable tbody
td.range{white-space:nowrap}.path-grade-report-singleview .reporttable tbody th>*{display:inline-block;vertical-align:middle;margin:0
2px}.path-grade-report-singleview
.itemnav{font-size:small;display:inline;margin-bottom:0.5em}.path-grade-report-singleview
itemnav.previtem{float:left}.path-grade-report-singleview.dir-rtl
div.previtem{float:right}.path-grade-report-singleview
div.nextitem{float:right}.path-grade-report-singleview.dir-rtl
div.nextitem{float:left}.path-grade-report-singleview
.reporttable{width:100%}.path-grade-report-singleview .reporttable
th{text-align:left}.dir-rtl.path-grade-report-singleview .reporttable
th{text-align:right}.path-grade-report-singleview div.reporttable form
div.singleview_bulk{display:inline-block;text-align:left;margin-bottom:1em}.dir-rtl.path-grade-report-singleview div.reporttable form
div.singleview_bulk{text-align:right}.path-grade-report-singleview .singleview_bulk div > *,
.path-grade-report-singleview .singleview_bulk fieldset>*{display:inline-block;vertical-align:middle;margin:0}.path-grade-report-singleview .singleselect select,
.path-grade-report-singleview div.reporttable form .singleview_bulk select,
.path-grade-report-singleview div.reporttable form .singleview_bulk
input{margin-left:10px;margin-right:10px}.path-grade-report-singleview .singleview_bulk>fieldset{display:block}.path-grade-report-singleview div.reporttable form .singleview_bulk>div.enable{margin-bottom:0.5em;text-align:left}.dir-rtl.path-grade-report-singleview div.reporttable form .singleview_bulk>div.enable{text-align:right}.path-grade-report-user
#graded_users_selector{float:right;margin-bottom:5px}.path-grade-report-user #graded_users_selector .singleselect
label{display:inline-block}.path-grade-report-user .user-grade{width:100%;border:1px
solid}.path-grade-report-user .user-grade thead
th{vertical-align:bottom}.path-grade-report-user .user-grade
th{text-align:left}.path-grade-report-user .user-grade
td{min-width:4.5em;vertical-align:top}.dir-rtl.path-grade-report-user .user-grade
td{direction:ltr}.dir-rtl.path-grade-report-user table.user-grade{border-collapse:separate}.path-grade-report-user .user-grade
.b1l{padding:0;width:24px;min-width:24px}.path-grade-report-user .user-grade tbody .column-itemname{padding-left:0;padding-right:8px}.path-grade-report-user .user-grade .column-itemname.item,
.path-grade-report-user .user-grade
.gradeitemdescription{font-weight:normal;padding-left:24px}.path-grade-report-user .user-grade .column-itemname.baggt,
.path-grade-report-user .user-grade .column-itemname.baggb{padding-left:24px}.path-grade-report-user .user-grade .baggt,
.path-grade-report-user .user-grade
.baggb{font-weight:bold}.dir-rtl.path-grade-report-user
#graded_users_selector{float:left}.dir-rtl.path-grade-report-user .user-grade
th{text-align:right}.dir-rtl.path-grade-report-user .user-grade tbody .column-itemname{padding-right:0;padding-left:8px}.dir-rtl.path-grade-report-user .user-grade .column-itemname.item,
.dir-rtl.path-grade-report-user .user-grade
.gradeitemdescription{padding-right:24px}.dir-rtl.path-grade-report-user .user-grade .column-itemname.baggt,
.dir-rtl.path-grade-report-user .user-grade .column-itemname.baggb{padding-right:24px}.gradingform_guide-regrade{padding:10px;background:#FDD;border:1px
solid #F00;margin-bottom:10px}.gradingform_guide-restored{padding:10px;background:#FFD;border:1px
solid #FF0;margin-bottom:10px}.gradingform_guide-error{color:red;font-weight:bold}.gradingform_guide_editform
.status{font-weight:normal;text-transform:uppercase;font-size:60%;padding:0.25em;border:1px
solid #EEE}.gradingform_guide_editform
.status.ready{background-color:#e7f1c3;border-color:#AEA}.gradingform_guide_editform
.status.draft{background-color:#f3f2aa;border-color:#EE2}.gradingform_guide.editor .criterion .controls,
.gradingform_guide .criterion .description,
.gradingform_guide .criterion
.remark{vertical-align:top}.gradingform_guide.editor .criterion .controls,
.gradingform_guide.editor .criterion .description,
.gradingform_guide.editor .criterion
.remark{padding:3px}.gradingform_guide
.criteria{height:100%}.gradingform_guide
.criterion{border:1px
solid #DDD;overflow:hidden}.gradingform_guide
.criterion.even{background:#F0F0F0}.gradingform_guide .criterion
.description{width:100%}.gradingform_guide .criterion .description .criterionmaxscore
input{width:20px}.gradingform_guide .criterion .description
.criterionname{font-weight:bold}.gradingform_guide .criterion
label{font-weight:bold;padding-right:5px}.gradingform_guide
.plainvalue.empty{font-style:italic;color:#AAA}.gradingform_guide
.plainvalue.editname{font-weight:bold}.gradingform_guide.editor .criterion.first.last .controls .delete input,
.gradingform_guide.editor .criterion.first .controls .moveup input,
.gradingform_guide.editor .criterion.last .controls .movedown
input{display:none}.gradingform_guide.editor .delete input,
.gradingform_guide.editor .moveup input,
.gradingform_guide.editor .movedown
input{text-indent:-1000em;cursor:pointer;border:none}.gradingform_guide.editor .criterion .controls .delete
input{width:20px;height:16px;background:transparent url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fdelete) no-repeat center top;margin-top:4px}.gradingform_guide.editor .moveup
input{width:20px;height:15px;background:transparent url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fup) no-repeat center top;margin-top:4px}.gradingform_guide.editor .movedown
input{width:20px;height:15px;background:transparent url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fdown) no-repeat center top;margin-top:4px}.gradingform_guide.editor .addcriterion input,
.gradingform_guide.editor .addcomment
input{background:transparent url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fadd) no-repeat;display:block;color:#555;font-weight:bold;text-decoration:none}.gradingform_guide.editor .addcriterion input,
.gradingform_guide.editor .addcomment
input{background-position:5px 8px;height:30px;line-height:29px;margin-bottom:14px;padding-left:20px;padding-right:10px}.gradingform_guide .options
.optionsheading{font-weight:bold;font-size:1.1em;padding-bottom:5px}.gradingform_guide .options
.option{padding-bottom:2px}.gradingform_guide .options .option
label{margin-left:5px}.gradingform_guide .options .option
.value{margin-left:5px;font-weight:bold}.gradingform_guide .criterion
.description.error{background:#FDD}.gradingform_guide.editor
.hiddenelement{display:none}.gradingform_guide.editor
.pseudotablink{background-color:transparent;border:0
solid;height:1px;width:1px;color:transparent;padding:0;margin:0;position:relative;float:right}.jsenabled .gradingform_guide
.markingguidecomment{cursor:pointer}.jsenabled .gradingform_guide .markingguidecomment:before{content:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fadd);padding-right:2px}.dir-rtl.jsenabled .gradingform_guide .markingguidecomment:before{padding-right:0;padding-left:2px}.gradingform_guide
.commentheader{font-weight:bold;font-size:1.1em;padding-bottom:5px}.jsenabled .gradingform_guide
.criterionnamelabel{display:none}.jsenabled .gradingform_guide
.criterionshortname{font-weight:bold}.gradingform_guide
table{width:100%}.gradingform_guide
.descriptionreadonly{vertical-align:top}.gradingform_guide
.criteriondescriptionmarkers{width:300px}.gradingform_guide
.markingguideremark{margin:0;width:100%;-moz-box-sizing:border-box;box-sizing:border-box}.gradingform_guide
.criteriondescriptionscore{display:inline}.gradingform_guide .score
label{display:block}.gradingform_guide .score
input{margin:0;width:auto}.gradingform_rubric_editform
.status{font-weight:normal;text-transform:uppercase;font-size:60%;padding:0.25em;border:1px
solid #EEE}.gradingform_rubric_editform
.status.ready{background-color:#e7f1c3;border-color:#AEA}.gradingform_rubric_editform
.status.draft{background-color:#f3f2aa;border-color:#EE2}.gradingform_rubric{overflow:auto;padding-bottom:1.5em;max-width:720px;position:relative}.gradingform_rubric.editor .criterion .controls,
.gradingform_rubric .criterion .description,
.gradingform_rubric .criterion .levels,
.gradingform_rubric.editor .criterion .addlevel,
.gradingform_rubric .criterion .remark,
.gradingform_rubric .criterion .levels
.level{vertical-align:top}.gradingform_rubric.editor .criterion .controls,
.gradingform_rubric .criterion .description,
.gradingform_rubric.editor .criterion .addlevel,
.gradingform_rubric .criterion .remark,
.gradingform_rubric .criterion .levels
.level{padding:3px}.gradingform_rubric
.criteria{height:100%}.gradingform_rubric
.criterion{border:1px
solid #DDD;overflow:hidden}.gradingform_rubric
.criterion.even{background:#F0F0F0}.gradingform_rubric .criterion
.description{width:150px;font-weight:bold}.gradingform_rubric .criterion .levels
table{width:100%;height:100%}.gradingform_rubric .criterion .levels,
.gradingform_rubric .criterion .levels table,
.gradingform_rubric .criterion .levels table
tbody{padding:0;margin:0}.gradingform_rubric .criterion .levels
.level{border-left:1px solid #DDD;max-width:150px}.gradingform_rubric .criterion .levels .level .level-wrapper{position:relative}.gradingform_rubric .criterion .levels
.level.last{border-right:1px solid #DDD}.gradingform_rubric
.plainvalue.empty{font-style:italic;color:#AAA}.gradingform_rubric.editor .criterion .levels .level
.delete{position:absolute;right:0}.gradingform_rubric .criterion .levels .level
.score{font-style:italic;color:#575;font-weight:bold;margin-top:5px;white-space:nowrap}.gradingform_rubric .criterion .levels .level .score
.scorevalue{padding-right:5px}.gradingform_rubric.editor .criterion.first .controls .moveup input,
.gradingform_rubric.editor .criterion.last .controls .movedown
input{display:none}.gradingform_rubric .criterion .levels
.level.currentchecked{background:#fff0f0}.gradingform_rubric .criterion .levels
.level.checked{background:#d0ffd0;border:1px
solid #555}.gradingform_rubric.evaluate .criterion .levels .level:hover{background:#30ff30}.gradingform_rubric.editor .delete input,
.gradingform_rubric.editor .duplicate input,
.gradingform_rubric.editor .moveup input,
.gradingform_rubric.editor .movedown
input{text-indent:-1000em;cursor:pointer;border:none}.gradingform_rubric.editor .criterion .controls .delete
input{width:12px;height:12px;background:transparent url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fdelete) no-repeat center top;margin: .3em .3em 0 .3em}.gradingform_rubric.editor .criterion .controls .duplicate
input{width:12px;height:12px;background:transparent url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fcopy) no-repeat center top;margin: .3em .3em 0 .3em}.gradingform_rubric.editor .levels .level .delete
input{width:12px;height:16px;background:transparent url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fdelete) no-repeat center center}.dir-rtl .gradingform_rubric.editor .levels .level .delete
input{margin-right: .45em;margin-left:0}.gradingform_rubric.editor .moveup
input{width:12px;height:12px;background:transparent url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fup) no-repeat center top;margin: .3em .3em 0 .3em}.gradingform_rubric.editor .movedown
input{width:12px;height:12px;background:transparent url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fdown) no-repeat center top;margin: .3em .3em 0 .3em}.gradingform_rubric.editor .addcriterion input,
.gradingform_rubric.editor .addlevel
input{background:transparent url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fadd) no-repeat top left;display:block;color:#555;font-weight:bold;text-decoration:none}.gradingform_rubric.editor .addcriterion
input{background-position:5px 8px;height:30px;line-height:29px;margin-bottom:14px;padding-left:20px;padding-right:10px}.gradingform_rubric.editor .addlevel
input{background-position:5px 5px;height:25px;line-height:24px;margin-bottom:45px;padding-left:18px;padding-right:8px}.gradingform_rubric .options
.optionsheading{font-weight:bold;font-size:1.1em;padding-bottom:5px}.gradingform_rubric .options
.option{padding-bottom:2px}.gradingform_rubric .options .option
label{margin-left:5px}.gradingform_rubric .options .option
.value{margin-left:5px;font-weight:bold}.gradingform_rubric .criterion
.levels.error{border:1px
solid red}.gradingform_rubric .criterion .description.error,
.gradingform_rubric .criterion .levels .level .definition.error,
.gradingform_rubric .criterion .levels .level
.score.error{background:#FDD}.gradingform_rubric-regrade{padding:10px;background:#FDD;border:1px
solid #F00;margin-bottom:10px}.gradingform_rubric-restored{padding:10px;background:#FFD;border:1px
solid #FF0;margin-bottom:10px}.gradingform_rubric-error{color:red;font-weight:bold}.gradingform_rubric.editor
.hiddenelement{display:none}.gradingform_rubric.editor
.pseudotablink{background-color:transparent;border:0
solid;height:1px;width:1px;color:transparent;padding:0;margin:0;position:relative;float:right}.path-admin-mnet-service-enrol
.singlebutton{text-align:center}.path-admin-mnet-service-enrol table.remotehosts,
.path-admin-mnet-service-enrol table.otherenrolledusers,
.path-admin-mnet-service-enrol
table.remotecourses{margin:0px
auto 1em auto}.path-admin-mnet-service-enrol table.remotecourses
th.categoryname{text-align:left;background-color:#f6f6f6}.path-admin-mnet-service-enrol table.remotecourses
td.c1{font-weight:bold}.path-admin-mnet-service-enrol table.remotecourses th.categoryname
img{margin-right:1em}.path-admin-mnet-service-enrol
.collapsibleregioncaption{font-size:110%;font-weight:bold;text-align:center}.path-admin-mnet-service-enrol
.collapsibleregioninner{border:1px
solid #ddd;padding:1em}.path-admin-mnet-service-enrol
.collapsibleregion.remotecourse.summary{margin:0px
10em}.path-admin-mnet-service-enrol
.roleassigntable{margin:1em
auto}.repository_alfresco .fp-toolbar .fp-tb-search{width:auto}.repository_alfresco .fp-toolbar .fp-tb-search .alfresco-workplace{width:140px;height:32px;padding:2px
1px 1px 1px;background-color:#fff;border-radius:4px;border-color:#bbb}.qbehaviour_deferredcbm_slightlyunderconfident,.qbehaviour_deferredcbm_slightlyoverconfident{font-weight:bold;color:#600}.qbehaviour_deferredcbm_underconfident,.qbehaviour_deferredcbm_overconfident{font-weight:bold;color:#c00}.qbehaviour_deferredcbm_judgementok{font-weight:bold;color:#080}.qbehaviour_deferredcbm_actual_percentage{font-weight:bold}.qbehaviour_deferredcbm_summary_heading{margin:0}.que.deferredcbm .certaintychoices input[type="radio"]{margin-left:0.5em}.que.deferredcbm .certaintychoices
label{white-space:nowrap}#page-admin-tool-assignmentupgrade-listnotupgraded .tool_assignmentupgrade_upgradetable
.c0{display:none}#page-admin-tool-assignmentupgrade-listnotupgraded.jsenabled .tool_assignmentupgrade_upgradetable
.c0{display:table-cell}#page-admin-tool-assignmentupgrade-listnotupgraded .tool_assignmentupgrade_upgradetable tr.selectedrow
td{background-color:#fec}#page-admin-tool-assignmentupgrade-listnotupgraded .tool_assignmentupgrade_upgradetable tr.unselectedrow
td{background-color:white}#page-admin-tool-assignmentupgrade-listnotupgraded .tool_assignmentupgrade_paginationform
.hidden{display:none}.steps-definitions{border-style:solid;border-width:1px;border-color:#BBB;padding:5px;margin:auto;width:50%}.steps-definitions
.step{margin:10px
0px 10px 0px}.steps-definitions
.stepdescription{color:#bf8c12}.steps-definitions
.steptype{color:#1467a6;margin-right:5px}.steps-definitions
.stepregex{color:#060}.path-admin-tool-capability
.comparisontable{margin-top:150px}.path-admin-tool-capability .comparisontable th,
.path-admin-tool-capability .comparisontable
td{vertical-align:middle;padding:0.4em 0.5em 0.3em}.path-admin-tool-capability .comparisontable thead
th{vertical-align:bottom;background:none}.path-admin-tool-capability .comparisontable thead th
div{position:relative}.path-admin-tool-capability .comparisontable thead th div>a{position:absolute;top:-1.75em;left:1em;width:150px;text-align:left;margin-bottom:1em;text-indent:-1.45em;-webkit-transform-origin:top left;-moz-transform-origin:top left;-ms-transform-origin:top left;-o-transform-origin:top left;-webkit-transform:rotate(315deg);-moz-transform:rotate(315deg);-ms-transform:rotate(315deg);-o-transform:rotate(315deg)}.path-admin-tool-capability .comparisontable tbody
th{background-color:#EEE;text-align:right;border:1px
solid #DFDFDF}.path-admin-tool-capability .comparisontable tbody th
span{display:block;color:#666;font-size:80%}.path-admin-tool-capability .comparisontable tbody
td{border:1px
solid #DFDFDF}.path-admin-tool-capability .comparisontable
.inherit{color:#666}.path-admin-tool-capability .comparisontable
.allow{background-color:#060;font-weight:bold;color:white}.path-admin-tool-capability .comparisontable
.prevent{background-color:#ad6704;font-weight:bold;color:white}.path-admin-tool-capability .comparisontable
.prohibit{background-color:#800;font-weight:bold;color:white}.coursearchiver_myformerror{background-color:#fdf5e6;border:2px
solid #800000;font-size:1.1em;font-weight:bold;margin:20px;padding:20px}.coursearchiver_myformconfirm{background-color:#f0f8ff;border:2px
solid #cacadc;font-size:1.1em;font-weight:bold;margin:20px;padding:20px;text-align:center}.coursearchiver_stats{background-color:#c0c0c0;border:1px
dotted #808080;color:#fff;font-size: .85em;padding:5px}.coursearchiver_error_text{background-color:whitesmoke;color:#800000;margin:5px;padding:5px}.coursearchiver_notice_text{background-color:yellow;color:black;margin:5px;padding:5px}.coursearchiver_completedmsg{background-color:whitesmoke;font-size:1.5em;font-weight:bold;padding:20px;text-align:center}.coursearchiver_alreadyhidden{opacity: .5}.coursearchiver_progress_bar{border:2px
solid black;box-sizing:border-box;margin-top:-64px;position:relative;text-align:center;width:100%}.coursearchiver_bar{background-color:red;font-size:3em;padding:20px
0}.mform .coursearchiver_checkbox
.fitem{margin:0;padding:4px}.path-admin-tool-coursearchiver .fdate_selector .form-group{display:inline-block}.path-admin-tool-coursearchiver
div.felement{display:flex !important}.path-admin-tool-coursearchiver .femptylabel>div:first-child{flex:0;padding-left:0px}.path-admin-tool-coursearchiver .femptylabel .form-group{margin: .5rem}.path-admin-tool-coursearchiver .btn-primary{margin:auto}.path-admin-tool-coursearchiver .form-check-input:not(#id_emptyonly){position:unset;vertical-align:middle}.path-admin-tool-customlang .langselectorbox,
.path-admin-tool-customlang fieldset.buttonsbar,
.path-admin-tool-customlang
.menu{margin:5px
auto;text-align:center}.path-admin-tool-customlang .menu .singlebutton,
.path-admin-tool-customlang .menu .singlebutton form,
.path-admin-tool-customlang .menu .singlebutton form
div{display:inline}.path-admin-tool-customlang
.mform.filterform{width:70%;margin-left:auto;margin-right:auto}.path-admin-tool-customlang .mform.filterform .fitem
.fitemtitle{width:30%}.path-admin-tool-customlang .mform.filterform .fitem
.felement{width:60%;margin-left:31%}.path-admin-tool-customlang
#translator{width:100%}.path-admin-tool-customlang #translator .standard,
.path-admin-tool-customlang #translator
.local{min-width:35%}.path-admin-tool-customlang #translator
.customized{background-color:#e7f1c3}.path-admin-tool-customlang #translator
.customized.outdated{background-color:#f3f2aa}.path-admin-tool-customlang #translator
.modified{background-color:#ffd3d9}.path-admin-tool-customlang #translator
.customized.modified{background-color:#d2ebff}.path-admin-tool-customlang #translator
textarea{width:100%;min-height:4em}.path-admin-tool-customlang #translator
.placeholderinfo{text-align:center;border:1px
dotted #ddd;background-color:#f6f6f6;margin-top:0.5em}#page-admin-tool-customlang-index
.continuebutton{margin-top:1em}.path-admin-tool-customlang #translator
.standard.master.cell.c2{word-break:break-all}.path-admin-tool-filetypes .generaltable .c0,
.path-admin-tool-filetypes .generaltable .c1,
.path-admin-tool-filetypes .generaltable .c2,
.path-admin-tool-filetypes .generaltable
th{white-space:nowrap}.path-admin-tool-filetypes .generaltable .deleted .c0
img{opacity:0.2}.path-admin-tool-filetypes .generaltable .deleted .c0
span{text-decoration:line-through}.path-admin-tool-filetypes .generaltable
.nonstandard{font-weight:bold}.path-admin-tool-filetypes .form-overridden{display:inline-block;margin-bottom:1em;padding:4px
6px}.path-admin-tool-health
div#healthnoproblemsfound{width:60%;margin:auto;padding:1em;border:1px
solid black;-moz-border-radius:6px}.path-admin-tool-health
dl.healthissues{width:60%;margin:auto}.path-admin-tool-health dl.critical dt,
.path-admin-tool-health dl.critical
dd{background-color:#a71501}.path-admin-tool-health dl.significant dt,
.path-admin-tool-health dl.significant
dd{background-color:#d36707}.path-admin-tool-health dl.annoyance dt,
.path-admin-tool-health dl.annoyance
dd{background-color:#dba707}.path-admin-tool-health dl.notice dt,
.path-admin-tool-health dl.notice
dd{background-color:#e5db36}.path-admin-tool-health dt.solution,
.path-admin-tool-health dd.solution,
.path-admin-tool-health
div#healthnoproblemsfound{background-color:#5BB83E !important}.path-admin-tool-health dl.healthissues dt,
.path-admin-tool-health dl.healthissues
dd{margin:0px;padding:1em;border:1px
solid black}.path-admin-tool-health dl.healthissues
dt{font-weight:bold;border-bottom:0;padding-bottom:0.5em}.path-admin-tool-health dl.healthissues
dd{border-top:0;padding-top:0.5em;margin-bottom:10px}.path-admin-tool-health dl.healthissues dd
form{margin-top:0.5em;text-align:right}.path-admin-tool-health
form#healthformreturn{text-align:center;margin:2em}.path-admin-tool-health dd.solution
p{padding:0px;margin:1em
0px}.path-admin-tool-health dd.solution
li{margin-top:1em}#page-admin-tool-installaddon-index
#installfromrepobox{text-align:center;padding-top:2em;padding-bottom:2em}#page-admin-tool-installaddon-index #installfromrepobox
.singlebutton{display:inline-block}#page-admin-tool-installaddon-index #installfromrepobox .singlebutton input[type=submit]{padding:1em}#page-admin-tool-langimport-index .generalbox
table{margin:auto;width:100%}#page-admin-tool-langimport-index .generalbox,
#page-admin-tool-langimport-index .generalbox
table{text-align:center}.path-admin-tool-lp [data-region="managecompetencies"] ul li,
.path-admin-tool-lp [data-region="plans"] ul li,
.path-admin-tool-lp [data-region="competencymovetree"] ul li,
.path-admin-tool-lp [data-region="competencylinktree"] ul
li{list-style-type:none}.path-admin-tool-lp
.progresstext{display:inline-block;vertical-align:top}.path-admin-tool-lp
.progress{width:100%;display:inline-block}.path-admin-tool-lp .progress
.bar{min-width:3em}.dir-rtl.path-admin-tool-lp .progress
.bar{float:right}.path-admin-tool-lp [data-region="managecompetencies"] ul[data-enhance="tree"],
.path-admin-tool-lp [data-region="plans"] ul[data-enhance="tree"],
.path-admin-tool-lp [data-region="competencylinktree"] ul[data-enhance="linktree"],
.path-admin-tool-lp [data-region="competencymovetree"] ul[data-enhance="movetree"]{border:1px
solid #ccc;box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);transition:border linear .2s,box-shadow linear .2s;border-radius:4px;padding-left:20px;padding-right:20px;margin-left:10px;margin-right:10px}.path-admin-tool-lp [data-region="managecompetencies"] ul,
.path-admin-tool-lp [data-region="plans"] ul,
.path-admin-tool-lp [data-region="competencylinktree"] ul,
.path-admin-tool-lp [data-region="competencymovetree"] ul{cursor:pointer}.path-admin-tool-lp [data-region="competencylinktree"] ul li>span,
.path-admin-tool-lp [data-region="competencymovetree"] ul li>span,
.path-admin-tool-lp [data-region="plans"] ul li>span,
.path-admin-tool-lp [data-region="managecompetencies"] ul li>span{padding-top:2px;padding-bottom:2px;padding-left:4px;padding-right:4px;border-radius:4px}.path-admin-tool-lp [data-region="competencylinktree"] ul [aria-selected="true"]>span,
.path-admin-tool-lp [data-region="competencymovetree"] ul [aria-selected="true"]>span,
.path-admin-tool-lp [data-region="plans"] ul [aria-selected="true"]>span,
.path-admin-tool-lp [data-region="managecompetencies"] ul [aria-selected="true"]>span{background-color:#dfdfdf}.path-admin-tool-lp [data-region="competencylinktree"] ul [tabindex="0"]>span,
.path-admin-tool-lp [data-region="competencymovetree"] ul [tabindex="0"]>span,
.path-admin-tool-lp [data-region="plans"] ul [tabindex="0"]>span,
.path-admin-tool-lp [data-region="managecompetencies"] ul [tabindex="0"]>span{border:2px
solid #0070a8}.path-admin-tool-lp [data-region="filtercompetencies"] input{margin-left:10px}.dir-rtl.path-admin-tool-lp [data-region="managecompetencies"] .row-fluid [class*="span"]{float:right}.path-admin-tool-lp [data-region="link-buttons"],
.path-admin-tool-lp [data-region="move-buttons"]{text-align:center}.path-admin-tool-lp [data-region="competencylinktree"]>ul{overflow-y:auto;height:400px}.dir-rtl.path-admin-tool-lp [data-region="filtercompetencies"] input{margin-right:10px}.path-admin-tool-lp
span.currentdragtarget{border:1px
dashed}.path-admin-tool-lp
.competencyactionsmenu{display:inline-block;vertical-align:text-top}.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-base"]{display:table;width:100%}.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-outcome"],
.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-type"]{display:table-row}.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-outcome"] label,
.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-type"] label{padding-right:10px}.dir-rtl.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-outcome"] label,
.dir-rtl.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-type"] label{padding-left:10px;padding-right:0}.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-outcome"] label,
.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-outcome"] select,
.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-type"] label,
.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-type"] select{display:table-cell}.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-outcome"] select,
.path-admin-tool-lp [data-region="competencyruleconfig"] [data-region="rule-type"] select,
.path-admin-tool-lp [data-region="competencylinktree"] select{width:100%}.path-admin-tool-lp [data-region] .generaltable.fullwidth{clear:both}.path-admin-tool-lp .competency-rule-points{margin-top:10px}.path-admin-tool-lp .competency-rule-points table
input{margin-bottom:0}.path-admin-tool-lp .competency-rule-points tr[data-competency] th{font-weight:normal}.path-admin-tool-lp .competency-rule-points input[type="number"]{width:50px}.competency-heading{margin-bottom:15px}.competency-heading
h4{margin:0}.tool-lp-menu{margin:0}.tool-lp-menu
li{float:left;display:inline;position:relative;list-style-type:none;white-space:nowrap}.tool-lp-sub-menu{position:absolute;list-style:none;margin:0;top:-10px}.tool-lp-sub-menu
li{float:none}.tool-lp-menu .tool-lp-sub-menu[aria-hidden=false]{display:block}.tool-lp-menu ul[aria-hidden=true]{display:none}.tool-lp-menu
.caret{margin:8px}.tool-lp-menu.tool-lp-menu-open-left .tool-lp-sub-menu{margin-left:-120px}.dir-rtl .tool-lp-menu.tool-lp-menu-open-left .tool-lp-sub-menu{margin-left:0px;margin-right:-120px}.tool-lp-menu .tool-lp-sub-menu .menu-focus
a{color:#fff;text-decoration:none;background-color:#00699e;background-image:linear-gradient(to bottom,#0070a8,#005f8f);background-repeat:repeat-x}input[type="radio"].tool_lp_scale_default,input[type="checkbox"].tool_lp_scale_proficient{margin-top:0px}.user-evidence-documents{margin:10px
20px;list-style:none}.user-evidence-competencies,
.user-evidence-documents
li{margin-bottom:5px;word-break:break-all}[data-region="user-evidence-list"] .user-evidence-competencies,
[data-region="user-evidence-list"] .user-evidence-documents{margin:0;list-style:none}.user-competency-course-navigation
select{display:none}.user-competency-course-navigation{width:240px}.user-competency-course-navigation
span{max-width:100%;overflow:hidden}.competency-grader
textarea{width:100%;max-width:100%;box-sizing:border-box}.dir-rtl.path-admin-tool-lp .pull-left{float:right}.dir-rtl.path-admin-tool-lp .pull-right{float:left}.dir-rtl.path-admin-tool-lp
dd{margin-right:10px}.dir-rtl.path-admin-tool-lp
ul.inline{margin-right:0}#page-admin-tool-messageinbound-index .handler-function{display:block;padding:0
0.5em;color:#888;font-size:0.75em}#page-admin-tool-messageinbound-index .state,
#page-admin-tool-messageinbound-index
.edit{text-align:center}.path-admin-tool-profiling .profilingruntable
.label{font-weight:bold}.path-admin-tool-profiling
.profiling_worse{color:red}.path-admin-tool-profiling
.profiling_better{color:green}.path-admin-tool-profiling
.profiling_same{color:dimgrey}.path-admin-tool-profiling .profiling_important,
.path-admin-tool-profiling .flexible
.referencerun{font-weight:bold}.path-admin-tool-profiling
.flexible{margin-left:auto;margin-right:auto}#page-admin-tool-task-scheduledtasks .task-class{display:block;padding:0
0.5em;color:#888;font-size:0.75em}[data-region="displaytemplateexample"]{border-radius:4px;border:1px
inset #e3e3e3;padding:1em}.path-admin-tool-xmldb a[name="lastused"]{padding-top:50px}.assignfeedback_editpdf_widget .toolbar
ul{display:none}.assignfeedback_editpdf_widget .toolbar
li{list-style-type:none}.assignfeedback_editpdf_widget
.drawingcanvas{position:relative;min-width:817px;min-height:400px;cursor:crosshair;background-repeat:no-repeat;background-color:#ccc;margin-left:auto;margin-right:auto;box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 20px rgba(0,0,0,.2)}.assignfeedback_editpdf_widget .moodle-dialogue-bd
.drawingregion{position:inherit}.assignfeedback_editpdf_widget .drawingregion[data-currenttool=drag] .drawingcanvas{cursor:move}.assignfeedback_editpdf_widget .drawingregion[data-currenttool=select] .drawingcanvas{cursor:pointer}.assignfeedback_editpdf_widget
.drawingregion{border:1px
solid #ccc;left:1em;right:1em;top:52px;bottom:0px;position:absolute;overflow:auto;background-color:#ccc}.assignfeedback_editpdf_widget{user-select:none;-moz-user-select:none;-webkit-user-select:none;-o-user-select:none}.assignfeedback_editpdf_widget
.pageheader{background-color:#ebebeb;border-bottom:1px solid #ccc;padding:0px;padding-left:20px;padding-right:20px;min-height:50px;height:52px;overflow:auto}.moodle-dialogue-base .moodle-dialogue.assignfeedback_editpdf_widget .moodle-dialogue-bd{padding:0px}.assignfeedback_editpdf_widget
.assignfeedback_editpdf_unsavedchanges.haschanges{display:inline-block}.assignfeedback_editpdf_widget
.assignfeedback_editpdf_unsavedchanges{display:none;position:absolute;left:20px;top:60px}.dir-rtl .assignfeedback_editpdf_widget
.assignfeedback_editpdf_unsavedchanges{float:right}.yui3-colourpicker-hidden,.yui3-commentsearch-hidden,.yui3-commentmenu-hidden{display:none}.assignfeedback_editpdf_widget .pageheader button
img{padding-top:3px;vertical-align:top}.assignfeedback_editpdf_widget .pageheader button:active{background-color:#ccc}.assignfeedback_editpdf_widget .pageheader select,
.assignfeedback_editpdf_widget .pageheader
button{background:none;padding:4px
7px;border:0px;border-radius:0px;margin:0px;height:30px;line-height:30px;vertical-align:top;cursor:pointer}.assignfeedback_editpdf_widget .pageheader
select{vertical-align:top;-webkit-appearance:none;-moz-appearance:menulist-text;background-color:#fff;padding:0px
10px}.assignfeedback_editpdf_widget .pageheader select::-ms-expand{display:none}.assignfeedback_editpdf_widget .pageheader .navigation button + button,
.assignfeedback_editpdf_widget .pageheader .toolbar button + button,
.assignfeedback_editpdf_widget .pageheader .navigation select + button,
.assignfeedback_editpdf_widget .pageheader .toolbar select+button{border-left:1px solid #ccc;border-right:0px}.assignfeedback_editpdf_widget .pageheader .navigation
button{border-right:1px solid #ccc}.assignfeedback_editpdf_widget .pageheader .toolbar,
.assignfeedback_editpdf_widget .pageheader .navigation-search,
.assignfeedback_editpdf_widget .pageheader
.navigation{border:1px
solid #ccc;border-bottom-color:#b3b3b3;border-radius:4px;margin:10px
4px;background-color:white;height:30px;line-height:30px;padding:0px}.assignfeedback_editpdf_commentsearch
ul{max-height:400px;overflow-y:auto;padding:1em}.assignfeedback_editpdf_commentsearch ul li
pre{background-color:#efefef}.assignfeedback_editpdf_commentsearch ul li pre:hover{background-color:#ddd}.assignfeedback_editpdf_commentsearch ul
li{line-height:0px;margin:2px}.assignfeedback_editpdf_commentsearch a
pre{font-family:helvetica;margin:0px;padding:4px}.assignfeedback_editpdf_widget .navigation-search,
.assignfeedback_editpdf_widget
.navigation{float:left}.dir-rtl .assignfeedback_editpdf_widget .navigation-search,
.dir-rtl .assignfeedback_editpdf_widget
.navigation{float:right}.assignfeedback_editpdf_widget .toolbar
button{box-shadow:none;-moz-box-shadow:none;-webkit-box-shadow:none}.assignfeedback_editpdf_widget
.toolbar{float:right}.dir-rtl .assignfeedback_editpdf_widget
.toolbar{float:left}.assignfeedback_editpdf_widget .navigation,
.assignfeedback_editpdf_widget .navigation-search,
.assignfeedback_editpdf_widget
.toolbar{display:inline-block}.assignfeedback_editpdf_colourpicker
ul{margin:0px}.assignfeedback_editpdf_commentmenu
li.quicklist_comment{width:150px}.assignfeedback_editpdf_commentmenu li.quicklist_comment
a{white-space:nowrap;display:inline-block;max-width:130px;overflow:hidden;text-overflow:ellipsis}.assignfeedback_editpdf_commentmenu
a.delete_quicklist_comment{float:right}.dir-rtl .assignfeedback_editpdf_commentmenu
a.delete_quicklist_comment{float:left}.assignfeedback_editpdf_dropdown
button{border:0px;background:none;padding:6px
7px;border-radius:0px;border-top:1px solid #ccc}.assignfeedback_editpdf_dropdown li:first-child
button{border-top:0px}.moodle-dialogue-base .moodle-dialogue.assignfeedback_editpdf_dropdown .moodle-dialogue-wrap{box-shadow:none;-moz-box-shadow:none;-webkit-box-shadow:none;margin-left:0px;margin-right:0px;margin-top:0px;border-radius:4px}.moodle-dialogue-base .moodle-dialogue.assignfeedback_editpdf_dropdown .moodle-dialogue-bd{padding:0px}.assignfeedback_editpdf_dropdown .moodle-dialogue-hd,
.assignfeedback_editpdf_dropdown .moodle-dialogue-ft{display:none}.assignfeedback_editpdf_menu li
hr{margin:0px}.assignfeedback_editpdf_menu li
a{text-decoration:none;color:#555;margin:10px}.assignfeedback_editpdf_menu li:hover,
.assignfeedback_editpdf_menu li:hover a,
.assignfeedback_editpdf_menu li a:hover{background-color:#ebebeb;background-image:radial-gradient(ellipse at center, #fff 60%,#dfdfdf 100%)}ul.assignfeedback_editpdf_menu{margin:0px}.assignfeedback_editpdf_menu
li{list-style-type:none;margin:0px;border-radius:4px}.assignfeedback_editpdf_menu li
img{height:auto}.assignfeedback_editpdf_menu li
button{margin:0px;background:none}.assignfeedback_editpdf_widget .pageheader button:hover{background-color:#ebebeb;background-image:radial-gradient(ellipse at center, #fff 60%,#dfdfdf 100%)}.assignfeedback_editpdf_widget .pageheader button.assignfeedback_editpdf_selectedbutton:hover,
.assignfeedback_editpdf_widget .pageheader
button.assignfeedback_editpdf_selectedbutton{background-color:#dfdfdf;background-image:radial-gradient(ellipse at center, #fff 40%,#dfdfdf 100%)}.assignfeedback_editpdf_widget .commentdrawable
img{padding:1px}.assignfeedback_editpdf_widget .commentdrawable
a{float:right;position:relative;left:-17px;top:2px;height:14px;background-color:white;border-left:1px solid #ccc;border-bottom:1px solid #ccc;line-height:14px}.dir-rtl .assignfeedback_editpdf_widget .commentdrawable
a{float:left;left:none;right:-17px;border-left:0px;border-right:1px solid #ccc}.assignfeedback_editpdf_widget .commentdrawable
textarea{padding:4px;padding-right:20px;resize:none;overflow:hidden;color:black;border:2px
solid #ccc;border-radius:4px;font-size:16px;font-family:helvetica;min-height:1.2em}.assignfeedback_editpdf_widget
.commentdrawable{display:inline-block}.dir-rtl .assignfeedback_editpdf_widget .commentdrawable
textarea{padding-left:20px;padding-right:4px}.assignfeedback_editpdf_widget .drawingcanvas .loading
.progressbarlabel{text-align:center}.hideoverflow{overflow:hidden;position:relative}@media (max-width: 960px){.assignfeedback_editpdf_widget
.pageheader{height:104px}.assignfeedback_editpdf_widget
.drawingregion{top:104px}}@media (max-width: 767px){.assignfeedback_editpdf_widget
.drawingregion{position:relative;margin-bottom:1em;top:0}.assignfeedback_editpdf_widget
.pageheader{height:auto}}@media (max-width: 480px){.assignfeedback_editpdf_widget
.pageheader{padding-left:5px;padding-right:5px}}#page-mod-quiz-report
#manualgradingform{width:100%}#page-mod-quiz-report #manualgradingform.mform
br{clear:none}#page-mod-quiz-report #manualgradingform.mform .clearfix:after{clear:none}#page-mod-quiz-report #manualgradingform
.que{margin-bottom:0.7em}.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper,
.path-mod-workshop .assessmentform.rubric #id_rubric-grid-wrapper{border:none}.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper legend,
.path-mod-workshop .assessmentform.rubric #id_rubric-grid-wrapper
legend{display:none}.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper th,
.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper td,
.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper th,
.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper
td{border:1px
solid #ddd;padding:5px;vertical-align:top}.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper,
.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper
.criterion{text-align:center}.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper
.fitem{text-align:center}.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper .fitem .fitemtitle,
.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper .fitem
.fitemtitle{display:none}.path-mod-workshop #id_rubric-grid-wrapper .rubric-grid{margin-left:auto;margin-right:auto}.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper .fitem .felement,
.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper .fitem
.felement{width:100%;margin-left:auto;margin-right:auto}.path-mod-workshop .mform.frozen #id_rubric-grid-wrapper .fitem
.felement{border:none}.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper .fitem .felement
span{display:block;text-align:center}.path-mod-workshop .assessmentform.rubric.grid #id_rubric-grid-wrapper .fitem .felement span
label{display:block;text-align:center}.path-mod-workshop .mform.frozen .fitem.description.rubric + .fitem .fitemtitle,
.path-mod-workshop .assessmentform.rubric.list #id_rubric-grid-wrapper .fitem
.fitemtitle{display:none}.path-mod-workshop .mform.frozen .fitem.description.rubric + .fitem .fitemtitle + .felement,
.path-mod-workshop .assessmentform.rubric.list .fitem
.felement{width:auto;border:none}.path-mod-workshop .assessmentform.rubric.list .fitem .felement span
input{display:block;float:left}.path-mod-workshop .assessmentform.rubric.list .fitem .felement.fgroup span
label{display:block;margin-left:30px}.path-mod-workshop .manual-allocator
.allocations{margin:0px
auto;width:100%}.path-mod-workshop .manual-allocator .allocations tbody tr:nth-of-type(odd){background-color:#eee}.path-mod-workshop .manual-allocator .allocations tbody tr:nth-of-type(odd).highlightreviewerof,
.path-mod-workshop .manual-allocator .allocations tbody tr:nth-of-type(odd).highlightreviewedby{background-color:inherit}.path-mod-workshop .manual-allocator .allocations .peer
.image{margin-right:5px;vertical-align:middle}.path-mod-workshop .manual-allocator .allocations .reviewedby .image,
.path-mod-workshop .manual-allocator .allocations .reviewerof
.image{margin-right:3px;vertical-align:middle}.path-mod-workshop .manual-allocator .allocations .highlightreviewedby .reviewedby,
.path-mod-workshop .manual-allocator .allocations .highlightreviewerof
.reviewerof{background-color:#fff3d2}.path-mod-workshop .manual-allocator .allocations tr
td{vertical-align:top;padding:5px}.path-mod-workshop .manual-allocator .allocations tr td
ul{margin:0px}.path-mod-workshop .manual-allocator .allocations tr td ul
li{list-style:none}.path-mod-workshop .manual-allocator .allocations tr
td.peer{border-left:1px solid #ccc;border-right:1px solid #ccc}.path-mod-workshop .manual-allocator .allocations .reviewedby .info,
.path-mod-workshop .manual-allocator .allocations .peer .info,
.path-mod-workshop .manual-allocator .allocations .reviewerof
.info{font-size:80%;color:#888;font-style:italic}.path-mod-workshop .manual-allocator .allocations .peer
.submission{font-size:90%;margin-top:1em}.path-mod-workshop .random-allocator
.warning{width:100%;margin:0px
auto 15px auto}.accessibilitywarnings
img{max-width:32px;max-height:32px}.atto_backcolor_button .dropdown-menu{min-width:inherit}.atto_charmap_selector
button{width:2em;padding:0
3px}@media (max-width: 768px){.toolbarbreak{display:none}}.atto_emoticon_map
ul{padding:0;margin:0;display:table;width:100%}.atto_emoticon_map
li{display:table-row;white-space:nowrap}.atto_emoticon_map li
div{display:table-cell;padding:0
1em}.atto_equation_library .yui3-tabview-list{border:none}.atto_equation_library .yui3-tab-selected .yui3-tab-label, .yui3-skin-sam #atto_equation_library .yui3-tab-selected .yui3-tab-label:focus, .yui3-skin-sam #atto_equation_library .yui3-tab-selected .yui3-tab-label:hover{background:none;color:black;border-top-left-radius:4px;border-top-right-radius:4px}.atto_equation_library
button{margin:0.25%;min-width:12%}#page-admin-setting-atto_equation_settings .form-defaultinfo{max-height:10em;overflow:auto;padding:5px;min-width:206px}.atto_form
.atto_equation_preview{margin-bottom:0px}.atto_fontcolor_button .dropdown-menu{min-width:inherit}.atto_image_preview{width:100%;height:100%;margin-left:auto;margin-right:auto}.atto_image_preview_box{max-height:200px;margin-bottom:1em;overflow:auto}.editor_atto_content
img{cursor:pointer}.atto_image_size{display:inline-block}.atto_image_size input[type=checkbox]{margin-left:1em;margin-right:1em}.atto_image_size input[type=text]{width:3em}.atto_image_size
label{display:inline-block}.atto_image_button_text-top{vertical-align:text-top;margin:0
0.5em}.atto_image_button_middle{vertical-align:middle;margin:0
0.5em}.atto_image_button_text-bottom{vertical-align:text-bottom;margin:0
0.5em}.atto_image_button_text-top.img-responsive,.atto_image_button_middle.img-responsive,.atto_image_button_text-bottom.img-responsive{max-width:calc(100% - 1em)}.atto_image_button_left{float:left;margin:0
0.5em 0 0;max-width:calc(100% - 1em)}.atto_image_button_right{float:right;margin:0
0 0 0.5em;max-width:calc(100% - 1em)}#atto_managefiles_manageform
#id_deletefileshdr{display:none}#atto_managefiles_manageform.has-unused-files
#id_deletefileshdr{display:block}#atto_managefiles_manageform
#id_missingfileshdr{display:none}#atto_managefiles_manageform.has-missing-files
#id_missingfileshdr{display:block}div.editor_atto_content td,
div.editor_atto_content th,
div.editor_atto_content
caption{border:1px
dashed #BBB;position:relative;min-width:30px;height:13px}div.editor_atto_content
caption{height:auto}div.availablecolors{max-width:55%;display:inline-block;vertical-align:middle}div.availablecolors label:not(.hideborder){border:1px
solid #ddd}div.availablecolors
label{border-radius:4px;display:inline-block;font-size:0.1em;padding:2px;padding-left:22px}div.availablecolors label input[type="radio"]{float:none;margin:0;margin-left:-15px}input[name="bordersize"],input[name="width"]{margin-right:0.3em}#tinymce_managefiles_manageform.hasunusedfiles
.managefilesstatus{display:none}#tinymce_managefiles_manageform.hasmissingfiles
.managefilesstatus{display:inline}#tinymce_managefiles_manageform
#id_deletefiles{display:none}#tinymce_managefiles_manageform.hasunusedfiles
#id_deletefiles{display:block}#tinymce_managefiles_manageform #id_deletefiles
.felement.fcheckbox{display:none}#tinymce_managefiles_manageform #id_deletefiles
.felement.fcheckbox.isunused{display:block}.layout-option-noheader #page-header,.layout-option-nonavbar #page-navbar,.layout-option-nofooter #page-footer,.layout-option-nocourseheader .course-content-header,.layout-option-nocoursefooter .course-content-footer{display:none}.empty-region-side-pre #block-region-side-pre,.empty-region-side-post #block-region-side-post,.jsenabled.docked-region-side-post #block-region-side-post,.jsenabled.docked-region-side-pre #block-region-side-pre{display:none}.content-only #region-main.span9,.empty-region-side-post #region-bs-main-and-pre.span9,.empty-region-side-pre #region-bs-main-and-post.span9,.empty-region-side-post #region-bs-main-and-post.span9 #region-main.span8,.jsenabled.docked-region-side-post #region-bs-main-and-pre.span9,.jsenabled.docked-region-side-post #region-bs-main-and-post.span9 #region-main.span8,.jsenabled.docked-region-side-pre #region-bs-main-and-post.span9{width:100%}.empty-region-side-pre #region-bs-main-and-pre.span9 #region-main,.jsenabled.docked-region-side-pre #region-bs-main-and-pre.span9 #region-main{float:none;width:100%}.empty-region-side-pre #region-bs-main-and-post.span9 #region-main.span8,.jsenabled.docked-region-side-pre #region-bs-main-and-post.span9 #region-main.span8{float:right}.content-only #region-main-box,.content-only #region-main{width:100%}.empty-region-side-pre.used-region-side-post #region-main{width:100%}.empty-region-side-post.used-region-side-pre #region-main-box{width:100%}.jsenabled.docked-region-side-pre.empty-region-side-pre.used-region-side-post #region-main{width:100%}.jsenabled.docked-region-side-post.empty-region-side-post.used-region-side-pre #region-main-box{width:100%}.empty-region-side-post.used-region-side-pre #region-main.span8,.jsenabled.docked-region-side-post.used-region-side-pre #region-main.span8{width:74.46808511%;*width:74.41489362%}.empty-region-side-post.used-region-side-pre #block-region-side-pre.span4,.jsenabled.docked-region-side-post.used-region-side-pre #block-region-side-pre.span4{width:23.40425532%;*width:23.35106383%}.dir-ltr,.mdl-left,.dir-rtl .mdl-right{text-align:left}.dir-rtl,.mdl-right,.dir-rtl .mdl-left{text-align:right}#add,#remove,.centerpara,.mdl-align{text-align:center}a.dimmed,a.dimmed:link,a.dimmed:visited,a.dimmed_text,a.dimmed_text:link,a.dimmed_text:visited,.dimmed_text,.dimmed_text a,.dimmed_text a:link,.dimmed_text a:visited,.usersuspended,.usersuspended a,.usersuspended a:link,.usersuspended a:visited,.dimmed_category,.dimmed_category
a{color:#999}.activity.label
.dimmed_text{opacity:.5;filter:alpha(opacity=50)}.unlist,.unlist li,.inline-list,.inline-list li,.block .list,.block .list li,.section li.activity,.section li.movehere,.tabtree
li{list-style:none;margin:0;padding:0}.inline,.inline-list
li{display:inline}.notifytiny{font-size:10.5px}.notifytiny li,.notifytiny
td{font-size:100%}.red,.notifyproblem{color:#b94a48}.green,.notifysuccess{color:#468847}.highlight{background:#d9edf7}.reportlink{text-align:right}a.autolink.glossary:hover{cursor:help}.collapsibleregioncaption{white-space:nowrap}.pagelayout-mydashboard.jsenabled
.collapsibleregioncaption{cursor:pointer}.collapsibleregioncaption
img{vertical-align:middle}.jsenabled
.hiddenifjs{display:none}.visibleifjs{display:none}.jsenabled
.visibleifjs{display:inline}.jsenabled
.collapsibleregion{overflow:hidden}.jsenabled .collapsed
.collapsibleregioninner{visibility:hidden}.collapsible-actions{display:none;text-align:right}.dir-rtl .collapsible-actions{text-align:left}.jsenabled .collapsible-actions{display:block}.collapsible-actions
.collapseexpand{padding-left:20px;background:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fcollapsed) 2px center no-repeat}.dir-rtl .collapsible-actions
.collapseexpand{padding-right:20px;padding-left:0;background:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fcollapsed_rtl) right center no-repeat}.collapsible-actions .collapse-all,.dir-rtl .collapsible-actions .collapse-all{background-image:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fexpanded)}.yui-overlay .yui-widget-bd{background-color:#FFEE69;border:1px
solid #A6982B;border-top-color:#D4C237;color:#000;left:0;padding:2px
5px;position:relative;top:0;z-index:1}.clearer{background:transparent;border-width:0;clear:both;display:block;height:1px;margin:0;padding:0}.bold,.warning,.errorbox .title,.pagingbar .title,.pagingbar
.thispage{font-weight:bold}img.resize{height:1em;width:1em}.block img.resize,.breadcrumb
img.resize{height:.9em;width:.8em}img.icon{height:16px;vertical-align:text-bottom;width:16px;padding-right:6px}.dir-rtl
img.icon{padding-left:6px;padding-right:0}img.iconsmall{height:12px;margin-right:3px;vertical-align:middle;width:12px}img.iconhelp,.helplink
img{height:16px;padding-left:3px;vertical-align:text-bottom;width:16px}h1 img.iconhelp,h1 img.icon,h2 img.iconhelp,h2 img.icon,h3 img.iconhelp,h3 img.icon,h4 img.iconhelp,h4 img.icon,h5 img.iconhelp,h5 img.icon,h6 img.iconhelp,h6
img.icon{vertical-align:middle;padding:4px}.dir-rtl img.iconhelp,.dir-rtl .helplink
img{padding-right:3px;padding-left:0}img.iconlarge{height:24px;width:24px;vertical-align:middle}img.iconsort{vertical-align:text-bottom;padding-left:.3em;margin-bottom:.15em}.dir-rtl
img.iconsort{padding-right:.3em;padding-left:0}img.icontoggle{height:17px;vertical-align:middle;width:50px}img.iconkbhelp{height:17px;width:49px}img.icon-pre,.dir-rtl img.icon-post{padding-right:3px;padding-left:0}img.icon-post,.dir-rtl img.icon-pre{padding-left:3px;padding-right:0}.boxaligncenter{margin-left:auto;margin-right:auto}.boxalignright{margin-left:auto;margin-right:0}.boxalignleft{margin-left:0;margin-right:auto}.boxwidthnarrow{width:30%}.boxwidthnormal{width:50%}.boxwidthwide{width:80%}.headermain{font-weight:bold}#maincontent{display:block;height:1px;overflow:hidden}img.uihint{cursor:help}#addmembersform
table{margin-left:auto;margin-right:auto}table.flexible
.emptyrow{display:none}img.emoticon{vertical-align:middle;width:15px;height:15px}form.popupform,form.popupform
div{display:inline}.arrow_button
input{overflow:hidden}.action-icon
img.smallicon{vertical-align:text-bottom;margin:0
.3em}.no-overflow{overflow:auto;padding-bottom:1px}.pagelayout-report .no-overflow{overflow:visible}.no-overflow>.generaltable{margin-bottom:0}.accesshide{position:absolute;left:-10000px;font-weight:normal;font-size:1em}.dir-rtl
.accesshide{top:-30000px;left:auto}span.hide,div.hide{display:none}a.skip-block,a.skip{position:absolute;top:-1000em;font-size:.85em;text-decoration:none}a.skip-block:focus,a.skip-block:active,a.skip:focus,a.skip:active{position:static;display:block}.skip-block-to{display:block;height:1px;overflow:hidden}.addbloglink{text-align:center}.blog_entry
.audience{text-align:right;padding-right:4px}.blog_entry
.tags{margin-top:15px}.blog_entry .tags .action-icon
img.smallicon{height:16px;width:16px}.blog_entry
.content{margin-left:43px}#page-group-index
#groupeditform{text-align:center}#doc-contents
h1{margin:1em
0 0 0}#doc-contents
ul{margin:0;padding:0;width:90%}#doc-contents ul
li{list-style-type:none}.groupmanagementtable
td{vertical-align:top}.groupmanagementtable #existingcell,.groupmanagementtable
#potentialcell{width:42%}.groupmanagementtable
#buttonscell{width:16%}.groupmanagementtable #buttonscell p.arrow_button
input{width:auto;min-width:80%;margin:0
auto}.groupmanagementtable #removeselect_wrapper,.groupmanagementtable
#addselect_wrapper{width:100%}.groupmanagementtable #removeselect_wrapper label,.groupmanagementtable #addselect_wrapper
label{font-weight:normal}.dir-rtl .groupmanagementtable
p{text-align:right}#group-usersummary{width:14em}.groupselector{margin-top:3px;margin-bottom:3px;display:inline-block}.groupselector
label{display:inline-block}.dataformatselector{margin:1em
0}.dataformatselector
label{display:inline-block;margin:0
5px 10px 0;line-height:30px;vertical-align:top}.loginbox{margin:15px;overflow:visible}.loginbox.twocolumns{margin:15px}.loginbox h2,.loginbox
.subcontent{margin:5px;padding:10px;text-align:center}.loginbox .loginpanel
.desc{margin:0;padding:0;margin-bottom:5px;margin-top:15px}.loginbox .signuppanel
.subcontent{text-align:left}.dir-rtl .loginbox .signuppanel
.subcontent{text-align:right}.loginbox
.loginsub{margin-left:0;margin-right:0}.loginbox .guestsub,.loginbox .forgotsub,.loginbox
.potentialidps{margin:5px
12%}.loginbox .potentialidps
.potentialidplist{margin-left:40%}.loginbox .potentialidps .potentialidplist
div{text-align:left}.loginbox
.loginform{margin-top:1em;text-align:left}.loginbox .loginform .form-label{float:left;text-align:right;width:49%;white-space:nowrap}.loginbox .loginform .form-input{float:right;width:50%}.loginbox .loginform .form-input
input{width:6em}.loginbox
.signupform{margin-top:1em;text-align:center}.loginbox.twocolumns .loginpanel,.loginbox.twocolumns
.signuppanel{width:48%;border:0;margin:0;padding:0;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;display:block;float:left;margin-left:2.76243%;min-height:30px;margin-bottom:-2000px;padding-bottom:2000px}.dir-rtl .loginbox.twocolumns .loginpanel,.dir-rtl .loginbox.twocolumns
.signuppanel{float:right}.loginbox .potentialidp
.smallicon{vertical-align:text-bottom;margin:0
.3em}.notepost{margin-bottom:1em}.notepost
.userpicture{float:left;margin-right:5px}.notepost .content,.notepost
.footer{clear:both}.notesgroup{margin-left:20px}.path-my .coursebox
.overview{margin:15px
30px 10px 30px}.path-my .coursebox
.info{float:none;margin:0}.mod_introbox{padding:10px}table.mod_index{width:100%}.comment-ctrl{font-size:12px;display:none;margin:0;padding:0}.comment-ctrl
h5{margin:0;padding:5px}.comment-area{max-width:400px;padding:5px}.comment-area
textarea{width:100%;overflow:auto}.comment-area
textarea.fullwidth{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.comment-area
.fd{text-align:right}.comment-meta
span{color:gray}.comment-link
img{vertical-align:text-bottom}.comment-list{font-size:11px;overflow:auto;list-style:none;padding:0;margin:0}.comment-list
li{margin:2px;list-style:none;margin-bottom:5px;clear:both;padding:.3em;position:relative}.comment-list
li.first{display:none}.comment-paging{text-align:center}.comment-paging
.pageno{padding:2px}.comment-paging
.curpage{border:1px
solid #CCC}.comment-message
.picture{width:20px;float:left}.dir-rtl .comment-message
.picture{float:right}.comment-message
.text{margin:0;padding:0}.comment-message .text
p{padding:0;margin:0
18px 0 0}.comment-delete{position:absolute;top:0;right:0;margin:.3em}.dir-rtl .comment-delete{position:absolute;left:0;right:auto;margin:.3em}.comment-report-selectall{display:none}.comment-link{display:none}.jsenabled .comment-link{display:block}.jsenabled
.showcommentsnonjs{display:none}.jsenabled .comment-report-selectall{display:inline}.completion-expired{background:#f2dede}.completion-expected{font-size:10.5px}.completion-sortchoice,.completion-identifyfield{font-size:10.5px;vertical-align:bottom}.completion-progresscell{text-align:right}.completion-expired .completion-expected{font-weight:bold}img.user-image{height:100px;width:100px}#tag-search-box{text-align:center;margin:10px
auto}.path-tag .tag-index-items
.tagarea{border:1px
solid #E3E3E3;border-radius:4px;padding:10px;margin-top:10px}.path-tag .tag-index-items .tagarea
h3{display:block;padding:3px
0 10px 0;margin:0;font-size:1.1em;font-weight:bold;line-height:20px;color:#999;text-shadow:0 1px 0 rgba(255,255,255,0.5);text-transform:uppercase;word-wrap:break-word;border-bottom:solid 1px #E3E3E3;margin-bottom:10px}.path-tag .tagarea .controls,.path-tag .tagarea
.taggeditems{*zoom:1}.path-tag .tagarea .controls:before,.path-tag .tagarea .taggeditems:before,.path-tag .tagarea .controls:after,.path-tag .tagarea .taggeditems:after{display:table;content:"";line-height:0}.path-tag .tagarea .controls:after,.path-tag .tagarea .taggeditems:after{clear:both}.path-tag .tagarea .controls,.path-tag .tag-backtoallitems{text-align:center}.path-tag .tagarea .controls
.gotopage.nextpage{float:right}.path-tag .tagarea .controls
.gotopage.prevpage{float:left}.path-tag .tagarea .controls
.exclusivemode{display:inline-block}.dir-rtl.path-tag .tagarea .controls
.gotopage.nextpage{float:left}.dir-rtl.path-tag .tagarea .controls
.gotopage.prevpage{float:right}.path-tag .tagarea .controls.controls-bottom{margin-top:5px}.path-tag .tagarea .controls .gotopage.nextpage::after{padding-right:5px;padding-left:5px;content:"»"}.path-tag .tagarea .controls .gotopage.prevpage::before{padding-right:5px;padding-left:5px;content:"«"}span.flagged-tag,tr.flagged-tag,span.flagged-tag a,tr.flagged-tag
a{color:#b94a48}.tag-management-table td,.tag-management-table
th{vertical-align:middle;padding:4px}.tag-management-table .inplaceeditable.inplaceeditingon
input{width:150px}.path-admin-tag
.addstandardtags{float:right}.path-admin-tag .addstandardtags
img{margin:0
5px}.dir-rtl.path-admin-tag
.addstandardtags{float:left}.path-tag .tag-relatedtags{padding-top:10px}.path-tag .tag-management-box{text-align:right}.path-tag .tag-index-toc{padding:10px;text-align:center}.path-tag .tag-index-toc li,.path-tag .tag-management-box
li{margin-left:5px;margin-right:5px}.path-tag .tag-management-box li
a.edittag{background-image:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=i%2Fsettings)}.path-tag .tag-management-box li
a.flagasinappropriate{background-image:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=i%2Fflagged)}.path-tag .tag-management-box li
a.removefrommyinterests{background-image:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fdelete)}.path-tag .tag-management-box li
a.addtomyinterests{background-image:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fadd)}.path-tag .tag-management-box li
a{background-repeat:no-repeat;background-position:left;padding-left:17px}.tag_feed.media-list .media
.itemimage{float:left}.dir-rtl .tag_feed.media-list .media
.itemimage{float:right}.tag_feed.media-list .media .itemimage
img{height:35px;width:35px}.tag_feed.media-list .media .media-body{padding-right:10px;padding-left:10px}.tag_feed .media .muted
a{color:#999}.tag_cloud{text-align:center}.tag_cloud .inline-list
li{padding:0
.2em}.tag_cloud
.tag_overflow{margin-top:1em;font-style:italic}.tag_cloud
.s20{font-size:2.7em}.tag_cloud
.s19{font-size:2.6em}.tag_cloud
.s18{font-size:2.5em}.tag_cloud
.s17{font-size:2.4em}.tag_cloud
.s16{font-size:2.3em}.tag_cloud
.s15{font-size:2.2em}.tag_cloud
.s14{font-size:2.1em}.tag_cloud
.s13{font-size:2em}.tag_cloud
.s12{font-size:1.9em}.tag_cloud
.s11{font-size:1.8em}.tag_cloud
.s10{font-size:1.7em}.tag_cloud
.s9{font-size:1.6em}.tag_cloud
.s8{font-size:1.5em}.tag_cloud
.s7{font-size:1.4em}.tag_cloud
.s6{font-size:1.3em}.tag_cloud
.s5{font-size:1.2em}.tag_cloud
.s4{font-size:1.1em}.tag_cloud
.s3{font-size:1em}.tag_cloud
.s2{font-size:.9em}.tag_cloud
.s1{font-size:.8em}.tag_cloud
.s0{font-size:.7em}.tag_list
ul{display:inline}.tag_list.hideoverlimit
.overlimit{display:none}.tag_list
.tagmorelink{display:none}.tag_list.hideoverlimit
.tagmorelink{display:inline}.tag_list.hideoverlimit
.taglesslink{display:none}#webservice-doc-generator
td{text-align:left;border:0
solid black}.smartselect{position:absolute}.smartselect
.smartselect_mask{background-color:#fff}.smartselect
ul{padding:0;margin:0}.smartselect ul
li{list-style:none}.smartselect
.smartselect_menu{margin-right:5px}.safari .smartselect
.smartselect_menu{margin-left:2px}.smartselect .smartselect_menu,.smartselect
.smartselect_submenu{border:1px
solid #000;background-color:#FFF;display:none}.smartselect .smartselect_menu.visible,.smartselect
.smartselect_submenu.visible{display:block}.smartselect .smartselect_menu_content ul
li{position:relative;padding:2px
5px}.smartselect .smartselect_menu_content ul li
a{color:#333;text-decoration:none}.smartselect .smartselect_menu_content ul li
a.selectable{color:inherit}.smartselect
.smartselect_submenuitem{background-image:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fcollapsed);background-repeat:no-repeat;background-position:100%}.smartselect.spanningmenu
.smartselect_submenu{position:absolute;top:-1px;left:100%}.smartselect.spanningmenu .smartselect_submenu
a{white-space:nowrap;padding-right:16px}.smartselect.spanningmenu .smartselect_menu_content ul li a.selectable:hover{text-decoration:underline}.smartselect.compactmenu
.smartselect_submenu{position:relative;margin:2px
-3px;margin-left:10px;display:none;border-width:0;z-index:1010}.smartselect.compactmenu
.smartselect_submenu.visible{display:block}.smartselect.compactmenu
.smartselect_menu{z-index:1000;overflow:hidden}.smartselect.compactmenu .smartselect_submenu
.smartselect_submenu{z-index:1020}.smartselect.compactmenu .smartselect_submenuitem:hover>.smartselect_menuitem_label{font-weight:bold}#page-admin-registration-register
.registration_textfield{width:300px}.userenrolment{width:100%;border-collapse:collapse}.userenrolment
tr{vertical-align:top}.userenrolment
td{padding:0;height:41px}.userenrolment
.subfield{margin-right:5px}.userenrolment .col_userdetails
.subfield{margin-left:40px}.userenrolment .col_userdetails
.subfield_picture{float:left;margin-left:0}.userenrolment
.col_lastseen{width:150px}.userenrolment
.col_role{width:262px}.userenrolment .col_role .roles,.userenrolment .col_group
.groups{margin-right:30px}.userenrolment .col_role .role,.userenrolment .col_group
.group{float:left;padding:3px;margin:3px;white-space:nowrap}.userenrolment .col_role .role a,.userenrolment .col_group .group
a{margin-left:3px;cursor:pointer}.userenrolment .col_role .addrole,.userenrolment .col_group
.addgroup{float:right;padding:3px;margin:3px}.userenrolment .col_role .addrole>a:hover,.userenrolment .col_group .addgroup>a:hover{border-bottom:1px solid #666}.userenrolment .col_role .addrole img,.userenrolment .col_group .addgroup
img{vertical-align:baseline}.dir-rtl .userenrolment .col_role
.role{float:right}.userenrolment .hasAllRoles .col_role
.addrole{display:none}.userenrolment .col_enrol
.enrolment{float:left;padding:3px;margin:3px}.userenrolment .col_enrol .enrolment
a{float:right;margin-left:3px}#page-enrol-users
.enrol_user_buttons{float:right}#page-enrol-users .enrol_user_buttons
.enrolusersbutton{display:inline}#page-enrol-users .enrol_user_buttons .enrolusersbutton div,#page-enrol-users .enrol_user_buttons .enrolusersbutton
form{display:inline;margin-right:0}#page-enrol-users
#filterform{min-height:20px;padding:19px;margin-bottom:20px;background-color:#f5f5f5;border:1px
solid #e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);border-color:#e3e3e3;padding:9px;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px;display:inline-block}#page-enrol-users #filterform
blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}#page-enrol-users #filterform
.fitem{display:inline-block;line-height:40px;margin-right:.3em;white-space:nowrap}#page-enrol-users #filterform .fitem
label{display:inline;line-height:20px;padding-right:.3em}#page-enrol-users #filterform .fitem :before,#page-enrol-users #filterform .fitem :after{display:inline}#page-enrol-users #filterform div,#page-enrol-users #filterform
fieldset{display:inline;float:none;clear:none;width:auto;margin:0}#page-enrol-users #filterform select,#page-enrol-users #filterform .ftext
input{width:7em}#page-enrol-users #filterform input,#page-enrol-users #filterform
select{margin-bottom:0}#page-enrol-users .user-enroller-panel .uep-search-results .user
.details{width:237px}#page-enrol-users .user-enroller-panel .uep-search-results .cohort
.details{width:237px}.dir-rtl#page-enrol-users .col_userdetails
.subfield{margin-right:40px;margin-left:5px}.dir-rtl#page-enrol-users .col_userdetails
.subfield_picture{float:right;margin-right:0}.dir-rtl#page-enrol-users
.enrol_user_buttons{float:left}.dir-rtl#page-enrol-users .enrol_user_buttons
.enrolusersbutton{margin-left:0;margin-right:1em}.dir-rtl#page-enrol-users .enrol_user_buttons .enrolusersbutton
div{margin-left:0}.dir-rtl#page-enrol-users #filterform
.fitem{margin-right:0;margin-left:.3em}.dir-rtl#page-enrol-users #filterform .fitem
label{padding-right:0;padding-left:.3em}.dir-rtl#page-enrol-users .user-enroller-panel .uep-search-results .user .count,.dir-rtl#page-enrol-users .user-enroller-panel .uep-search-results .user .picture,.dir-rtl#page-enrol-users .user-enroller-panel .uep-search-results .user
.details{float:right}.dir-rtl#page-enrol-users .user-enroller-panel .uep-search-results .user .options
.enrol{float:left}#page-enrol-users .enrol-users-page-action
input{margin-left:0}.dir-rtl
.headermain{float:right}.dir-rtl
.headermenu{float:left}.dir-rtl .loginbox .loginform .form-label{float:right;text-align:left}.dir-rtl .loginbox .loginform .form-input{text-align:right;margin-right:1%}.dir-rtl .yui3-menu-hidden{left:0}#page-admin-roles-define.dir-rtl #rolesform
.felement{margin-right:180px}#page-message-edit.dir-rtl table.generaltable
th.c0{text-align:right}.corelightbox{background-color:#CCC;position:absolute;top:0;left:0;width:100%;height:100%;text-align:center}.corelightbox
img{position:fixed;top:50%;left:50%}.mod-indent-outer{display:table}.mod-indent{display:table-cell}.label .mod-indent{float:left;padding-top:20px}.mod-indent-1{width:30px}.mod-indent-2{width:60px}.mod-indent-3{width:90px}.mod-indent-4{width:120px}.mod-indent-5{width:150px}.mod-indent-6{width:180px}.mod-indent-7{width:210px}.mod-indent-8{width:240px}.mod-indent-9{width:270px}.mod-indent-10{width:300px}.mod-indent-11{width:330px}.mod-indent-12{width:360px}.mod-indent-13{width:390px}.mod-indent-14{width:420px}.mod-indent-15{width:450px}.mod-indent-16{width:480px}.mod-indent-huge{width:480px}.resourcecontent .mediaplugin_mp3
object{height:25px;width:600px}.resourcecontent
audio.mediaplugin_html5audio{width:600px}.resourceimage{max-width:100%}.mediaplugin_mp3
object{height:15px;width:300px}audio.mediaplugin_html5audio{width:300px}.core_media_preview.pagelayout-embedded
#content{padding:0}.core_media_preview.pagelayout-embedded
#maincontent{height:0}body#page-lib-editor-tinymce-plugins-moodlemedia-preview{padding:0;margin:0;min-width:0;background:none}.dir-rtl .ygtvtn,.dir-rtl .ygtvtm,.dir-rtl .ygtvtmh,.dir-rtl .ygtvtmhh,.dir-rtl .ygtvtp,.dir-rtl .ygtvtph,.dir-rtl .ygtvtphh,.dir-rtl .ygtvln,.dir-rtl .ygtvlm,.dir-rtl .ygtvlmh,.dir-rtl .ygtvlmhh,.dir-rtl .ygtvlp,.dir-rtl .ygtvlph,.dir-rtl .ygtvlphh,.dir-rtl .ygtvdepthcell,.dir-rtl .ygtvok,.dir-rtl .ygtvok:hover,.dir-rtl .ygtvcancel,.dir-rtl .ygtvcancel:hover{width:18px;height:22px;background-image:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=yui2-treeview-sprite-rtl);background-repeat:no-repeat;cursor:pointer}.dir-rtl
.ygtvtn{background-position:0 -5600px}.dir-rtl
.ygtvtm{background-position:0 -4000px}.dir-rtl .ygtvtmh,.dir-rtl
.ygtvtmhh{background-position:0 -4800px}.dir-rtl
.ygtvtp{background-position:0 -6400px}.dir-rtl .ygtvtph,.dir-rtl
.ygtvtphh{background-position:0 -7200px}.dir-rtl
.ygtvln{background-position:0 -1600px}.dir-rtl
.ygtvlm{background-position:0 0}.dir-rtl .ygtvlmh,.dir-rtl
.ygtvlmhh{background-position:0 -800px}.dir-rtl
.ygtvlp{background-position:0 -2400px}.dir-rtl .ygtvlph,.dir-rtl
.ygtvlphh{background-position:0 -3200px}.dir-rtl
.ygtvdepthcell{background-position:0 -8000px}.dir-rtl
.ygtvok{background-position:0 -8800px}.dir-rtl .ygtvok:hover{background-position:0 -8844px}.dir-rtl
.ygtvcancel{background-position:0 -8822px}.dir-rtl .ygtvcancel:hover{background-position:0 -8866px}.dir-rtl.yui-skin-sam .yui-panel
.hd{text-align:right}.dir-rtl .yui-skin-sam .yui-layout .yui-layout-unit div.yui-layout-bd{text-align:right}.dir-rtl .clearlooks2.ie9 .mceAlert .mceMiddle span,.dir-rtl .clearlooks2 .mceConfirm .mceMiddle
span{top:44px}.dir-rtl .o2k7Skin table,.dir-rtl .o2k7Skin tbody,.dir-rtl .o2k7Skin a,.dir-rtl .o2k7Skin img,.dir-rtl .o2k7Skin tr,.dir-rtl .o2k7Skin div,.dir-rtl .o2k7Skin td,.dir-rtl .o2k7Skin iframe,.dir-rtl .o2k7Skin span,.dir-rtl .o2k7Skin *,.dir-rtl .o2k7Skin .mceText,.dir-rtl .o2k7Skin .mceListBox
.mceText{text-align:right}.path-rating
.ratingtable{width:100%;margin-bottom:1em}.path-rating .ratingtable
th.rating{width:100%}.path-rating .ratingtable td.rating,.path-rating .ratingtable
td.time{white-space:nowrap;text-align:center}.initialbar a,.initialbar
strong{padding-left:3px;padding-right:3px}.moodle-dialogue-base .moodle-dialogue-lightbox{background-color:#AAA}.moodle-dialogue-base .hidden,.moodle-dialogue-base .moodle-dialogue-hidden{display:none}.no-scrolling{overflow:hidden}.moodle-dialogue-base .moodle-dialogue-fullscreen{left:0;top:0;right:0;bottom:-50px;position:fixed}.moodle-dialogue-base .moodle-dialogue-fullscreen .moodle-dialogue-content{overflow:auto}.moodle-dialogue-base .moodle-dialogue-fullscreen
.closebutton{width:28px;height:16px;background-size:100%}.moodle-dialogue-base .moodle-dialogue{padding:0;margin:0;background:none;border:none;z-index:600;outline:#000 dotted 0}.moodle-dialogue-base .moodle-dialogue-wrap{margin-top:-3px;margin-left:-3px;background-color:#fff;border:1px
solid #ccc;-webkit-border-radius:10px;-moz-border-radius:10px;border-radius:10px;-webkit-box-shadow:5px 5px 20px 0 #666;-moz-box-shadow:5px 5px 20px 0 #666;box-shadow:5px 5px 20px 0 #666}.moodle-dialogue-base .moodle-dialogue-wrap .moodle-dialogue-hd,.moodle-dialogue-base .moodle-dialogue-wrap .moodle-dialogue-hd.yui3-widget-hd{margin:0;padding:5px;font-size:12px;font-weight:normal;letter-spacing:1px;color:#333;text-align:center;text-shadow:1px 1px 1px #fff;-webkit-border-radius:10px 10px 0 0;-moz-border-radius:10px 10px 0 0;border-radius:10px 10px 0 0;border-bottom:1px solid #bbb;background:#ccc;background-color:#ebebeb;background-image:-moz-linear-gradient(top, #fff, #ccc);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#fff), to(#ccc));background-image:-webkit-linear-gradient(top, #fff, #ccc);background-image:-o-linear-gradient(top, #fff, #ccc);background-image:linear-gradient(to bottom, #fff, #ccc);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff', endColorstr='#ffcccccc', GradientType=0);filter:0}.moodle-dialogue-base .moodle-dialogue-wrap .moodle-dialogue-hd
h1{margin:0;padding:0;display:inline;font-size:100%;font-weight:bold}.moodle-dialogue-base .moodle-dialogue-wrap .moodle-dialogue-hd .yui3-widget-buttons{padding:5px}.moodle-dialogue-base
.closebutton{width:25px;height:15px;float:right;vertical-align:middle;display:inline-block;cursor:pointer;padding:0;background-image:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=sprite);background-repeat:no-repeat;border-style:none}.dir-rtl .moodle-dialogue-base .moodle-dialogue-wrap .moodle-dialogue-hd .yui3-widget-buttons{left:0;right:auto}.moodle-dialogue-base .moodle-dialogue .moodle-dialogue-bd{padding:1em;line-height:2em;color:#555;font-size:12px}.moodle-dialogue-base .moodle-dialogue-wrap .moodle-dialogue-content{padding:0;background:#FFF}.moodle-dialogue-base .moodle-dialogue-fullscreen .moodle-dialogue-hd{padding:10px;font-size:16px}.moodle-dialogue-base .moodle-dialogue-fullscreen .moodle-dialogue-content{overflow:auto;position:absolute;top:0;bottom:50px;left:0;right:0;margin:0;border:0}.moodle-dialogue-base .moodle-dialogue-fullscreen .moodle-dialogue-hd,.moodle-dialogue-base .moodle-dialogue-fullscreen .moodle-dialogue-wrap{border-radius:0}.moodle-dialogue-confirm .confirmation-dialogue{text-align:center}.moodle-dialogue-confirm .confirmation-dialogue
input{text-align:center}.moodle-dialogue-exception .moodle-exception-message{text-align:center}.moodle-dialogue-exception .moodle-exception-param
label{font-weight:bold}.moodle-dialogue-exception .param-stacktrace
label{background-color:#EEE;border:1px
solid #ccc;border-bottom-width:0}.moodle-dialogue-exception .param-stacktrace
pre{border:1px
solid #ccc;background-color:#fff}.moodle-dialogue-exception .param-stacktrace .stacktrace-file{color:navy;font-size:11.9px}.moodle-dialogue-exception .param-stacktrace .stacktrace-line{color:#b94a48;font-size:11.9px}.moodle-dialogue-exception .param-stacktrace .stacktrace-call{color:#333;font-size:90%;border-bottom:1px solid #eee}.moodle-dialogue-base .moodle-dialogue .moodle-dialogue-content .moodle-dialogue-ft{padding:0;margin:.7em 1em;text-align:right;background-color:#FFF;font-size:12px}.moodle-dialogue-confirm .confirmation-message{margin:.5em 1em}.moodle-dialogue-confirm .confirmation-dialogue
input{min-width:80px}.moodle-dialogue-exception .moodle-exception-message{margin:1em}.moodle-dialogue-exception .moodle-exception-param{margin-bottom:.5em}.moodle-dialogue-exception .moodle-exception-param
label{width:150px}.moodle-dialogue-exception .param-stacktrace
label{display:block;margin:0;padding:4px
1em}.moodle-dialogue-exception .param-stacktrace
pre{display:block;height:200px;overflow:auto}.moodle-dialogue-exception .param-stacktrace .stacktrace-file{display:inline-block;margin:4px
0}.moodle-dialogue-exception .param-stacktrace .stacktrace-line{display:inline-block;width:50px;margin:4px
1em}.moodle-dialogue-exception .param-stacktrace .stacktrace-call{padding-left:25px;margin-bottom:4px;padding-bottom:4px}.moodle-dialogue .moodle-dialogue-bd .content-lightbox{opacity:.75;filter:alpha(opacity=75);width:100%;height:100%;top:0;left:0;background-color:white;text-align:center;padding:10% 0}.moodle-dialogue
.tooltiptext{max-height:300px}.moodle-dialogue-base .moodle-dialogue.moodle-dialogue-tooltip{z-index:3001}.moodle-dialogue-base .moodle-dialogue.moodle-dialogue-tooltip .moodle-dialogue-bd{overflow:auto}#page-question-edit.dir-rtl a.container-close{right:auto;left:6px}.chooserdialoguebody,.choosertitle{display:none}.moodle-dialogue.chooserdialogue .moodle-dialogue-content .moodle-dialogue-ft{margin:0}.chooserdialogue .moodle-dialogue-wrap .moodle-dialogue-bd{padding:0;background:#F2F2F2;-webkit-border-bottom-right-radius:10px;-moz-border-radius-bottomright:10px;border-bottom-right-radius:10px;-webkit-border-bottom-left-radius:10px;-moz-border-radius-bottomleft:10px;border-bottom-left-radius:10px}.choosercontainer #chooseform
.submitbuttons{padding:.7em 0;text-align:center}@media (max-height:639px){.ios.safari .choosercontainer #chooseform
.submitbuttons{padding:45px
0}}.choosercontainer #chooseform .submitbuttons
input{min-width:100px;margin:0
.5em}.choosercontainer #chooseform
.options{position:relative;border-bottom:1px solid #BBB}.jschooser .choosercontainer #chooseform
.alloptions{overflow-x:hidden;overflow-y:auto;max-width:20.3em;-webkit-box-shadow:inset 0 0 30px 0 #ccc;-moz-box-shadow:inset 0 0 30px 0 #ccc;box-shadow:inset 0 0 30px 0 #ccc}.jschooser .choosercontainer #chooseform .alloptions .option input[type=radio]{display:inline-block}.jschooser .choosercontainer #chooseform .alloptions .option
.modicon{display:inline-block}.jschooser .choosercontainer #chooseform .alloptions .option
.typename{display:inline-block;width:65%}.dir-rtl.jschooser .choosercontainer #chooseform
.alloptions{max-width:18.3em}.choosercontainer #chooseform .moduletypetitle,.choosercontainer #chooseform .option,.choosercontainer #chooseform
.nonoption{margin-bottom:0;padding:0
1.6em 0 1.6em}.choosercontainer #chooseform
.moduletypetitle{text-transform:uppercase;padding-top:1.2em;padding-bottom:.4em}.choosercontainer #chooseform .option .typename,.choosercontainer #chooseform .option span.modicon img.icon,.choosercontainer #chooseform .nonoption .typename,.choosercontainer #chooseform .nonoption span.modicon
img.icon{padding:0
0 0 .5em}.dir-rtl .choosercontainer #chooseform .option .typename,.dir-rtl .choosercontainer #chooseform .option span.modicon img.icon,.dir-rtl .choosercontainer #chooseform .nonoption .typename,.dir-rtl .choosercontainer #chooseform .nonoption span.modicon
img.icon{padding:0
.5em 0 0}.chooserdialogue-course-modchooser .choosercontainer #chooseform .option span.modicon img.icon,.chooserdialogue-course-modchooser .choosercontainer #chooseform .nonoption span.modicon
img.icon{height:24px;width:24px}.choosercontainer #chooseform .option input[type=radio],.choosercontainer #chooseform .option span.typename,.choosercontainer #chooseform .option
span.modicon{vertical-align:middle}.choosercontainer #chooseform .option
label{display:block;padding:.3em 0 .1em 0;border-bottom:1px solid #FFF}.choosercontainer #chooseform
.nonoption{padding-left:2.7em;padding-top:.3em;padding-bottom:.1em}.dir-rtl .choosercontainer #chooseform
.nonoption{padding-right:2.7em;padding-left:0}.choosercontainer #chooseform
.subtype{margin-bottom:0;padding:0
1.6em 0 3.2em}.dir-rtl .choosercontainer #chooseform
.subtype{padding:0
3.2em 0 1.6em}.choosercontainer #chooseform .subtype
.typename{margin:0
0 0 .2em}.dir-rtl .choosercontainer #chooseform .subtype
.typename{margin:0
.2em 0 0}.jschooser .choosercontainer #chooseform .instruction,.jschooser .choosercontainer #chooseform
.typesummary{display:none;position:absolute;top:0;right:0;bottom:0;left:20.3em;margin:0;padding:1.6em;background-color:#fff;overflow-x:hidden;overflow-y:auto;line-height:2em}.dir-rtl.jschooser .choosercontainer #chooseform .instruction,.dir-rtl.jschooser .choosercontainer #chooseform
.typesummary{left:0;right:18.5em;border-right:1px solid grey}.jschooser .choosercontainer #chooseform .instruction,.choosercontainer #chooseform .selected
.typesummary{display:block}.choosercontainer #chooseform
.selected{background-color:#fff;-webkit-box-shadow:0 0 10px 0 #ccc;-moz-box-shadow:0 0 10px 0 #ccc;box-shadow:0 0 10px 0 #ccc}.section-modchooser-link
img.smallicon{padding:3px}.formlistingradio{padding-bottom:25px;padding-right:10px}.formlistinginputradio{float:left}.formlistingmain{min-height:225px}.formlisting{position:relative;margin:15px
0;padding:1px
19px 14px;background-color:white;border:1px
solid #DDD;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.formlistingmore{position:absolute;cursor:pointer;bottom:-1px;right:-1px;padding:3px
7px;font-size:12px;font-weight:bold;background-color:whiteSmoke;border:1px
solid #ddd;color:#9DA0A4;-webkit-border-radius:4px 0 4px 0;-moz-border-radius:4px 0 4px 0;border-radius:4px 0 4px 0}.formlistingall{margin:15px
0;padding:0;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.formlistingrow{cursor:pointer;border-bottom:1px solid;border-color:#E1E1E8;border-left:1px solid #E1E1E8;border-right:1px solid #E1E1E8;background-color:#F7F7F9;-webkit-border-radius:0 0 4px 4px;-moz-border-radius:0 0 4px 4px;border-radius:0 0 4px 4px;padding:6px;top:50%;left:50%;min-height:34px;float:left;width:150px}body.jsenabled
.formlistingradio{display:none}body.jsenabled
.formlisting{display:block}table.collection{width:100%;margin-bottom:20px;border:1px
solid #ddd;border-collapse:separate;*border-collapse:collapse;border-left:0;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}table.collection th,table.collection
td{padding:8px;line-height:20px;text-align:left;vertical-align:top;border-top:1px solid #ddd}table.collection
th{font-weight:bold}table.collection thead
th{vertical-align:bottom}table.collection caption+thead tr:first-child th,table.collection caption+thead tr:first-child td,table.collection colgroup+thead tr:first-child th,table.collection colgroup+thead tr:first-child td,table.collection thead:first-child tr:first-child th,table.collection thead:first-child tr:first-child
td{border-top:0}table.collection tbody+tbody{border-top:2px solid #ddd}table.collection
.table{background-color:#fff}table.collection th,table.collection
td{border-left:1px solid #ddd}table.collection caption+thead tr:first-child th,table.collection caption+tbody tr:first-child th,table.collection caption+tbody tr:first-child td,table.collection colgroup+thead tr:first-child th,table.collection colgroup+tbody tr:first-child th,table.collection colgroup+tbody tr:first-child td,table.collection thead:first-child tr:first-child th,table.collection tbody:first-child tr:first-child th,table.collection tbody:first-child tr:first-child
td{border-top:0}table.collection thead:first-child tr:first-child>th:first-child,table.collection tbody:first-child tr:first-child>td:first-child,table.collection tbody:first-child tr:first-child>th:first-child{-webkit-border-top-left-radius:4px;-moz-border-radius-topleft:4px;border-top-left-radius:4px}table.collection thead:first-child tr:first-child>th:last-child,table.collection tbody:first-child tr:first-child>td:last-child,table.collection tbody:first-child tr:first-child>th:last-child{-webkit-border-top-right-radius:4px;-moz-border-radius-topright:4px;border-top-right-radius:4px}table.collection thead:last-child tr:last-child>th:first-child,table.collection tbody:last-child tr:last-child>td:first-child,table.collection tbody:last-child tr:last-child>th:first-child,table.collection tfoot:last-child tr:last-child>td:first-child,table.collection tfoot:last-child tr:last-child>th:first-child{-webkit-border-bottom-left-radius:4px;-moz-border-radius-bottomleft:4px;border-bottom-left-radius:4px}table.collection thead:last-child tr:last-child>th:last-child,table.collection tbody:last-child tr:last-child>td:last-child,table.collection tbody:last-child tr:last-child>th:last-child,table.collection tfoot:last-child tr:last-child>td:last-child,table.collection tfoot:last-child tr:last-child>th:last-child{-webkit-border-bottom-right-radius:4px;-moz-border-radius-bottomright:4px;border-bottom-right-radius:4px}table.collection tfoot+tbody:last-child tr:last-child td:first-child{-webkit-border-bottom-left-radius:0;-moz-border-radius-bottomleft:0;border-bottom-left-radius:0}table.collection tfoot+tbody:last-child tr:last-child td:last-child{-webkit-border-bottom-right-radius:0;-moz-border-radius-bottomright:0;border-bottom-right-radius:0}table.collection caption+thead tr:first-child th:first-child,table.collection caption+tbody tr:first-child td:first-child,table.collection colgroup+thead tr:first-child th:first-child,table.collection colgroup+tbody tr:first-child td:first-child{-webkit-border-top-left-radius:4px;-moz-border-radius-topleft:4px;border-top-left-radius:4px}table.collection caption+thead tr:first-child th:last-child,table.collection caption+tbody tr:first-child td:last-child,table.collection colgroup+thead tr:first-child th:last-child,table.collection colgroup+tbody tr:first-child td:last-child{-webkit-border-top-right-radius:4px;-moz-border-radius-topright:4px;border-top-right-radius:4px}table.collection tbody>tr:nth-child(odd)>td,table.collection tbody>tr:nth-child(odd)>th{background-color:#f9f9f9}table.collection
td.name{text-align:left;vertical-align:middle}table.collection
td.awards{width:15%;text-align:center;vertical-align:middle}table.collection
td.criteria{width:40%;text-align:left;vertical-align:top}table.collection
td.status{width:15%;text-align:center;vertical-align:middle}table.collection
td.description{width:25%;text-align:left}table.collection
td.actions{width:11em;text-align:center;vertical-align:middle}a.criteria-action{padding:0
3px;float:right}div.criteria-description{padding:10px
15px;margin:5px
0;background:none repeat scroll 0 0 #f9f9f9;border:1px
solid #EEE}ul.badges{margin:0;list-style:none}.badges
li{position:relative;display:inline-block;padding-top:1em;text-align:center;vertical-align:top;width:150px}.badges li .badge-name{display:block;padding:5px}.badges li>img{position:absolute}.badges li .badge-image{width:100px;height:100px;left:10px;top:0;z-index:1}.badges li .badge-actions{position:relative}.badges li
.expireimage{width:100px;height:100px;left:25px;top:0;position:absolute;z-index:10;opacity:.85}#badge-image{background-color:transparent;padding:0;position:relative;min-width:100px;width:20%;display:inline-block;vertical-align:top;margin-top:17px}#badge-image
.expireimage{width:100px;height:100px;left:0;top:0;opacity:.85;filter:alpha(opacity=85);position:absolute;z-index:10}#badge-image
.singlebutton{padding-top:5px}#badge-image .singlebutton
input{margin-left:0}.dir-rtl #badge-image{float:right}.dir-rtl #badge-image
.expireimage{left:41px}#badge-details{display:inline-block;width:79%}#badge-overview dl,#badge-details
dl{margin:0}#badge-overview dl dt,#badge-details dl dt,#badge-overview dl dd,#badge-details dl
dd{vertical-align:top;padding:3px
0}#badge-overview dl dt,#badge-details dl
dt{clear:both;display:inline-block;width:20%;min-width:100px}#badge-overview dl dd,#badge-details dl
dd{display:inline-block;width:79%;margin-left:1%}.badge-profile{vertical-align:top}.connected{color:#468847}.notconnected{color:#b94a48}.connecting{color:#8a6d3b}#page-badges-award .recipienttable tr
td{vertical-align:top}#page-badges-award .recipienttable tr td.actions
.actionbutton{margin:.3em 0;padding:.5em 0;width:100%}#page-badges-award .recipienttable tr td.existing,#page-badges-award .recipienttable tr
td.potential{width:42%}#issued-badge-table
.activatebadge{display:inline-block}.statusbox.active{background-color:#dff0d8}.statusbox.inactive{background-color:#fcf8e3}.statusbox{text-align:center;margin-bottom:5px;padding:5px}.statusbox
.activatebadge{display:inline-block}.statusbox .activatebadge input[type=submit]{margin:3px}.activatebadge{margin:0;text-align:left;vertical-align:middle}.dir-rtl
.activatebadge{text-align:right}img#persona_signin{cursor:pointer}.addcourse{float:right}.invisiblefieldset{display:inline;margin:0;padding:0;border-width:0}.breadcrumb-nav{float:left;margin-bottom:10px}.dir-rtl .breadcrumb-nav{float:right}.breadcrumb-button .singlebutton
div{margin-right:0}.breadcrumb-nav
.breadcrumb{margin:0}.page-context-header{overflow:hidden}.page-context-header .page-header-image,.page-context-header .page-header-headings{display:block;position:relative}.page-context-header .page-header-image{margin-bottom:1em}.page-context-header .page-header-headings{margin-top:30px;margin-bottom:10px}.page-context-header .page-header-headings
h1{display:block}.page-context-header .page-header-headings,.page-context-header .header-button-group{position:relative;line-height:24px;vertical-align:middle}.page-context-header .header-button-group{display:block}.page-context-header .header-button-group
a{position:relative;top:-0.4em}.dir-ltr .page-context-header .page-header-image{float:left;margin-right:1em}.dir-ltr .page-context-header .header-button-group{float:left}.dir-rtl .page-context-header .page-header-image{float:right;margin-left:1em}.dir-rtl .page-context-header .header-button-group{float:right}.moodle-actionmenu,.moodle-actionmenu>ul,.moodle-actionmenu>ul>li{display:inline-block}.moodle-actionmenu
ul{padding:0;margin:0;list-style-type:none}.section_action_menu .moodle-actionmenu
ul.menubar{margin:0}.section_action_menu .moodle-actionmenu
ul.menu{margin:0
10px 10px 0}.moodle-actionmenu .toggle-display,.moodle-actionmenu .menu-action-text{display:none}.jsenabled .moodle-actionmenu[data-enhance]{display:block}.jsenabled .moodle-actionmenu[data-enhance] .menu{display:none}.jsenabled .moodle-actionmenu[data-enhance] .toggle-display{display:inline;opacity:.5;filter:alpha(opacity=50)}.jsenabled .moodle-actionmenu[data-enhance] .toggle-display.textmenu{display:block;margin-left:4px;padding-left:4px;padding-right:4px}.jsenabled .moodle-actionmenu[data-enhance] .toggle-display.textmenu .iconsmall,.jsenabled .moodle-actionmenu[data-enhance] .toggle-display.textmenu
.smallicon{margin:4px
4px 4px 0;padding:8px
4px 0 2px;vertical-align:text-bottom}.jsenabled .moodle-actionmenu[data-enhance] .toggle-display.textmenu
.caret{margin-top:8px;margin-left:2px;border-top-color:#777}.jsenabled .moodle-actionmenu[data-enhance] .toggle-display.textmenu .caret:hover,.jsenabled .moodle-actionmenu[data-enhance] .toggle-display.textmenu .caret:active{border-top-color:#555}.jsenabled .moodle-actionmenu[data-enhanced] .toggle-display{opacity:1;filter:alpha(opacity=100)}.jsenabled .moodle-actionmenu[data-enhanced] .menu-action-text{display:inline}.jsenabled.dir-rtl .moodle-actionmenu[data-enhance] .toggle-display.textmenu{margin-left:initial;margin-right:4px}.jsenabled.dir-rtl .moodle-actionmenu[data-enhance] .toggle-display.textmenu
.caret{margin-left:initial;margin-right:2px}.moodle-actionmenu[data-enhanced].show{position:relative}.moodle-actionmenu[data-enhanced].show
.menu{display:block;position:absolute;text-align:left;background-color:#fff;border:1px
solid rgba(0,0,0,0.2);z-index:1000;-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px;-webkit-box-shadow:5px 5px 20px 0 #666;-moz-box-shadow:5px 5px 20px 0 #666;box-shadow:5px 5px 20px 0 #666}.moodle-actionmenu[data-enhanced].show .menu
a{display:block;color:#333;padding:2px
1em 2px 28px}.moodle-actionmenu[data-enhanced].show .menu a:hover{color:#fff;background-color:#0070a8}.moodle-actionmenu[data-enhanced].show .menu a:first-child{-webkit-border-top-right-radius:4px;-moz-border-radius-topright:4px;border-top-right-radius:4px;-webkit-border-top-left-radius:4px;-moz-border-radius-topleft:4px;border-top-left-radius:4px}.moodle-actionmenu[data-enhanced].show .menu a:last-child{-webkit-border-bottom-right-radius:4px;-moz-border-radius-bottomright:4px;border-bottom-right-radius:4px;-webkit-border-bottom-left-radius:4px;-moz-border-radius-bottomleft:4px;border-bottom-left-radius:4px}.moodle-actionmenu[data-enhanced].show .menu
a.hidden{display:none}.moodle-actionmenu[data-enhanced].show .menu
img{vertical-align:middle}.moodle-actionmenu[data-enhanced].show .menu .iconsmall,.moodle-actionmenu[data-enhanced].show .menu
.smallicon{margin:4px
4px 4px -24px;padding:4px}.moodle-actionmenu[data-enhanced].show .menu>li{display:block}.moodle-actionmenu[data-enhanced].show .menu.align-tl-bl{top:100%;left:0;margin-top:4px}.moodle-actionmenu[data-enhanced].show .menu.align-tr-bl{top:100%;right:100%}.moodle-actionmenu[data-enhanced].show .menu.align-bl-bl{bottom:100%;left:0}.moodle-actionmenu[data-enhanced].show .menu.align-br-bl{bottom:100%;right:100%}.moodle-actionmenu[data-enhanced].show .menu.align-tl-br{top:100%;left:100%}.moodle-actionmenu[data-enhanced].show .menu.align-tr-br{top:100%;right:0;margin-top:4px}.moodle-actionmenu[data-enhanced].show .menu.align-bl-br{bottom:100%;left:100%}.moodle-actionmenu[data-enhanced].show .menu.align-br-br{bottom:100%;right:0}.moodle-actionmenu[data-enhanced].show .menu.align-tl-tl{top:0;left:0}.moodle-actionmenu[data-enhanced].show .menu.align-tr-tl{top:0;right:100%;margin-right:4px}.moodle-actionmenu[data-enhanced].show .menu.align-bl-tl{bottom:100%;left:0;margin-bottom:4px}.moodle-actionmenu[data-enhanced].show .menu.align-br-tl{bottom:100%;right:100%}.moodle-actionmenu[data-enhanced].show .menu.align-tl-tr{top:0;left:100%;margin-left:4px}.moodle-actionmenu[data-enhanced].show .menu.align-tr-tr{top:0;right:0}.moodle-actionmenu[data-enhanced].show .menu.align-bl-tr{bottom:100%;left:100%}.moodle-actionmenu[data-enhanced].show .menu.align-br-tr{bottom:100%;right:0;margin-bottom:4px}.moodle-actionmenu[data-enhanced].show.nowrap-items .menu>li{white-space:nowrap}.block .moodle-actionmenu{text-align:right}.dir-rtl .moodle-actionmenu[data-enhanced].show
.menu{text-align:right;left:0;right:auto}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu
a{padding:2px
28px 2px 1em}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu .iconsmall,.dir-rtl .moodle-actionmenu[data-enhanced].show .menu
.smallicon{margin-right:-24px;margin-left:4px}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-tl-bl{left:auto;right:0}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-tr-bl{right:auto;left:100%}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-bl-bl{left:auto;right:0}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-br-bl{right:auto;left:100%}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-tl-br{left:auto;right:100%}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-tr-br{right:auto;left:0}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-bl-br{left:auto;right:100%}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-br-br{right:auto;left:0}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-tl-tl{left:auto;right:0}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-tr-tl{right:auto;left:100%}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-bl-tl{left:auto;right:0}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-br-tl{right:auto;left:100%}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-tl-tr{left:auto;right:100%}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-tr-tr{right:auto;left:0}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-bl-tr{left:auto;right:100%}.dir-rtl .moodle-actionmenu[data-enhanced].show .menu.align-br-tr{right:auto;left:0}.dir-rtl .block .moodle-actionmenu{text-align:right}ul.dragdrop-keyboard-drag
li{list-style-type:none}.block-control-actions .moodle-core-dragdrop-draghandle
img{width:12px;height:12px}a.disabled:hover,a.disabled{text-decoration:none;cursor:default;font-style:italic;color:#808080}body.lockscroll{height:100%;overflow:hidden}.dir-rtl
ul{margin-left:0;margin-right:25px}.progressbar_container{max-width:500px;margin:0
auto}.ie10 .yui3-calendar-header-label{display:inline-block}dd:before,dd:after{display:block;content:" "}dd:after{clear:both}.nav-tabs>.active>a[href],.nav-tabs>.active>a[href]:hover,.nav-tabs>.active>a[href]:focus{cursor:pointer}.inplaceeditable.inplaceeditingon{position:relative}.inplaceeditable.inplaceeditingon
.editinstructions{margin-top:-30px;font-weight:normal;margin-right:0;margin-left:0;left:0;right:auto;white-space:nowrap}.inplaceeditable.inplaceeditingon
input{width:330px;height:16px;vertical-align:text-bottom;margin-bottom:0}.inplaceeditable.inplaceeditingon
select{margin-bottom:0}.inplaceeditable .quickediticon
img{opacity:.2}.inplaceeditable
.quickeditlink{color:inherit;text-decoration:inherit}.inplaceeditable:hover .quickeditlink .quickediticon img,.inplaceeditable .quickeditlink:focus .quickediticon
img{opacity:1}.inplaceeditable.inplaceeditable-toggle
.quickediticon{display:none}.dir-rtl .inplaceeditable.inplaceeditingon
.editinstructions{right:0;left:auto}h3.sectionname .inplaceeditable.inplaceeditingon
.editinstructions{margin-top:-20px}.formtable tbody
th{font-weight:normal;text-align:right}.path-admin
#assignrole{width:60%;margin-left:auto;margin-right:auto}.path-admin .admintable
.leftalign{text-align:left}.dir-rtl.path-admin .admintable
.leftalign{text-align:right}.environmenttable
p.warn{background-color:#fcf8e3;color:#8a6d3b}.environmenttable .error,.environmenttable span.warn,.environmenttable
.ok{display:inline-block;padding:2px
4px;font-size:11.844px;font-weight:bold;line-height:14px;color:#fff;vertical-align:baseline;white-space:nowrap;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#999;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.environmenttable .error:empty,.environmenttable span.warn:empty,.environmenttable .ok:empty{display:none}.environmenttable .error-important,.environmenttable span.warn-important,.environmenttable .ok-important{background-color:#b94a48}.environmenttable .error-important[href],.environmenttable span.warn-important[href],.environmenttable .ok-important[href]{background-color:#953b39}.environmenttable .error-warning,.environmenttable span.warn-warning,.environmenttable .ok-warning{background-color:#f89406}.environmenttable .error-warning[href],.environmenttable span.warn-warning[href],.environmenttable .ok-warning[href]{background-color:#c67605}.environmenttable .error-success,.environmenttable span.warn-success,.environmenttable .ok-success{background-color:#468847}.environmenttable .error-success[href],.environmenttable span.warn-success[href],.environmenttable .ok-success[href]{background-color:#356635}.environmenttable .error-info,.environmenttable span.warn-info,.environmenttable .ok-info{background-color:#3a87ad}.environmenttable .error-info[href],.environmenttable span.warn-info[href],.environmenttable .ok-info[href]{background-color:#2d6987}.environmenttable .error-inverse,.environmenttable span.warn-inverse,.environmenttable .ok-inverse{background-color:#333}.environmenttable .error-inverse[href],.environmenttable span.warn-inverse[href],.environmenttable .ok-inverse[href]{background-color:#1a1a1a}.environmenttable
.error{background-color:#b94a48}.environmenttable
span.warn{background-color:#f89406}.environmenttable
.ok{background-color:#468847}.path-admin .admintable.environmenttable .name,.path-admin .admintable.environmenttable .info,.path-admin #assignrole .admintable .role,.path-admin #assignrole .admintable .userrole,.path-admin #assignrole .admintable
.roleholder{white-space:nowrap}.path-admin .incompatibleblockstable
td.c0{font-weight:bold}#page-admin-course-category
.addcategory{padding:10px}#page-admin-course-index
.editcourse{margin:20px
auto}#page-admin-course-index .editcourse th,#page-admin-course-index .editcourse
td{padding-left:10px;padding-right:10px}.timewarninghidden{display:none}.statusok,.statuswarning,.statusserious,.statuscritical{display:inline-block;padding:2px
4px;font-size:11.844px;font-weight:bold;line-height:14px;color:#fff;vertical-align:baseline;white-space:nowrap;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#999;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.statusok:empty,.statuswarning:empty,.statusserious:empty,.statuscritical:empty{display:none}.statusok-important,.statuswarning-important,.statusserious-important,.statuscritical-important{background-color:#b94a48}.statusok-important[href],.statuswarning-important[href],.statusserious-important[href],.statuscritical-important[href]{background-color:#953b39}.statusok-warning,.statuswarning-warning,.statusserious-warning,.statuscritical-warning{background-color:#f89406}.statusok-warning[href],.statuswarning-warning[href],.statusserious-warning[href],.statuscritical-warning[href]{background-color:#c67605}.statusok-success,.statuswarning-success,.statusserious-success,.statuscritical-success{background-color:#468847}.statusok-success[href],.statuswarning-success[href],.statusserious-success[href],.statuscritical-success[href]{background-color:#356635}.statusok-info,.statuswarning-info,.statusserious-info,.statuscritical-info{background-color:#3a87ad}.statusok-info[href],.statuswarning-info[href],.statusserious-info[href],.statuscritical-info[href]{background-color:#2d6987}.statusok-inverse,.statuswarning-inverse,.statusserious-inverse,.statuscritical-inverse{background-color:#333}.statusok-inverse[href],.statuswarning-inverse[href],.statusserious-inverse[href],.statuscritical-inverse[href]{background-color:#1a1a1a}.statusok{background-color:#468847}.statuswarning{background-color:#8a6d3b}.statusserious{background-color:#f89406}.statuscritical{background-color:#b94a48}#page-admin-report-capability-index
#capabilitysearch{width:30em}#page-admin-report-backups-index .backup-error,#page-admin-report-backups-index .backup-unfinished{color:#b94a48}#page-admin-report-backups-index .backup-skipped,#page-admin-report-backups-index .backup-ok,#page-admin-report-backups-index .backup-notyetrun{color:#468847}#page-admin-report-backups-index .backup-warning{color:#8a6d3b}#page-admin-qtypes .disabled,#page-admin-qbehaviours
.disabled{color:#999}#page-admin-qtypes #qtypes div,#page-admin-qtypes #qtypes form,#page-admin-qbehaviours #qbehaviours div,#page-admin-qbehaviours #qbehaviours
form{display:inline}#page-admin-qtypes #qtypes img.spacer,#page-admin-qbehaviours #qbehaviours
img.spacer{width:16px}img.iconsmall{margin:0;padding:.3em}#page-admin-qbehaviours .cell.c3,#page-admin-qtypes
.cell.c3{font-size:10.5px}#page-admin-lang .generalbox,#page-admin-course-index .singlebutton,#page-admin-course-index .addcategory,#page-course-index .buttons,#page-course-index-category .buttons,#page-admin-course-category .addcategory,#page-admin-stickyblocks .generalbox,#page-admin-maintenance .buttons,#page-admin-course-index .buttons,#page-admin-course-category .buttons,#page-admin-index .copyright,#page-admin-index .copyrightnotice,#page-admin-index .adminerror .singlebutton,#page-admin-index .adminwarning .singlebutton,#page-admin-index #layout-table
.singlebutton{text-align:center;margin-bottom:1em}.path-admin-roles
.capabilitysearchui{text-align:left;margin-left:auto;margin-right:auto}#page-admin-roles-define
.topfields{margin:1em
0 2em}#page-admin-roles-define
.capdefault{background-color:#f5f5f5;border:1px
solid #ddd}#page-filter-manage .backlink,.path-admin-roles
.backlink{margin-top:1em}#page-admin-roles-explain #chooseuser h3,#page-admin-roles-usersroles
.contextname{margin-top:0}#page-admin-roles-explain
#chooseusersubmit{margin-top:0;text-align:center}#page-admin-roles-usersroles
p{margin:0}#page-admin-roles-override .cell.c1,#page-admin-roles-assign .cell.c3,#page-admin-roles-assign
.cell.c1{padding-top:.75em}#page-admin-roles-override .overridenotice,#page-admin-roles-define
.definenotice{margin:1em
10% 2em 10%;text-align:left}#notice{width:60%;min-width:220px;margin:auto}#page-admin-index .releasenoteslink,#page-admin-index .adminwarning,#page-admin-index
.adminerror{margin:auto;padding:8px
35px 8px 14px;margin-bottom:20px;text-shadow:0 1px 0 rgba(255,255,255,0.5);background-color:#fcf8e3;border:1px
solid #fbeed5;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;color:#8a6d3b;width:60%;min-width:220px}#page-admin-index
.adminerror{background-color:#f2dede;border-color:#eed3d7;color:#b94a48}#page-admin-index
.releasenoteslink{background-color:#d9edf7;border-color:#bce8f1;color:#3a87ad}#page-admin-index .adminwarning.availableupdatesinfo .moodleupdateinfo
span{display:block}#page-admin-index .updateplugin
div{margin-bottom:.5em}#page-admin-index .updateplugin
.updatepluginconfirmexternal{padding:1em;background-color:#f2dede;border:1px
solid #eed3d7}#page-admin-user-user_bulk #users
.fgroup{white-space:nowrap}#page-admin-report-stats-index
.graph{text-align:center;margin-bottom:1em}#page-admin-report-courseoverview-index
.graph{text-align:center;margin-bottom:1em}#page-admin-lang
.translator{border-width:1px;border-style:solid}.path-admin
.roleassigntable{width:100%}.path-admin .roleassigntable
td{vertical-align:top;padding:.2em .3em}.path-admin .roleassigntable
p{text-align:left;margin:.2em 0}.path-admin .roleassigntable #existingcell,.path-admin .roleassigntable
#potentialcell{width:42%}.path-admin .roleassigntable #existingcell p>label:first-child,.path-admin .roleassigntable #potentialcell p>label:first-child{font-weight:bold}.path-admin .roleassigntable
#buttonscell{width:16%}.path-admin .roleassigntable #buttonscell
#assignoptions{font-size:10.5px}.path-admin .roleassigntable #removeselect_wrapper,.path-admin .roleassigntable
#addselect_wrapper{width:100%}.path-admin table.rolecap tr.rolecap
th{text-align:left;font-weight:normal}.path-admin.dir-rtl table.rolecap tr.rolecap
th{text-align:right}.path-admin .rolecap
.hiddenrow{display:none}.path-admin #defineroletable .rolecap .inherit,.path-admin #defineroletable .rolecap .allow,.path-admin #defineroletable .rolecap .prevent,.path-admin #defineroletable .rolecap
.prohibit{text-align:center;padding:0;min-width:3.5em}.path-admin .rolecap .cap-name,.path-admin .rolecap
.note{display:block;font-size:10.5px;white-space:nowrap;font-weight:normal}.path-admin .rolecap
label{display:block;text-align:center;padding:.5em;margin:0}.plugincheckwrapper{width:100%}.environmentbox{margin-top:1em}#mnetconfig
table{margin-left:auto;margin-right:auto}.environmenttable
.cell{padding:.15em .5em}.environmenttable
img.iconhelp{padding-right:.3em}.dir-rtl .environmenttable
img.iconhelp{padding-left:.3em;padding-right:0}#trustedhosts
.generaltable{margin-left:auto;margin-right:auto;width:500px}#trustedhosts
.standard{width:auto}#adminsettings
legend{display:none}#adminsettings
fieldset.error{margin:.2em 0 .5em 0}#adminsettings fieldset.error
legend{display:block}.dir-rtl #admin-spelllanguagelist textarea,#page-admin-setting-editorsettingstinymce.dir-rtl .form-textarea
textarea{text-align:left;direction:ltr}.adminsettingsflags{float:right}.dir-rtl
.adminsettingsflags{float:left}.adminsettingsflags
label{margin-right:7px}.dir-rtl .adminsettingsflags
label{margin-left:7px}.form-description{clear:right}.dir-rtl .form-description{clear:left}.form-item .form-setting .form-htmlarea{width:640px;display:inline}.form-item .form-setting .form-htmlarea
.htmlarea{width:640px;display:block}.form-item .form-setting .form-multicheckbox
ul{list-style:none;padding:0;margin:7px
0 0 0}.form-item .form-setting
.defaultsnext{margin-right:.5em;display:inline}.dir-rtl .form-item .form-setting
.defaultsnext{margin-left:.5em;margin-right:0}.form-item .form-setting .locked-checkbox{margin-right:.2em;margin-left:.5em;display:inline}.dir-rtl .form-item .form-setting .locked-checkbox{margin-right:.5em;margin-left:.2em;display:inline}.form-item .form-setting .form-password .unmask,.form-item .form-setting .form-defaultinfo{display:inline-block}.form-item .pathok,.form-item
.patherror{margin-left:.5em}#admin-emoticons td
input{width:8em}#admin-emoticons td.c0
input{width:4em}#adminthemeselector .selectedtheme
td.c0{border:1px
solid #000;border-right-width:0}#adminthemeselector .selectedtheme
td.c1{border:1px
solid #000;border-left-width:0}.admin_colourpicker,.admin_colourpicker_preview{display:none}.jsenabled
.admin_colourpicker_preview{display:inline}.jsenabled
.admin_colourpicker{display:block;height:102px;width:410px;margin-bottom:10px}.admin_colourpicker
.loadingicon{vertical-align:middle;margin-left:auto}.admin_colourpicker
.colourdialogue{float:left;border:1px
solid #000}.admin_colourpicker
.previewcolour{border:1px
solid #000;margin-left:301px}.admin_colourpicker
.currentcolour{border:1px
solid #000;margin-left:301px;border-top-width:0}.dir-rtl .form-item .form-setting,.dir-rtl .form-item .form-label,.dir-rtl .form-item .form-description,.dir-rtl.path-admin .roleassigntable
p{text-align:right}#page-admin-index #notice
.checkforupdates{text-align:center}#page-admin-index .adminwarning.availableupdatesinfo .moodleupdateinfo.maturity200
.info.release{background-color:#d9edf7}#page-admin-index .adminwarning.availableupdatesinfo .moodleupdateinfo.maturity100 .info.release,#page-admin-index .adminwarning.availableupdatesinfo .moodleupdateinfo.maturity150
.info.release{background-color:#fcf8e3}#page-admin-index .adminwarning.availableupdatesinfo .moodleupdateinfo.maturity50
.info.release{background-color:#f2dede}#page-admin-plugins #plugins-overview-panel
.info{display:inline-block;margin-right:1em}#page-admin-plugins
.checkforupdates{margin:10px
0}#page-admin-plugins .checkforupdates
.singlebutton{margin:5px
0;padding:0}#page-admin-plugins .checkforupdates .singlebutton div,#page-admin-plugins .checkforupdates .singlebutton
input{margin:0
3px 0 0}#page-admin-plugins
.updateavailableinstallall{margin:5px
0;padding:0}#page-admin-plugins .updateavailableinstallall div,#page-admin-plugins .updateavailableinstallall
input{margin:0
3px 5px 0}#page-admin-plugins #plugins-control-panel .status-missing
td{background-color:#f2dede}#page-admin-plugins #plugins-control-panel .pluginname .displayname
img.icon{padding-top:0;padding-bottom:0}#page-admin-plugins #plugins-control-panel .pluginname
.componentname{font-size:11.9px;color:#999;margin-left:22px}#page-admin-plugins #plugins-control-panel .version
.versionnumber{font-size:11.9px;color:#999}#page-admin-plugins #plugins-control-panel .uninstall
a{color:#b94a48}#page-admin-plugins #plugins-control-panel .notes
.label{margin-right:3px}#page-admin-plugins #plugins-control-panel .notes
.requiredby{font-size:11.9px;color:#999}#plugins-check-page .page-description{color:#999}#plugins-check-page .checkforupdates
.singlebutton{margin:5px
0;padding:0}#plugins-check-page .checkforupdates .singlebutton div,#plugins-check-page .checkforupdates .singlebutton
input{margin:0
3px 0 0}#plugins-check-page #plugins-check-info .actions>div{display:inline-block;margin-right:1em}#plugins-check-page #plugins-check-info .actions
.singlebutton{margin:5px
0;padding:0}#plugins-check-page #plugins-check-info .actions .singlebutton div,#plugins-check-page #plugins-check-info .actions .singlebutton
input{margin:0
3px 0 0}#plugins-check-page #plugins-check .requires-ok{color:#999}#plugins-check-page #plugins-check .status-missing td,#plugins-check-page #plugins-check .status-downgrade
td{background-color:#f2dede}#plugins-check-page #plugins-check .displayname
.pluginicon{margin-right:5px;width:16px}#plugins-check-page #plugins-check .displayname
.plugindir{color:#999;font-size:11.9px}#plugins-check-page #plugins-check .requires
ul{margin-left:13px}#plugins-check-page #plugins-check .status
.actionbutton{margin:5px
0;padding:0}#plugins-check-page #plugins-check .status .actionbutton
input{margin:0}#plugins-check-page .plugins-check-dependencies-actions>div{display:inline-block;margin-right:1em}#plugins-check-page .plugins-check-dependencies-actions
.singlebutton{margin:5px
0;padding:0}#plugins-check-page .plugins-check-dependencies-actions .singlebutton div,#plugins-check-page .plugins-check-dependencies-actions .singlebutton
input{margin:0
3px 0 0}#plugins-check-page #plugins-check-available-dependencies .displayname
.component{font-size:11.9px;color:#999}#plugins-check-page #plugins-check-available-dependencies .info .actions>div{display:inline-block;margin-right:1em}#plugins-check-page #plugins-check-available-dependencies .info .actions
.dependencyinstall{display:block;margin:5px
0;padding:0}#plugins-check-page #plugins-check-available-dependencies .info .actions .dependencyinstall
input{margin:0}#plugins-check-page .pluginupdateinfo,#plugins-control-panel
.pluginupdateinfo{background-color:#d9edf7;padding:5px;margin:10px
0;-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px}#plugins-check-page .pluginupdateinfo.maturity50,#plugins-control-panel
.pluginupdateinfo.maturity50{background-color:#f2dede}#plugins-check-page .pluginupdateinfo.maturity100,#plugins-control-panel .pluginupdateinfo.maturity100,#plugins-check-page .pluginupdateinfo.maturity150,#plugins-control-panel
.pluginupdateinfo.maturity150{background-color:#fcf8e3}#plugins-check-page .pluginupdateinfo .info,#plugins-control-panel .pluginupdateinfo
.info{display:inline-block}#plugins-check-page .pluginupdateinfo .separator:after,#plugins-control-panel .pluginupdateinfo .separator:after{content:" | "}#plugins-check-page .pluginupdateinfo .singlebutton,#plugins-control-panel .pluginupdateinfo
.singlebutton{margin:5px
0;padding:0}#plugins-check-page .pluginupdateinfo .singlebutton div,#plugins-control-panel .pluginupdateinfo .singlebutton div,#plugins-check-page .pluginupdateinfo .singlebutton input,#plugins-control-panel .pluginupdateinfo .singlebutton
input{margin:0
3px 0 0}.plugins-management-confirm-buttons>div{display:inline-block;margin:1em
1em 1em 0}.plugins-management-confirm-buttons
.continue{padding:0}.plugins-management-confirm-buttons .continue div,.plugins-management-confirm-buttons .continue
input{margin:0}.uninstalldeleteconfirmexternal{background-color:#fcf8e3;padding:.5em 1em;margin:5px
0 10px 0}#page-admin-index
.upgradepluginsinfo{text-align:center}#page-admin-index .adminwarning.availableupdatesinfo .moodleupdateinfo .separator:after{content:" | "}.dir-rtl #plugins-check
.pluginupdateinfo{text-align:center;direction:ltr}.dir-rtl #plugins-check .requires-ok{text-align:left;direction:ltr}#page-admin-mnet-peers
.box.deletedhosts{margin-bottom:1em;font-size:11.9px}#page-admin-mnet-peers .mform
.deletedhostinfo{background-color:#f2dede;border:2px
solid #eed3d7;padding:4px;margin-bottom:5px}#core-cache-plugin-summaries table,#core-cache-store-summaries
table{width:100%}#core-cache-lock-summary table,#core-cache-definition-summaries table,#core-cache-mode-mappings
table{margin:0
auto}#core-cache-store-summaries .default-store
td{font-style:italic}#core-cache-rescan-definitions,#core-cache-mode-mappings .edit-link,#core-cache-lock-summary .new-instance{margin-top:.5em;text-align:center}.tinymcesubplugins
img.icon{padding-top:0;padding-bottom:0}.maintenancewarning{padding:3px
1em;text-align:center;position:fixed;bottom:0;right:0;overflow:hidden;z-index:1}.maintenancewarning.error{color:#b94a48;background-color:#f2dede;border:2px
solid #eed3d7;font-weight:bold}.maintenancewarning.warning{color:#8a6d3b;background-color:#fcf8e3;border:2px
solid #fbeed5}#adminsettings .form-overridden{color:#3a87ad;background-color:#d9edf7}.calendar_event_course{background-color:#ffd3bd}.calendar_event_global{background-color:#d6f8cd}.calendar_event_group{background-color:#fee7ae}.calendar_event_user{background-color:#dce7ec}.path-calendar
.calendartable{width:100%}.path-calendar .calendartable th,.path-calendar .calendartable
td{width:14%;vertical-align:top;text-align:center;border:0}.path-calendar .calendar-controls .previous,.path-calendar .calendar-controls .next,.path-calendar .calendar-controls
.current{display:block;float:left;width:12%}.path-calendar .calendar-controls
.previous{text-align:left}.path-calendar .calendar-controls
.current{text-align:center;width:76%}.path-calendar .calendar-controls
.next{text-align:right}.path-calendar .filters
table{border-collapse:separate;border-spacing:2px;width:100%}.path-calendar
.cal_courses_flt{float:left}.path-calendar .cal_courses_flt
label{margin-right:.45em}.path-calendar
.maincalendar{vertical-align:top;padding:0}.path-calendar .maincalendar
.bottom{text-align:center;padding:5px
0 0 0}.path-calendar .maincalendar
.heightcontainer{height:100%;position:relative}.path-calendar .maincalendar
.calendarmonth{width:98%;margin:10px
auto}.path-calendar .maincalendar .calendarmonth
ul{margin:0}.path-calendar .maincalendar .calendarmonth ul
li{list-style-type:none;margin-top:4px}.path-calendar .maincalendar .calendarmonth
td{height:5em}.path-calendar .maincalendar .calendar-controls .previous,.path-calendar .maincalendar .calendar-controls
.next{width:30%}.path-calendar .maincalendar .calendar-controls
.current{width:39.95%}.path-calendar .maincalendar
.controls{width:98%;margin:10px
auto}.path-calendar .maincalendar .calendar_event_course,.path-calendar .maincalendar .calendar_event_global,.path-calendar .maincalendar .calendar_event_group,.path-calendar .maincalendar
.calendar_event_user{border-width:1px 1px 1px 12px;border-style:solid}.path-calendar .maincalendar
.calendar_event_course{border-color:#ffd3bd}.path-calendar .maincalendar
.calendar_event_global{border-color:#d6f8cd}.path-calendar .maincalendar
.calendar_event_group{border-color:#fee7ae}.path-calendar .maincalendar
.calendar_event_user{border-color:#dce7ec}.path-calendar .maincalendar .calendar-event-panel{background-color:#eee;border:2px
solid #eee}.path-calendar .maincalendar .calendar-event-panel .yui3-overlay-content{padding:19px;background-color:#fdfdfd;border:1px
solid #e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05)}.path-calendar .maincalendar .calendar-controls
.current{font-family:inherit;font-weight:bold;color:inherit;font-size:25px;line-height:1.2}.path-calendar .maincalendar .calendartable td,.path-calendar .maincalendar .calendartable
li{padding:5px}.path-calendar .maincalendar .calendartable
li{padding-left:10px;text-align:left}.path-calendar .maincalendar
.header{overflow:hidden}.path-calendar .maincalendar .header
.buttons{float:right}.path-calendar .maincalendar
.eventlist{margin:0}.path-calendar .maincalendar .eventlist
.event{width:92%;border-spacing:0;border-collapse:separate;position:relative;padding:20px
4%;margin-bottom:20px;background-color:#fdfdfd;border:1px
solid #e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);list-style-type:none}.path-calendar .maincalendar .eventlist .event>img{padding-top:3px;float:left}.path-calendar .maincalendar .eventlist .event
.name{font-size:17.5px;font-weight:200;line-height:24px;float:left;margin:0}.path-calendar .maincalendar .eventlist .event .name,.path-calendar .maincalendar .eventlist .event
.course{margin-bottom:5px}.path-calendar .maincalendar .eventlist .event
.date{float:right}.path-calendar .maincalendar .eventlist .event .course,.path-calendar .maincalendar .eventlist .event
.subscription{float:left;clear:left}.path-calendar .maincalendar .eventlist .event
.side{width:22px}.path-calendar .maincalendar .eventlist .event
.description{background-color:#fff;padding:5px;clear:both}.path-calendar .maincalendar .eventlist .event .description
.commands{position:absolute;right:0;top:0;margin:3px}.path-calendar .maincalendar .eventlist .event
.commands{position:absolute;top:2px;right:2px}.path-calendar .maincalendar .eventlist .event .commands
a{margin:0
3px}.dir-rtl.path-calendar
.cal_courses_flt{float:right}.dir-rtl.path-calendar .cal_courses_flt
label{margin-left:.45em;margin-right:0}.dir-rtl.path-calendar .maincalendar .calendar_event_course,.dir-rtl.path-calendar .maincalendar .calendar_event_global,.dir-rtl.path-calendar .maincalendar .calendar_event_group,.dir-rtl.path-calendar .maincalendar
.calendar_event_user{border-left-width:1px;border-right-width:12px}.dir-rtl.path-calendar .maincalendar .calendar-controls
.next{text-align:left}.dir-rtl.path-calendar .maincalendar .calendar-controls
.previous{text-align:right}.dir-rtl.path-calendar .maincalendar .calendartable td,.dir-rtl.path-calendar .maincalendar .calendartable
li{text-align:right}.dir-rtl.path-calendar .maincalendar .calendartable
li{padding-right:10px;padding-left:5px}.dir-rtl.path-calendar .maincalendar .header
.buttons{float:left}.dir-rtl.path-calendar .maincalendar .eventlist .event>img{float:right}.dir-rtl.path-calendar .maincalendar .eventlist .event
.name{float:right}.dir-rtl.path-calendar .maincalendar .eventlist .event
.date{float:left}.dir-rtl.path-calendar .maincalendar .eventlist .event .description
.commands{right:inherit;left:0}.dir-rtl.path-calendar .maincalendar .eventlist .event .course,.dir-rtl.path-calendar .maincalendar .eventlist .event
.subscription{float:right;clear:right}.dir-rtl.path-calendar .maincalendar .eventlist .event
.commands{left:2px;right:inherit}#page-calendar-export
.indent{padding-left:20px}.block
.minicalendar{max-width:280px;margin:0
auto;width:100%}.block .minicalendar th,.block .minicalendar
td{padding:2px;font-size:.8em;text-align:center}.block .minicalendar
td.weekend{color:#999}.block .minicalendar td
a{width:100%;height:100%;display:block}.block .minicalendar
td.duration_global{border-top:1px solid #d6f8cd;border-bottom:1px solid #d6f8cd}.block .minicalendar
td.duration_global.duration_finish{background-color:#d6f8cd}.block .minicalendar
td.duration_course{border-top:1px solid #ffd3bd;border-bottom:1px solid #ffd3bd}.block .minicalendar
td.duration_course.duration_finish{background-color:#ffd3bd}.block .minicalendar
td.duration_group{border-top:1px solid #fee7ae;border-bottom:1px solid #fee7ae}.block .minicalendar
td.duration_group.duration_finish{background-color:#fee7ae}.block .minicalendar
td.duration_user{border-top:1px solid #dce7ec;border-bottom:1px solid #dce7ec}.block .minicalendar
td.duration_user.duration_finish{background-color:#dce7ec}.block .minicalendar
caption{font-size:inherit;font-weight:inherit;line-height:inherit;text-align:center}.block .calendar-event-panel{background-color:#eee;border:1px
solid #eee}.block .calendar-event-panel .yui3-overlay-content{padding:19px;background-color:#fdfdfd;border:1px
solid #e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05)}.block .calendar-event-panel .yui3-overlay-content
h2.eventtitle{line-height:1.2;font-size:18px}.block .calendar-event-panel .yui3-overlay-content .eventcontent
img{padding-right:5px}.block .calendar-controls .previous,.block .calendar-controls .current,.block .calendar-controls
.next{display:block;float:left}.block .calendar-controls
.previous{text-align:left;width:12%}.block .calendar-controls
.current{text-align:center;width:76%}.block .calendar-controls
.next{text-align:right;width:12%}.block .calendar_filters
ul{list-style:none;margin:0}.block .calendar_filters
li{margin-bottom:.2em}.block .calendar_filters li span
img{padding:0
.2em}.block .calendar_filters
.eventname{padding-left:.2em}.block .content
h3.eventskey{margin-top:.5em}.dir-rtl .block .calendar_filters
.eventname{padding-right:.2em;padding-left:0}.dir-rtl .block .calendar-event-panel .yui3-overlay-content .eventcontent
img{padding-right:0;padding-left:5px}.ical-link{font-size:10px;font-weight:bold;background-color:#f60;padding:0
5px;color:#fff;border-top:1px solid #f93;border-left:1px solid #f93;border-bottom:1px solid #013;border-right:1px solid #013}.ical-link:hover,.ical-link:active,.ical-link:focus,.ical-link:visited{color:#fff;text-decoration:none}@media (min-width:768px){#page-calender-view .container-fluid{min-width:1024px}}.section_add_menus{text-align:right;clear:both}.section-modchooser{clear:both}.dir-rtl
.section_add_menus{text-align:left;clear:both}.section_add_menus .horizontal div,.section_add_menus .horizontal
form{display:inline}.section_add_menus
optgroup{font-weight:normal;font-style:italic}.section_add_menus
.urlselect{margin-left:.4em}.dir-rtl .section_add_menus
.urlselect{margin-right:.4em;margin-left:0}.section_add_menus .urlselect
select{margin-left:.2em}.dir-rtl .section_add_menus .urlselect
select{margin-right:.2em;margin-left:0}.section_add_menus .urlselect
img.iconhelp{padding:0;margin:0;vertical-align:text-bottom}.sitetopic
ul.section{margin:0}.course-content
ul.section{margin:1em}.section
.side.left{float:left}.section
.side.right{float:right}.section
.spinner{height:16px;width:16px}.section .activity
.spinner{left:100%;position:absolute;vertical-align:text-bottom}.section .activity
.actions{position:absolute;right:0;top:0}.section .activity .contentwithoutlink,.section .activity
.activityinstance{min-width:40%;display:table-cell;padding-right:4px;min-height:2em}.section .activity .contentwithoutlink .dimmed img.activityicon,.section .activity .activityinstance .dimmed
img.activityicon{opacity:.5;filter:alpha(opacity=50)}.section .label .contentwithoutlink,.section .label
.activityinstance{padding-right:32px;display:block;height:inherit}.section .label .mod-indent-outer{padding-left:24px;display:block}.section
.filler{width:16px;height:16px;padding:.3em;display:inline-block}.section .activity.editor_displayed a.editing_title,.section .activity.editor_displayed .moodle-actionmenu{display:none}.section .activity.editor_displayed
div.activityinstance{padding-right:initial}.section .activity.editor_displayed div.activityinstance
input{margin-bottom:initial;padding-top:initial;padding-bottom:initial;vertical-align:text-bottom}.dir-rtl .section
.side.left{float:right}.dir-rtl .section
.side.right{float:left}.dir-rtl .section .activity
.spinner{left:auto;right:100%}.dir-rtl .section .activity
.actions{left:0;right:auto}.dir-rtl .section .activity .contentwithoutlink,.dir-rtl .section .activity
.activityinstance{padding-left:4px;padding-right:initial}.dir-rtl .section .activity.editor_displayed
div.activityinstance{padding-left:initial}.activity
img.activityicon{margin-right:6px;vertical-align:text-bottom}.dir-rtl .section .activity
img.activityicon{margin-left:6px;margin-right:0}.section .activity .activityinstance,.section .activity .activityinstance
div{display:inline-block}.editing .section .activity
.editing_move{position:absolute;left:0;top:0}.editing .section .activity .mod-indent-outer{padding-left:32px}.editing .section .activity .contentwithoutlink,.editing .section .activity
.activityinstance{padding-right:200px}.dir-rtl.editing .section .activity .contentwithoutlink,.dir-rtl.editing .section .activity
.activityinstance{padding-left:200px;padding-right:0}.dir-rtl.editing .section .activity
.editing_move{left:auto;right:0}.dir-rtl.editing .section .activity .mod-indent-outer{padding-left:0;padding-right:32px}.editing_show+.editing_assign,.editing_hide+.editing_assign{margin-left:20px}.section .activity
.commands{white-space:nowrap;display:inline}.section
.activity.modtype_label.label{font-weight:normal;padding:.2em}.section
li.activity{padding:.2em;clear:both}.section .activity .activityinstance
.groupinglabel{padding-left:30px}.dir-rtl .section .activity .activityinstance
.groupinglabel{padding-right:30px}.section .activity .availabilityinfo,.section .activity
.contentafterlink{margin-top:.5em;margin-left:30px}.dir-rtl .section .activity .availabilityinfo,.dir-rtl .section .activity
.contentafterlink{margin-left:0;margin-right:30px}.section .activity .contentafterlink
p{margin:.5em 0}.editing .section .activity:hover,.editing .section .activity.action-menu-shown{background-color:#eee}.course-content
.current{background-color:#d9edf7}.course-content .section-summary{border:1px
solid #ddd;margin-top:5px;list-style:none}.course-content .section-summary .section-title{margin:2px
5px 10px 5px}.course-content .section-summary
.summarytext{margin:2px
5px 2px 5px}.course-content .section-summary .section-summary-activities .activity-count{color:#999;font-size:11.9px;margin:3px;white-space:nowrap;display:inline-block}.course-content .section-summary
.summary{margin-top:5px}.course-content .single-section{margin-top:1em}.course-content .single-section .section-navigation{display:block;padding:.5em;margin-bottom:-0.5em}.course-content .single-section .section-navigation
.title{font-weight:bold;font-size:108%;clear:both}.course-content .single-section .section-navigation .mdl-left{font-weight:normal;float:left;margin-right:1em}.dir-rtl .course-content .single-section .section-navigation .mdl-left{float:right}.course-content .single-section .section-navigation .mdl-left
.larrow{margin-right:.1em}.course-content .single-section .section-navigation .mdl-right{font-weight:normal;float:right;margin-left:1em}.dir-rtl .course-content .single-section .section-navigation .mdl-right{float:left}.course-content .single-section .section-navigation .mdl-right
.rarrow{margin-left:.1em}.course-content .single-section .section-navigation .mdl-bottom{margin-top:0}.course-content ul
li.section.main{border-bottom:2px solid #ddd;margin-top:0}.course-content ul li.section.hidden .sectionname>span,.course-content ul li.section.hidden .content>div,.course-content ul li.section.hidden .activity
.activityinstance{opacity:.5}.course-content ul li.section.hidden .sectionname>span,.course-content ul li.section.hidden .activity
.activityinstance{margin-left:10px;margin-right:10px}.course-content ul.topics li.section .content,.course-content ul.weeks li.section
.content{margin-right:20px;margin-left:20px;padding:0}.course-content{margin-top:0}.course-content ul.topics
li.section{padding-bottom:20px}.course-content ul.topics li.section
.summary{margin-left:25px}.course-content li.section
ul{list-style:disc}.course-content li.section ul
ul{list-style:circle}.course-content li.section ul ul
ul{list-style:square}.course-content li.section li.activity
ul{list-style:disc}.course-content li.section li.activity ul
ul{list-style:circle}.course-content li.section li.activity ul ul
ul{list-style:square}.path-course-view
.completionprogress{margin-left:25px}.path-course-view
.completionprogress{display:block;float:right;height:20px;position:relative}#page-site-index
.subscribelink{text-align:right}#site-news-forum h2,#frontpage-course-list h2,#frontpage-category-names h2,#frontpage-category-combo
h2{margin-bottom:9px}.path-course-view a.reduce-sections{padding-left:.2em}.path-course-view
.subscribelink{text-align:right}.path-course-view
.unread{margin-left:30px}.dir-rtl.path-course-view
.unread{margin-right:30px}.path-course-view .block.drag
.header{cursor:move}.path-course-view
.completionprogress{text-align:right}.dir-rtl.path-course-view
.completionprogress{text-align:left}.path-course-view .single-section
.completionprogress{margin-right:5px}.path-course-view .section
.summary{line-height:normal}.path-site li.activity>div,.path-course-view li.activity>div{position:relative;padding:0
16px 0 0}.dir-rtl.path-site li.activity>div,.dir-rtl.path-course-view li.activity>div{position:relative;padding:0
0 0 16px}.path-course-view li.activity span.autocompletion
img{vertical-align:text-bottom}.path-course-view li.activity form.togglecompletion
img{max-width:none}.path-course-view li.activity form.togglecompletion
.ajaxworking{width:16px;height:16px;position:absolute;right:22px;top:3px;background:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=i%2Fajaxloader) no-repeat}.dir-rtl.path-course-view
.completionprogress{float:none}.dir-rtl.path-course-view li.activity form.togglecompletion
.ajaxworking{right:-22px}li.section.hidden span.commands a.editing_hide,li.section.hidden span.commands
a.editing_show{cursor:default}ul.weeks
h3.sectionname{white-space:nowrap}.editing ul.weeks
h3.sectionname{white-space:normal}.single-section
h3.sectionname{text-align:center;clear:both}.section
img.movetarget{height:16px;width:80px}input.titleeditor{width:330px;vertical-align:text-bottom}span.editinstructions{position:absolute;top:0;margin-top:-22px;margin-left:30px;line-height:16px;font-size:11.9px;padding:.1em .4em;background-color:#d9edf7;color:#3a87ad;text-decoration:none;z-index:9999;-webkit-box-shadow:2px 2px 5px 1px #ccc;-moz-box-shadow:2px 2px 5px 1px #ccc;box-shadow:2px 2px 5px 1px #ccc;border:1px
solid #bce8f1}#dndupload-status{position:fixed;left:0;width:40%;margin:0
30%;padding:6px;border:1px
solid #bce8f1;text-align:center;background:#d9edf7;color:#3a87ad;z-index:1;-webkit-box-shadow:2px 2px 5px 1px #ccc;-moz-box-shadow:2px 2px 5px 1px #ccc;box-shadow:2px 2px 5px 1px #ccc;-webkit-border-radius:8px;-moz-border-radius:8px;border-radius:8px}.dndupload-preview{color:#909090;border:1px
dashed #909090;list-style:none;margin-top:.2em;padding:.3em}.dndupload-preview
img.icon{vertical-align:text-bottom;padding:0}.dndupload-progress-outer{overflow:hidden;height:20px;margin-bottom:20px;background-color:#f7f7f7;background-image:-moz-linear-gradient(top, #f5f5f5, #f9f9f9);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#f5f5f5), to(#f9f9f9));background-image:-webkit-linear-gradient(top, #f5f5f5, #f9f9f9);background-image:-o-linear-gradient(top, #f5f5f5, #f9f9f9);background-image:linear-gradient(to bottom, #f5f5f5, #f9f9f9);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#fff5f5f5', endColorstr='#fff9f9f9', GradientType=0);-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,0.1);-moz-box-shadow:inset 0 1px 2px rgba(0,0,0,0.1);box-shadow:inset 0 1px 2px rgba(0,0,0,0.1);-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.dndupload-progress-inner{width:0;height:100%;color:#fff;float:left;font-size:12px;text-align:center;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#0e90d2;background-image:-moz-linear-gradient(top, #149bdf, #0480be);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#149bdf), to(#0480be));background-image:-webkit-linear-gradient(top, #149bdf, #0480be);background-image:-o-linear-gradient(top, #149bdf, #0480be);background-image:linear-gradient(to bottom, #149bdf, #0480be);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff149bdf', endColorstr='#ff0480be', GradientType=0);-webkit-box-shadow:inset 0 -1px 0 rgba(0,0,0,0.15);-moz-box-shadow:inset 0 -1px 0 rgba(0,0,0,0.15);box-shadow:inset 0 -1px 0 rgba(0,0,0,0.15);-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;-webkit-transition:width .6s ease;-moz-transition:width .6s ease;-o-transition:width .6s ease;transition:width .6s ease}.dndupload-hidden{display:none}#page-course-pending .singlebutton,#page-course-index .singlebutton,#page-course-index-category .singlebutton,#page-course-editsection
.singlebutton{text-align:center}#page-admin-course-manage #movecourses td
img{margin:0
.22em;vertical-align:text-bottom}#page-admin-course-manage #movecourses td
img.icon{padding:0}#coursesearch{margin-top:1em;text-align:center}#page-course-pending
.pendingcourserequests{margin-bottom:1em}#page-course-pending .pendingcourserequests
.singlebutton{display:inline}#page-course-pending .pendingcourserequests
.cell{padding:0
5px}#page-course-pending .pendingcourserequests
.cell.c6{white-space:nowrap}.coursebox{margin-bottom:15px;border:1px
dotted #ddd;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;padding:5px}.coursebox>.info>.coursename
a{display:block;background-image:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=i%2Fcourse);background-repeat:no-repeat;padding-left:21px;background-position:left .2em}.dir-rtl .coursebox>.info>.coursename
a{padding-left:0;padding-right:21px;background-position:right .2em}.coursebox>.info>.coursename,.coursebox .content .teachers,.coursebox .content .courseimage,.coursebox .content
.coursefile{float:left;clear:left}.coursebox .content .teachers,.coursebox .content .courseimage,.coursebox .content
.coursefile{width:40%}.dir-rtl .coursebox>.info>.coursename,.dir-rtl .coursebox .teachers,.dir-rtl .coursebox .content .courseimage,.dir-rtl .coursebox .content
.coursefile{float:right;clear:right}.coursebox>.info>h3.coursename{margin:5px;line-height:1}.coursebox>.info>.coursename{margin:5px;padding:0}.coursebox .content .teachers
li{list-style-type:none;padding:0;margin:0}.coursebox
.enrolmenticons{padding:3px
0;float:right}.coursebox
.moreinfo{padding:3px
0;float:right}.coursebox .enrolmenticons img,.coursebox .moreinfo
img{margin:0
.2em}.coursebox
.content{clear:both}.coursebox .content .summary,.coursebox .content
.coursecat{float:right;width:55%}.coursebox .content
.coursecat{text-align:right;clear:right}.coursebox.remotecoursebox
.remotecourseinfo{float:left;width:40%}.coursebox .content .courseimage
img{max-width:100px;max-height:100px}.coursebox .content .coursecat,.coursebox .content .summary,.coursebox .content .courseimage,.coursebox .content .coursefile,.coursebox .content .teachers,.coursebox.remotecoursebox
.remotecourseinfo{margin:3px
5px;padding:0}.coursebox.remotehost>.info>.categoryname
a{background-image:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=i%2Fmnethost)}.dir-rtl .coursebox>.info>.categoryname
a{padding-left:0;padding-right:21px;background-position:center right}.dir-rtl .coursebox>.info>.categoryname,.dir-rtl .coursebox .teachers,.dir-rtl .coursebox .content .courseimage,.dir-rtl .coursebox .content
.coursefile{float:right;clear:right}.dir-rtl .coursebox .enrolmenticons,.dir-rtl .coursebox
.moreinfo{float:left}.dir-rtl .coursebox .summary,.dir-rtl .coursebox
.coursecat{float:left}.dir-rtl .coursebox
.coursecat{text-align:left;clear:left}.coursebox.collapsed{margin-bottom:0}.coursebox.collapsed>.content{display:none}.courses
.coursebox.collapsed{border:1px
solid #ddd;padding:5px}.courses
.coursebox.even{background-color:#f9f9f9}.courses .coursebox:hover,.course_category_tree .courses>.paging.paging-morelink:hover{background-color:#f5f5f5}.course_category_tree .category
.numberofcourse{font-size:11.9px}.course_category_tree
.controls{visibility:hidden}.course_category_tree .controls
div{display:inline;cursor:pointer}.jsenabled .course_category_tree
.controls{visibility:visible}.course_category_tree
.controls{margin-bottom:5px;text-align:right;float:right}.course_category_tree .controls
div{padding-right:2em;font-size:75%}.course_category_tree .category>.info>.categoryname{background-image:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fcollapsed_empty);background-repeat:no-repeat;padding:2px
18px;margin:3px;background-position:center left}.dir-rtl .course_category_tree .category>.info>.categoryname{background-image:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fcollapsed_empty_rtl);background-position:center right}.course_category_tree .category.with_children>.info>.categoryname{background-image:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fexpanded);cursor:pointer}.course_category_tree .category.with_children.collapsed>.info>.categoryname{background-image:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fcollapsed)}.dir-rtl .course_category_tree .category.with_children.collapsed>.info>.categoryname{background-image:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fcollapsed_rtl)}.course_category_tree .category.collapsed>.content{display:none}.course_category_tree .category>.info{min-height:20px;padding:19px;margin-bottom:20px;background-color:#f5f5f5;border:1px
solid #e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);border-color:#e3e3e3;min-height:0;padding:0;margin:3px
0;margin-bottom:3px;clear:both}.course_category_tree .category>.info
blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}.course_category_tree.frontpage-category-names .category>.info{background:none;border:none;margin:0}.course_category_tree .category>.content{padding-left:16px}.dir-rtl .course_category_tree .category>.content{padding-left:0;padding-right:16px}.course_category_tree .subcategories>.paging,.courses>.paging{margin:0;padding:5px;text-align:center}.courses>.paging.paging-morelink,.course_category_tree .subcategories>.paging.paging-morelink{text-align:left}.course_category_tree .paging.paging-morelink
a{font-size:11.9px}.dir-rtl .courses>.paging.paging-morelink,.dir-rtl .course_category_tree .paging.paging-morelink{text-align:right}#page-course-index-category
.generalbox.info{margin-bottom:15px;border:1px
dotted #ddd;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;padding:5px}#page-course-index-category
.categorypicker{text-align:center;margin:10px
0 20px}.section .summary .iconsmall,.section .activity
.iconsmall{width:16px;height:16px}.section .editing_title
.iconsmall{width:12px;height:12px;margin:8px
8px 0 0;padding:4px
8px 0 0;vertical-align:text-bottom}.section .moodle-actionmenu
.iconsmall{max-width:none !important;width:16px;height:16px;padding:4px;vertical-align:text-bottom}.section .moodle-actionmenu[data-enhanced] .menu
img{width:12px;height:12px}.dir-rtl .section .editing_title
.iconsmall{margin:8px
0 0 8px;padding:4px
0 0 8px}#course-category-listings{background-color:transparent;margin-bottom:200px}#course-category-listings.columns-2>#course-listing>div{position:relative;left:-1px}#course-category-listings.columns-3>#course-listing>div{height:100%}#course-category-listings>div>div{min-height:300px}#course-category-listings>div>div>ul.ml>li:first-child>div{border-top:0}#course-category-listings
h3{margin:0;padding:.4rem .6rem .3rem}#course-category-listings
h4{margin:1rem 0 0;padding:.6rem 1rem .5rem}#course-category-listings .moodle-actionmenu{white-space:nowrap}#course-category-listings .moodle-actionmenu[data-enhance] .toggle-display
img{width:auto}#course-category-listings .moodle-actionmenu[data-enhance] .toggle-display.textmenu{padding-right:4px}#course-category-listings .moodle-actionmenu[data-enhance] .toggle-display.textmenu
.caret{margin-top:12px}#course-category-listings .listing-actions{text-align:center;padding:.4rem .3rem .3rem;line-height:2.2em}#course-category-listings .listing-actions>a,#course-category-listings .listing-actions>.moodle-actionmenu{display:inline-block}#course-category-listings .listing-actions>.moodle-actionmenu .menu
a{padding-left:1rem}#course-category-listings .listing-actions .moodle-actionmenu:not([data-enhanced]) li{line-height:normal}#course-category-listings .listing-actions .moodle-actionmenu:not([data-enhanced])>.menubar
a{color:inherit;display:inline-block}#course-category-listings .listing-actions .moodle-actionmenu:not([data-enhanced])>.menubar a>img{display:none}#course-category-listings .listing-actions .moodle-actionmenu:not([data-enhanced])>.menubar a
.caret{display:none}#course-category-listings .listing-actions .moodle-actionmenu:not([data-enhanced])>.menu .menu-action-text{display:inline-block}#course-category-listings
ul.ml{list-style:none;margin:1rem 0}#course-category-listings ul.ml
ul.ml{margin:0}#course-category-listings
li{line-height:2.2em}#course-category-listings li>div:hover{background-color:#f5f5f5}#course-category-listings li .tree-icon{margin:2px
6px 0 0;width:12px;vertical-align:inherit}#course-category-listings li[data-selected='1']>div{background-color:#f9f9f9}#course-category-listings li[data-selected='1']>div:hover{background-color:#f5f5f5}#course-category-listings li .tree-icon{margin-left:0}#course-category-listings li li .tree-icon{margin-left:1em}#course-category-listings li li li .tree-icon{margin-left:2em}#course-category-listings li li li li .tree-icon{margin-left:3em}#course-category-listings li li li li li .tree-icon{margin-left:4em}#course-category-listings li li li li li li .tree-icon{margin-left:4.5em}#course-category-listings li li li li li li li .tree-icon{margin-left:5em}#course-category-listings li li li li li li li li .tree-icon{margin-left:5.5em}#course-category-listings .item-actions{margin-right:1em;display:inline-block;display:initial}#course-category-listings .item-actions>a img,#course-category-listings .item-actions .menubar
img{margin:0
4px;height:12px;padding:0;vertical-align:inherit}#course-category-listings .item-actions.show .menu
li{line-height:20px}#course-category-listings .item-actions.show .menu
img{width:12px;max-width:none}#course-category-listings .item-actions .menu-action-text{vertical-align:inherit}#course-category-listings .listitem>div>.float-left{float:left}#course-category-listings .listitem>div>.float-right{float:right;text-align:right}#course-category-listings .listitem>div .item-actions .action-show{display:none}#course-category-listings .listitem>div .item-actions .action-hide{display:inline}#course-category-listings .listitem>div .without-actions{color:#333}#course-category-listings .listitem>div
.idnumber{color:#a1a1a8;margin-right:2em}#course-category-listings .listitem[data-visible="0"]{color:#999}#course-category-listings .listitem[data-visible="0"]>div>a{color:#999}#course-category-listings .listitem[data-visible="0"]>div .item-actions .action-show{display:inline}#course-category-listings .listitem[data-visible="0"]>div .item-actions .action-hide{display:none}#course-category-listings
.listitem.highlight{background-color:transparent}#course-category-listings .listitem.highlight>div,#course-category-listings .listitem.highlight>div:hover,#course-category-listings .listitem.highlight[data-selected='1']>div{background-color:#f5f5f5}#course-category-listings #course-listing .listitem
.categoryname{display:inline-block;margin-left:1em;color:#a1a1a8}#course-category-listings #course-listing .listitem
.coursename{display:inline-block}#course-category-listings #course-listing .listitem>div{padding-left:1rem}#course-category-listings #course-listing>.firstpage .listitem:first-child>div .item-actions .action-moveup,#course-category-listings #course-listing>.lastpage .listitem:last-child>div .item-actions .action-movedown{display:none}#course-category-listings #course-listing .bulk-action-checkbox{margin:-2px 6px 0 0}#course-category-listings #category-listing .listitem.collapsed>ul.ml{display:none}#course-category-listings #category-listing .listitem>div>.ba-checkbox{width:2.2em;text-align:center;margin:-1px .5em 0 0;padding-top:2px}#course-category-listings #category-listing .listitem.highlight>div>.ba-checkbox{background-color:#f5f5f5}#course-category-listings #category-listing .listitem[data-selected='1']>div>.ba-checkbox{margin:0
.5em 0 0;padding:0;background-color:inherit}#course-category-listings #category-listing .listitem:first-child>div .item-actions .action-moveup,#course-category-listings #category-listing .listitem:last-child>div .item-actions .action-movedown{display:none}#course-category-listings #category-listing .course-count{color:#a1a1a8;margin-right:2rem;min-width:3.5em;display:inline-block}#course-category-listings #category-listing .course-count
.smallicon{width:12px;margin-left:4px;vertical-align:inherit}#course-category-listings #category-listing .bulk-action-checkbox{margin-right:-3px}#course-category-listings #category-listing .category-listing>ul>.listitem:first-child{position:relative}#course-category-listings #category-listing .category-bulk-actions{margin:0
.5em .5em;position:relative}#course-category-listings .detail-pair{border-bottom:1px solid #ddd;margin:0
1rem}#course-category-listings .detail-pair>*{display:inline-block;line-height:2.2rem}#course-category-listings .detail-pair .pair-key{font-weight:bold;vertical-align:top}#course-category-listings .detail-pair .pair-key
span{margin-right:1rem;display:block}#course-category-listings .detail-pair .pair-value
select{max-width:100%}#course-category-listings .bulk-actions .detail-pair>*{display:block;width:100%}#course-category-listings .listing-pagination{text-align:center}#course-category-listings .listing-pagination .yui3-button{background-color:#fff;border:0;margin:.4rem .2rem .45rem;font-size:10.4px}#course-category-listings .listing-pagination .yui3-button.active-page{background-color:#e6e6e6}#course-category-listings .listing-pagination-totals{text-align:center}#course-category-listings .listing-pagination-totals.dimmed{color:#999;margin:.4rem 1rem .45rem}#course-category-listings .select-a-category .notifymessage,#course-category-listings .select-a-category
.alert{margin:1em}#course-category-listings #course-listing .listitem .drag-handle{display:none}.jsenabled #course-category-listings #course-listing .listitem .drag-handle{display:inline-block;margin:0
6px 0 0;cursor:pointer}.dir-rtl #course-category-listings #category-listing,.dir-rtl #course-category-listings #course-listing{float:right;margin-left:0}.dir-rtl #course-category-listings .listitem>div>.float-left{float:right}.dir-rtl #course-category-listings .listitem>div>.float-right{float:left;text-align:left}.dir-rtl #course-category-listings li .tree-icon{margin:2px
0 0 6px}.dir-rtl #course-category-listings li .tree-icon{margin-right:0}.dir-rtl #course-category-listings li li .tree-icon{margin-right:1em}.dir-rtl #course-category-listings li li li .tree-icon{margin-right:2em}.dir-rtl #course-category-listings li li li li .tree-icon{margin-right:3em}.dir-rtl #course-category-listings li li li li li .tree-icon{margin-right:4em}.dir-rtl #course-category-listings li li li li li li .tree-icon{margin-right:4.5em}.dir-rtl #course-category-listings li li li li li li li .tree-icon{margin-right:5em}.dir-rtl #course-category-listings li li li li li li li li .tree-icon{margin-right:5.5em}.dir-rtl #course-category-listings #category-listing .listitem>div{margin-right:.5em;margin-left:0}.dir-rtl #course-category-listings #category-listing .listitem>div>.ba-checkbox{margin:-1px 0 0 .5em}.dir-rtl #course-category-listings #category-listing .listitem[data-selected='1']>div>.ba-checkbox{margin:0
0 0 .5em}.dir-rtl #course-category-listings #category-listing .course-count{margin-left:2rem}.dir-rtl #course-category-listings #category-listing .course-count
.smallicon{margin-left:0;margin-right:4px}.dir-rtl #course-category-listings #category-listing .bulk-action-checkbox{margin-left:-3px;margin-right:0}.dir-rtl #course-category-listings #course-listing{padding-right:24px}.dir-rtl #course-category-listings #course-listing .listitem
.idnumber{color:#a1a1a8;padding-right:2em}.dir-rtl #course-category-listings #course-listing .listitem
.categoryname{display:inline-block;margin-right:1em;margin-left:0}.dir-rtl #course-category-listings #course-listing .listitem .drag-handle{margin:0
6px 0 6px}.dir-rtl #course-category-listings #course-listing .listitem>div{padding-left:1rem}.dir-rtl #course-category-listings #course-listing .bulk-action-checkbox{vertical-align:middle;margin:-2px 0 0 6px}.dir-rtl #course-category-listings .detail-pair>*{float:right;margin-right:0}.dir-rtl #course-category-listings .detail-pair .pair-key
span{margin-right:0;margin-left:0}.dir-rtl #course-category-listings .detail-pair .pair-value{margin-right:.5em}.coursecat-management-header{vertical-align:middle}.coursecat-management-header
h2{display:inline-block;text-align:left}.coursecat-management-header>div{display:inline-block;float:right;line-height:40px}.coursecat-management-header>div>div{margin-left:1em;margin:10px
0;display:inline-block}.coursecat-management-header
select{max-width:300px;cursor:pointer;padding:.4em .5em .45em 1em;vertical-align:baseline;white-space:nowrap}.coursecat-management-header .view-mode-selector .moodle-actionmenu{white-space:nowrap;display:inline-block}.coursecat-management-header .view-mode-selector .moodle-actionmenu[data-enhanced].show .menu
a{padding-left:1em}.dir-rtl .coursecat-management-header
h2{text-align:right}.dir-rtl .coursecat-management-header>div{float:left;margin-right:1em;margin-left:0}.course-being-dragged-proxy{border:0;color:#0070a8;vertical-align:middle;padding:0
0 0 4em}.course-being-dragged{opacity:.5;filter:alpha(opacity=50)}@media (min-width:1200px) and (max-width:1600px){#course-category-listings.columns-3{background-color:transparent;border:0}#course-category-listings.columns-3 #category-listing,#course-category-listings.columns-3 #course-listing{width:50%}#course-category-listings.columns-3 #category-listing>div,#course-category-listings.columns-3 #course-listing>div,#course-category-listings.columns-3 #course-detail>div{background-color:transparent}#course-category-listings.columns-3 #course-detail{width:100%;margin-top:1em}}@media (max-width:1199px){#course-category-listings.columns-2,#course-category-listings.columns-3{background-color:transparent;border:0}#course-category-listings.columns-2 #category-listing,#course-category-listings.columns-3 #category-listing,#course-category-listings.columns-2 #course-listing,#course-category-listings.columns-3 #course-listing,#course-category-listings.columns-2 #course-detail,#course-category-listings.columns-3 #course-detail{width:100%;margin:0
0 1em}#course-category-listings.columns-2 #category-listing>div,#course-category-listings.columns-3 #category-listing>div,#course-category-listings.columns-2 #course-listing>div,#course-category-listings.columns-3 #course-listing>div,#course-category-listings.columns-2 #course-detail>div,#course-category-listings.columns-3 #course-detail>div{background-color:transparent}}.filemanager,.filepicker,.file-picker{font-size:11px}.filemanager a,.file-picker a,.filemanager a:hover,.file-picker a:hover{color:#555;text-decoration:none}.filemanager input[type="text"],.file-picker input[type="text"]{width:265px}.filemanager .fp-license td,.file-picker .fp-setlicense
td{max-width:265px}.filemanager .fp-license select,.file-picker .fp-setlicense
select{max-width:100%}.fp-content-center{height:100%;width:100%;display:table-cell;vertical-align:middle}.fp-content-hidden{visibility:hidden}.yui3-panel-focused{outline:none}#filesskin .yui3-panel-content{padding-bottom:20px;background:#F2F2F2;-webkit-border-radius:8px;-moz-border-radius:8px;border-radius:8px;border:1px
solid #fff;display:inline-block;*display:inline;*zoom:1;-webkit-box-shadow:5px 5px 20px 0 #666;-moz-box-shadow:5px 5px 20px 0 #666;box-shadow:5px 5px 20px 0 #666}#filesskin .yui3-widget-hd{-webkit-border-radius:10px 10px 0 0;-moz-border-radius:10px 10px 0 0;border-radius:10px 10px 0 0;border-bottom:1px solid #BBB;padding:5px;text-align:center;font-size:12px;color:#333;letter-spacing:1px;text-shadow:1px 1px 1px #fff;filter:dropshadow(color=#FFFFFF, offx=1, offy=1);background-color:#ebebeb;background-image:-moz-linear-gradient(top, #fff, #ccc);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#fff), to(#ccc));background-image:-webkit-linear-gradient(top, #fff, #ccc);background-image:-o-linear-gradient(top, #fff, #ccc);background-image:linear-gradient(to bottom,#fff,#ccc);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff',endColorstr='#ffcccccc',GradientType=0)}.fp-panel-button{background:#fff;padding:3px
20px 2px 20px;text-align:center;margin:10px;-webkit-border-radius:10px;-moz-border-radius:10px;border-radius:10px;display:inline-block;*display:inline;*zoom:1;-webkit-box-shadow:2px 2px 3px .1px #999;-moz-box-shadow:2px 2px 3px .1px #999;box-shadow:2px 2px 3px .1px #999}.moodle-dialogue
h3{font-size:14px;margin:0;line-height:20px}.moodle-dialogue-base .filepicker .moodle-dialogue-wrap .moodle-dialogue-bd{padding:0}#filesskin .file-picker.fp-generallayout{width:859px;background:#FFF;-webkit-border-radius:10px;-moz-border-radius:10px;border-radius:10px;border:1px
solid #CCC;position:relative}.file-picker .fp-repo-area{width:180px;overflow:auto;display:inline-block;*display:inline;*zoom:1;float:left;height:525px;border-right:1px solid #BBB}.dir-rtl .file-picker .fp-repo-area{border-left:1px solid #BBB;border-right:none;float:right}.file-picker .fp-repo-items{float:none;width:auto;margin-left:181px}.moodle-dialogue-fullscreen .file-picker .fp-repo-items{margin-left:0;margin-right:0;float:left}.dir-rtl .file-picker .fp-repo-items{margin-left:0;margin-right:181px}.dir-rtl .moodle-dialogue-fullscreen .file-picker .fp-repo-items{margin-left:0;margin-right:0;float:right}.file-picker .fp-navbar{background:#F2F2F2;border-bottom:1px solid #BBB;min-height:40px;overflow:hidden}.file-picker .fp-navbar .fp-viewbar{margin:4px}.file-picker .fp-content{background:#FFF;clear:none;overflow:auto;height:452px}.filepicker.moodle-dialogue-fullscreen .file-picker .fp-content{width:100%}.file-picker .fp-content-loading{height:100%;width:100%;display:table;text-align:center}.file-picker .fp-content .fp-object-container{width:98%;height:98%}.dir-rtl .file-picker .fp-list{text-align:right}.dir-rtl .file-picker .fp-toolbar{padding:4px}.dir-rtl .file-picker .fp-list{text-align:right}.dir-rtl .file-picker .fp-repo-name{display:inline}.dir-rtl .file-picker .fp-pathbar{text-align:right;display:block;border-top:none}.dir-rtl .file-picker
div.bd{text-align:right}.dir-rtl #filemenu
.yuimenuitemlabel{text-align:right}.dir-rtl .filepicker .yui-layout-unit-left{left:500px}.dir-rtl .filepicker .yui-layout-unit-center{left:0}.dir-rtl .filemanager-toolbar
a{padding:0}.file-picker .fp-list{list-style-type:none;padding:0;float:left;width:100%;margin:0}.dir-rtl .file-picker .fp-list{text-align:right;float:left}.file-picker .fp-list .fp-repo
a{display:block;padding:.5em .7em}.file-picker .fp-list .fp-repo.active{background:#F2F2F2}.file-picker .fp-list .fp-repo-icon{padding:0
7px 0 5px;width:16px;height:16px}.fp-toolbar{float:left}.dir-rtl .fp-toolbar{float:right}.fp-toolbar.empty{display:none}.dir-rtl .fp-toolbar div.disabled,.fp-toolbar
.disabled{display:none}.fp-toolbar
div{display:block;float:left;margin-right:4px}.dir-rtl .fp-toolbar
div{display:block;float:right;margin-left:4px;margin-right:0}.fp-toolbar
img{vertical-align:-15%;margin-right:5px}.fp-toolbar .fp-tb-search{width:235px;height:27px}.fp-toolbar .fp-tb-search
input{background:#FFF url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=a%2Fsearch') no-repeat 7px 7px;padding:2px
6px 1px 27px;width:200px;height:27px;border:1px
solid #BBB}.fp-viewbar{float:right;height:30px;border:1px
solid #CCC;border-bottom:1px solid #B3B3B3;border-radius:4px;background:white}.fp-repo-items fp-viewbar{margin:4px}.dir-rtl .fp-toolbar
img{vertical-align:-35%}.dir-rtl .fp-viewbar{float:left}.fp-viewbar
a{width:30px;height:30px;border-right:1px solid #CCC;display:block;float:left}.fp-viewbar a.checked:hover,.fp-viewbar a:hover{background-image:radial-gradient(ellipse at center, #fff 60%, #dfdfdf 100%);background-color:#ebebeb}.fp-viewbar a.checked,.fp-viewbar a:active{background-image:radial-gradient(ellipse at center, #fff 40%, #dfdfdf 100%);background-color:#dfdfdf}.fp-viewbar a.fp-vb-icons{border-radius:4px 0 0 4px}.fp-viewbar a.fp-vb-tree{border-right:0;border-radius:0 4px 4px 0}.fp-viewbar a
img{margin:7px}.fp-viewbar.disabled
a{opacity:.45;background:none;cursor:default}.file-picker .fp-clear-left{clear:left}.dir-rtl .fp-vb-details a:hover{background:none;border:20px
solid black}.dir-rtl .fp-vb-details.checked a:hover{background:none;border:40px
solid black}.dir-rtl .fp-vb-tree a:hover{background:none;border:30px
solid black}.dir-rtl .fp-vb-tree.checked a:hover{background:none;border:50px
solid black}.file-picker .fp-pathbar{display:table-row}.fp-pathbar.empty{display:none}.fp-pathbar .fp-path-folder{background:url('/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=fp%2Fpath_folder') no-repeat 0 0;width:27px;height:12px;margin-left:4px}.dir-rtl .fp-pathbar .fp-path-folder{background:url('/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=fp%2Fpath_folder_rtl') no-repeat right top;width:auto;height:12px;margin-left:4px}.dir-rtl .fp-pathbar
span{display:inline-block;*display:inline;*zoom:1;float:right;margin-left:32px}.fp-pathbar .fp-path-folder-name{margin-left:32px;line-height:20px}.dir-rtl .fp-pathbar .fp-path-folder-name{margin-right:32px;line-height:20px}.fp-iconview .fp-file{float:left;text-align:center;position:relative;margin:10px
10px 35px}.fp-iconview .fp-thumbnail{min-width:110px;min-height:110px;line-height:110px;text-align:center;border:1px
solid #FFF;display:block}.fp-iconview .fp-thumbnail
img{border:1px
solid #ddd;padding:3px;vertical-align:middle;-webkit-box-shadow:1px 1px 2px 0 #ccc;-moz-box-shadow:1px 1px 2px 0 #ccc;box-shadow:1px 1px 2px 0 #ccc}.fp-iconview .fp-thumbnail:hover{background:#fff;border:1px
solid #ddd;-webkit-box-shadow:inset 0 0 10px 0 #ccc;-moz-box-shadow:inset 0 0 10px 0 #ccc;box-shadow:inset 0 0 10px 0 #ccc}.fp-iconview .fp-filename-field{height:33px;word-wrap:break-word;overflow:hidden;position:absolute}.fp-iconview .fp-filename-field:hover{overflow:visible;z-index:1000}.fp-iconview .fp-filename-field .fp-filename{background:#FFF;padding-top:5px;padding-bottom:12px;min-width:112px}.dir-rtl .fp-iconview .fp-file{float:right}.file-picker .yui3-datatable
table{border:0
solid #BBB;width:100%}#filesskin .file-picker .yui3-datatable-header{background:#FFF;border-bottom:1px solid #CCC;border-left:0 solid #FFF;color:#555}#filesskin .file-picker .yui3-datatable-odd .yui3-datatable-cell{background-color:#F6F6F6;border-left:0 solid #F6F6F6}#filesskin .file-picker .yui3-datatable-even .yui3-datatable-cell{background-color:#FFF;border-left:0 solid #FFF}.dir-rtl .file-picker .yui3-datatable-header{text-align:right}.file-picker .ygtvtn,.filemanager
.ygtvtn{background:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=y%2Ftn') 0 0 no-repeat;width:17px;height:22px}.dir-rtl .filemanager .ygtvtn,.dir-rtl .file-picker
.ygtvtn{background:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=y%2Ftn_rtl') 0 0 no-repeat;width:17px;height:22px}.file-picker .ygtvtm,.filemanager
.ygtvtm{background:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=y%2Ftm') 0 10px no-repeat;width:13px;height:12px;cursor:pointer}.file-picker .ygtvtmh,.filemanager
.ygtvtmh{background:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=y%2Ftm') 0 10px no-repeat;width:13px;height:12px;cursor:pointer}.file-picker .ygtvtp,.filemanager
.ygtvtp{background:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=y%2Ftp') 0 10px no-repeat;width:13px;height:12px;cursor:pointer}.dir-rtl .file-picker .ygtvtp,.dir-rtl .filemanager
.ygtvtp{background:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=y%2Ftp_rtl') 0 10px no-repeat}.file-picker .ygtvtph,.filemanager
.ygtvtph{background:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=y%2Ftp') 0 10px no-repeat;width:13px;height:22px;cursor:pointer}.dir-rtl .file-picker .ygtvtph,.dir-rtl .filemanager
.ygtvtph{background:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=y%2Ftp_rtl') 0 10px no-repeat}.file-picker .ygtvln,.filemanager
.ygtvln{background:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=y%2Fln') 0 0 no-repeat;width:17px;height:22px}.dir-rtl .file-picker .ygtvln,.dir-rtl .filemanager
.ygtvln{background:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=y%2Fln_rtl') 0 0 no-repeat}.file-picker .ygtvlm,.filemanager
.ygtvlm{background:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=y%2Flm') 0 10px no-repeat;width:13px;height:12px;cursor:pointer}.file-picker .ygtvlmh,.filemanager
.ygtvlmh{background:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=y%2Flm') 0 10px no-repeat;width:13px;height:12px;cursor:pointer}.file-picker .ygtvlp,.filemanager
.ygtvlp{background:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=y%2Flp') 0 10px no-repeat;width:13px;height:12px;cursor:pointer}.dir-rtl .file-picker .ygtvlp,.dir-rtl .filemanager
.ygtvlp{background:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=y%2Flp_rtl') 0 10px no-repeat}.file-picker .ygtvlph,.filemanager
.ygtvlph{background:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=y%2Flp') 0 10px no-repeat;width:13px;height:12px;cursor:pointer}.dir-rtl .file-picker .ygtvlph,.dir-rtl .filemanager
.ygtvlph{background:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=y%2Flp_rtl') 0 10px no-repeat}.file-picker .ygtvloading,.filemanager
.ygtvloading{background:transparent url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=y%2Floading') 0 0 no-repeat;width:16px;height:22px}.file-picker .ygtvdepthcell,.filemanager
.ygtvdepthcell{background:url('/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=y%2Fvline') 0 0 no-repeat;width:17px;height:32px}.file-picker .ygtvblankdepthcell,.filemanager
.ygtvblankdepthcell{width:17px;height:22px}a.ygtvspacer:hover{color:transparent;text-decoration:none}.ygtvlabel,.ygtvlabel:link,.ygtvlabel:visited,.ygtvlabel:hover{background-color:transparent;cursor:pointer;margin-left:2px;text-decoration:none}.file-picker .ygtvfocus,.filemanager
.ygtvfocus{background-color:#EEE}.fp-filename-icon{margin-top:10px;display:block;position:relative}.fp-icon{float:left;margin-top:-7px;width:24px;height:24px;margin-right:10px;text-align:center;line-height:24px}.dir-rtl .fp-icon{float:right;margin-left:10px;margin-right:0}.fp-icon
img{max-height:24px;max-width:24px;vertical-align:middle}.fp-filename{padding-right:10px}.dir-rtl .fp-filename{padding-left:10px;padding-right:0}.file-picker .fp-login-form{height:100%;width:100%;display:table}.file-picker .fp-login-form
table{margin:0
auto}.file-picker .fp-login-form
p{text-align:center;margin-top:3em}.file-picker .fp-login-form .fp-login-input
label{text-align:right;display:block}.file-picker .fp-login-form .fp-login-input
.input{text-align:left}.file-picker .fp-login-form input[type="checkbox"]{width:15px;height:15px}.file-picker .fp-upload-form{height:100%;width:100%;display:table}.file-picker .fp-upload-form
table{margin:0
auto}.file-picker.fp-dlg{text-align:center}.file-picker.fp-dlg .fp-dlg-text{padding:30px
20px 10px;font-size:12px}.file-picker.fp-dlg .fp-dlg-buttons{margin:0
20px}.file-picker.fp-msg{text-align:center}.file-picker.fp-msg .fp-msg-text{padding:40px
20px 10px 20px;min-width:200px;max-width:500px;max-height:300px;overflow:auto;font-size:12px}.file-picker.fp-msg.fp-msg-error .fp-msg-text{padding:40px
20px 10px 20px;font-size:12px}.file-picker .fp-content-error{height:100%;width:100%;display:table;text-align:center}.file-picker .fp-content-error .fp-error{height:100%;width:100%;display:table-cell;vertical-align:middle;padding:40px
20px 10px 20px;font-size:12px}.file-picker .fp-nextpage{clear:both}.file-picker .fp-nextpage .fp-nextpage-loading{display:none}.file-picker .fp-nextpage.loading .fp-nextpage-link{display:none}.file-picker .fp-nextpage.loading .fp-nextpage-loading{display:block;text-align:center;height:100px;padding-top:50px}.fp-select
form{padding:20px
20px 0}.fp-select .fp-select-loading{text-align:center;margin-top:20px}.fp-select .fp-hr{clear:both;height:1px;background-color:#FFF;border-bottom:1px solid #BBB;width:auto;margin:10px
0}.fp-select
table{padding:0
0 10px}.fp-select table .mdl-right{min-width:84px}.fp-select .fp-reflist .mdl-right{vertical-align:top}.fp-select .fp-select-buttons{float:right}.fp-select .fp-info{display:block;clear:both;padding:1px
20px 0}.fp-select .fp-thumbnail{float:left;min-width:110px;min-height:110px;line-height:110px;text-align:center;margin:10px
20px 0 0;background:#fff;border:1px
solid #ddd;-webkit-box-shadow:inset 0 0 10px 0 #ccc;-moz-box-shadow:inset 0 0 10px 0 #ccc;box-shadow:inset 0 0 10px 0 #ccc}.fp-select .fp-thumbnail
img{border:1px
solid #DDD;padding:3px;vertical-align:middle;margin:10px}.fp-select .fp-fileinfo{display:inline-block;*display:inline;*zoom:1;margin-top:10px}.file-picker.fp-select .fp-fileinfo{max-width:240px}.fp-select .fp-fileinfo
div{padding-bottom:5px}.file-picker.fp-select
.uneditable{display:none}.file-picker.fp-select .fp-select-loading{display:none}.file-picker.fp-select.loading .fp-select-loading{display:block}.file-picker.fp-select.loading
form{display:none}.fp-select .fp-dimensions.fp-unknown{display:none}.fp-select .fp-size.fp-unknown{display:none}.filemanager-loading{display:none}.jsenabled .filemanager-loading{display:block;margin-top:100px}.filemanager.fm-loading .filemanager-toolbar,.filemanager.fm-loading .fp-pathbar,.filemanager.fm-loading .filemanager-container,.filemanager.fm-loaded .filemanager-loading,.filemanager.fm-maxfiles .fp-btn-add,.filemanager.fm-maxfiles .dndupload-message,.filemanager.fm-noitems .fp-btn-download,.filemanager .fm-empty-container,.filemanager.fm-noitems .filemanager-container .fp-content{display:none}.filemanager .fp-img-downloading{display:none;padding-top:7px}.filemanager .filemanager-updating{display:none;text-align:center}.filemanager.fm-updating .filemanager-updating{display:block;margin-top:37px}.filemanager.fm-updating .fm-content-wrapper,.filemanager.fm-nomkdir .fp-btn-mkdir,.fitem.disabled .filemanager .filemanager-toolbar,.fitem.disabled .filemanager .fp-pathbar,.fitem.disabled .filemanager .fp-restrictions,.fitem.disabled .filemanager .fm-content-wrapper{display:none}.filemanager .fp-restrictions{text-align:right}.filemanager .fp-navbar{background:#F2F2F2;border:1px
solid #BBB;border-bottom:none}.filemanager-toolbar{padding:4px;overflow:hidden}.fp-pathbar{border-top:1px solid #BBB;padding:5px
8px 1px;min-height:20px}.file-picker .fp-toolbar{padding:4px}.fp-toolbar .fp-btn-add,.fp-toolbar .fp-btn-download,.fp-toolbar .fp-btn-mkdir,.fp-toolbar .fp-tb-help,.fp-toolbar .fp-tb-manage,.fp-toolbar .fp-tb-logout,.fp-toolbar .fp-tb-refresh{border:1px
solid #CCC;border-bottom:1px solid #B3B3B3;border-radius:4px;background:white;width:30px;height:30px}.fp-toolbar a:hover{background-image:radial-gradient(ellipse at center, #fff 60%, #dfdfdf 100%);background-color:#ebebeb}.fp-toolbar a:active{background-image:radial-gradient(ellipse at center, #fff 40%, #dfdfdf 100%);background-color:#dfdfdf}.fp-btn-add a,.fp-btn-download a,.fp-btn-mkdir a,.fp-tb-help a,.fp-tb-manage a,.fp-tb-logout a,.fp-tb-refresh
a{display:block;width:30px;height:30px;border-radius:4px}.fp-btn-add img,.fp-btn-download img,.fp-btn-mkdir img,.fp-tb-help img,.fp-tb-manage img,.fp-tb-logout img,.fp-tb-refresh
img{margin:7px}.filemanager .fp-pathbar.empty{display:none}.filepicker-filelist,.filemanager-container{background:#FFF;clear:both;overflow:auto;border:1px
solid #BBB;min-height:140px;position:relative}.filemanager .fp-content{overflow:auto;max-height:472px;min-height:157px}.filemanager-container,.filepicker-filelist{overflow:hidden}.fitem.disabled .filepicker-filelist,.fitem.disabled .filemanager-container{background-color:#EBEBE4}.fitem.disabled .fp-btn-choose{color:#999}.fitem.disabled .filepicker-filelist .filepicker-filename{display:none}.fp-iconview .fp-reficons1{position:absolute;height:100%;width:100%;top:0;left:0}.fp-iconview .fp-reficons2{position:absolute;height:100%;width:100%;top:0;left:0}.fp-iconview .fp-file.fp-hasreferences .fp-reficons1{background:url('/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=fp%2Flink') no-repeat;background-position:bottom right}.fp-iconview .fp-file.fp-isreference .fp-reficons2{background:url('/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=fp%2Falias') no-repeat;background-position:bottom left}.dir-rtl .fp-iconview .fp-file.fp-hasreferences .fp-reficons1{transform:scaleX(-1)}.dir-rtl .fp-iconview .fp-file.fp-isreference .fp-reficons2{transform:scaleX(-1)}.filemanager .fp-iconview .fp-file.fp-originalmissing .fp-thumbnail
img{display:none}.filemanager .fp-iconview .fp-file.fp-originalmissing .fp-thumbnail{background:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=s%2Fdead) no-repeat;background-position:center center}.filemanager .yui3-datatable
table{border:0
solid #BBB;width:100%}.filemanager .yui3-datatable-header{background:#FFF !important;border-bottom:1px solid #CCC !important;border-left:0 solid #FFF !important;color:#555 !important}.filemanager .yui3-datatable-odd .yui3-datatable-cell{background-color:#F6F6F6 !important;border-left:0 solid #F6F6F6}.filemanager .yui3-datatable-even .yui3-datatable-cell{background-color:#FFF !important;border-left:0 solid #FFF}.filemanager .fp-filename-icon.fp-hasreferences .fp-reficons1{background:url('/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=fp%2Flink_sm') no-repeat 0 0;height:100%;width:100%;position:absolute;top:8px;left:17px;z-index:1000}.filemanager .fp-filename-icon.fp-isreference .fp-reficons2{background:url('/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=fp%2Falias_sm') no-repeat 0 0;height:100%;width:100%;position:absolute;top:9px;left:-6px;z-index:1001}.dir-rtl .filemanager .fp-filename-icon.fp-hasreferences .fp-reficons1{transform:scaleX(-1);left:-17px}.dir-rtl .filemanager .fp-filename-icon.fp-isreference .fp-reficons2{transform:scaleX(-1);left:6px}.filemanager .fp-contextmenu{display:none}.filemanager .fp-iconview .fp-folder.fp-hascontextmenu .fp-contextmenu{display:block;position:absolute;right:7px;bottom:5px}.filemanager .fp-treeview .fp-folder.fp-hascontextmenu .fp-contextmenu,.filemanager .fp-tableview .fp-folder.fp-hascontextmenu .fp-contextmenu{display:inline;position:absolute;left:14px;margin-right:-20px;top:6px}.dir-rtl .filemanager .fp-iconview .fp-folder.fp-hascontextmenu .fp-contextmenu{left:7px;right:inherit}.dir-rtl .filemanager .fp-treeview .fp-folder.fp-hascontextmenu .fp-contextmenu,.dir-rtl .filemanager .fp-tableview .fp-folder.fp-hascontextmenu .fp-contextmenu{left:inherit;right:16px;margin-right:0}.filepicker-filelist .filepicker-container,.filemanager.fm-noitems .fm-empty-container{display:block;position:absolute;top:10px;bottom:10px;left:10px;right:10px;border:2px
dashed #BBB;padding-top:85px;text-align:center}.filepicker-filelist .dndupload-target,.filemanager-container .dndupload-target{background:#FFF;position:absolute;top:10px;bottom:10px;left:10px;right:10px;border:2px
dashed #fb7979;padding-top:85px;text-align:center;-webkit-box-shadow:0 0 0 10px #fff;-moz-box-shadow:0 0 0 10px #fff;box-shadow:0 0 0 10px #fff}.filepicker-filelist.dndupload-over .dndupload-target,.filemanager-container.dndupload-over .dndupload-target{background:#FFF;position:absolute;top:10px;bottom:10px;left:10px;right:10px;border:2px
dashed #6c8cd3;padding-top:85px;text-align:center}.dndupload-message{display:none}.dndsupported .dndupload-message{display:inline}.dnduploadnotsupported-message{display:none}.dndnotsupported .dnduploadnotsupported-message{display:inline}.dndupload-target{display:none}.dndsupported .dndupload-ready .dndupload-target{display:block}.dndupload-uploadinprogress{display:none;text-align:center}.dndupload-uploading .dndupload-uploadinprogress{display:block}.dndupload-arrow{background:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=fp%2Fdnd_arrow) center no-repeat;width:100%;height:80px;position:absolute;top:5px}.fitem.disabled .filepicker-container,.fitem.disabled .fm-empty-container{display:none}.dndupload-progressbars{padding:10px;display:none}.dndupload-inprogress .dndupload-progressbars{display:block}.dndupload-inprogress .fp-content{display:none}.filemanager.fm-noitems .dndupload-inprogress .fm-empty-container{display:none}.filepicker-filelist.dndupload-inprogress .filepicker-container{display:none}.filepicker-filelist.dndupload-inprogress
a{display:none}.filemanager.fp-select .fp-select-loading{display:none}.filemanager.fp-select.loading .fp-select-loading{display:block}.filemanager.fp-select.loading
form{display:none}.filemanager.fp-select.fp-folder .fp-license,.filemanager.fp-select.fp-folder .fp-author,.filemanager.fp-select.fp-file .fp-file-unzip,.filemanager.fp-select.fp-folder .fp-file-unzip,.filemanager.fp-select.fp-file .fp-file-zip,.filemanager.fp-select.fp-zip .fp-file-zip{display:none}.filemanager.fp-select .fp-file-setmain,.filemanager.fp-select .fp-file-setmain-help{display:none}.filemanager.fp-select.fp-cansetmain .fp-file-setmain,.filemanager.fp-select.fp-cansetmain .fp-file-setmain-help{display:inline-block;*display:inline;*zoom:1}.filemanager .fp-mainfile .fp-filename{font-weight:bold}.filemanager.fp-select.fp-folder .fp-file-download{display:none}.fm-operation{font-weight:bold}.filemanager.fp-select .fp-original.fp-unknown,.filemanager.fp-select .fp-original .fp-originloading{display:none}.filemanager.fp-select .fp-original.fp-loading .fp-originloading{display:inline}.filemanager.fp-select .fp-reflist.fp-unknown,.filemanager.fp-select .fp-reflist .fp-reflistloading{display:none}.filemanager.fp-select .fp-refcount{max-width:265px}.filemanager.fp-select .fp-reflist.fp-loading .fp-reflistloading{display:inline}.filemanager.fp-select .fp-reflist .fp-value{background:#F9F9F9;border:1px
solid #BBB;padding:8px
7px;margin:0;max-width:265px;max-height:75px;overflow:auto}.filemanager.fp-select .fp-reflist .fp-value
li{padding-bottom:7px}.filemanager.fp-mkdir-dlg{text-align:center}.filemanager.fp-mkdir-dlg .fp-mkdir-dlg-text{text-align:left;margin:20px}.dir-rtl .filemanager .fp-mkdir-dlg
p{text-align:right}.filemanager.fp-dlg{text-align:center}.filemanager.fp-dlg .fp-dlg-text{padding:0
10px;min-width:200px;max-width:340px;max-height:300px;overflow:auto;line-height:22px;margin:40px
20px 20px;font-size:12px}.file-picker
div.bd{text-align:left}.dir-rtl .filemanager .fp-restrictions{text-align:left}.dir-rtl .file-picker div.bd,.dir-rtl .file-picker .fp-pathbar,.dir-rtl .file-picker .fp-list,.dir-rtl #filemenu .yuimenuitemlabel,.dir-rtl .filemanager-container .yui3-skin-sam .yui3-datatable-header{text-align:right}.dir-rtl .filepicker .yui-layout-unit-left{left:500px}.dir-rtl .filepicker .yui-layout-unit-center{left:0}.dir-rtl .file-picker .fp-toolbar .fp-tb-search
input{background-position:208px 7px;padding:2px
30px 1px 3px}.dir-rtl .file-picker .fp-toolbar
div{float:right;margin-left:4px}.fp-formset{max-width:500px;padding:10px}.fp-formset input[type="file"]{line-height:inherit}.fp-forminset{max-width:400px;padding:0
10px}.fp-forminset .control-group.control-radio{margin-bottom:0}.fp-forminset .control-group label.control-label{width:105px}.fp-forminset .control-group label.control-radio{float:right;text-align:left;width:215px}.fp-forminset .control-group
.controls{margin-left:125px}.fp-forminset .control-group .controls
select{width:100%}.fp-forminset .control-group .controls.control-radio
input{margin-top:3px}.fp-forminset .fp-select-buttons{float:none}.fp-forminset input[type="text"]{width:228px}.fp-fileinfo .fp-value{display:inline-block;padding-left:5px}.dir-rtl .fp-forminset{max-width:400px}.dir-rtl .fp-forminset .control-group label.control-label{float:right;text-align:left}.dir-rtl .fp-forminset .control-group label.control-radio{float:left;text-align:right;width:215px}.dir-rtl .fp-forminset .control-group
.controls{margin-left:0;margin-right:125px}.dir-rtl .fp-forminset .fp-select-buttons{float:left}.dir-rtl .fp-forminset input[type="text"]{width:228px}.dir-rtl .fp-fileinfo .fp-value{display:inline-block;padding-right:5px}.dir-rtl .fp-select .fp-thumbnail{margin:10px
0 0 0}.dir-rtl .filepicker .fp-formset
label{float:right;text-align:left}.dir-rtl .filepicker .fp-formset
.controls{margin-left:0;text-align:right}.message-discussion-noframes
h1{font-size:1em}.message-discussion-noframes #userinfo .commands,.message .noframesjslink,.message
.link{font-size:11.9px}.message
.heading{font-size:1em;font-weight:bold;clear:both;word-wrap:break-word}.message
.author{font-weight:bold}.message
.time{font-style:italic}#page-message-user .commands
span{font-size:.7em}#page-message-user
.name{font-weight:bold;font-size:1.1em}.message
.time{color:#999}#page-message-messages{padding:10px}#page-message-send
.notifysuccess{padding:1px}#page-message-send
td.fixeditor{text-align:center}.message{overflow:hidden}.message
.note{padding:10px}table.message .searchresults
td{padding:5px}.message
.contactselector{max-width:380px;margin:0
auto;width:auto}@media screen and (min-width:1000px){.message
.contactselector{float:left;padding:0
8px 0 0}}.message .contactselector
.singleselect{width:240px}.message .contactselector
.paging{z-index:1;position:relative}.message .contactselector
#message_participants{max-width:240px}.message .contactselector .message-contacts{list-style-type:none;margin:0}.message .contactselector .message-contacts
li{clear:both;position:relative;min-height:23px;padding:2px}.message .contactselector .message-contacts li:nth-child(odd){background:rgba(120,120,255,0.1)}.message .contactselector .message-contacts li>div{display:block;height:100%}.message .contactselector .message-contacts li>div>*{vertical-align:middle;display:inline-block}.message .contactselector .message-contacts li>div.pix{position:relative;float:left}.message .contactselector .message-contacts li>div.link{white-space:nowrap;width:60px;position:relative;float:right;text-align:right}.message .contactselector .message-contacts li>div.contact{position:relative;word-break:break-all}.message .contactselector .message-contacts li>div.contact
a{line-height:22px}.dir-ltr .message .message-contacts
li{text-align:left}.dir-ltr .message .message-contacts li>div.pix{float:left}.dir-ltr .message .message-contacts li>div.link{float:right;text-align:right}.dir-ltr .message .message-contacts li>div.contact{margin:0
60px 0 24px}.dir-ltr .message .message-contacts li>div.contact.nolinks{margin:0
0 0 24px}.dir-rtl .message .message-contacts
li{text-align:right}.dir-rtl .message .message-contacts li>div.pix{float:right}.dir-rtl .message .message-contacts li>div.link{float:left;text-align:left}.dir-rtl .message .message-contacts li>div.contact{margin:0
24px 0 60px}.dir-rtl .message .message-contacts li>div.contact.nolinks{margin:0
24px 0 0}@media screen and (min-width:1000px){.dir-rtl .message
.contactselector{float:right}}.message
.messagearea{float:none;overflow:hidden;min-height:200px;min-width:300px}@media screen and (min-width:1000px){.message
.messagearea{border-left:1px solid #ddd;padding:0
8px}}@media screen and (max-width:1000px){.message
.messagearea{width:100%}}#message_user_pictures{text-align:center}.dir-rtl
#message_user_pictures{direction:rtl}.message .messagearea
.messagehistorytype{clear:both;padding-bottom:20px}.message .messagearea .messagehistory
.user{vertical-align:top;width:45%;min-width:100px;display:inline-block}.message .messagearea .messagehistory .user>div{text-align:center}.message .messagearea .messagehistory
.between{display:inline-block;width:16px;margin:0
1%;padding-top:40px}@media screen and (max-width:320px){.message
.messagearea{min-width:0}.message .messagearea .messagehistory
.user{max-width:70px;min-width:0}.message .messagearea .messagehistory .user
.userpicture{width:50px;height:auto}}@media screen and (min-width:800px){.message .messagearea .messagehistory
.between{margin:0
3%}.message .messagearea .messagehistory
.user{width:32%}}@media screen and (min-width:1200px){.message .messagearea .messagehistory
.user{width:25%}}.message .messagearea .messagehistory
.heading{width:100%;clear:both}.message .messagearea .messagehistory
.left{margin-bottom:10px;width:50%;float:left;position:relative;clear:both}.dir-rtl .message .messagearea .messagehistory
.left{float:right}.message .messagearea .messagehistory
.right{margin-bottom:10px;width:50%;float:right;position:relative;clear:both}.dir-rtl .message .messagearea .messagehistory
.right{float:left}.message .messagearea .messagehistory
.notification{min-height:20px;padding:19px;margin-bottom:20px;background-color:#f5f5f5;border:1px
solid #e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);border-color:#e3e3e3;padding:9px;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px;margin-bottom:0;margin-top:5px}.message .messagearea .messagehistory .notification
blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}.dir-ltr .message .messagearea .messagehistory
.message{margin-right:20px}.dir-ltr .message .messagearea .messagehistory .right
.message{margin-left:20px}.dir-rtl .message .messagearea .messagehistory
.message{margin-left:20px}.dir-rtl .message .messagearea .messagehistory .right
.message{margin-right:20px}.message .messagearea .messagehistory
.messageactive{background-color:#f5f5f5}.message .messagearea .messagehistory .messagecontent
.deleteicon{width:20px;position:absolute;top:-2px}.dir-ltr .message .messagearea .messagehistory .messagecontent
.deleteicon{right:0}.dir-rtl .message .messagearea .messagehistory .messagecontent
.deleteicon{left:0}.message .messagearea
.messagesend{padding-top:20px;clear:both}.message .messagearea .messagesend
.messagesendbox{width:100%;box-sizing:border-box}.message .messagearea .messagesend
fieldset{padding:0;margin:0}.message .messagearea
.messagerecent{text-align:left;width:100%}.message .messagearea .messagerecent
.singlemessage{border-bottom:1px solid #ddd;padding:10px}.message .messagearea .messagerecent .singlemessage .otheruser
span{padding:5px}.message .messagearea .messagerecent .singlemessage
.messagedate{float:right}.message
.hiddenelement{display:none}.message
.visible{display:inline}.message #usergroupselector.fieldset,.message
#viewing{width:100%}.messagesearchresults{margin-bottom:40px}.messagesearchresults
td{padding:0
10px 0 20px}.messagesearchresults td
span{white-space:nowrap}.messagesearchresults td
img.userpicture{padding-right:.45em;vertical-align:text-bottom}.dir-rtl .messagesearchresults td
img.userpicture{padding-left:.45em;padding-right:0}.messagesearchresults td span
img{padding:0
0 0 .45em;vertical-align:text-bottom}.dir-rtl .messagesearchresults td span
img{padding:0
.45em 0 0}#newmessageoverlay{min-height:20px;padding:19px;margin-bottom:20px;background-color:#f5f5f5;border:1px
solid #e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);border-color:#e3e3e3;margin:0
1em;position:fixed;bottom:0;right:0}#newmessageoverlay
blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}#newmessageoverlay
#usermessage{padding:10px}#page-user-action_redir #edit-messagebody{width:auto}.core_message-messenger-sendmessage-hidden{display:none}.core_message-messenger-sendmessage .message-actions{position:relative}.core_message-messenger-sendmessage .message-area{height:240px;max-height:100%;position:relative;margin-bottom:10px}.core_message-messenger-sendmessage .message-input{width:100%;height:100%;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.core_message-messenger-sendmessage .message-send{margin:0;float:right}.core_message-messenger-sendmessage .message-notice-area{display:table;position:absolute;top:0;bottom:0;left:0;right:0;width:100%;height:100%}.core_message-messenger-sendmessage .message-notice{display:table-cell;vertical-align:middle;text-align:center}.core_message-messenger-sendmessage .message-notice>div{background:#eee;padding:5px;font-size:12px}.core_message-messenger-sendmessage .message-footer{margin-top:3px;line-height:20px}.core_message-messenger-sendmessage .message-history{position:absolute;bottom:0}.dir-rtl .core_message-messenger-sendmessage .message-send{float:left}.questionbank
h2{margin-top:0}.questioncategories
h3{margin-top:0}#chooseqtypebox{margin-top:1em}#chooseqtype
h3{margin:0
0 .3em}#chooseqtype
.instruction{display:none}#chooseqtype
.fakeqtypes{border-top:1px solid silver}#chooseqtype
.qtypeoption{margin-bottom:.5em}#chooseqtype
label{display:block}#chooseqtype .qtypename
img{padding:0
.3em}#chooseqtype
.qtypename{display:inline-table;width:16em}#chooseqtype
.qtypesummary{display:block;margin:0
2em}#chooseqtype
.submitbuttons{margin:.7em 0;text-align:center}#qtypechoicecontainer{display:none}#qtypechoicecontainer_c.yui-panel-container.shadow
.underlay{background:none}#qtypechoicecontainer.yui-panel
.hd{color:#333;letter-spacing:1px;text-shadow:1px 1px 1px #fff;-webkit-border-top-right-radius:10px;-moz-border-radius-topright:10px;border-top-right-radius:10px;-webkit-border-top-left-radius:10px;-moz-border-radius-topleft:10px;border-top-left-radius:10px;border:1px
solid #ccc;border-bottom:1px solid #bbb;background-color:#ebebeb;background-image:-moz-linear-gradient(top, #fff, #ccc);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#fff), to(#ccc));background-image:-webkit-linear-gradient(top, #fff, #ccc);background-image:-o-linear-gradient(top, #fff, #ccc);background-image:linear-gradient(to bottom,#fff,#ccc);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff',endColorstr='#ffcccccc',GradientType=0)}#qtypechoicecontainer{font-size:12px;color:#333;background:#F2F2F2;-webkit-border-radius:10px;-moz-border-radius:10px;border-radius:10px;border:1px
solid #ccc;border-top:0 none;-webkit-box-shadow:5px 5px 20px 0 #666;-moz-box-shadow:5px 5px 20px 0 #666;box-shadow:5px 5px 20px 0 #666}#qtypechoicecontainer
#chooseqtype{width:40em}#chooseqtypehead
h3{margin:0;font-weight:normal}#chooseqtype
.qtypes{position:relative;border-bottom:1px solid #bbb;padding:.24em 0}#chooseqtype
.alloptions{overflow-x:hidden;overflow-y:auto;max-height:400px;max-height:calc(85vh);max-height:60vh;width:60%}#chooseqtype
.qtypeoption{margin-bottom:0;padding:.3em .3em .3em 1.6em}#chooseqtype .qtypeoption
img{vertical-align:text-bottom;padding-left:1em;padding-right:.5em}#chooseqtype
.selected{background-color:#fff;-webkit-box-shadow:0 0 10px 0 #ccc;-moz-box-shadow:0 0 10px 0 #ccc;box-shadow:0 0 10px 0 #ccc}#chooseqtype .instruction,#chooseqtype
.qtypesummary{display:none;position:absolute;top:0;right:0;bottom:0;left:60%;margin:0;overflow-x:hidden;padding:1.5em 1.6em;background-color:#fff;overflow-y:auto}#chooseqtype .instruction,#chooseqtype .selected
.qtypesummary{display:block}#categoryquestions{margin:0}#categoryquestions td,#categoryquestions
th{padding:0
.2em}#categoryquestions
th{text-align:left;font-weight:normal}#categoryquestions
.checkbox{padding-left:5px}#categoryquestions .checkbox input[type="checkbox"]{margin-left:0;float:none}#categoryquestions
img.iconsmall{padding:0}#categoryquestions
.iconcol{padding:3px}#categoryquestions
label{margin:0}#page-mod-quiz-edit div.questionbankwindow
div.header{margin:0}#page-mod-quiz-edit
div.questionbankwindow.block{padding:0}.dir-rtl #categoryquestions
th{text-align:right}.questionbank
.singleselect{margin:0}#combinedfeedbackhdr
div.fhtmleditor{padding:0}#combinedfeedbackhdr
div.fcheckbox{margin-bottom:1em}#multitriesheader
div.fitem_feditor{margin-top:1em}#multitriesheader
div.fitem_fgroup{margin-bottom:1em}#multitriesheader div.fitem_fgroup fieldset.felement
label{margin-left:.3em;margin-right:.3em}body.path-question-type .fitem_fgroup
.accesshide{font:inherit;left:0;position:static;padding-right:.3em}.que{clear:left;text-align:left;margin:0
auto 1.8em auto}.dir-rtl
.que{text-align:right}.que
.info{float:left;width:7em;padding:.5em;margin-bottom:1.8em;background-color:#eee;border:1px
solid #dcdcdc;-webkit-border-radius:2px;-moz-border-radius:2px;border-radius:2px}.que
h3.no{margin:0;font-size:.8em;line-height:1}.que
span.qno{font-size:1.5em;font-weight:bold}.que .info>div{font-size:.8em;margin-top:.7em}.que .info
.questionflag.editable{cursor:pointer}.que .info .editquestion img,.que .info .questionflag img,.que .info .questionflag
input{vertical-align:bottom}.que
.content{margin:0
0 0 8.5em}.que .formulation,.que .outcome,.que
.comment{padding:8px
35px 8px 14px;margin-bottom:20px;text-shadow:0 1px 0 rgba(255,255,255,0.5);background-color:#fcf8e3;border:1px
solid #fbeed5;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;color:#8a6d3b}.que
.formulation{background-color:#d9edf7;border-color:#bce8f1;color:#3a87ad;color:#333}.formulation input[type="text"],.formulation
select{width:auto;vertical-align:baseline}.path-mod-quiz input[size]{width:auto}.que
.comment{background-color:#dff0d8;border-color:#d6e9c6;color:#468847}.que
.history{min-height:20px;padding:19px;margin-bottom:20px;background-color:#f5f5f5;border:1px
solid #e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);border-color:#e3e3e3}.que .history
blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}.que
.ablock{margin:.7em 0 .3em 0}.que .im-controls{margin-top:.5em;text-align:left}.dir-rtl .que .im-controls{text-align:right}.que .specificfeedback,.que .generalfeedback,.que .rightanswer,.que .im-feedback,.que .feedback,.que
p{margin:0
0 .5em}.que
.qtext{margin-bottom:1.5em}.que
.correctness{display:inline-block;padding:2px
4px;font-size:11.844px;font-weight:bold;line-height:14px;color:#fff;vertical-align:baseline;white-space:nowrap;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#999;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.que .correctness:empty{display:none}.que .correctness-important{background-color:#b94a48}.que .correctness-important[href]{background-color:#953b39}.que .correctness-warning{background-color:#f89406}.que .correctness-warning[href]{background-color:#c67605}.que .correctness-success{background-color:#468847}.que .correctness-success[href]{background-color:#356635}.que .correctness-info{background-color:#3a87ad}.que .correctness-info[href]{background-color:#2d6987}.que .correctness-inverse{background-color:#333}.que .correctness-inverse[href]{background-color:#1a1a1a}.que
.correctness.correct{background-color:#468847}.que
.correctness.partiallycorrect{background-color:#f89406}.que .correctness.notanswered,.que
.correctness.incorrect{background-color:#b94a48}.que
.validationerror{color:#b94a48}.formulation
.correct{background-color:#dff0d8}.formulation
.partiallycorrect{background-color:#fcf8e3}.formulation
.incorrect{background-color:#f2dede}.formulation select.correct,.formulation
input.correct{color:#468847;background-color:#dff0d8;border-color:#468847;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075)}.formulation select.correct:focus,.formulation input.correct:focus{border-color:#356635;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #7aba7b;-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #7aba7b;box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #7aba7b}.formulation select.partiallycorrect,.formulation
input.partiallycorrect{color:#8a6d3b;background-color:#fcf8e3;border-color:#8a6d3b;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075)}.formulation select.partiallycorrect:focus,.formulation input.partiallycorrect:focus{border-color:#66512c;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #c0a16b;-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #c0a16b;box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #c0a16b}.formulation select.incorrect,.formulation
input.incorrect{color:#b94a48;background-color:#f2dede;border-color:#b94a48;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075)}.formulation select.incorrect:focus,.formulation input.incorrect:focus{border-color:#953b39;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #d59392;-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #d59392;box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #d59392}.que .grading,.que .comment,.que .commentlink,.que
.history{margin-top:.5em}.que .history
h3{margin:0
0 .2em;font-size:1em}.que .history
table{width:100%;margin:0}.que .history
.current{font-weight:bold}.que
.questioncorrectnessicon{vertical-align:text-bottom}.que
input.questionflagimage{padding-right:3px}.dir-rtl .que
input.questionflagimage{padding-left:3px;padding-right:0}.importerror{margin-top:10px;border-bottom:1px solid #555}.mform .que.comment
.fitemtitle{width:20%}#page-question-preview
#techinfo{margin:1em
0}.dir-rtl #chooseqtype .instruction,.dir-rtl #chooseqtype
.qtypesummary{right:60%;left:0;border-left:0;border-right:1px solid grey}#page-mod-quiz-edit
.box.generalbox.questionbank{padding:.5em}#page-mod-quiz-edit .questionbank .categorypagingbarcontainer,#page-mod-quiz-edit .questionbank .categoryquestionscontainer,#page-mod-quiz-edit .questionbank
.choosecategory{padding:0}#page-mod-quiz-edit .questionbank .choosecategory
select{width:100%}#page-mod-quiz-edit div.questionbank
.categoryquestionscontainer{background:transparent}#page-mod-quiz-edit #categoryquestions>thead{background:#FFF}#page-mod-quiz-edit #categoryquestions>tbody>tr:nth-of-type(even){background:#e4e4e4}#page-mod-quiz-edit .questionbankwindow
div.header{color:#444;text-shadow:none;padding:3px;-webkit-border-top-right-radius:4px;-moz-border-radius-topright:4px;border-top-right-radius:4px;-webkit-border-top-left-radius:4px;-moz-border-radius-topleft:4px;border-top-left-radius:4px;margin:0
-10px 0 -10px;padding:2px
10px 2px 10px;background:transparent}#page-mod-quiz-edit .questionbankwindow div.header a:link,#page-mod-quiz-edit .questionbankwindow div.header a:visited{color:#0070a8}#page-mod-quiz-edit .questionbankwindow div.header a:hover{color:#003d5c}#page-mod-quiz-edit
.createnewquestion{padding:.3em 0}#page-mod-quiz-edit .createnewquestion div,#page-mod-quiz-edit .createnewquestion
input{margin:0}#page-mod-quiz-edit .questionbankwindow div.header
.title{color:#333}#page-mod-quiz-edit div.container
div.generalbox{background-color:transparent;padding:1.5em}#page-mod-quiz-edit
.categoryinfo{background-color:transparent;border-bottom:none}#page-mod-quiz-edit .createnewquestion .singlebutton
input{margin-bottom:0}#page-mod-quiz-edit div.questionbank .categorysortopotionscontainer,#page-mod-quiz-edit div.questionbank
.categoryselectallcontainer{padding:0
0 1.5em 0}#page-mod-quiz-edit div.questionbank
.categorypagingbarcontainer{background-color:transparent;margin:0;border-top:0;border-bottom:0}#page-mod-quiz-edit div.questionbank .categorypagingbarcontainer
.paging{padding:0
.3em}#page-mod-quiz-edit div.question div.content
div.questioncontrols{background-color:#fff}#page-mod-quiz-edit div.question div.content
div.points{margin-top:-0.5em;padding-bottom:0;border:none;background-color:#fff;position:static;width:12.1em;float:right;margin-right:60px}#page-mod-quiz-edit.dir-rtl div.question div.content
div.points{float:left;margin-left:60px;margin-right:0}#page-mod-quiz-edit div.question div.content div.points
br{display:none}#page-mod-quiz-edit div.question div.content div.points
label{display:inline-block}#page-mod-quiz-edit div.quizpage .pagecontent
.pagestatus{background-color:#fff}#page-mod-quiz-edit .quizpagedelete,#page-mod-quiz-edit .quizpagedelete
img{background-color:transparent}#page-mod-quiz-edit div.quizpage
.pagecontent{border:1px
solid #ddd;-webkit-border-radius:2px;-moz-border-radius:2px;border-radius:2px;overflow:hidden}#page-mod-quiz-edit div.questionbank
.categoryinfo{padding:.3em 0}#page-mod-quiz-edit div.questionbank
.modulespecificbuttonscontainer{padding:0}#page-mod-quiz-edit div.questionbank .modulespecificbuttonscontainer
strong{display:block}#page-mod-quiz-edit div.questionbank .modulespecificbuttonscontainer hr,#page-mod-quiz-edit div.questionbank .modulespecificbuttonscontainer
br{display:none}#page-mod-quiz-edit div.questionbank .modulespecificbuttonscontainer
strong{margin-left:-0.3em}#page-mod-quiz-edit div.questionbank .modulespecificbuttonscontainer strong
label{margin-left:.3em}#page-mod-quiz-edit div.questionbank .modulespecificbuttonscontainer
input{margin-left:0}#page-mod-quiz-edit div.questionbank .modulespecificbuttonscontainer input+input{margin-left:5px}.questionbankwindow
.module{width:auto}#page-mod-quiz-edit div.editq div.question
div.content{background-color:#fff;border:1px
solid #ddd;-webkit-border-radius:2px;-moz-border-radius:2px;border-radius:2px;overflow:hidden}.path-mod-quiz
.statedetails{display:block;font-size:.9em}a#hidebankcmd{color:#0070a8}.que.shortanswer
.answer{padding:0}.que
label{display:inline}body.path-question-type .mform
fieldset.hidden{padding:0;margin:.7em 0 0}.userprofile
.fullprofilelink{text-align:center;margin:10px}.userprofile .page-context-header{margin-bottom:10px}.userprofile
.description{margin-top:10px;margin-bottom:30px}.userprofile
.profile_tree{-webkit-column-count:2;-moz-column-count:2;column-count:2;-webkit-column-gap:20px;-moz-column-gap:20px;column-gap:20px}.userprofile .profile_tree
section{display:inline-block;width:100%;border:1px
solid #ddd;border-radius:4px;padding:0
15px;margin-bottom:20px;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.userprofile .profile_tree section
h3{font-size:18px;line-height:20px}.userprofile
dl.list{*zoom:1}.userprofile dl.list:before,.userprofile dl.list:after{display:table;content:"";line-height:0}.userprofile dl.list:after{clear:both}.userprofile dl.list
dt{float:left;width:180px;clear:left;text-align:right;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.userprofile dl.list
dd{margin-left:200px}.user-box{margin:8px;width:115px;height:160px;text-align:center;float:left;clear:none}#page-user-profile .node_category ul,.path-user .node_category
ul{margin-left:0;margin-right:0;list-style:none}#page-user-profile .node_category li,.path-user .node_category
li{margin-top:5px}#page-user-profile .node_category .editprofile,.path-user .node_category .editprofile,#page-user-profile .node_category .viewmore,.path-user .node_category
.viewmore{text-align:right}.dir-rtl .user-box{float:right}.dir-rtl .userprofile .node_category .editprofile,.dir-rtl .userprofile .node_category
.viewmore{text-align:left}.dir-rtl .userprofile dl
dd{margin-left:0;margin-right:10px}@media (max-width:480px){.userprofile
.profile_tree{-webkit-column-count:1;-moz-column-count:1;column-count:1;-webkit-column-gap:20px;-moz-column-gap:20px;column-gap:20px}}.userlist .action-icon
img{vertical-align:middle}.userlist
#showall{margin:10px
0}.userlist
.buttons{text-align:center}.userlist .buttons
label{padding:0
3px}.userlist
table#participants{text-align:center}.userlist table#participants td,.userlist table#participants
th{vertical-align:middle;text-align:left;padding:4px}.userlist
table.controls{width:100%}.userlist table.controls
tr{vertical-align:top}.userlist table.controls
.right{text-align:right}.userlist table.controls
.groupselector{margin-bottom:0;margin-top:0}.userlist table.controls .groupselector
label{display:block}.userinfobox{width:100%;border:1px
solid;border-collapse:separate;padding:10px}.userinfobox .left,.userinfobox
.side{width:100px;vertical-align:top}.userinfobox
.userpicture{width:100px;height:100px}.userinfobox
.content{vertical-align:top}.userinfobox
.links{width:100px;padding:5px;vertical-align:bottom}.userinfobox .links
a{display:block}.userinfobox .list
td{padding:3px}.userinfobox
.username{padding-bottom:20px;font-weight:bold}.userinfobox
td.label{text-align:right;white-space:nowrap;vertical-align:top;font-weight:bold}.groupinfobox{min-height:20px;padding:19px;margin-bottom:20px;background-color:#f5f5f5;border:1px
solid #e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);border-color:#e3e3e3}.groupinfobox
blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}.groupinfobox
.left{padding:10px;width:100px;vertical-align:top}.course-participation
#showall{text-align:center;margin:10px
0}#user-policy
.noticebox{text-align:center;margin-left:auto;margin-right:auto;margin-bottom:10px;width:80%;height:250px}#user-policy
#policyframe{width:100%;height:100%}.iplookup
#map{margin:auto}.userselector
select{width:100%}.userselector
div{margin-top:.2em}.userselector div
label{margin-right:.3em}.userselector .userselector-infobelow{font-size:.8em}#userselector_options{padding:.3em 0}#userselector_options
.collapsibleregioncaption{font-weight:bold}#userselector_options
p{margin:.2em 0;text-align:left}.dir-rtl #userselector_options
p{text-align:right}#page-user-profile
.messagebox{text-align:center;margin-left:auto;margin-right:auto}#page-course-view-weeks
.messagebox{text-align:center;margin-left:auto;margin-right:auto}.dir-rtl .userlist table#participants td,.dir-rtl .userlist table#participants
th{text-align:right}.dir-rtl .userlist
table#participants{margin:0
auto}#page-my-index.dir-rtl .block
h3{text-align:right}.profileeditor>.singleselect{margin:0
.5em 0 0}.profileeditor>.singlebutton{display:inline-block;margin:0
0 0 .5em}.profileeditor>.singlebutton div,.profileeditor>.singlebutton
input{margin:0}.dir-rtl .profileeditor>.singleselect{margin:0
0 0 .5em}.dir-rtl .profileeditor>.singlebutton{margin:0
.5em 0 0}#groupeditform .groups,#groupeditform
.members{min-width:175px;width:49%;float:left;text-align:left}#groupeditform .groups select,#groupeditform .members
select{min-width:175px;max-width:90%}.dir-rtl #groupeditform .groups,.dir-rtl #groupeditform
.members{float:right;text-align:right}.preferences-group
ul{list-style:none;margin-left:0;margin-right:0}.dir-rtl .preferences-group{float:right}.search-results
.result{margin-left:0;margin-right:0}.dir-rtl .search-results
.result{margin-right:15px;margin-left:0}.search-results .result .result-content{margin:7px
0}.search-results .result
.filename{font-style:italic}.search-input-wrapper{margin:0
5px 0 2px;overflow:hidden;float:right;height:100%;width:16px;transition:width .5s ease,left .5s ease}.search-input-wrapper>div{float:left;margin:10px
0 9px 0}.dir-rtl .search-input-wrapper{margin:0
2px 0 5px;float:left}.dir-rtl .search-input-wrapper>div{float:right}.dir-rtl .search-input-wrapper>form{margin:5px
25px 5px 0}.search-input-wrapper>form{opacity:0;margin:5px
0 5px 25px;transition:opacity .5s ease-in-out}.search-input-wrapper>form>input{margin:0}.search-input-wrapper
form.expanded{opacity:1}.search-input-wrapper.expanded{width:160px}.dir-rtl .navbar .search-input-wrapper>form{margin:5px
25px 5px 0}.navbar .search-input-wrapper>form{margin:5px
0 5px 25px}.clearfix{*zoom:1}.clearfix:before,.clearfix:after{display:table;content:"";line-height:0}.clearfix:after{clear:both}.hide-text{font:0/0 a;color:transparent;text-shadow:none;background-color:transparent;border:0}.input-block-level{display:block;width:100%;min-height:30px;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}article,aside,details,figcaption,figure,footer,header,hgroup,nav,section{display:block}audio,canvas,video{display:inline-block;*display:inline;*zoom:1}audio:not([controls]){display:none}html{font-size:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%}a:focus{outline:thin dotted #333;outline:5px
auto -webkit-focus-ring-color;outline-offset:-2px}a:hover,a:active{outline:0}sub,sup{position:relative;font-size:75%;line-height:0;vertical-align:baseline}sup{top:-0.5em}sub{bottom:-0.25em}.img-responsive{max-width:100%;width:auto\9;height:auto;-ms-interpolation-mode:bicubic}img{vertical-align:middle;border:0}#map_canvas img,.google-maps
img{max-width:none}button,input,select,textarea{margin:0;font-size:100%;vertical-align:middle}button,input{*overflow:visible;line-height:normal}button::-moz-focus-inner,input::-moz-focus-inner{padding:0;border:0}button,html input[type="button"],input[type="reset"],input[type="submit"]{-webkit-appearance:button;cursor:pointer}label,select,button,input[type="button"],input[type="reset"],input[type="submit"],input[type="radio"],input[type="checkbox"]{cursor:pointer}input[type="search"]{-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;-webkit-appearance:textfield}input[type="search"]::-webkit-search-decoration,input[type="search"]::-webkit-search-cancel-button{-webkit-appearance:none}textarea{overflow:auto;vertical-align:top}@media
print{*{text-shadow:none !important;color:#000 !important;background:transparent !important;box-shadow:none !important}a,a:visited{text-decoration:underline}a[href]:after{content:" (" attr(href) ")"}abbr[title]:after{content:" (" attr(title) ")"}.ir a:after,a[href^="javascript:"]:after,a[href^="#"]:after{content:""}pre,blockquote{border:1px
solid #999;page-break-inside:avoid}thead{display:table-header-group}tr,img{page-break-inside:avoid}img{max-width:100% !important}@page{margin:.5cm}p,h2,h3{orphans:3;widows:3}h2,h3{page-break-after:avoid}}body{margin:0;font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;font-size:14px;line-height:20px;color:#333;background-color:#fff}a{color:#0070a8;text-decoration:none}a:hover,a:focus{color:#003d5c;text-decoration:underline}.img-rounded{-webkit-border-radius:6px;-moz-border-radius:6px;border-radius:6px}.img-polaroid{padding:4px;background-color:#fff;border:1px
solid #ccc;border:1px
solid rgba(0,0,0,0.2);-webkit-box-shadow:0 1px 3px rgba(0,0,0,0.1);-moz-box-shadow:0 1px 3px rgba(0,0,0,0.1);box-shadow:0 1px 3px rgba(0,0,0,0.1)}.img-circle{-webkit-border-radius:500px;-moz-border-radius:500px;border-radius:500px}.row{margin-left:-20px;*zoom:1}.row:before,.row:after{display:table;content:"";line-height:0}.row:after{clear:both}[class*="span"]{float:left;min-height:1px;margin-left:20px}.container,.navbar-static-top .container,.navbar-fixed-top .container,.navbar-fixed-bottom
.container{width:940px}.span12{width:940px}.span11{width:860px}.span10{width:780px}.span9{width:700px}.span8{width:620px}.span7{width:540px}.span6{width:460px}.span5{width:380px}.span4{width:300px}.span3{width:220px}.span2{width:140px}.span1{width:60px}.offset12{margin-left:980px}.offset11{margin-left:900px}.offset10{margin-left:820px}.offset9{margin-left:740px}.offset8{margin-left:660px}.offset7{margin-left:580px}.offset6{margin-left:500px}.offset5{margin-left:420px}.offset4{margin-left:340px}.offset3{margin-left:260px}.offset2{margin-left:180px}.offset1{margin-left:100px}.row-fluid{width:100%;*zoom:1}.row-fluid:before,.row-fluid:after{display:table;content:"";line-height:0}.row-fluid:after{clear:both}.row-fluid [class*="span"]{display:block;width:100%;min-height:30px;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;float:left;margin-left:2.12765957%;*margin-left:2.07446809%}.row-fluid [class*="span"]:first-child{margin-left:0}.row-fluid .controls-row [class*="span"]+[class*="span"]{margin-left:2.12765957%}.row-fluid
.span12{width:100%;*width:99.94680851%}.row-fluid
.span11{width:91.4893617%;*width:91.43617021%}.row-fluid
.span10{width:82.9787234%;*width:82.92553191%}.row-fluid
.span9{width:74.46808511%;*width:74.41489362%}.row-fluid
.span8{width:65.95744681%;*width:65.90425532%}.row-fluid
.span7{width:57.44680851%;*width:57.39361702%}.row-fluid
.span6{width:48.93617021%;*width:48.88297872%}.row-fluid
.span5{width:40.42553191%;*width:40.37234043%}.row-fluid
.span4{width:31.91489362%;*width:31.86170213%}.row-fluid
.span3{width:23.40425532%;*width:23.35106383%}.row-fluid
.span2{width:14.89361702%;*width:14.84042553%}.row-fluid
.span1{width:6.38297872%;*width:6.32978723%}.row-fluid
.offset12{margin-left:104.25531915%;*margin-left:104.14893617%}.row-fluid .offset12:first-child{margin-left:102.12765957%;*margin-left:102.0212766%}.row-fluid
.offset11{margin-left:95.74468085%;*margin-left:95.63829787%}.row-fluid .offset11:first-child{margin-left:93.61702128%;*margin-left:93.5106383%}.row-fluid
.offset10{margin-left:87.23404255%;*margin-left:87.12765957%}.row-fluid .offset10:first-child{margin-left:85.10638298%;*margin-left:85%}.row-fluid
.offset9{margin-left:78.72340426%;*margin-left:78.61702128%}.row-fluid .offset9:first-child{margin-left:76.59574468%;*margin-left:76.4893617%}.row-fluid
.offset8{margin-left:70.21276596%;*margin-left:70.10638298%}.row-fluid .offset8:first-child{margin-left:68.08510638%;*margin-left:67.9787234%}.row-fluid
.offset7{margin-left:61.70212766%;*margin-left:61.59574468%}.row-fluid .offset7:first-child{margin-left:59.57446809%;*margin-left:59.46808511%}.row-fluid
.offset6{margin-left:53.19148936%;*margin-left:53.08510638%}.row-fluid .offset6:first-child{margin-left:51.06382979%;*margin-left:50.95744681%}.row-fluid
.offset5{margin-left:44.68085106%;*margin-left:44.57446809%}.row-fluid .offset5:first-child{margin-left:42.55319149%;*margin-left:42.44680851%}.row-fluid
.offset4{margin-left:36.17021277%;*margin-left:36.06382979%}.row-fluid .offset4:first-child{margin-left:34.04255319%;*margin-left:33.93617021%}.row-fluid
.offset3{margin-left:27.65957447%;*margin-left:27.55319149%}.row-fluid .offset3:first-child{margin-left:25.53191489%;*margin-left:25.42553191%}.row-fluid
.offset2{margin-left:19.14893617%;*margin-left:19.04255319%}.row-fluid .offset2:first-child{margin-left:17.0212766%;*margin-left:16.91489362%}.row-fluid
.offset1{margin-left:10.63829787%;*margin-left:10.53191489%}.row-fluid .offset1:first-child{margin-left:8.5106383%;*margin-left:8.40425532%}[class*="span"].hide,.row-fluid [class*="span"].hide{display:none}[class*="span"].pull-right,.row-fluid [class*="span"].pull-right{float:right}.container{margin-right:auto;margin-left:auto;*zoom:1}.container:before,.container:after{display:table;content:"";line-height:0}.container:after{clear:both}.container-fluid{padding-right:20px;padding-left:20px;*zoom:1}.container-fluid:before,.container-fluid:after{display:table;content:"";line-height:0}.container-fluid:after{clear:both}p{margin:0
0 10px}.lead{margin-bottom:20px;font-size:21px;font-weight:200;line-height:30px}small{font-size:85%}strong{font-weight:bold}em{font-style:italic}cite{font-style:normal}.muted{color:#999}a.muted:hover,a.muted:focus{color:#808080}.text-warning{color:#8a6d3b}a.text-warning:hover,a.text-warning:focus{color:#66512c}.text-error{color:#b94a48}a.text-error:hover,a.text-error:focus{color:#953b39}.text-info{color:#3a87ad}a.text-info:hover,a.text-info:focus{color:#2d6987}.text-success{color:#468847}a.text-success:hover,a.text-success:focus{color:#356635}.text-left{text-align:left}.text-right{text-align:right}.text-center{text-align:center}h1,h2,h3,h4,h5,h6{margin:10px
0;font-family:inherit;font-weight:bold;line-height:20px;color:inherit;text-rendering:optimizelegibility}h1 small,h2 small,h3 small,h4 small,h5 small,h6
small{font-weight:normal;line-height:1;color:#999}h1,h2,h3{line-height:40px}h1{font-size:38.5px}h2{font-size:31.5px}h3{font-size:24.5px}h4{font-size:17.5px}h5{font-size:14px}h6{font-size:11.9px}h1
small{font-size:24.5px}h2
small{font-size:17.5px}h3
small{font-size:14px}h4
small{font-size:14px}.page-header{padding-bottom:9px;margin:20px
0 30px;border-bottom:1px solid #eee}ul,ol{padding:0;margin:0
0 10px 25px}ul ul,ul ol,ol ol,ol
ul{margin-bottom:0}li{line-height:20px}ul.unstyled,ol.unstyled{margin-left:0;list-style:none}ul.inline,ol.inline{margin-left:0;list-style:none}ul.inline>li,ol.inline>li{display:inline-block;*display:inline;*zoom:1;padding-left:5px;padding-right:5px}dl{margin-bottom:20px}dt,dd{line-height:20px}dt{font-weight:bold}dd{margin-left:10px}.dl-horizontal{*zoom:1}.dl-horizontal:before,.dl-horizontal:after{display:table;content:"";line-height:0}.dl-horizontal:after{clear:both}.dl-horizontal
dt{float:left;width:180px;clear:left;text-align:right;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.dl-horizontal
dd{margin-left:200px}hr{margin:20px
0;border:0;border-top:1px solid #eee;border-bottom:1px solid #fff}abbr[title],abbr[data-original-title]{cursor:help;border-bottom:1px dotted #999}abbr.initialism{font-size:90%;text-transform:uppercase}blockquote{padding:0
0 0 15px;margin:0
0 20px;border-left:5px solid #eee}blockquote
p{margin-bottom:0;font-size:17.5px;font-weight:300;line-height:1.25}blockquote
small{display:block;line-height:20px;color:#999}blockquote small:before{content:'\2014 \00A0'}blockquote.pull-right{float:right;padding-right:15px;padding-left:0;border-right:5px solid #eee;border-left:0}blockquote.pull-right p,blockquote.pull-right
small{text-align:right}blockquote.pull-right small:before{content:''}blockquote.pull-right small:after{content:'\00A0 \2014'}q:before,q:after,blockquote:before,blockquote:after{content:""}address{display:block;margin-bottom:20px;font-style:normal;line-height:20px}code,pre{padding:0
3px 2px;font-family:Monaco,Menlo,Consolas,"Courier New",monospace;font-size:12px;color:#333;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}code{padding:2px
4px;color:#d14;background-color:#f7f7f9;border:1px
solid #e1e1e8;white-space:nowrap}pre{display:block;padding:9.5px;margin:0
0 10px;font-size:13px;line-height:20px;word-break:break-all;word-wrap:break-word;white-space:pre;white-space:pre-wrap;background-color:#f5f5f5;border:1px
solid #ccc;border:1px
solid rgba(0,0,0,0.15);-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}pre.prettyprint{margin-bottom:20px}pre
code{padding:0;color:inherit;white-space:pre;white-space:pre-wrap;background-color:transparent;border:0}.pre-scrollable{max-height:340px;overflow-y:scroll}form{margin:0
0 20px}fieldset{padding:0;margin:0;border:0}legend{display:block;width:100%;padding:0;margin-bottom:20px;font-size:21px;line-height:40px;color:#333;border:0;border-bottom:1px solid #e5e5e5}legend
small{font-size:15px;color:#999}label,input,button,select,textarea{font-size:14px;font-weight:normal;line-height:20px}input,button,select,textarea{font-family:"Helvetica Neue",Helvetica,Arial,sans-serif}label{display:block;margin-bottom:5px}select,textarea,input[type="text"],input[type="password"],input[type="datetime"],input[type="datetime-local"],input[type="date"],input[type="month"],input[type="time"],input[type="week"],input[type="number"],input[type="email"],input[type="url"],input[type="search"],input[type="tel"],input[type="color"],.uneditable-input{display:inline-block;height:20px;padding:4px
6px;margin-bottom:10px;font-size:14px;line-height:20px;color:#555;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;vertical-align:middle}input,textarea,.uneditable-input{width:206px}textarea{height:auto}textarea,input[type="text"],input[type="password"],input[type="datetime"],input[type="datetime-local"],input[type="date"],input[type="month"],input[type="time"],input[type="week"],input[type="number"],input[type="email"],input[type="url"],input[type="search"],input[type="tel"],input[type="color"],.uneditable-input{background-color:#fff;border:1px
solid #ccc;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);-webkit-transition:border linear .2s, box-shadow linear .2s;-moz-transition:border linear .2s, box-shadow linear .2s;-o-transition:border linear .2s, box-shadow linear .2s;transition:border linear .2s, box-shadow linear .2s}textarea:focus,input[type="text"]:focus,input[type="password"]:focus,input[type="datetime"]:focus,input[type="datetime-local"]:focus,input[type="date"]:focus,input[type="month"]:focus,input[type="time"]:focus,input[type="week"]:focus,input[type="number"]:focus,input[type="email"]:focus,input[type="url"]:focus,input[type="search"]:focus,input[type="tel"]:focus,input[type="color"]:focus,.uneditable-input:focus{border-color:rgba(82,168,236,0.8);outline:0;outline:thin dotted \9;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(82,168,236,.6);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(82,168,236,.6);box-shadow:inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(82,168,236,.6)}input[type="radio"],input[type="checkbox"]{margin:4px
0 0;*margin-top:0;margin-top:1px \9;line-height:normal}input[type="file"],input[type="image"],input[type="submit"],input[type="reset"],input[type="button"],input[type="radio"],input[type="checkbox"]{width:auto}select,input[type="file"]{height:30px;*margin-top:4px;line-height:30px}select{width:220px;border:1px
solid #ccc;background-color:#fff}select[multiple],select[size]{height:auto}select:focus,input[type="file"]:focus,input[type="radio"]:focus,input[type="checkbox"]:focus{outline:thin dotted #333;outline:5px
auto -webkit-focus-ring-color;outline-offset:-2px}.uneditable-input,.uneditable-textarea{color:#999;background-color:#fcfcfc;border-color:#ccc;-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,0.025);-moz-box-shadow:inset 0 1px 2px rgba(0,0,0,0.025);box-shadow:inset 0 1px 2px rgba(0,0,0,0.025);cursor:not-allowed}.uneditable-input{overflow:hidden;white-space:nowrap}.uneditable-textarea{width:auto;height:auto}input:-moz-placeholder,textarea:-moz-placeholder{color:#999}input:-ms-input-placeholder,textarea:-ms-input-placeholder{color:#999}input::-webkit-input-placeholder,textarea::-webkit-input-placeholder{color:#999}.radio,.checkbox{min-height:20px;padding-left:20px}.radio input[type="radio"],.checkbox input[type="checkbox"]{float:left;margin-left:-20px}.controls>.radio:first-child,.controls>.checkbox:first-child{padding-top:5px}.radio.inline,.checkbox.inline{display:inline-block;padding-top:5px;margin-bottom:0;vertical-align:middle}.radio.inline+.radio.inline,.checkbox.inline+.checkbox.inline{margin-left:10px}.input-mini{width:60px}.input-small{width:90px}.input-medium{width:150px}.input-large{width:210px}.input-xlarge{width:270px}.input-xxlarge{width:530px}input[class*="span"],select[class*="span"],textarea[class*="span"],.uneditable-input[class*="span"],.row-fluid input[class*="span"],.row-fluid select[class*="span"],.row-fluid textarea[class*="span"],.row-fluid .uneditable-input[class*="span"]{float:none;margin-left:0}.input-append input[class*="span"],.input-append .uneditable-input[class*="span"],.input-prepend input[class*="span"],.input-prepend .uneditable-input[class*="span"],.row-fluid input[class*="span"],.row-fluid select[class*="span"],.row-fluid textarea[class*="span"],.row-fluid .uneditable-input[class*="span"],.row-fluid .input-prepend [class*="span"],.row-fluid .input-append [class*="span"]{display:inline-block}input,textarea,.uneditable-input{margin-left:0}.controls-row [class*="span"]+[class*="span"]{margin-left:20px}input.span12,textarea.span12,.uneditable-input.span12{width:926px}input.span11,textarea.span11,.uneditable-input.span11{width:846px}input.span10,textarea.span10,.uneditable-input.span10{width:766px}input.span9,textarea.span9,.uneditable-input.span9{width:686px}input.span8,textarea.span8,.uneditable-input.span8{width:606px}input.span7,textarea.span7,.uneditable-input.span7{width:526px}input.span6,textarea.span6,.uneditable-input.span6{width:446px}input.span5,textarea.span5,.uneditable-input.span5{width:366px}input.span4,textarea.span4,.uneditable-input.span4{width:286px}input.span3,textarea.span3,.uneditable-input.span3{width:206px}input.span2,textarea.span2,.uneditable-input.span2{width:126px}input.span1,textarea.span1,.uneditable-input.span1{width:46px}.controls-row{*zoom:1}.controls-row:before,.controls-row:after{display:table;content:"";line-height:0}.controls-row:after{clear:both}.controls-row [class*="span"],.row-fluid .controls-row [class*="span"]{float:left}.controls-row .checkbox[class*="span"],.controls-row .radio[class*="span"]{padding-top:5px}input[disabled],select[disabled],textarea[disabled],input[readonly],select[readonly],textarea[readonly]{cursor:not-allowed;background-color:#eee}input[type="radio"][disabled],input[type="checkbox"][disabled],input[type="radio"][readonly],input[type="checkbox"][readonly]{background-color:transparent}.control-group.warning .control-label,.control-group.warning .help-block,.control-group.warning .help-inline{color:#8a6d3b}.control-group.warning .checkbox,.control-group.warning .radio,.control-group.warning input,.control-group.warning select,.control-group.warning
textarea{color:#8a6d3b}.control-group.warning input,.control-group.warning select,.control-group.warning
textarea{border-color:#8a6d3b;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075)}.control-group.warning input:focus,.control-group.warning select:focus,.control-group.warning textarea:focus{border-color:#66512c;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #c0a16b;-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #c0a16b;box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #c0a16b}.control-group.warning .input-prepend .add-on,.control-group.warning .input-append .add-on{color:#8a6d3b;background-color:#fcf8e3;border-color:#8a6d3b}.control-group.error .control-label,.control-group.error .help-block,.control-group.error .help-inline{color:#b94a48}.control-group.error .checkbox,.control-group.error .radio,.control-group.error input,.control-group.error select,.control-group.error
textarea{color:#b94a48}.control-group.error input,.control-group.error select,.control-group.error
textarea{border-color:#b94a48;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075)}.control-group.error input:focus,.control-group.error select:focus,.control-group.error textarea:focus{border-color:#953b39;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #d59392;-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #d59392;box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #d59392}.control-group.error .input-prepend .add-on,.control-group.error .input-append .add-on{color:#b94a48;background-color:#f2dede;border-color:#b94a48}.control-group.success .control-label,.control-group.success .help-block,.control-group.success .help-inline{color:#468847}.control-group.success .checkbox,.control-group.success .radio,.control-group.success input,.control-group.success select,.control-group.success
textarea{color:#468847}.control-group.success input,.control-group.success select,.control-group.success
textarea{border-color:#468847;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075)}.control-group.success input:focus,.control-group.success select:focus,.control-group.success textarea:focus{border-color:#356635;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #7aba7b;-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #7aba7b;box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #7aba7b}.control-group.success .input-prepend .add-on,.control-group.success .input-append .add-on{color:#468847;background-color:#dff0d8;border-color:#468847}.control-group.info .control-label,.control-group.info .help-block,.control-group.info .help-inline{color:#3a87ad}.control-group.info .checkbox,.control-group.info .radio,.control-group.info input,.control-group.info select,.control-group.info
textarea{color:#3a87ad}.control-group.info input,.control-group.info select,.control-group.info
textarea{border-color:#3a87ad;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);box-shadow:inset 0 1px 1px rgba(0,0,0,0.075)}.control-group.info input:focus,.control-group.info select:focus,.control-group.info textarea:focus{border-color:#2d6987;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #7ab5d3;-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #7ab5d3;box-shadow:inset 0 1px 1px rgba(0,0,0,0.075),0 0 6px #7ab5d3}.control-group.info .input-prepend .add-on,.control-group.info .input-append .add-on{color:#3a87ad;background-color:#d9edf7;border-color:#3a87ad}input:focus:invalid,textarea:focus:invalid,select:focus:invalid{color:#b94a48;border-color:#ee5f5b}input:focus:invalid:focus,textarea:focus:invalid:focus,select:focus:invalid:focus{border-color:#e9322d;-webkit-box-shadow:0 0 6px #f8b9b7;-moz-box-shadow:0 0 6px #f8b9b7;box-shadow:0 0 6px #f8b9b7}.form-actions{padding:19px
20px 20px;margin-top:20px;margin-bottom:20px;background-color:#f5f5f5;border-top:1px solid #e5e5e5;*zoom:1}.form-actions:before,.form-actions:after{display:table;content:"";line-height:0}.form-actions:after{clear:both}.help-block,.help-inline{color:#595959}.help-block{display:block;margin-bottom:10px}.help-inline{display:inline-block;*display:inline;*zoom:1;vertical-align:middle;padding-left:5px}.input-append,.input-prepend{display:inline-block;margin-bottom:10px;vertical-align:middle;font-size:0;white-space:nowrap}.input-append input,.input-prepend input,.input-append select,.input-prepend select,.input-append .uneditable-input,.input-prepend .uneditable-input,.input-append .dropdown-menu,.input-prepend .dropdown-menu,.input-append .popover,.input-prepend
.popover{font-size:14px}.input-append input,.input-prepend input,.input-append select,.input-prepend select,.input-append .uneditable-input,.input-prepend .uneditable-input{position:relative;margin-bottom:0;*margin-left:0;vertical-align:top;-webkit-border-radius:0 4px 4px 0;-moz-border-radius:0 4px 4px 0;border-radius:0 4px 4px 0}.input-append input:focus,.input-prepend input:focus,.input-append select:focus,.input-prepend select:focus,.input-append .uneditable-input:focus,.input-prepend .uneditable-input:focus{z-index:2}.input-append .add-on,.input-prepend .add-on{display:inline-block;width:auto;height:20px;min-width:16px;padding:4px
5px;font-size:14px;font-weight:normal;line-height:20px;text-align:center;text-shadow:0 1px 0 #fff;background-color:#eee;border:1px
solid #ccc}.input-append .add-on,.input-prepend .add-on,.input-append .btn,.input-prepend .btn,.input-append .btn-group>.dropdown-toggle,.input-prepend .btn-group>.dropdown-toggle{vertical-align:top;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.input-append .active,.input-prepend
.active{background-color:#a9dba9;border-color:#46a546}.input-prepend .add-on,.input-prepend
.btn{margin-right:-1px}.input-prepend .add-on:first-child,.input-prepend .btn:first-child{-webkit-border-radius:4px 0 0 4px;-moz-border-radius:4px 0 0 4px;border-radius:4px 0 0 4px}.input-append input,.input-append select,.input-append .uneditable-input{-webkit-border-radius:4px 0 0 4px;-moz-border-radius:4px 0 0 4px;border-radius:4px 0 0 4px}.input-append input+.btn-group .btn:last-child,.input-append select+.btn-group .btn:last-child,.input-append .uneditable-input+.btn-group .btn:last-child{-webkit-border-radius:0 4px 4px 0;-moz-border-radius:0 4px 4px 0;border-radius:0 4px 4px 0}.input-append .add-on,.input-append .btn,.input-append .btn-group{margin-left:-1px}.input-append .add-on:last-child,.input-append .btn:last-child,.input-append .btn-group:last-child>.dropdown-toggle{-webkit-border-radius:0 4px 4px 0;-moz-border-radius:0 4px 4px 0;border-radius:0 4px 4px 0}.input-prepend.input-append input,.input-prepend.input-append select,.input-prepend.input-append .uneditable-input{-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.input-prepend.input-append input+.btn-group .btn,.input-prepend.input-append select+.btn-group .btn,.input-prepend.input-append .uneditable-input+.btn-group
.btn{-webkit-border-radius:0 4px 4px 0;-moz-border-radius:0 4px 4px 0;border-radius:0 4px 4px 0}.input-prepend.input-append .add-on:first-child,.input-prepend.input-append .btn:first-child{margin-right:-1px;-webkit-border-radius:4px 0 0 4px;-moz-border-radius:4px 0 0 4px;border-radius:4px 0 0 4px}.input-prepend.input-append .add-on:last-child,.input-prepend.input-append .btn:last-child{margin-left:-1px;-webkit-border-radius:0 4px 4px 0;-moz-border-radius:0 4px 4px 0;border-radius:0 4px 4px 0}.input-prepend.input-append .btn-group:first-child{margin-left:0}input.search-query{padding-right:14px;padding-right:4px \9;padding-left:14px;padding-left:4px \9;margin-bottom:0;-webkit-border-radius:15px;-moz-border-radius:15px;border-radius:15px}.form-search .input-append .search-query,.form-search .input-prepend .search-query{-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.form-search .input-append .search-query{-webkit-border-radius:14px 0 0 14px;-moz-border-radius:14px 0 0 14px;border-radius:14px 0 0 14px}.form-search .input-append
.btn{-webkit-border-radius:0 14px 14px 0;-moz-border-radius:0 14px 14px 0;border-radius:0 14px 14px 0}.form-search .input-prepend .search-query{-webkit-border-radius:0 14px 14px 0;-moz-border-radius:0 14px 14px 0;border-radius:0 14px 14px 0}.form-search .input-prepend
.btn{-webkit-border-radius:14px 0 0 14px;-moz-border-radius:14px 0 0 14px;border-radius:14px 0 0 14px}.form-search input,.form-inline input,.form-horizontal input,.form-search textarea,.form-inline textarea,.form-horizontal textarea,.form-search select,.form-inline select,.form-horizontal select,.form-search .help-inline,.form-inline .help-inline,.form-horizontal .help-inline,.form-search .uneditable-input,.form-inline .uneditable-input,.form-horizontal .uneditable-input,.form-search .input-prepend,.form-inline .input-prepend,.form-horizontal .input-prepend,.form-search .input-append,.form-inline .input-append,.form-horizontal .input-append{display:inline-block;*display:inline;*zoom:1;margin-bottom:0;vertical-align:middle}.form-search .hide,.form-inline .hide,.form-horizontal
.hide{display:none}.form-search label,.form-inline label,.form-search .btn-group,.form-inline .btn-group{display:inline-block}.form-search .input-append,.form-inline .input-append,.form-search .input-prepend,.form-inline .input-prepend{margin-bottom:0}.form-search .radio,.form-search .checkbox,.form-inline .radio,.form-inline
.checkbox{padding-left:0;margin-bottom:0;vertical-align:middle}.form-search .radio input[type="radio"],.form-search .checkbox input[type="checkbox"],.form-inline .radio input[type="radio"],.form-inline .checkbox input[type="checkbox"]{float:left;margin-right:3px;margin-left:0}.control-group{margin-bottom:10px}legend+.control-group{margin-top:20px;-webkit-margin-top-collapse:separate}.form-horizontal .control-group{margin-bottom:20px;*zoom:1}.form-horizontal .control-group:before,.form-horizontal .control-group:after{display:table;content:"";line-height:0}.form-horizontal .control-group:after{clear:both}.form-horizontal .control-label{float:left;width:180px;padding-top:5px;text-align:right}.form-horizontal
.controls{*display:inline-block;*padding-left:20px;margin-left:200px;*margin-left:0}.form-horizontal .controls:first-child{*padding-left:200px}.form-horizontal .help-block{margin-bottom:0}.form-horizontal input+.help-block,.form-horizontal select+.help-block,.form-horizontal textarea+.help-block,.form-horizontal .uneditable-input+.help-block,.form-horizontal .input-prepend+.help-block,.form-horizontal .input-append+.help-block{margin-top:10px}.form-horizontal .form-actions{padding-left:200px}table{max-width:100%;background-color:transparent;border-collapse:collapse;border-spacing:0}.table{width:100%;margin-bottom:20px}.table th,.table
td{padding:8px;line-height:20px;text-align:left;vertical-align:top;border-top:1px solid #ddd}.table
th{font-weight:bold}.table thead
th{vertical-align:bottom}.table caption+thead tr:first-child th,.table caption+thead tr:first-child td,.table colgroup+thead tr:first-child th,.table colgroup+thead tr:first-child td,.table thead:first-child tr:first-child th,.table thead:first-child tr:first-child
td{border-top:0}.table tbody+tbody{border-top:2px solid #ddd}.table
.table{background-color:#fff}.table-condensed th,.table-condensed
td{padding:4px
5px}.table-bordered{border:1px
solid #ddd;border-collapse:separate;*border-collapse:collapse;border-left:0;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.table-bordered th,.table-bordered
td{border-left:1px solid #ddd}.table-bordered caption+thead tr:first-child th,.table-bordered caption+tbody tr:first-child th,.table-bordered caption+tbody tr:first-child td,.table-bordered colgroup+thead tr:first-child th,.table-bordered colgroup+tbody tr:first-child th,.table-bordered colgroup+tbody tr:first-child td,.table-bordered thead:first-child tr:first-child th,.table-bordered tbody:first-child tr:first-child th,.table-bordered tbody:first-child tr:first-child
td{border-top:0}.table-bordered thead:first-child tr:first-child>th:first-child,.table-bordered tbody:first-child tr:first-child>td:first-child,.table-bordered tbody:first-child tr:first-child>th:first-child{-webkit-border-top-left-radius:4px;-moz-border-radius-topleft:4px;border-top-left-radius:4px}.table-bordered thead:first-child tr:first-child>th:last-child,.table-bordered tbody:first-child tr:first-child>td:last-child,.table-bordered tbody:first-child tr:first-child>th:last-child{-webkit-border-top-right-radius:4px;-moz-border-radius-topright:4px;border-top-right-radius:4px}.table-bordered thead:last-child tr:last-child>th:first-child,.table-bordered tbody:last-child tr:last-child>td:first-child,.table-bordered tbody:last-child tr:last-child>th:first-child,.table-bordered tfoot:last-child tr:last-child>td:first-child,.table-bordered tfoot:last-child tr:last-child>th:first-child{-webkit-border-bottom-left-radius:4px;-moz-border-radius-bottomleft:4px;border-bottom-left-radius:4px}.table-bordered thead:last-child tr:last-child>th:last-child,.table-bordered tbody:last-child tr:last-child>td:last-child,.table-bordered tbody:last-child tr:last-child>th:last-child,.table-bordered tfoot:last-child tr:last-child>td:last-child,.table-bordered tfoot:last-child tr:last-child>th:last-child{-webkit-border-bottom-right-radius:4px;-moz-border-radius-bottomright:4px;border-bottom-right-radius:4px}.table-bordered tfoot+tbody:last-child tr:last-child td:first-child{-webkit-border-bottom-left-radius:0;-moz-border-radius-bottomleft:0;border-bottom-left-radius:0}.table-bordered tfoot+tbody:last-child tr:last-child td:last-child{-webkit-border-bottom-right-radius:0;-moz-border-radius-bottomright:0;border-bottom-right-radius:0}.table-bordered caption+thead tr:first-child th:first-child,.table-bordered caption+tbody tr:first-child td:first-child,.table-bordered colgroup+thead tr:first-child th:first-child,.table-bordered colgroup+tbody tr:first-child td:first-child{-webkit-border-top-left-radius:4px;-moz-border-radius-topleft:4px;border-top-left-radius:4px}.table-bordered caption+thead tr:first-child th:last-child,.table-bordered caption+tbody tr:first-child td:last-child,.table-bordered colgroup+thead tr:first-child th:last-child,.table-bordered colgroup+tbody tr:first-child td:last-child{-webkit-border-top-right-radius:4px;-moz-border-radius-topright:4px;border-top-right-radius:4px}.table-striped tbody>tr:nth-child(odd)>td,.table-striped tbody>tr:nth-child(odd)>th{background-color:#f9f9f9}.table-hover tbody tr:hover>td,.table-hover tbody tr:hover>th{background-color:#f5f5f5}table td[class*="span"],table th[class*="span"],.row-fluid table td[class*="span"],.row-fluid table th[class*="span"]{display:table-cell;float:none;margin-left:0}.table td.span1,.table
th.span1{float:none;width:44px;margin-left:0}.table td.span2,.table
th.span2{float:none;width:124px;margin-left:0}.table td.span3,.table
th.span3{float:none;width:204px;margin-left:0}.table td.span4,.table
th.span4{float:none;width:284px;margin-left:0}.table td.span5,.table
th.span5{float:none;width:364px;margin-left:0}.table td.span6,.table
th.span6{float:none;width:444px;margin-left:0}.table td.span7,.table
th.span7{float:none;width:524px;margin-left:0}.table td.span8,.table
th.span8{float:none;width:604px;margin-left:0}.table td.span9,.table
th.span9{float:none;width:684px;margin-left:0}.table td.span10,.table
th.span10{float:none;width:764px;margin-left:0}.table td.span11,.table
th.span11{float:none;width:844px;margin-left:0}.table td.span12,.table
th.span12{float:none;width:924px;margin-left:0}.table tbody tr.success>td{background-color:#dff0d8}.table tbody tr.error>td{background-color:#f2dede}.table tbody tr.warning>td{background-color:#fcf8e3}.table tbody tr.info>td{background-color:#d9edf7}.table-hover tbody tr.success:hover>td{background-color:#d0e9c6}.table-hover tbody tr.error:hover>td{background-color:#ebcccc}.table-hover tbody tr.warning:hover>td{background-color:#faf2cc}.table-hover tbody tr.info:hover>td{background-color:#c4e3f3}[class^="icon-"],[class*=" icon-"]{display:inline-block;width:14px;height:14px;*margin-right:.3em;line-height:14px;vertical-align:text-top;background-image:url("/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=glyphicons-halflings");background-position:14px 14px;background-repeat:no-repeat;margin-top:1px}.icon-white,.nav-pills>.active>a>[class^="icon-"],.nav-pills>.active>a>[class*=" icon-"],.nav-list>.active>a>[class^="icon-"],.nav-list>.active>a>[class*=" icon-"],.navbar-inverse .nav>.active>a>[class^="icon-"],.navbar-inverse .nav>.active>a>[class*=" icon-"],.dropdown-menu>li>a:hover>[class^="icon-"],.dropdown-menu>li>a:focus>[class^="icon-"],.dropdown-menu>li>a:hover>[class*=" icon-"],.dropdown-menu>li>a:focus>[class*=" icon-"],.dropdown-menu>.active>a>[class^="icon-"],.dropdown-menu>.active>a>[class*=" icon-"],.dropdown-submenu:hover>a>[class^="icon-"],.dropdown-submenu:focus>a>[class^="icon-"],.dropdown-submenu:hover>a>[class*=" icon-"],.dropdown-submenu:focus>a>[class*=" icon-"]{background-image:url("/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=glyphicons-halflings-white")}.icon-glass{background-position:0 0}.icon-music{background-position:-24px 0}.icon-search{background-position:-48px 0}.icon-envelope{background-position:-72px 0}.icon-heart{background-position:-96px 0}.icon-star{background-position:-120px 0}.icon-star-empty{background-position:-144px 0}.icon-user{background-position:-168px 0}.icon-film{background-position:-192px 0}.icon-th-large{background-position:-216px 0}.icon-th{background-position:-240px 0}.icon-th-list{background-position:-264px 0}.icon-ok{background-position:-288px 0}.icon-remove{background-position:-312px 0}.icon-zoom-in{background-position:-336px 0}.icon-zoom-out{background-position:-360px 0}.icon-off{background-position:-384px 0}.icon-signal{background-position:-408px 0}.icon-cog{background-position:-432px 0}.icon-trash{background-position:-456px 0}.icon-home{background-position:0 -24px}.icon-file{background-position:-24px -24px}.icon-time{background-position:-48px -24px}.icon-road{background-position:-72px -24px}.icon-download-alt{background-position:-96px -24px}.icon-download{background-position:-120px -24px}.icon-upload{background-position:-144px -24px}.icon-inbox{background-position:-168px -24px}.icon-play-circle{background-position:-192px -24px}.icon-repeat{background-position:-216px -24px}.icon-refresh{background-position:-240px -24px}.icon-list-alt{background-position:-264px -24px}.icon-lock{background-position:-287px -24px}.icon-flag{background-position:-312px -24px}.icon-headphones{background-position:-336px -24px}.icon-volume-off{background-position:-360px -24px}.icon-volume-down{background-position:-384px -24px}.icon-volume-up{background-position:-408px -24px}.icon-qrcode{background-position:-432px -24px}.icon-barcode{background-position:-456px -24px}.icon-tag{background-position:0 -48px}.icon-tags{background-position:-25px -48px}.icon-book{background-position:-48px -48px}.icon-bookmark{background-position:-72px -48px}.icon-print{background-position:-96px -48px}.icon-camera{background-position:-120px -48px}.icon-font{background-position:-144px -48px}.icon-bold{background-position:-167px -48px}.icon-italic{background-position:-192px -48px}.icon-text-height{background-position:-216px -48px}.icon-text-width{background-position:-240px -48px}.icon-align-left{background-position:-264px -48px}.icon-align-center{background-position:-288px -48px}.icon-align-right{background-position:-312px -48px}.icon-align-justify{background-position:-336px -48px}.icon-list{background-position:-360px -48px}.icon-indent-left{background-position:-384px -48px}.icon-indent-right{background-position:-408px -48px}.icon-facetime-video{background-position:-432px -48px}.icon-picture{background-position:-456px -48px}.icon-pencil{background-position:0 -72px}.icon-map-marker{background-position:-24px -72px}.icon-adjust{background-position:-48px -72px}.icon-tint{background-position:-72px -72px}.icon-edit{background-position:-96px -72px}.icon-share{background-position:-120px -72px}.icon-check{background-position:-144px -72px}.icon-move{background-position:-168px -72px}.icon-step-backward{background-position:-192px -72px}.icon-fast-backward{background-position:-216px -72px}.icon-backward{background-position:-240px -72px}.icon-play{background-position:-264px -72px}.icon-pause{background-position:-288px -72px}.icon-stop{background-position:-312px -72px}.icon-forward{background-position:-336px -72px}.icon-fast-forward{background-position:-360px -72px}.icon-step-forward{background-position:-384px -72px}.icon-eject{background-position:-408px -72px}.icon-chevron-left{background-position:-432px -72px}.icon-chevron-right{background-position:-456px -72px}.icon-plus-sign{background-position:0 -96px}.icon-minus-sign{background-position:-24px -96px}.icon-remove-sign{background-position:-48px -96px}.icon-ok-sign{background-position:-72px -96px}.icon-question-sign{background-position:-96px -96px}.icon-info-sign{background-position:-120px -96px}.icon-screenshot{background-position:-144px -96px}.icon-remove-circle{background-position:-168px -96px}.icon-ok-circle{background-position:-192px -96px}.icon-ban-circle{background-position:-216px -96px}.icon-arrow-left{background-position:-240px -96px}.icon-arrow-right{background-position:-264px -96px}.icon-arrow-up{background-position:-289px -96px}.icon-arrow-down{background-position:-312px -96px}.icon-share-alt{background-position:-336px -96px}.icon-resize-full{background-position:-360px -96px}.icon-resize-small{background-position:-384px -96px}.icon-plus{background-position:-408px -96px}.icon-minus{background-position:-433px -96px}.icon-asterisk{background-position:-456px -96px}.icon-exclamation-sign{background-position:0 -120px}.icon-gift{background-position:-24px -120px}.icon-leaf{background-position:-48px -120px}.icon-fire{background-position:-72px -120px}.icon-eye-open{background-position:-96px -120px}.icon-eye-close{background-position:-120px -120px}.icon-warning-sign{background-position:-144px -120px}.icon-plane{background-position:-168px -120px}.icon-calendar{background-position:-192px -120px}.icon-random{background-position:-216px -120px;width:16px}.icon-comment{background-position:-240px -120px}.icon-magnet{background-position:-264px -120px}.icon-chevron-up{background-position:-288px -120px}.icon-chevron-down{background-position:-313px -119px}.icon-retweet{background-position:-336px -120px}.icon-shopping-cart{background-position:-360px -120px}.icon-folder-close{background-position:-384px -120px;width:16px}.icon-folder-open{background-position:-408px -120px;width:16px}.icon-resize-vertical{background-position:-432px -119px}.icon-resize-horizontal{background-position:-456px -118px}.icon-hdd{background-position:0 -144px}.icon-bullhorn{background-position:-24px -144px}.icon-bell{background-position:-48px -144px}.icon-certificate{background-position:-72px -144px}.icon-thumbs-up{background-position:-96px -144px}.icon-thumbs-down{background-position:-120px -144px}.icon-hand-right{background-position:-144px -144px}.icon-hand-left{background-position:-168px -144px}.icon-hand-up{background-position:-192px -144px}.icon-hand-down{background-position:-216px -144px}.icon-circle-arrow-right{background-position:-240px -144px}.icon-circle-arrow-left{background-position:-264px -144px}.icon-circle-arrow-up{background-position:-288px -144px}.icon-circle-arrow-down{background-position:-312px -144px}.icon-globe{background-position:-336px -144px}.icon-wrench{background-position:-360px -144px}.icon-tasks{background-position:-384px -144px}.icon-filter{background-position:-408px -144px}.icon-briefcase{background-position:-432px -144px}.icon-fullscreen{background-position:-456px -144px}.dropup,.dropdown{position:relative}.dropdown-toggle{*margin-bottom:-3px}.dropdown-toggle:active,.open .dropdown-toggle{outline:0}.caret{display:inline-block;width:0;height:0;vertical-align:top;border-top:4px solid #000;border-right:4px solid transparent;border-left:4px solid transparent;content:""}.dropdown
.caret{margin-top:8px;margin-left:2px}.dropdown-menu{position:absolute;top:100%;left:0;z-index:1000;display:none;float:left;min-width:160px;padding:5px
0;margin:2px
0 0;list-style:none;background-color:#fff;border:1px
solid #ccc;border:1px
solid rgba(0,0,0,0.2);*border-right-width:2px;*border-bottom-width:2px;-webkit-border-radius:6px;-moz-border-radius:6px;border-radius:6px;-webkit-box-shadow:0 5px 10px rgba(0,0,0,0.2);-moz-box-shadow:0 5px 10px rgba(0,0,0,0.2);box-shadow:0 5px 10px rgba(0,0,0,0.2);-webkit-background-clip:padding-box;-moz-background-clip:padding;background-clip:padding-box}.dropdown-menu.pull-right{right:0;left:auto}.dropdown-menu
.divider{*width:100%;height:1px;margin:9px
1px;*margin:-5px 0 5px;overflow:hidden;background-color:#e5e5e5;border-bottom:1px solid #fff}.dropdown-menu>li>a{display:block;padding:3px
20px;clear:both;font-weight:normal;line-height:20px;color:#333;white-space:nowrap}.dropdown-menu>li>a:hover,.dropdown-menu>li>a:focus,.dropdown-submenu:hover>a,.dropdown-submenu:focus>a{text-decoration:none;color:#fff;background-color:#00699e;background-image:-moz-linear-gradient(top, #0070a8, #005f8f);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#0070a8), to(#005f8f));background-image:-webkit-linear-gradient(top, #0070a8, #005f8f);background-image:-o-linear-gradient(top, #0070a8, #005f8f);background-image:linear-gradient(to bottom,#0070a8,#005f8f);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff0070a8',endColorstr='#ff005f8f',GradientType=0)}.dropdown-menu>.active>a,.dropdown-menu>.active>a:hover,.dropdown-menu>.active>a:focus{color:#fff;text-decoration:none;outline:0;background-color:#00699e;background-image:-moz-linear-gradient(top, #0070a8, #005f8f);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#0070a8), to(#005f8f));background-image:-webkit-linear-gradient(top, #0070a8, #005f8f);background-image:-o-linear-gradient(top, #0070a8, #005f8f);background-image:linear-gradient(to bottom,#0070a8,#005f8f);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff0070a8',endColorstr='#ff005f8f',GradientType=0)}.dropdown-menu>.disabled>a,.dropdown-menu>.disabled>a:hover,.dropdown-menu>.disabled>a:focus{color:#999}.dropdown-menu>.disabled>a:hover,.dropdown-menu>.disabled>a:focus{text-decoration:none;background-color:transparent;background-image:none;filter:progid:DXImageTransform.Microsoft.gradient(enabled = false);cursor:default}.open{*z-index:1000}.open>.dropdown-menu{display:block}.dropdown-backdrop{position:fixed;left:0;right:0;bottom:0;top:0;z-index:990}.pull-right>.dropdown-menu{right:0;left:auto}.dropup .caret,.navbar-fixed-bottom .dropdown
.caret{border-top:0;border-bottom:4px solid #000;content:""}.dropup .dropdown-menu,.navbar-fixed-bottom .dropdown .dropdown-menu{top:auto;bottom:100%;margin-bottom:1px}.dropdown-submenu{position:relative}.dropdown-submenu>.dropdown-menu{top:0;left:100%;margin-top:-6px;margin-left:-1px;-webkit-border-radius:0 6px 6px 6px;-moz-border-radius:0 6px 6px 6px;border-radius:0 6px 6px 6px}.dropdown-submenu:hover>.dropdown-menu{display:block}.dropup .dropdown-submenu>.dropdown-menu{top:auto;bottom:0;margin-top:0;margin-bottom:-2px;-webkit-border-radius:5px 5px 5px 0;-moz-border-radius:5px 5px 5px 0;border-radius:5px 5px 5px 0}.dropdown-submenu>a:after{display:block;content:" ";float:right;width:0;height:0;border-color:transparent;border-style:solid;border-width:5px 0 5px 5px;border-left-color:#ccc;margin-top:5px;margin-right:-10px}.dropdown-submenu:hover>a:after{border-left-color:#fff}.dropdown-submenu.pull-left{float:none}.dropdown-submenu.pull-left>.dropdown-menu{left:-100%;margin-left:10px;-webkit-border-radius:6px 0 6px 6px;-moz-border-radius:6px 0 6px 6px;border-radius:6px 0 6px 6px}.dropdown .dropdown-menu .nav-header{padding-left:20px;padding-right:20px}.typeahead{z-index:1051;margin-top:2px;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.well{min-height:20px;padding:19px;margin-bottom:20px;background-color:#f5f5f5;border:1px
solid #e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05)}.well
blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}.well-large{padding:24px;-webkit-border-radius:6px;-moz-border-radius:6px;border-radius:6px}.well-small{padding:9px;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.fade{opacity:0;-webkit-transition:opacity .15s linear;-moz-transition:opacity .15s linear;-o-transition:opacity .15s linear;transition:opacity .15s linear}.fade.in{opacity:1}.collapse{position:relative;height:0;overflow:hidden;-webkit-transition:height .35s ease;-moz-transition:height .35s ease;-o-transition:height .35s ease;transition:height .35s ease}.collapse.in{height:auto}.close{float:right;font-size:20px;font-weight:bold;line-height:20px;color:#000;text-shadow:0 1px 0 #fff;opacity:.2;filter:alpha(opacity=20)}.close:hover,.close:focus{color:#000;text-decoration:none;cursor:pointer;opacity:.4;filter:alpha(opacity=40)}button.close{padding:0;cursor:pointer;background:transparent;border:0;-webkit-appearance:none}.btn{display:inline-block;*display:inline;*zoom:1;padding:4px
12px;margin-bottom:0;font-size:14px;line-height:20px;text-align:center;vertical-align:middle;cursor:pointer;color:#333;text-shadow:0 1px 1px rgba(255,255,255,0.75);background-color:#f5f5f5;background-image:-moz-linear-gradient(top, #fff, #e6e6e6);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#fff), to(#e6e6e6));background-image:-webkit-linear-gradient(top, #fff, #e6e6e6);background-image:-o-linear-gradient(top, #fff, #e6e6e6);background-image:linear-gradient(to bottom, #fff, #e6e6e6);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff', endColorstr='#ffe6e6e6', GradientType=0);border-color:#e6e6e6 #e6e6e6 #bfbfbf;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);*background-color:#e6e6e6;filter:progid:DXImageTransform.Microsoft.gradient(enabled = false);border:1px
solid #ccc;*border:0;border-bottom-color:#b3b3b3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;*margin-left:.3em;-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05);-moz-box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05);box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05)}.btn:hover,.btn:focus,.btn:active,.btn.active,.btn.disabled,.btn[disabled]{color:#333;background-color:#e6e6e6;*background-color:#d9d9d9}.btn:active,.btn.active{background-color:#ccc \9}.btn:first-child{*margin-left:0}.btn:hover,.btn:focus{color:#333;text-decoration:none;background-position:0 -15px;-webkit-transition:background-position .1s linear;-moz-transition:background-position .1s linear;-o-transition:background-position .1s linear;transition:background-position .1s linear}.btn:focus{outline:thin dotted #333;outline:5px
auto -webkit-focus-ring-color;outline-offset:-2px}.btn.active,.btn:active{background-image:none;outline:0;-webkit-box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05);-moz-box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05);box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05)}.btn.disabled,.btn[disabled]{cursor:default;background-image:none;opacity:.65;filter:alpha(opacity=65);-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}.btn-large{padding:11px
19px;font-size:17.5px;-webkit-border-radius:6px;-moz-border-radius:6px;border-radius:6px}.btn-large [class^="icon-"],.btn-large [class*=" icon-"]{margin-top:4px}.btn-small{padding:2px
10px;font-size:11.9px;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.btn-small [class^="icon-"],.btn-small [class*=" icon-"]{margin-top:0}.btn-mini [class^="icon-"],.btn-mini [class*=" icon-"]{margin-top:-1px}.btn-mini{padding:0
6px;font-size:10.5px;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.btn-block{display:block;width:100%;padding-left:0;padding-right:0;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.btn-block+.btn-block{margin-top:5px}input[type="submit"].btn-block,input[type="reset"].btn-block,input[type="button"].btn-block{width:100%}.btn-primary.active,.btn-warning.active,.btn-danger.active,.btn-success.active,.btn-info.active,.btn-inverse.active{color:rgba(255,255,255,0.75)}.btn-primary{color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#005aa8;background-image:-moz-linear-gradient(top, #0070a8, #0038a8);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#0070a8), to(#0038a8));background-image:-webkit-linear-gradient(top, #0070a8, #0038a8);background-image:-o-linear-gradient(top, #0070a8, #0038a8);background-image:linear-gradient(to bottom, #0070a8, #0038a8);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff0070a8', endColorstr='#ff0038a8', GradientType=0);border-color:#0038a8 #0038a8 #001e5c;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);*background-color:#0038a8;filter:progid:DXImageTransform.Microsoft.gradient(enabled = false)}.btn-primary:hover,.btn-primary:focus,.btn-primary:active,.btn-primary.active,.btn-primary.disabled,.btn-primary[disabled]{color:#fff;background-color:#0038a8;*background-color:#002f8f}.btn-primary:active,.btn-primary.active{background-color:#002775 \9}.btn-warning{color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#faa732;background-image:-moz-linear-gradient(top, #fbb450, #f89406);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#fbb450), to(#f89406));background-image:-webkit-linear-gradient(top, #fbb450, #f89406);background-image:-o-linear-gradient(top, #fbb450, #f89406);background-image:linear-gradient(to bottom, #fbb450, #f89406);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#fffbb450', endColorstr='#fff89406', GradientType=0);border-color:#f89406 #f89406 #ad6704;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);*background-color:#f89406;filter:progid:DXImageTransform.Microsoft.gradient(enabled = false)}.btn-warning:hover,.btn-warning:focus,.btn-warning:active,.btn-warning.active,.btn-warning.disabled,.btn-warning[disabled]{color:#fff;background-color:#f89406;*background-color:#df8505}.btn-warning:active,.btn-warning.active{background-color:#c67605 \9}.btn-danger{color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#da4f49;background-image:-moz-linear-gradient(top, #ee5f5b, #bd362f);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#ee5f5b), to(#bd362f));background-image:-webkit-linear-gradient(top, #ee5f5b, #bd362f);background-image:-o-linear-gradient(top, #ee5f5b, #bd362f);background-image:linear-gradient(to bottom, #ee5f5b, #bd362f);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffee5f5b', endColorstr='#ffbd362f', GradientType=0);border-color:#bd362f #bd362f #802420;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);*background-color:#bd362f;filter:progid:DXImageTransform.Microsoft.gradient(enabled = false)}.btn-danger:hover,.btn-danger:focus,.btn-danger:active,.btn-danger.active,.btn-danger.disabled,.btn-danger[disabled]{color:#fff;background-color:#bd362f;*background-color:#a9302a}.btn-danger:active,.btn-danger.active{background-color:#942a25 \9}.btn-success{color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#5bb75b;background-image:-moz-linear-gradient(top, #62c462, #51a351);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#62c462), to(#51a351));background-image:-webkit-linear-gradient(top, #62c462, #51a351);background-image:-o-linear-gradient(top, #62c462, #51a351);background-image:linear-gradient(to bottom, #62c462, #51a351);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff62c462', endColorstr='#ff51a351', GradientType=0);border-color:#51a351 #51a351 #387038;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);*background-color:#51a351;filter:progid:DXImageTransform.Microsoft.gradient(enabled = false)}.btn-success:hover,.btn-success:focus,.btn-success:active,.btn-success.active,.btn-success.disabled,.btn-success[disabled]{color:#fff;background-color:#51a351;*background-color:#499249}.btn-success:active,.btn-success.active{background-color:#408140 \9}.btn-info{color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#49afcd;background-image:-moz-linear-gradient(top, #5bc0de, #2f96b4);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#5bc0de), to(#2f96b4));background-image:-webkit-linear-gradient(top, #5bc0de, #2f96b4);background-image:-o-linear-gradient(top, #5bc0de, #2f96b4);background-image:linear-gradient(to bottom, #5bc0de, #2f96b4);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff5bc0de', endColorstr='#ff2f96b4', GradientType=0);border-color:#2f96b4 #2f96b4 #1f6377;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);*background-color:#2f96b4;filter:progid:DXImageTransform.Microsoft.gradient(enabled = false)}.btn-info:hover,.btn-info:focus,.btn-info:active,.btn-info.active,.btn-info.disabled,.btn-info[disabled]{color:#fff;background-color:#2f96b4;*background-color:#2a85a0}.btn-info:active,.btn-info.active{background-color:#24748c \9}.btn-inverse{color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#363636;background-image:-moz-linear-gradient(top, #444, #222);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#444), to(#222));background-image:-webkit-linear-gradient(top, #444, #222);background-image:-o-linear-gradient(top, #444, #222);background-image:linear-gradient(to bottom, #444, #222);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff444444', endColorstr='#ff222222', GradientType=0);border-color:#222 #222 #000;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);*background-color:#222;filter:progid:DXImageTransform.Microsoft.gradient(enabled = false)}.btn-inverse:hover,.btn-inverse:focus,.btn-inverse:active,.btn-inverse.active,.btn-inverse.disabled,.btn-inverse[disabled]{color:#fff;background-color:#222;*background-color:#151515}.btn-inverse:active,.btn-inverse.active{background-color:#080808 \9}button.btn,input[type="submit"].btn{*padding-top:3px;*padding-bottom:3px}button.btn::-moz-focus-inner,input[type="submit"].btn::-moz-focus-inner{padding:0;border:0}button.btn.btn-large,input[type="submit"].btn.btn-large{*padding-top:7px;*padding-bottom:7px}button.btn.btn-small,input[type="submit"].btn.btn-small{*padding-top:3px;*padding-bottom:3px}button.btn.btn-mini,input[type="submit"].btn.btn-mini{*padding-top:1px;*padding-bottom:1px}.btn-link,.btn-link:active,.btn-link[disabled]{background-color:transparent;background-image:none;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}.btn-link{border-color:transparent;cursor:pointer;color:#0070a8;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.btn-link:hover,.btn-link:focus{color:#003d5c;text-decoration:underline;background-color:transparent}.btn-link[disabled]:hover,.btn-link[disabled]:focus{color:#333;text-decoration:none}.btn-group{position:relative;display:inline-block;*display:inline;*zoom:1;font-size:0;vertical-align:middle;white-space:nowrap;*margin-left:.3em}.btn-group:first-child{*margin-left:0}.btn-group+.btn-group{margin-left:5px}.btn-toolbar{font-size:0;margin-top:10px;margin-bottom:10px}.btn-toolbar>.btn+.btn,.btn-toolbar>.btn-group+.btn,.btn-toolbar>.btn+.btn-group{margin-left:5px}.btn-group>.btn{position:relative;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.btn-group>.btn+.btn{margin-left:-1px}.btn-group>.btn,.btn-group>.dropdown-menu,.btn-group>.popover{font-size:14px}.btn-group>.btn-mini{font-size:10.5px}.btn-group>.btn-small{font-size:11.9px}.btn-group>.btn-large{font-size:17.5px}.btn-group>.btn:first-child{margin-left:0;-webkit-border-top-left-radius:4px;-moz-border-radius-topleft:4px;border-top-left-radius:4px;-webkit-border-bottom-left-radius:4px;-moz-border-radius-bottomleft:4px;border-bottom-left-radius:4px}.btn-group>.btn:last-child,.btn-group>.dropdown-toggle{-webkit-border-top-right-radius:4px;-moz-border-radius-topright:4px;border-top-right-radius:4px;-webkit-border-bottom-right-radius:4px;-moz-border-radius-bottomright:4px;border-bottom-right-radius:4px}.btn-group>.btn.large:first-child{margin-left:0;-webkit-border-top-left-radius:6px;-moz-border-radius-topleft:6px;border-top-left-radius:6px;-webkit-border-bottom-left-radius:6px;-moz-border-radius-bottomleft:6px;border-bottom-left-radius:6px}.btn-group>.btn.large:last-child,.btn-group>.large.dropdown-toggle{-webkit-border-top-right-radius:6px;-moz-border-radius-topright:6px;border-top-right-radius:6px;-webkit-border-bottom-right-radius:6px;-moz-border-radius-bottomright:6px;border-bottom-right-radius:6px}.btn-group>.btn:hover,.btn-group>.btn:focus,.btn-group>.btn:active,.btn-group>.btn.active{z-index:2}.btn-group .dropdown-toggle:active,.btn-group.open .dropdown-toggle{outline:0}.btn-group>.btn+.dropdown-toggle{padding-left:8px;padding-right:8px;-webkit-box-shadow:inset 1px 0 0 rgba(255,255,255,.125), inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05);-moz-box-shadow:inset 1px 0 0 rgba(255,255,255,.125), inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05);box-shadow:inset 1px 0 0 rgba(255,255,255,.125), inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05);*padding-top:5px;*padding-bottom:5px}.btn-group>.btn-mini+.dropdown-toggle{padding-left:5px;padding-right:5px;*padding-top:2px;*padding-bottom:2px}.btn-group>.btn-small+.dropdown-toggle{*padding-top:5px;*padding-bottom:4px}.btn-group>.btn-large+.dropdown-toggle{padding-left:12px;padding-right:12px;*padding-top:7px;*padding-bottom:7px}.btn-group.open .dropdown-toggle{background-image:none;-webkit-box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05);-moz-box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05);box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05)}.btn-group.open .btn.dropdown-toggle{background-color:#e6e6e6}.btn-group.open .btn-primary.dropdown-toggle{background-color:#0038a8}.btn-group.open .btn-warning.dropdown-toggle{background-color:#f89406}.btn-group.open .btn-danger.dropdown-toggle{background-color:#bd362f}.btn-group.open .btn-success.dropdown-toggle{background-color:#51a351}.btn-group.open .btn-info.dropdown-toggle{background-color:#2f96b4}.btn-group.open .btn-inverse.dropdown-toggle{background-color:#222}.btn
.caret{margin-top:8px;margin-left:0}.btn-large
.caret{margin-top:6px}.btn-large
.caret{border-left-width:5px;border-right-width:5px;border-top-width:5px}.btn-mini .caret,.btn-small
.caret{margin-top:8px}.dropup .btn-large
.caret{border-bottom-width:5px}.btn-primary .caret,.btn-warning .caret,.btn-danger .caret,.btn-info .caret,.btn-success .caret,.btn-inverse
.caret{border-top-color:#fff;border-bottom-color:#fff}.btn-group-vertical{display:inline-block;*display:inline;*zoom:1}.btn-group-vertical>.btn{display:block;float:none;max-width:100%;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.btn-group-vertical>.btn+.btn{margin-left:0;margin-top:-1px}.btn-group-vertical>.btn:first-child{-webkit-border-radius:4px 4px 0 0;-moz-border-radius:4px 4px 0 0;border-radius:4px 4px 0 0}.btn-group-vertical>.btn:last-child{-webkit-border-radius:0 0 4px 4px;-moz-border-radius:0 0 4px 4px;border-radius:0 0 4px 4px}.btn-group-vertical>.btn-large:first-child{-webkit-border-radius:6px 6px 0 0;-moz-border-radius:6px 6px 0 0;border-radius:6px 6px 0 0}.btn-group-vertical>.btn-large:last-child{-webkit-border-radius:0 0 6px 6px;-moz-border-radius:0 0 6px 6px;border-radius:0 0 6px 6px}.alert{padding:8px
35px 8px 14px;margin-bottom:20px;text-shadow:0 1px 0 rgba(255,255,255,0.5);background-color:#fcf8e3;border:1px
solid #fbeed5;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.alert,.alert
h4{color:#8a6d3b}.alert
h4{margin:0}.alert
.close{position:relative;top:-2px;right:-21px;line-height:20px}.alert-success{background-color:#dff0d8;border-color:#d6e9c6;color:#468847}.alert-success
h4{color:#468847}.alert-danger,.alert-error{background-color:#f2dede;border-color:#eed3d7;color:#b94a48}.alert-danger h4,.alert-error
h4{color:#b94a48}.alert-info{background-color:#d9edf7;border-color:#bce8f1;color:#3a87ad}.alert-info
h4{color:#3a87ad}.alert-block{padding-top:14px;padding-bottom:14px}.alert-block>p,.alert-block>ul{margin-bottom:0}.alert-block p+p{margin-top:5px}.nav{margin-left:0;margin-bottom:20px;list-style:none}.nav>li>a{display:block}.nav>li>a:hover,.nav>li>a:focus{text-decoration:none;background-color:#eee}.nav>li>a>img{max-width:none}.nav>.pull-right{float:right}.nav-header{display:block;padding:3px
15px;font-size:11px;font-weight:bold;line-height:20px;color:#999;text-shadow:0 1px 0 rgba(255,255,255,0.5);text-transform:uppercase}.nav li+.nav-header{margin-top:9px}.nav-list{padding-left:15px;padding-right:15px;margin-bottom:0}.nav-list>li>a,.nav-list .nav-header{margin-left:-15px;margin-right:-15px;text-shadow:0 1px 0 rgba(255,255,255,0.5)}.nav-list>li>a{padding:3px
15px}.nav-list>.active>a,.nav-list>.active>a:hover,.nav-list>.active>a:focus{color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.2);background-color:#0070a8}.nav-list [class^="icon-"],.nav-list [class*=" icon-"]{margin-right:2px}.nav-list
.divider{*width:100%;height:1px;margin:9px
1px;*margin:-5px 0 5px;overflow:hidden;background-color:#e5e5e5;border-bottom:1px solid #fff}.nav-tabs,.nav-pills{*zoom:1}.nav-tabs:before,.nav-pills:before,.nav-tabs:after,.nav-pills:after{display:table;content:"";line-height:0}.nav-tabs:after,.nav-pills:after{clear:both}.nav-tabs>li,.nav-pills>li{float:left}.nav-tabs>li>a,.nav-pills>li>a{padding-right:12px;padding-left:12px;margin-right:2px;line-height:14px}.nav-tabs{border-bottom:1px solid #ddd}.nav-tabs>li{margin-bottom:-1px}.nav-tabs>li>a{padding-top:8px;padding-bottom:8px;line-height:20px;border:1px
solid transparent;-webkit-border-radius:4px 4px 0 0;-moz-border-radius:4px 4px 0 0;border-radius:4px 4px 0 0}.nav-tabs>li>a:hover,.nav-tabs>li>a:focus{border-color:#eee #eee #ddd}.nav-tabs>.active>a,.nav-tabs>.active>a:hover,.nav-tabs>.active>a:focus{color:#555;background-color:#fff;border:1px
solid #ddd;border-bottom-color:transparent;cursor:default}.nav-pills>li>a{padding-top:8px;padding-bottom:8px;margin-top:2px;margin-bottom:2px;-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px}.nav-pills>.active>a,.nav-pills>.active>a:hover,.nav-pills>.active>a:focus{color:#fff;background-color:#0070a8}.nav-stacked>li{float:none}.nav-stacked>li>a{margin-right:0}.nav-tabs.nav-stacked{border-bottom:0}.nav-tabs.nav-stacked>li>a{border:1px
solid #ddd;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.nav-tabs.nav-stacked>li:first-child>a{-webkit-border-top-right-radius:4px;-moz-border-radius-topright:4px;border-top-right-radius:4px;-webkit-border-top-left-radius:4px;-moz-border-radius-topleft:4px;border-top-left-radius:4px}.nav-tabs.nav-stacked>li:last-child>a{-webkit-border-bottom-right-radius:4px;-moz-border-radius-bottomright:4px;border-bottom-right-radius:4px;-webkit-border-bottom-left-radius:4px;-moz-border-radius-bottomleft:4px;border-bottom-left-radius:4px}.nav-tabs.nav-stacked>li>a:hover,.nav-tabs.nav-stacked>li>a:focus{border-color:#ddd;z-index:2}.nav-pills.nav-stacked>li>a{margin-bottom:3px}.nav-pills.nav-stacked>li:last-child>a{margin-bottom:1px}.nav-tabs .dropdown-menu{-webkit-border-radius:0 0 6px 6px;-moz-border-radius:0 0 6px 6px;border-radius:0 0 6px 6px}.nav-pills .dropdown-menu{-webkit-border-radius:6px;-moz-border-radius:6px;border-radius:6px}.nav .dropdown-toggle
.caret{border-top-color:#0070a8;border-bottom-color:#0070a8;margin-top:6px}.nav .dropdown-toggle:hover .caret,.nav .dropdown-toggle:focus
.caret{border-top-color:#003d5c;border-bottom-color:#003d5c}.nav-tabs .dropdown-toggle
.caret{margin-top:8px}.nav .active .dropdown-toggle
.caret{border-top-color:#fff;border-bottom-color:#fff}.nav-tabs .active .dropdown-toggle
.caret{border-top-color:#555;border-bottom-color:#555}.nav>.dropdown.active>a:hover,.nav>.dropdown.active>a:focus{cursor:pointer}.nav-tabs .open .dropdown-toggle,.nav-pills .open .dropdown-toggle,.nav>li.dropdown.open.active>a:hover,.nav>li.dropdown.open.active>a:focus{color:#fff;background-color:#999;border-color:#999}.nav li.dropdown.open .caret,.nav li.dropdown.open.active .caret,.nav li.dropdown.open a:hover .caret,.nav li.dropdown.open a:focus
.caret{border-top-color:#fff;border-bottom-color:#fff;opacity:1;filter:alpha(opacity=100)}.tabs-stacked .open>a:hover,.tabs-stacked .open>a:focus{border-color:#999}.tabbable{*zoom:1}.tabbable:before,.tabbable:after{display:table;content:"";line-height:0}.tabbable:after{clear:both}.tab-content{overflow:auto}.tabs-below>.nav-tabs,.tabs-right>.nav-tabs,.tabs-left>.nav-tabs{border-bottom:0}.tab-content>.tab-pane,.pill-content>.pill-pane{display:none}.tab-content>.active,.pill-content>.active{display:block}.tabs-below>.nav-tabs{border-top:1px solid #ddd}.tabs-below>.nav-tabs>li{margin-top:-1px;margin-bottom:0}.tabs-below>.nav-tabs>li>a{-webkit-border-radius:0 0 4px 4px;-moz-border-radius:0 0 4px 4px;border-radius:0 0 4px 4px}.tabs-below>.nav-tabs>li>a:hover,.tabs-below>.nav-tabs>li>a:focus{border-bottom-color:transparent;border-top-color:#ddd}.tabs-below>.nav-tabs>.active>a,.tabs-below>.nav-tabs>.active>a:hover,.tabs-below>.nav-tabs>.active>a:focus{border-color:transparent #ddd #ddd #ddd}.tabs-left>.nav-tabs>li,.tabs-right>.nav-tabs>li{float:none}.tabs-left>.nav-tabs>li>a,.tabs-right>.nav-tabs>li>a{min-width:74px;margin-right:0;margin-bottom:3px}.tabs-left>.nav-tabs{float:left;margin-right:19px;border-right:1px solid #ddd}.tabs-left>.nav-tabs>li>a{margin-right:-1px;-webkit-border-radius:4px 0 0 4px;-moz-border-radius:4px 0 0 4px;border-radius:4px 0 0 4px}.tabs-left>.nav-tabs>li>a:hover,.tabs-left>.nav-tabs>li>a:focus{border-color:#eee #ddd #eee #eee}.tabs-left>.nav-tabs .active>a,.tabs-left>.nav-tabs .active>a:hover,.tabs-left>.nav-tabs .active>a:focus{border-color:#ddd transparent #ddd #ddd;*border-right-color:#fff}.tabs-right>.nav-tabs{float:right;margin-left:19px;border-left:1px solid #ddd}.tabs-right>.nav-tabs>li>a{margin-left:-1px;-webkit-border-radius:0 4px 4px 0;-moz-border-radius:0 4px 4px 0;border-radius:0 4px 4px 0}.tabs-right>.nav-tabs>li>a:hover,.tabs-right>.nav-tabs>li>a:focus{border-color:#eee #eee #eee #ddd}.tabs-right>.nav-tabs .active>a,.tabs-right>.nav-tabs .active>a:hover,.tabs-right>.nav-tabs .active>a:focus{border-color:#ddd #ddd #ddd transparent;*border-left-color:#fff}.nav>.disabled>a{color:#999}.nav>.disabled>a:hover,.nav>.disabled>a:focus{text-decoration:none;background-color:transparent;cursor:default}.navbar{overflow:visible;margin-bottom:20px;*position:relative;*z-index:2}.navbar-inner{min-height:40px;padding-left:20px;padding-right:20px;background-color:#fafafa;background-image:-moz-linear-gradient(top, #ffffff, #f2f2f2);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#ffffff), to(#f2f2f2));background-image:-webkit-linear-gradient(top, #ffffff, #f2f2f2);background-image:-o-linear-gradient(top, #ffffff, #f2f2f2);background-image:linear-gradient(to bottom, #ffffff, #f2f2f2);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff', endColorstr='#fff2f2f2', GradientType=0);border:1px
solid #d4d4d4;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:0 1px 4px rgba(0,0,0,0.065);-moz-box-shadow:0 1px 4px rgba(0,0,0,0.065);box-shadow:0 1px 4px rgba(0,0,0,0.065);*zoom:1}.navbar-inner:before,.navbar-inner:after{display:table;content:"";line-height:0}.navbar-inner:after{clear:both}.navbar
.container{width:auto}.nav-collapse.collapse{height:auto;overflow:visible}.navbar
.brand{float:left;display:block;padding:10px
20px 10px;margin-left:-20px;font-size:20px;font-weight:200;color:#777;text-shadow:0 1px 0 #fff}.navbar .brand:hover,.navbar .brand:focus{text-decoration:none}.navbar-text{margin-bottom:0;line-height:40px;color:#777}.navbar-link{color:#777}.navbar-link:hover,.navbar-link:focus{color:#333}.navbar .divider-vertical{height:40px;margin:0
9px;border-left:1px solid #f2f2f2;border-right:1px solid #fff}.navbar .btn,.navbar .btn-group{margin-top:5px}.navbar .btn-group .btn,.navbar .input-prepend .btn,.navbar .input-append .btn,.navbar .input-prepend .btn-group,.navbar .input-append .btn-group{margin-top:0}.navbar-form{margin-bottom:0;*zoom:1}.navbar-form:before,.navbar-form:after{display:table;content:"";line-height:0}.navbar-form:after{clear:both}.navbar-form input,.navbar-form select,.navbar-form .radio,.navbar-form
.checkbox{margin-top:5px}.navbar-form input,.navbar-form select,.navbar-form
.btn{display:inline-block;margin-bottom:0}.navbar-form input[type="image"],.navbar-form input[type="checkbox"],.navbar-form input[type="radio"]{margin-top:3px}.navbar-form .input-append,.navbar-form .input-prepend{margin-top:5px;white-space:nowrap}.navbar-form .input-append input,.navbar-form .input-prepend
input{margin-top:0}.navbar-search{position:relative;float:left;margin-top:5px;margin-bottom:0}.navbar-search .search-query{margin-bottom:0;padding:4px
14px;font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;font-size:13px;font-weight:normal;line-height:1;-webkit-border-radius:15px;-moz-border-radius:15px;border-radius:15px}.navbar-static-top{position:static;margin-bottom:0}.navbar-static-top .navbar-inner{-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.navbar-fixed-top,.navbar-fixed-bottom{position:fixed;right:0;left:0;z-index:1030;margin-bottom:0}.navbar-fixed-top .navbar-inner,.navbar-static-top .navbar-inner{border-width:0 0 1px}.navbar-fixed-bottom .navbar-inner{border-width:1px 0 0}.navbar-fixed-top .navbar-inner,.navbar-fixed-bottom .navbar-inner{padding-left:0;padding-right:0;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.navbar-static-top .container,.navbar-fixed-top .container,.navbar-fixed-bottom
.container{width:940px}.navbar-fixed-top{top:0}.navbar-fixed-top .navbar-inner,.navbar-static-top .navbar-inner{-webkit-box-shadow:0 1px 10px rgba(0,0,0,.1);-moz-box-shadow:0 1px 10px rgba(0,0,0,.1);box-shadow:0 1px 10px rgba(0,0,0,.1)}.navbar-fixed-bottom{bottom:0}.navbar-fixed-bottom .navbar-inner{-webkit-box-shadow:0 -1px 10px rgba(0,0,0,.1);-moz-box-shadow:0 -1px 10px rgba(0,0,0,.1);box-shadow:0 -1px 10px rgba(0,0,0,.1)}.navbar
.nav{position:relative;left:0;display:block;float:left;margin:0
10px 0 0}.navbar .nav.pull-right{float:right;margin-right:0}.navbar .nav>li{float:left}.navbar .nav>li>a{float:none;padding:10px
15px 10px;color:#777;text-decoration:none;text-shadow:0 1px 0 #fff}.navbar .nav .dropdown-toggle
.caret{margin-top:8px}.navbar .nav>li>a:focus,.navbar .nav>li>a:hover{background-color:transparent;color:#333;text-decoration:none}.navbar .nav>.active>a,.navbar .nav>.active>a:hover,.navbar .nav>.active>a:focus{color:#555;text-decoration:none;background-color:#e5e5e5;-webkit-box-shadow:inset 0 3px 8px rgba(0,0,0,0.125);-moz-box-shadow:inset 0 3px 8px rgba(0,0,0,0.125);box-shadow:inset 0 3px 8px rgba(0,0,0,0.125)}.navbar .btn-navbar{display:none;float:right;padding:7px
10px;margin-left:5px;margin-right:5px;color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#ededed;background-image:-moz-linear-gradient(top, #f2f2f2, #e5e5e5);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#f2f2f2), to(#e5e5e5));background-image:-webkit-linear-gradient(top, #f2f2f2, #e5e5e5);background-image:-o-linear-gradient(top, #f2f2f2, #e5e5e5);background-image:linear-gradient(to bottom, #f2f2f2, #e5e5e5);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#fff2f2f2', endColorstr='#ffe5e5e5', GradientType=0);border-color:#e5e5e5 #e5e5e5 #bfbfbf;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);*background-color:#e5e5e5;filter:progid:DXImageTransform.Microsoft.gradient(enabled = false);-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,.1), 0 1px 0 rgba(255,255,255,.075);-moz-box-shadow:inset 0 1px 0 rgba(255,255,255,.1), 0 1px 0 rgba(255,255,255,.075);box-shadow:inset 0 1px 0 rgba(255,255,255,.1), 0 1px 0 rgba(255,255,255,.075)}.navbar .btn-navbar:hover,.navbar .btn-navbar:focus,.navbar .btn-navbar:active,.navbar .btn-navbar.active,.navbar .btn-navbar.disabled,.navbar .btn-navbar[disabled]{color:#fff;background-color:#e5e5e5;*background-color:#d9d9d9}.navbar .btn-navbar:active,.navbar .btn-navbar.active{background-color:#ccc \9}.navbar .btn-navbar .icon-bar{display:block;width:18px;height:2px;background-color:#f5f5f5;-webkit-border-radius:1px;-moz-border-radius:1px;border-radius:1px;-webkit-box-shadow:0 1px 0 rgba(0,0,0,0.25);-moz-box-shadow:0 1px 0 rgba(0,0,0,0.25);box-shadow:0 1px 0 rgba(0,0,0,0.25)}.btn-navbar .icon-bar+.icon-bar{margin-top:3px}.navbar .nav>li>.dropdown-menu:before{content:'';display:inline-block;border-left:7px solid transparent;border-right:7px solid transparent;border-bottom:7px solid #ccc;border-bottom-color:rgba(0,0,0,0.2);position:absolute;top:-7px;left:9px}.navbar .nav>li>.dropdown-menu:after{content:'';display:inline-block;border-left:6px solid transparent;border-right:6px solid transparent;border-bottom:6px solid #fff;position:absolute;top:-6px;left:10px}.navbar-fixed-bottom .nav>li>.dropdown-menu:before{border-top:7px solid #ccc;border-top-color:rgba(0,0,0,0.2);border-bottom:0;bottom:-7px;top:auto}.navbar-fixed-bottom .nav>li>.dropdown-menu:after{border-top:6px solid #fff;border-bottom:0;bottom:-6px;top:auto}.navbar .nav li.dropdown>a:hover .caret,.navbar .nav li.dropdown>a:focus
.caret{border-top-color:#333;border-bottom-color:#333}.navbar .nav li.dropdown.open>.dropdown-toggle,.navbar .nav li.dropdown.active>.dropdown-toggle,.navbar .nav li.dropdown.open.active>.dropdown-toggle{background-color:#e5e5e5;color:#555}.navbar .nav li.dropdown>.dropdown-toggle
.caret{border-top-color:#777;border-bottom-color:#777}.navbar .nav li.dropdown.open>.dropdown-toggle .caret,.navbar .nav li.dropdown.active>.dropdown-toggle .caret,.navbar .nav li.dropdown.open.active>.dropdown-toggle
.caret{border-top-color:#555;border-bottom-color:#555}.navbar .pull-right>li>.dropdown-menu,.navbar .nav>li>.dropdown-menu.pull-right{left:auto;right:0}.navbar .pull-right>li>.dropdown-menu:before,.navbar .nav>li>.dropdown-menu.pull-right:before{left:auto;right:12px}.navbar .pull-right>li>.dropdown-menu:after,.navbar .nav>li>.dropdown-menu.pull-right:after{left:auto;right:13px}.navbar .pull-right>li>.dropdown-menu .dropdown-menu,.navbar .nav>li>.dropdown-menu.pull-right .dropdown-menu{left:auto;right:100%;margin-left:0;margin-right:-1px;-webkit-border-radius:6px 0 6px 6px;-moz-border-radius:6px 0 6px 6px;border-radius:6px 0 6px 6px}.navbar-inverse .navbar-inner{background-color:#1b1b1b;background-image:-moz-linear-gradient(top, #222222, #111111);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#222222), to(#111111));background-image:-webkit-linear-gradient(top, #222222, #111111);background-image:-o-linear-gradient(top, #222222, #111111);background-image:linear-gradient(to bottom, #222222, #111111);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff222222', endColorstr='#ff111111', GradientType=0);border-color:#252525}.navbar-inverse .brand,.navbar-inverse .nav>li>a{color:#999;text-shadow:0 -1px 0 rgba(0,0,0,0.25)}.navbar-inverse .brand:hover,.navbar-inverse .nav>li>a:hover,.navbar-inverse .brand:focus,.navbar-inverse .nav>li>a:focus{color:#fff}.navbar-inverse
.brand{color:#999}.navbar-inverse .navbar-text{color:#999}.navbar-inverse .nav>li>a:focus,.navbar-inverse .nav>li>a:hover{background-color:transparent;color:#fff}.navbar-inverse .nav .active>a,.navbar-inverse .nav .active>a:hover,.navbar-inverse .nav .active>a:focus{color:#fff;background-color:#111}.navbar-inverse .navbar-link{color:#999}.navbar-inverse .navbar-link:hover,.navbar-inverse .navbar-link:focus{color:#fff}.navbar-inverse .divider-vertical{border-left-color:#111;border-right-color:#222}.navbar-inverse .nav li.dropdown.open>.dropdown-toggle,.navbar-inverse .nav li.dropdown.active>.dropdown-toggle,.navbar-inverse .nav li.dropdown.open.active>.dropdown-toggle{background-color:#111;color:#fff}.navbar-inverse .nav li.dropdown>a:hover .caret,.navbar-inverse .nav li.dropdown>a:focus
.caret{border-top-color:#fff;border-bottom-color:#fff}.navbar-inverse .nav li.dropdown>.dropdown-toggle
.caret{border-top-color:#999;border-bottom-color:#999}.navbar-inverse .nav li.dropdown.open>.dropdown-toggle .caret,.navbar-inverse .nav li.dropdown.active>.dropdown-toggle .caret,.navbar-inverse .nav li.dropdown.open.active>.dropdown-toggle
.caret{border-top-color:#fff;border-bottom-color:#fff}.navbar-inverse .navbar-search .search-query{color:#fff;background-color:#515151;border-color:#111;-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,.1), 0 1px 0 rgba(255,255,255,.15);-moz-box-shadow:inset 0 1px 2px rgba(0,0,0,.1), 0 1px 0 rgba(255,255,255,.15);box-shadow:inset 0 1px 2px rgba(0,0,0,.1), 0 1px 0 rgba(255,255,255,.15);-webkit-transition:none;-moz-transition:none;-o-transition:none;transition:none}.navbar-inverse .navbar-search .search-query:-moz-placeholder{color:#ccc}.navbar-inverse .navbar-search .search-query:-ms-input-placeholder{color:#ccc}.navbar-inverse .navbar-search .search-query::-webkit-input-placeholder{color:#ccc}.navbar-inverse .navbar-search .search-query:focus,.navbar-inverse .navbar-search .search-query.focused{padding:5px
15px;color:#333;text-shadow:0 1px 0 #fff;background-color:#fff;border:0;-webkit-box-shadow:0 0 3px rgba(0,0,0,0.15);-moz-box-shadow:0 0 3px rgba(0,0,0,0.15);box-shadow:0 0 3px rgba(0,0,0,0.15);outline:0}.navbar-inverse .btn-navbar{color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#0e0e0e;background-image:-moz-linear-gradient(top, #151515, #040404);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#151515), to(#040404));background-image:-webkit-linear-gradient(top, #151515, #040404);background-image:-o-linear-gradient(top, #151515, #040404);background-image:linear-gradient(to bottom, #151515, #040404);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff151515', endColorstr='#ff040404', GradientType=0);border-color:#040404 #040404 #000;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);*background-color:#040404;filter:progid:DXImageTransform.Microsoft.gradient(enabled = false)}.navbar-inverse .btn-navbar:hover,.navbar-inverse .btn-navbar:focus,.navbar-inverse .btn-navbar:active,.navbar-inverse .btn-navbar.active,.navbar-inverse .btn-navbar.disabled,.navbar-inverse .btn-navbar[disabled]{color:#fff;background-color:#040404;*background-color:#000}.navbar-inverse .btn-navbar:active,.navbar-inverse .btn-navbar.active{background-color:#000 \9}.breadcrumb{padding:8px
15px;margin:0
0 20px;list-style:none;background-color:#f5f5f5;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.breadcrumb>li{display:inline-block;*display:inline;*zoom:1;text-shadow:0 1px 0 #fff}.breadcrumb>li>.divider{padding:0
5px;color:#ccc}.breadcrumb>.active{color:#999}.pagination{margin:20px
0}.pagination
ul{display:inline-block;*display:inline;*zoom:1;margin-left:0;margin-bottom:0;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:0 1px 2px rgba(0,0,0,0.05);-moz-box-shadow:0 1px 2px rgba(0,0,0,0.05);box-shadow:0 1px 2px rgba(0,0,0,0.05)}.pagination ul>li{display:inline}.pagination ul>li>a,.pagination ul>li>span{float:left;padding:4px
12px;line-height:20px;text-decoration:none;background-color:#fff;border:1px
solid #ddd;border-left-width:0}.pagination ul>li>a:hover,.pagination ul>li>a:focus,.pagination ul>.active>a,.pagination ul>.active>span{background-color:#f5f5f5}.pagination ul>.active>a,.pagination ul>.active>span{color:#999;cursor:default}.pagination ul>.disabled>span,.pagination ul>.disabled>a,.pagination ul>.disabled>a:hover,.pagination ul>.disabled>a:focus{color:#999;background-color:transparent;cursor:default}.pagination ul>li:first-child>a,.pagination ul>li:first-child>span{border-left-width:1px;-webkit-border-top-left-radius:4px;-moz-border-radius-topleft:4px;border-top-left-radius:4px;-webkit-border-bottom-left-radius:4px;-moz-border-radius-bottomleft:4px;border-bottom-left-radius:4px}.pagination ul>li:last-child>a,.pagination ul>li:last-child>span{-webkit-border-top-right-radius:4px;-moz-border-radius-topright:4px;border-top-right-radius:4px;-webkit-border-bottom-right-radius:4px;-moz-border-radius-bottomright:4px;border-bottom-right-radius:4px}.pagination-centered{text-align:center}.pagination-right{text-align:right}.pagination-large ul>li>a,.pagination-large ul>li>span{padding:11px
19px;font-size:17.5px}.pagination-large ul>li:first-child>a,.pagination-large ul>li:first-child>span{-webkit-border-top-left-radius:6px;-moz-border-radius-topleft:6px;border-top-left-radius:6px;-webkit-border-bottom-left-radius:6px;-moz-border-radius-bottomleft:6px;border-bottom-left-radius:6px}.pagination-large ul>li:last-child>a,.pagination-large ul>li:last-child>span{-webkit-border-top-right-radius:6px;-moz-border-radius-topright:6px;border-top-right-radius:6px;-webkit-border-bottom-right-radius:6px;-moz-border-radius-bottomright:6px;border-bottom-right-radius:6px}.pagination-mini ul>li:first-child>a,.pagination-small ul>li:first-child>a,.pagination-mini ul>li:first-child>span,.pagination-small ul>li:first-child>span{-webkit-border-top-left-radius:3px;-moz-border-radius-topleft:3px;border-top-left-radius:3px;-webkit-border-bottom-left-radius:3px;-moz-border-radius-bottomleft:3px;border-bottom-left-radius:3px}.pagination-mini ul>li:last-child>a,.pagination-small ul>li:last-child>a,.pagination-mini ul>li:last-child>span,.pagination-small ul>li:last-child>span{-webkit-border-top-right-radius:3px;-moz-border-radius-topright:3px;border-top-right-radius:3px;-webkit-border-bottom-right-radius:3px;-moz-border-radius-bottomright:3px;border-bottom-right-radius:3px}.pagination-small ul>li>a,.pagination-small ul>li>span{padding:2px
10px;font-size:11.9px}.pagination-mini ul>li>a,.pagination-mini ul>li>span{padding:0
6px;font-size:10.5px}.pager{margin:20px
0;list-style:none;text-align:center;*zoom:1}.pager:before,.pager:after{display:table;content:"";line-height:0}.pager:after{clear:both}.pager
li{display:inline}.pager li>a,.pager li>span{display:inline-block;padding:5px
14px;background-color:#fff;border:1px
solid #ddd;-webkit-border-radius:15px;-moz-border-radius:15px;border-radius:15px}.pager li>a:hover,.pager li>a:focus{text-decoration:none;background-color:#f5f5f5}.pager .next>a,.pager .next>span{float:right}.pager .previous>a,.pager .previous>span{float:left}.pager .disabled>a,.pager .disabled>a:hover,.pager .disabled>a:focus,.pager .disabled>span{color:#999;background-color:#fff;cursor:default}.modal-backdrop{position:fixed;top:0;right:0;bottom:0;left:0;z-index:1040;background-color:#000}.modal-backdrop.fade{opacity:0}.modal-backdrop,.modal-backdrop.fade.in{opacity:.8;filter:alpha(opacity=80)}.modal{position:fixed;top:10%;left:50%;z-index:1050;width:560px;margin-left:-280px;background-color:#fff;border:1px
solid #999;border:1px
solid rgba(0,0,0,0.3);*border:1px
solid #999;-webkit-border-radius:6px;-moz-border-radius:6px;border-radius:6px;-webkit-box-shadow:0 3px 7px rgba(0,0,0,0.3);-moz-box-shadow:0 3px 7px rgba(0,0,0,0.3);box-shadow:0 3px 7px rgba(0,0,0,0.3);-webkit-background-clip:padding-box;-moz-background-clip:padding-box;background-clip:padding-box;outline:none}.modal.fade{-webkit-transition:opacity .3s linear, top .3s ease-out;-moz-transition:opacity .3s linear, top .3s ease-out;-o-transition:opacity .3s linear, top .3s ease-out;transition:opacity .3s linear, top .3s ease-out;top:-25%}.modal.fade.in{top:10%}.modal-header{padding:9px
15px;border-bottom:1px solid #eee}.modal-header
.close{margin-top:2px}.modal-header
h3{margin:0;line-height:30px}.modal-body{position:relative;overflow-y:auto;max-height:400px;padding:15px}.modal-form{margin-bottom:0}.modal-footer{padding:14px
15px 15px;margin-bottom:0;text-align:right;background-color:#f5f5f5;border-top:1px solid #ddd;-webkit-border-radius:0 0 6px 6px;-moz-border-radius:0 0 6px 6px;border-radius:0 0 6px 6px;-webkit-box-shadow:inset 0 1px 0 #fff;-moz-box-shadow:inset 0 1px 0 #fff;box-shadow:inset 0 1px 0 #fff;*zoom:1}.modal-footer:before,.modal-footer:after{display:table;content:"";line-height:0}.modal-footer:after{clear:both}.modal-footer .btn+.btn{margin-left:5px;margin-bottom:0}.modal-footer .btn-group .btn+.btn{margin-left:-1px}.modal-footer .btn-block+.btn-block{margin-left:0}.tooltip{position:absolute;z-index:1030;display:block;visibility:visible;font-size:11px;line-height:1.4;opacity:0;filter:alpha(opacity=0)}.tooltip.in{opacity:.8;filter:alpha(opacity=80)}.tooltip.top{margin-top:-3px;padding:5px
0}.tooltip.right{margin-left:3px;padding:0
5px}.tooltip.bottom{margin-top:3px;padding:5px
0}.tooltip.left{margin-left:-3px;padding:0
5px}.tooltip-inner{max-width:200px;padding:8px;color:#fff;text-align:center;text-decoration:none;background-color:#000;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.tooltip-arrow{position:absolute;width:0;height:0;border-color:transparent;border-style:solid}.tooltip.top .tooltip-arrow{bottom:0;left:50%;margin-left:-5px;border-width:5px 5px 0;border-top-color:#000}.tooltip.right .tooltip-arrow{top:50%;left:0;margin-top:-5px;border-width:5px 5px 5px 0;border-right-color:#000}.tooltip.left .tooltip-arrow{top:50%;right:0;margin-top:-5px;border-width:5px 0 5px 5px;border-left-color:#000}.tooltip.bottom .tooltip-arrow{top:0;left:50%;margin-left:-5px;border-width:0 5px 5px;border-bottom-color:#000}.popover{position:absolute;top:0;left:0;z-index:1010;display:none;max-width:276px;padding:1px;text-align:left;background-color:#fff;-webkit-background-clip:padding-box;-moz-background-clip:padding;background-clip:padding-box;border:1px
solid #ccc;border:1px
solid rgba(0,0,0,0.2);-webkit-border-radius:6px;-moz-border-radius:6px;border-radius:6px;-webkit-box-shadow:0 5px 10px rgba(0,0,0,0.2);-moz-box-shadow:0 5px 10px rgba(0,0,0,0.2);box-shadow:0 5px 10px rgba(0,0,0,0.2);white-space:normal}.popover.top{margin-top:-10px}.popover.right{margin-left:10px}.popover.bottom{margin-top:10px}.popover.left{margin-left:-10px}.popover-title{margin:0;padding:8px
14px;font-size:14px;font-weight:normal;line-height:18px;background-color:#f7f7f7;border-bottom:1px solid #ebebeb;-webkit-border-radius:5px 5px 0 0;-moz-border-radius:5px 5px 0 0;border-radius:5px 5px 0 0}.popover-title:empty{display:none}.popover-content{padding:9px
14px}.popover .arrow,.popover .arrow:after{position:absolute;display:block;width:0;height:0;border-color:transparent;border-style:solid}.popover
.arrow{border-width:11px}.popover .arrow:after{border-width:10px;content:""}.popover.top
.arrow{left:50%;margin-left:-11px;border-bottom-width:0;border-top-color:#999;border-top-color:rgba(0,0,0,0.25);bottom:-11px}.popover.top .arrow:after{bottom:1px;margin-left:-10px;border-bottom-width:0;border-top-color:#fff}.popover.right
.arrow{top:50%;left:-11px;margin-top:-11px;border-left-width:0;border-right-color:#999;border-right-color:rgba(0,0,0,0.25)}.popover.right .arrow:after{left:1px;bottom:-10px;border-left-width:0;border-right-color:#fff}.popover.bottom
.arrow{left:50%;margin-left:-11px;border-top-width:0;border-bottom-color:#999;border-bottom-color:rgba(0,0,0,0.25);top:-11px}.popover.bottom .arrow:after{top:1px;margin-left:-10px;border-top-width:0;border-bottom-color:#fff}.popover.left
.arrow{top:50%;right:-11px;margin-top:-11px;border-right-width:0;border-left-color:#999;border-left-color:rgba(0,0,0,0.25)}.popover.left .arrow:after{right:1px;border-right-width:0;border-left-color:#fff;bottom:-10px}.thumbnails{margin-left:-20px;list-style:none;*zoom:1}.thumbnails:before,.thumbnails:after{display:table;content:"";line-height:0}.thumbnails:after{clear:both}.row-fluid
.thumbnails{margin-left:0}.thumbnails>li{float:left;margin-bottom:20px;margin-left:20px}.thumbnail{display:block;padding:4px;line-height:20px;border:1px
solid #ddd;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:0 1px 3px rgba(0,0,0,0.055);-moz-box-shadow:0 1px 3px rgba(0,0,0,0.055);box-shadow:0 1px 3px rgba(0,0,0,0.055);-webkit-transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;transition:all .2s ease-in-out}a.thumbnail:hover,a.thumbnail:focus{border-color:#0070a8;-webkit-box-shadow:0 1px 4px rgba(0,105,214,0.25);-moz-box-shadow:0 1px 4px rgba(0,105,214,0.25);box-shadow:0 1px 4px rgba(0,105,214,0.25)}.thumbnail>img{display:block;max-width:100%;margin-left:auto;margin-right:auto}.thumbnail
.caption{padding:9px;color:#555}.media,.media-body{overflow:hidden;*overflow:visible;zoom:1}.media,.media
.media{margin-top:15px}.media:first-child{margin-top:0}.media-object{display:block}.media-heading{margin:0
0 5px}.media>.pull-left{margin-right:10px}.media>.pull-right{margin-left:10px}.media-list{margin-left:0;list-style:none}.label,.badge{display:inline-block;padding:2px
4px;font-size:11.844px;font-weight:bold;line-height:14px;color:#fff;vertical-align:baseline;white-space:nowrap;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#999}.label{-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.badge{padding-left:9px;padding-right:9px;-webkit-border-radius:9px;-moz-border-radius:9px;border-radius:9px}.label:empty,.badge:empty{display:none}a.label:hover,a.label:focus,a.badge:hover,a.badge:focus{color:#fff;text-decoration:none;cursor:pointer}.label-important,.badge-important{background-color:#b94a48}.label-important[href],.badge-important[href]{background-color:#953b39}.label-warning,.badge-warning{background-color:#f89406}.label-warning[href],.badge-warning[href]{background-color:#c67605}.label-success,.badge-success{background-color:#468847}.label-success[href],.badge-success[href]{background-color:#356635}.label-info,.badge-info{background-color:#3a87ad}.label-info[href],.badge-info[href]{background-color:#2d6987}.label-inverse,.badge-inverse{background-color:#333}.label-inverse[href],.badge-inverse[href]{background-color:#1a1a1a}.btn .label,.btn
.badge{position:relative;top:-1px}.btn-mini .label,.btn-mini
.badge{top:0}@-webkit-keyframes progress-bar-stripes{from{background-position:40px 0}to{background-position:0 0}}@-moz-keyframes progress-bar-stripes{from{background-position:40px 0}to{background-position:0 0}}@-ms-keyframes progress-bar-stripes{from{background-position:40px 0}to{background-position:0 0}}@-o-keyframes progress-bar-stripes{from{background-position:0 0}to{background-position:40px 0}}@keyframes progress-bar-stripes{from{background-position:40px 0}to{background-position:0 0}}.progress{overflow:hidden;height:20px;margin-bottom:20px;background-color:#f7f7f7;background-image:-moz-linear-gradient(top, #f5f5f5, #f9f9f9);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#f5f5f5), to(#f9f9f9));background-image:-webkit-linear-gradient(top, #f5f5f5, #f9f9f9);background-image:-o-linear-gradient(top, #f5f5f5, #f9f9f9);background-image:linear-gradient(to bottom, #f5f5f5, #f9f9f9);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#fff5f5f5', endColorstr='#fff9f9f9', GradientType=0);-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,0.1);-moz-box-shadow:inset 0 1px 2px rgba(0,0,0,0.1);box-shadow:inset 0 1px 2px rgba(0,0,0,0.1);-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.progress
.bar{width:0;height:100%;color:#fff;float:left;font-size:12px;text-align:center;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#0e90d2;background-image:-moz-linear-gradient(top, #149bdf, #0480be);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#149bdf), to(#0480be));background-image:-webkit-linear-gradient(top, #149bdf, #0480be);background-image:-o-linear-gradient(top, #149bdf, #0480be);background-image:linear-gradient(to bottom, #149bdf, #0480be);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff149bdf', endColorstr='#ff0480be', GradientType=0);-webkit-box-shadow:inset 0 -1px 0 rgba(0,0,0,0.15);-moz-box-shadow:inset 0 -1px 0 rgba(0,0,0,0.15);box-shadow:inset 0 -1px 0 rgba(0,0,0,0.15);-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;-webkit-transition:width .6s ease;-moz-transition:width .6s ease;-o-transition:width .6s ease;transition:width .6s ease}.progress .bar+.bar{-webkit-box-shadow:inset 1px 0 0 rgba(0,0,0,.15), inset 0 -1px 0 rgba(0,0,0,.15);-moz-box-shadow:inset 1px 0 0 rgba(0,0,0,.15), inset 0 -1px 0 rgba(0,0,0,.15);box-shadow:inset 1px 0 0 rgba(0,0,0,.15), inset 0 -1px 0 rgba(0,0,0,.15)}.progress-striped
.bar{background-color:#149bdf;background-image:-webkit-gradient(linear, 0 100%, 100% 0, color-stop(.25, rgba(255,255,255,0.15)), color-stop(.25, transparent), color-stop(.5, transparent), color-stop(.5, rgba(255,255,255,0.15)), color-stop(.75, rgba(255,255,255,0.15)), color-stop(.75, transparent), to(transparent));background-image:-webkit-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:-moz-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:-o-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);-webkit-background-size:40px 40px;-moz-background-size:40px 40px;-o-background-size:40px 40px;background-size:40px 40px}.progress.active
.bar{-webkit-animation:progress-bar-stripes 2s linear infinite;-moz-animation:progress-bar-stripes 2s linear infinite;-ms-animation:progress-bar-stripes 2s linear infinite;-o-animation:progress-bar-stripes 2s linear infinite;animation:progress-bar-stripes 2s linear infinite}.progress-danger .bar,.progress .bar-danger{background-color:#dd514c;background-image:-moz-linear-gradient(top, #ee5f5b, #c43c35);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#ee5f5b), to(#c43c35));background-image:-webkit-linear-gradient(top, #ee5f5b, #c43c35);background-image:-o-linear-gradient(top, #ee5f5b, #c43c35);background-image:linear-gradient(to bottom, #ee5f5b, #c43c35);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffee5f5b', endColorstr='#ffc43c35', GradientType=0)}.progress-danger.progress-striped .bar,.progress-striped .bar-danger{background-color:#ee5f5b;background-image:-webkit-gradient(linear, 0 100%, 100% 0, color-stop(.25, rgba(255,255,255,0.15)), color-stop(.25, transparent), color-stop(.5, transparent), color-stop(.5, rgba(255,255,255,0.15)), color-stop(.75, rgba(255,255,255,0.15)), color-stop(.75, transparent), to(transparent));background-image:-webkit-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:-moz-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:-o-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent)}.progress-success .bar,.progress .bar-success{background-color:#5eb95e;background-image:-moz-linear-gradient(top, #62c462, #57a957);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#62c462), to(#57a957));background-image:-webkit-linear-gradient(top, #62c462, #57a957);background-image:-o-linear-gradient(top, #62c462, #57a957);background-image:linear-gradient(to bottom, #62c462, #57a957);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff62c462', endColorstr='#ff57a957', GradientType=0)}.progress-success.progress-striped .bar,.progress-striped .bar-success{background-color:#62c462;background-image:-webkit-gradient(linear, 0 100%, 100% 0, color-stop(.25, rgba(255,255,255,0.15)), color-stop(.25, transparent), color-stop(.5, transparent), color-stop(.5, rgba(255,255,255,0.15)), color-stop(.75, rgba(255,255,255,0.15)), color-stop(.75, transparent), to(transparent));background-image:-webkit-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:-moz-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:-o-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent)}.progress-info .bar,.progress .bar-info{background-color:#4bb1cf;background-image:-moz-linear-gradient(top, #5bc0de, #339bb9);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#5bc0de), to(#339bb9));background-image:-webkit-linear-gradient(top, #5bc0de, #339bb9);background-image:-o-linear-gradient(top, #5bc0de, #339bb9);background-image:linear-gradient(to bottom, #5bc0de, #339bb9);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff5bc0de', endColorstr='#ff339bb9', GradientType=0)}.progress-info.progress-striped .bar,.progress-striped .bar-info{background-color:#5bc0de;background-image:-webkit-gradient(linear, 0 100%, 100% 0, color-stop(.25, rgba(255,255,255,0.15)), color-stop(.25, transparent), color-stop(.5, transparent), color-stop(.5, rgba(255,255,255,0.15)), color-stop(.75, rgba(255,255,255,0.15)), color-stop(.75, transparent), to(transparent));background-image:-webkit-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:-moz-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:-o-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent)}.progress-warning .bar,.progress .bar-warning{background-color:#faa732;background-image:-moz-linear-gradient(top, #fbb450, #f89406);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#fbb450), to(#f89406));background-image:-webkit-linear-gradient(top, #fbb450, #f89406);background-image:-o-linear-gradient(top, #fbb450, #f89406);background-image:linear-gradient(to bottom, #fbb450, #f89406);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#fffbb450', endColorstr='#fff89406', GradientType=0)}.progress-warning.progress-striped .bar,.progress-striped .bar-warning{background-color:#fbb450;background-image:-webkit-gradient(linear, 0 100%, 100% 0, color-stop(.25, rgba(255,255,255,0.15)), color-stop(.25, transparent), color-stop(.5, transparent), color-stop(.5, rgba(255,255,255,0.15)), color-stop(.75, rgba(255,255,255,0.15)), color-stop(.75, transparent), to(transparent));background-image:-webkit-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:-moz-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:-o-linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-image:linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%,transparent)}.accordion{margin-bottom:20px}.accordion-group{margin-bottom:2px;border:1px
solid #e5e5e5;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.accordion-heading{border-bottom:0}.accordion-heading .accordion-toggle{display:block;padding:8px
15px}.accordion-toggle{cursor:pointer}.accordion-inner{padding:9px
15px;border-top:1px solid #e5e5e5}.carousel{position:relative;margin-bottom:20px;line-height:1}.carousel-inner{overflow:hidden;width:100%;position:relative}.carousel-inner>.item{display:none;position:relative;-webkit-transition:.6s ease-in-out left;-moz-transition:.6s ease-in-out left;-o-transition:.6s ease-in-out left;transition:.6s ease-in-out left}.carousel-inner>.item>img,.carousel-inner>.item>a>img{display:block;line-height:1}.carousel-inner>.active,.carousel-inner>.next,.carousel-inner>.prev{display:block}.carousel-inner>.active{left:0}.carousel-inner>.next,.carousel-inner>.prev{position:absolute;top:0;width:100%}.carousel-inner>.next{left:100%}.carousel-inner>.prev{left:-100%}.carousel-inner>.next.left,.carousel-inner>.prev.right{left:0}.carousel-inner>.active.left{left:-100%}.carousel-inner>.active.right{left:100%}.carousel-control{position:absolute;top:40%;left:15px;width:40px;height:40px;margin-top:-20px;font-size:60px;font-weight:100;line-height:30px;color:#fff;text-align:center;background:#222;border:3px
solid #fff;-webkit-border-radius:23px;-moz-border-radius:23px;border-radius:23px;opacity:.5;filter:alpha(opacity=50)}.carousel-control.right{left:auto;right:15px}.carousel-control:hover,.carousel-control:focus{color:#fff;text-decoration:none;opacity:.9;filter:alpha(opacity=90)}.carousel-indicators{position:absolute;top:15px;right:15px;z-index:5;margin:0;list-style:none}.carousel-indicators
li{display:block;float:left;width:10px;height:10px;margin-left:5px;text-indent:-999px;background-color:#ccc;background-color:rgba(255,255,255,0.25);border-radius:5px}.carousel-indicators
.active{background-color:#fff}.carousel-caption{position:absolute;left:0;right:0;bottom:0;padding:15px;background:#333;background:rgba(0,0,0,0.75)}.carousel-caption h4,.carousel-caption
p{color:#fff;line-height:20px}.carousel-caption
h4{margin:0
0 5px}.carousel-caption
p{margin-bottom:0}.hero-unit{padding:60px;margin-bottom:30px;font-size:18px;font-weight:200;line-height:30px;color:inherit;background-color:#eee;-webkit-border-radius:6px;-moz-border-radius:6px;border-radius:6px}.hero-unit
h1{margin-bottom:0;font-size:60px;line-height:1;color:inherit;letter-spacing:-1px}.hero-unit
li{line-height:30px}.pull-right{float:right}.pull-left{float:left}.hide{display:none}.show{display:block}.invisible{visibility:hidden}.affix{position:fixed}h1{font-size:32px}h2{font-size:28px}h3{font-size:24px}h4{font-size:20px}h5{font-size:16px}h6{font-size:12px}h1
small{font-size:24px}h2
small{font-size:20px}h3
small{font-size:16px}h4
small{font-size:12px}@media
print{a[href]:after{content:""}}legend{border-bottom-color:#ddd;color:#333}.breadcrumb{background-color:#f5f5f5}.well{border-color:#e3e3e3}sup{vertical-align:super}sub{vertical-align:sub}.dropdown-backdrop{position:static}li.activity.label,.file-picker
td.label{background:inherit;color:inherit;border:inherit;text-shadow:none;padding:8px;white-space:normal;display:block;font-size:inherit;line-height:inherit}.file-picker
td.label{display:table-cell;text-align:right}.choosercontainer #chooseform .option
label{font-size:12px}li.section.hidden,.block.hidden,.block.invisible{visibility:visible;display:block}#turnitintool_style .row,.forumpost
.row{margin-left:0 !important}#turnitintool_style .row:before,#turnitintool_style .row:after,.forumpost .row:before,.forumpost .row:after{content:none}fieldset.hidden{display:inherit;visibility:inherit}div.c1.btn{display:block;padding:0;margin-bottom:0;font-size:inherit;line-height:inherit;text-align:inherit;vertical-align:inherit;cursor:default;color:inherit;text-shadow:inherit;background-color:inherit;background-image:none;background-repeat:no-repeat;border:none;border-radius:0;box-shadow:none}#questionbank+.container{width:auto}img.hide{display:inherit}.icon-bar,img.icon-post,img.icon-info,img.icon-warn,img.icon-pre{background-image:none}.loginbox.twocolumns .signuppanel,.loginbox.twocolumns .signuppanel,.loginbox.twocolumns .loginpanel,.loginbox.twocolumns
.loginpanel{padding:0;margin:0}.tooltip{opacity:1;filter:alpha(opacity=100);display:inline}body:not(.jsenabled) .dropdown:hover>.dropdown-menu{display:block;margin-top:-6px}body:not(.jsenabled) .langmenu:hover>.dropdown-menu,.langmenu.open>.dropdown-menu{display:block;max-height:150px;overflow-y:auto}ol{margin:0
0 10px 2.5em}.dir-rtl
ol{margin:0
2.5em 10px 0}body{padding-top:60px}.block{min-height:20px;padding:19px;margin-bottom:20px;background-color:#f5f5f5;border:1px
solid #e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);border-color:#e3e3e3;padding:8px
0}.block
blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}.block .header
h2{display:block;padding:3px
15px;font-size:11px;font-weight:bold;line-height:20px;color:#999;text-shadow:0 1px 0 rgba(255,255,255,0.5);text-transform:uppercase;font-size:1.1em;word-wrap:break-word;margin:0}.block .header
.block_action{padding:3px
15px;float:right}.block .header .block_action>*{margin-left:3px}.block .header .block_action .block-hider-show,.block .header .block_action .block-hider-hide{cursor:pointer}.block .header .block_action .block-hider-show{display:none}.block
.content{padding:4px
14px;word-wrap:break-word}.block .content
h3{display:block;padding:3px
15px;font-size:11px;font-weight:bold;line-height:20px;color:#999;text-shadow:0 1px 0 rgba(255,255,255,0.5);text-transform:uppercase;font-size:1.1em}.block .content
hr{margin:5px
0}.block .content
.userpicture{width:16px;height:16px;margin-right:6px}.block .content .list
li.listentry{clear:both}.block .content .list
.c0{display:inline}.block .content .list
.c1{margin-left:5px;display:inline}.block
.footer{margin-bottom:4px;display:block;padding:3px
5px}.block.beingmoved{border-width:2px;border-style:dashed}.block.invisible .header
h2{opacity:.5;filter:alpha(opacity=50)}.block.hidden .header .block_action .block-hider-hide{display:none}.block.hidden .header .block_action .block-hider-show{display:inline}.block.list_block .unlist>li>.column{display:inline-block;*display:inline;*zoom:1}.editing .block .header
.commands{clear:both;text-align:right;display:block;padding:3px
15px}.editing .block .header .commands>a{margin:0
3px}.editing .block .header .commands .icon
img{width:12px;height:12px}.editing .block .header .commands
img.actionmenu{width:auto}.dir-rtl.editing .block .header
.commands{text-align:left}.jsenabled .block.hidden
.content{display:none}.blockmovetarget{border-width:2px;border-style:dashed;display:block;height:1em;margin-bottom:20px}.blockannotation{position:relative;top:-10px;margin-bottom:10px}.block_blog_menu
#blogsearchquery{max-width:92%}.block_settings
#adminsearchquery{max-width:92%}.block_search_forums
#searchform_search{width:auto;max-width:92%}.block_calendar_upcoming .content
.date{padding-left:22px}.block_calendar_upcoming .content
.footer{margin-top:.5em;padding-top:10px;padding-left:0}.block_rss_client .content
li{margin-bottom:10px;padding:5px;border:1px
solid #ddd;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.block_rss_client .content li
.link{font-weight:inherit}.block_rss_client .list li:first-child{border-top-width:1px}.block_news_items .content
.newlink{padding-bottom:10px}.block_news_items .content ul
li{border-top:1px rgba(0,0,0,0.05) solid;padding:2px;display:table;width:100%}.block_news_items .content ul li
.info{display:table-header-group}.block_news_items .content ul li
.date{font-size:11.9px;display:inline}.block_news_items .content ul li
.name{font-size:11.9px;padding-left:1ex;display:inline}.block_news_items .content
.footer{padding-top:10px;padding-left:0}.block_login input#login_username,.block_login
input#login_password{width:95%}.block_login
.content{margin-left:auto;margin-right:auto;max-width:280px}.block_login input[type="submit"]{margin:10px
0}.block_adminblock
.content{display:block;margin:0
10px;padding:3px
5px;width:auto}.block_adminblock
.singleselect{display:block}.block_adminblock .singleselect
select.singleselect{display:block;width:100%}.dir-rtl .block
.header{text-align:right}.dir-rtl .block .header
h2{text-align:right}.dir-rtl .block .header
.block_action{float:left}.dir-rtl .block .header .block_action>*{margin-left:0;margin-right:3px}.dir-rtl .block_calendar_upcoming .content
.date{padding-right:22px}.dir-rtl .block_calendar_upcoming .content
.footer{padding-right:0}.dir-rtl .block_news_items .content ul li
.name{padding-right:1ex}.dir-rtl .block_news_items .content
.footer{padding-left:0}form{margin:0}.mform fieldset
.advancedbutton{text-align:right}.jsenabled .mform .containsadvancedelements
.advanced{display:none}.mform .containsadvancedelements
.advanced.show{display:block}.mform
fieldset.group{margin-bottom:0}.mform
fieldset.error{border:1px
solid #b94a48}.mform span.error,#adminsettings
span.error{display:inline-block;border:1px
solid #eed3d7;border-radius:4px;background-color:#f2dede;padding:4px;margin-bottom:4px}.mform fieldset.collapsible legend
a.fheader{padding:0
5px 0 20px;margin-left:-20px;background:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fexpanded) 2px center no-repeat}.dir-rtl .mform fieldset.collapsible legend
a.fheader{padding:0
20px 0 5px;margin-right:-20px;margin-left:0;background-position:right center}.mform fieldset.collapsed legend
a.fheader{background-image:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fcollapsed)}.dir-rtl .mform fieldset.collapsed legend
a.fheader{background-image:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fcollapsed_rtl)}.jsenabled .mform .collapsed
.fcontainer{display:none}.mform .fitem .fitemtitle
div{display:inline}#adminsettings .error,.loginpanel .error,.mform
.error{color:#b94a48}.mform
.fdescription.required{margin-left:200px}.mform .fpassword
.unmask{display:inline-block;margin-left:.5em}.mform .fpassword .unmask>input{margin:0}.mform .fpassword .unmask>label{display:inline-block}.mform
label{display:inline-block}.mform
.iconhelp{margin-left:4px}.dir-rtl .mform
.iconhelp{margin-right:4px}.mform .ftextarea
#id_alltext{width:100%}.mform ul.file-list{padding:0;margin:0;list-style:none}.mform label .req,.mform label
.adv{cursor:help}.mform .fcheckbox
input{margin-left:0}.mform .fcheckbox>span,.mform .fradio>span,.mform .fgroup>span{display:inline-block;margin-top:5px}.mform .fitem fieldset.fgroup label,.mform fieldset.fdate_selector
label{display:inline;float:none;width:auto}.mform .ftags
label.accesshide{display:block;position:static}.mform .ftags
select{margin-bottom:.7em;min-width:22em}.mform .helplink
img{margin:0
.45em;padding:0}.mform legend .helplink
img{margin:0
.2em}.singleselect
label{margin-right:.3em}.dir-rtl .singleselect
label{margin-left:.3em;margin-right:0}input#id_externalurl{direction:ltr}#portfolio-add-button{display:inline}.form-item,.mform
.fitem{margin-bottom:20px;*zoom:1;margin-bottom:10px}.form-item:before,.mform .fitem:before,.form-item:after,.mform .fitem:after{display:table;content:"";line-height:0}.form-item:after,.mform .fitem:after{clear:both}.form-item .form-label,.mform .fitem
div.fitemtitle{float:left;width:180px;padding-top:5px;text-align:right}.dir-rtl .form-item .form-label,.dir-rtl .mform .fitem
div.fitemtitle{float:right;text-align:left}.form-defaultinfo,.form-label .form-shortname{color:#999}.form-label .form-shortname{font-size:10.5px;display:block}.dir-rtl .form-label .form-shortname{text-align:left}.form-item .form-setting,.form-item .form-description,.mform .fitem .felement,#page-mod-forum-search
.c1{*display:inline-block;*padding-left:20px;margin-left:200px;*margin-left:0}.form-item .form-setting:first-child,.form-item .form-description:first-child,.mform .fitem .felement:first-child,#page-mod-forum-search .c1:first-child{*padding-left:200px}.formsettingheading{margin-bottom:0}.form-item .form-description,.felement.fstatic{color:#595959;display:block;margin-bottom:10px;padding-top:5px}.form-item .form-description{padding-top:0}.fitem
.fstaticlabel{font-weight:bold}table#form td.submit,.form-buttons,.path-admin .buttons,#fitem_id_submitbutton,.fp-content-center form+div,div.backup-section+form,#fgroup_id_buttonar{padding:19px
20px 20px;margin-top:20px;margin-bottom:20px;background-color:#f5f5f5;border-top:1px solid #e5e5e5;*zoom:1;padding-left:0}table#form td.submit:before,.form-buttons:before,.path-admin .buttons:before,#fitem_id_submitbutton:before,.fp-content-center form+div:before,div.backup-section+form:before,#fgroup_id_buttonar:before,table#form td.submit:after,.form-buttons:after,.path-admin .buttons:after,#fitem_id_submitbutton:after,.fp-content-center form+div:after,div.backup-section+form:after,#fgroup_id_buttonar:after{display:table;content:"";line-height:0}table#form td.submit:after,.form-buttons:after,.path-admin .buttons:after,#fitem_id_submitbutton:after,.fp-content-center form+div:after,div.backup-section+form:after,#fgroup_id_buttonar:after{clear:both}.path-admin .buttons,.form-buttons{padding-left:200px}.dir-rtl table#form td.submit,.dir-rtl .form-buttons,.dir-rtl .path-admin .buttons,.dir-rtl #fitem_id_submitbutton,.dir-rtl .fp-content-center form+div,.dir-rtl div.backup-section+form,.dir-rtl
#fgroup_id_buttonar{padding:19px
20px 20px;margin-top:20px;margin-bottom:20px;background-color:#f5f5f5;border-top:1px solid #e5e5e5;*zoom:1;padding-right:0}.dir-rtl table#form td.submit:before,.dir-rtl .form-buttons:before,.dir-rtl .path-admin .buttons:before,.dir-rtl #fitem_id_submitbutton:before,.dir-rtl .fp-content-center form+div:before,.dir-rtl div.backup-section+form:before,.dir-rtl #fgroup_id_buttonar:before,.dir-rtl table#form td.submit:after,.dir-rtl .form-buttons:after,.dir-rtl .path-admin .buttons:after,.dir-rtl #fitem_id_submitbutton:after,.dir-rtl .fp-content-center form+div:after,.dir-rtl div.backup-section+form:after,.dir-rtl #fgroup_id_buttonar:after{display:table;content:"";line-height:0}.dir-rtl table#form td.submit:after,.dir-rtl .form-buttons:after,.dir-rtl .path-admin .buttons:after,.dir-rtl #fitem_id_submitbutton:after,.dir-rtl .fp-content-center form+div:after,.dir-rtl div.backup-section+form:after,.dir-rtl #fgroup_id_buttonar:after{clear:both}.dir-rtl .path-admin .buttons,.dir-rtl .form-buttons{padding-right:200px}.form-item .form-setting .form-checkbox.defaultsnext{margin-top:5px;display:inline-block}#adminsettings
h3{display:block;width:100%;padding:0;margin-bottom:20px;font-size:21px;line-height:40px;color:#333;border:0;border-bottom:1px solid #e5e5e5}.mform legend a,.mform legend a:hover{color:#333;text-decoration:none}.dir-rtl .mform .fitem
.felement{margin-right:30%;margin-left:auto;text-align:right}.dir-rtl .mform .fitem .felement input[name=email],.dir-rtl .mform .fitem .felement input[name=email2],.dir-rtl .mform .fitem .felement input[name=url],.dir-rtl .mform .fitem .felement input[name=idnumber],.dir-rtl .mform .fitem .felement input[name=phone1],.dir-rtl .mform .fitem .felement input[name=phone2]{text-align:left;direction:ltr}.dir-rtl #id_s__pathtodu,.dir-rtl #id_s__aspellpath,.dir-rtl #id_s__pathtodot,.dir-rtl #id_s__supportemail,.dir-rtl #id_s__supportpage,.dir-rtl #id_s__sessioncookie,.dir-rtl #id_s__sessioncookiepath,.dir-rtl #id_s__sessioncookiedomain,.dir-rtl #id_s__proxyhost,.dir-rtl #id_s__proxyuser,.dir-rtl #id_s__proxypassword,.dir-rtl #id_s__proxybypass,.dir-rtl #id_s__jabberhost,.dir-rtl #id_s__jabberserver,.dir-rtl #id_s__jabberusername,.dir-rtl #id_s__jabberpassword,.dir-rtl #id_s__additionalhtmlhead,.dir-rtl #id_s__additionalhtmltopofbody,.dir-rtl #id_s__additionalhtmlfooter,.dir-rtl #id_s__docroot,.dir-rtl #id_s__filter_tex_latexpreamble,.dir-rtl #id_s__filter_tex_latexbackground,.dir-rtl #id_s__filter_tex_pathlatex,.dir-rtl #id_s__filter_tex_pathdvips,.dir-rtl #id_s__filter_tex_pathconvert,.dir-rtl #id_s__blockedip,.dir-rtl #id_s__pathtoclam,.dir-rtl #id_s__quarantinedir,.dir-rtl #id_s__sitepolicy,.dir-rtl #id_s__sitepolicyguest,.dir-rtl #id_s__cronremotepassword,.dir-rtl #id_s__allowedip,.dir-rtl #id_s__blockedip,.dir-rtl #id_s_enrol_meta_nosyncroleids,.dir-rtl #id_s_enrol_ldap_host_url,.dir-rtl #id_s_enrol_ldap_ldapencoding,.dir-rtl #id_s_enrol_ldap_bind_dn,.dir-rtl #id_s_enrol_ldap_bind_pw,.dir-rtl #admin-emoticons .form-text,.dir-rtl #admin-role_mapping input[type=text],.dir-rtl #id_s_enrol_paypal_paypalbusiness,.dir-rtl #id_s_enrol_flatfile_location,#page-admin-setting-enrolsettingsflatfile.dir-rtl input[type=text],#page-admin-setting-enrolsettingsdatabase.dir-rtl input[type=text],#page-admin-auth-db.dir-rtl input[type=text]{direction:ltr}#page-admin-setting-enrolsettingsflatfile.dir-rtl
.informationbox{direction:ltr;text-align:left}#page-admin-grade-edit-scale-edit.dir-rtl .error
input#id_name{margin-right:170px}#page-grade-edit-outcome-course
.courseoutcomes{margin-left:auto;margin-right:auto;width:100%}#page-grade-edit-outcome-course .courseoutcomes
td{text-align:center}#installform #id_wwwroot,#installform #id_dirroot,#installform #id_dataroot,#installform #id_dbhost,#installform #id_dbname,#installform #id_dbuser,#installform #id_dbpass,#installform
#id_prefix{direction:ltr}.mdl-right>label{display:inline-block}input[type="radio"]+label,input[type="checkbox"]+label{display:inline;padding-left:.2em}input[type="radio"],input[type="checkbox"]{margin-top:-4px;margin-right:7px}.dir-rtl input[type="radio"],.dir-rtl input[type="checkbox"]{margin-left:7px;margin-right:auto}.singleselect{display:inline-block}.singleselect form,.singleselect
select{margin:0}.form-item .form-label
label{margin-bottom:0}.dir-rtl .form-item .form-label
label{text-align:left}.felement.ffilepicker{margin-top:5px}div#dateselector-calendar-panel{z-index:3100}fieldset.coursesearchbox
label{display:inline}#region-main .mform:not(.unresponsive) .fitem .fitemtitle
label{font-weight:bold}@media (max-width:1199px){body #region-main .mform:not(.unresponsive) .fitem
.fitemtitle{display:block;margin-top:4px;margin-bottom:4px;text-align:left;width:100%}body #region-main .mform:not(.unresponsive) .fitem
.felement{margin-left:0;width:100%;float:left;padding-left:0;padding-right:0}body #region-main .mform:not(.unresponsive) .fitem .fstatic:empty{display:none}body #region-main .mform:not(.unresponsive) .fitem .fcheckbox>span,body #region-main .mform:not(.unresponsive) .fitem .fradio>span,body #region-main .mform:not(.unresponsive) .fitem .fgroup>span{margin-top:4px}body #region-main .mform:not(.unresponsive) .femptylabel
.fitemtitle{display:inline-block;width:auto;margin-right:8px}body #region-main .mform:not(.unresponsive) .femptylabel
.felement{display:inline-block;margin-top:4px;padding-top:5px;width:auto}body #region-main .mform:not(.unresponsive) .fitem_fcheckbox .fitemtitle,body #region-main .mform:not(.unresponsive) .fitem_fcheckbox
.felement{display:inline-block;width:auto}body #region-main .mform:not(.unresponsive) .fitem_fcheckbox
.felement{padding:6px}body.dir-rtl #region-main .mform:not(.unresponsive) .femptylabel
.fitemtitle{margin-right:0;margin-left:8px}body.dir-rtl #region-main .mform:not(.unresponsive) .fitem
.fitemtitle{text-align:right}body.dir-rtl #region-main .mform:not(.unresponsive) .fitem
.felement{margin-right:0;float:right;padding-right:0;padding-left:0}body.dir-rtl #region-main .mform:not(.unresponsive) .fitem_fcheckbox
.felement{float:right}}@media (max-width:1474px){.used-region-side-pre.used-region-side-post #region-main .mform:not(.unresponsive) .fitem
.fitemtitle{display:block;margin-top:4px;margin-bottom:4px;text-align:left;width:100%}.used-region-side-pre.used-region-side-post #region-main .mform:not(.unresponsive) .fitem
.felement{margin-left:0;width:100%;float:left;padding-left:0;padding-right:0}.used-region-side-pre.used-region-side-post #region-main .mform:not(.unresponsive) .fitem .fstatic:empty{display:none}.used-region-side-pre.used-region-side-post #region-main .mform:not(.unresponsive) .fitem .fcheckbox>span,.used-region-side-pre.used-region-side-post #region-main .mform:not(.unresponsive) .fitem .fradio>span,.used-region-side-pre.used-region-side-post #region-main .mform:not(.unresponsive) .fitem .fgroup>span{margin-top:4px}.used-region-side-pre.used-region-side-post #region-main .mform:not(.unresponsive) .femptylabel
.fitemtitle{display:inline-block;width:auto;margin-right:8px}.used-region-side-pre.used-region-side-post #region-main .mform:not(.unresponsive) .femptylabel
.felement{display:inline-block;margin-top:4px;padding-top:5px;width:auto}.used-region-side-pre.used-region-side-post #region-main .mform:not(.unresponsive) .fitem_fcheckbox .fitemtitle,.used-region-side-pre.used-region-side-post #region-main .mform:not(.unresponsive) .fitem_fcheckbox
.felement{display:inline-block;width:auto}.used-region-side-pre.used-region-side-post #region-main .mform:not(.unresponsive) .fitem_fcheckbox
.felement{padding:6px}.used-region-side-pre.used-region-side-post.dir-rtl #region-main .mform:not(.unresponsive) .femptylabel
.fitemtitle{margin-right:0;margin-left:8px}.used-region-side-pre.used-region-side-post.dir-rtl #region-main .mform:not(.unresponsive) .fitem
.fitemtitle{text-align:right}.used-region-side-pre.used-region-side-post.dir-rtl #region-main .mform:not(.unresponsive) .fitem
.felement{margin-right:0;float:right;padding-right:0;padding-left:0}.used-region-side-pre.used-region-side-post.dir-rtl #region-main .mform:not(.unresponsive) .fitem_fcheckbox
.felement{float:right}}#fitem_id_availabilityconditionsjson *[aria-hidden=true]{display:none}#fitem_id_availabilityconditionsjson select,#fitem_id_availabilityconditionsjson input[type=text]{position:relative;top:4px}#fitem_id_availabilityconditionsjson
label{display:inline}#fitem_id_availabilityconditionsjson .availability-group{margin-right:8px}#fitem_id_availabilityconditionsjson .availability-item{margin-bottom:6px}#fitem_id_availabilityconditionsjson .availability-none{margin-left:20px;margin-bottom:4px}#fitem_id_availabilityconditionsjson .availability-plugincontrols{padding:2px
0 0 4px;background:none repeat scroll 0 0 #f5f5f5;border:1px
solid #eee;border-radius:4px;display:inline-block;margin-right:8px}#fitem_id_availabilityconditionsjson .availability-plugincontrols
select{width:auto;max-width:200px}#fitem_id_availabilityconditionsjson .availability-eye,#fitem_id_availabilityconditionsjson .availability-delete{margin-right:8px}#fitem_id_availabilityconditionsjson .availability-eye[aria-hidden=true]{display:inline;visibility:hidden}#fitem_id_availabilityconditionsjson .availability-list>.availability-eye
img{vertical-align:top;margin-top:12px}#fitem_id_availabilityconditionsjson .availability-button{margin-left:15px}#fitem_id_availabilityconditionsjson .availability-childlist>.availability-inner{display:inline-block;background:#f5f5f5;border:1px
solid #eee;border-radius:4px;padding:6px;margin-bottom:6px}#fitem_id_availabilityconditionsjson .availability-childlist .availability-childlist>.availability-inner{background:white}#fitem_id_availabilityconditionsjson .availability-connector{margin-left:20px;margin-bottom:6px}.dir-rtl #fitem_id_availabilityconditionsjson .availability-group{margin-right:0;margin-left:8px}.dir-rtl #fitem_id_availabilityconditionsjson .availability-none{margin-right:20px;margin-left:0}.dir-rtl #fitem_id_availabilityconditionsjson .availability-plugincontrols{padding-right:4px;padding-left:0;margin-right:0;margin-left:8px}.dir-rtl #fitem_id_availabilityconditionsjson .availability-eye,.dir-rtl #fitem_id_availabilityconditionsjson .availability-delete{margin-left:8px;margin-right:0}.dir-rtl #fitem_id_availabilityconditionsjson .availability-button{margin-right:15px;margin-left:0}.dir-rtl #fitem_id_availabilityconditionsjson .availability-connector{margin-right:20px;margin-left:0}.mform .error .availability-field{color:#333}.availability-dialogue .moodle-dialogue .moodle-dialogue-bd{padding-left:0;padding-right:0;padding-bottom:2px}.availability-dialogue
ul{display:block;margin:0}.availability-dialogue
li{display:block;list-style-type:none;padding:0
0 4px;clear:both;border-bottom:1px solid #eee;margin-bottom:4px}.availability-dialogue ul
button{float:left;margin-left:1em;min-width:140px;margin-top:4px}.availability-dialogue
label{margin-left:170px;margin-right:1em;margin-bottom:0}.availability-dialogue .availability-buttons
button{margin-left:1em;margin-right:1em;margin-top:4px}.dir-rtl .availability-dialogue ul
button{float:right;margin-right:1em;margin-left:0}.dir-rtl .availability-dialogue
label{margin-right:170px;margin-left:1em}textarea[cols],input[size]{width:auto}.form-autocomplete-selection{margin:.2em;min-height:21px}.form-autocomplete-multiple [role=listitem]{cursor:pointer}.form-autocomplete-suggestions{position:absolute;background-color:white;border:2px
solid #eee;border-radius:3px;min-width:206px;max-height:20em;overflow:auto;margin:0;padding:0;margin-top:-0.2em;z-index:1}.form-autocomplete-suggestions
li{list-style-type:none;padding:.2em;margin:0;cursor:pointer;color:#333}.form-autocomplete-suggestions li:hover{background-color:#00a3f4;color:#fff}.form-autocomplete-suggestions li[aria-selected=true]{background-color:#e5e5e5;color:#555}.form-autocomplete-downarrow{color:#333;position:relative;top:-0.3em;left:-1.5em;cursor:pointer}.dir-rtl .form-autocomplete-downarrow{right:-1.5em;left:inherit}.form-autocomplete-selection:focus{outline:none}.form-autocomplete-selection [data-active-selection=true]{padding:.5em;font-size:large}select{width:auto}.path-mod-forum .forumsearch input,.path-mod-forum .forumsearch
.helptooltip{margin:0
3px}.path-mod-forum .forumheaderlist,.path-mod-forum .forumheaderlist
td{border:none}.path-mod-forum .forumheaderlist thead .header,.path-mod-forum .forumheaderlist tbody .discussion
td{white-space:normal;vertical-align:top;padding-left:.5em;padding-right:.5em}.path-mod-forum .forumheaderlist thead
.header{white-space:normal;vertical-align:top}.path-mod-forum .forumheaderlist thead
.header.replies{text-align:center}.path-mod-forum .forumheaderlist thead
.header.lastpost{text-align:right}.path-mod-forum .forumheaderlist thead .header th.discussionsubscription,.path-mod-forum .forumheaderlist tbody .discussion
td.discussionsubscription{width:16px;padding-left:.5em;padding-right:.5em}.path-mod-forum .forumheaderlist .discussion .author,.path-mod-forum .forumheaderlist .discussion .replies,.path-mod-forum .forumheaderlist .discussion
.lastpost{white-space:normal}.path-mod-forum .forumheaderlist .discussion .discussionsubscription,.path-mod-forum .forumheaderlist .discussion
.replies{text-align:center}.path-mod-forum .forumheaderlist .discussion .topic,.path-mod-forum .forumheaderlist .discussion .discussionsubscription,.path-mod-forum .forumheaderlist .discussion .topic.starter,.path-mod-forum .forumheaderlist .discussion .picture,.path-mod-forum .forumheaderlist .discussion .author,.path-mod-forum .forumheaderlist .discussion .replies,.path-mod-forum .forumheaderlist .discussion
.lastpost{vertical-align:top}.forumpost{min-height:20px;padding:19px;margin-bottom:20px;background-color:#f5f5f5;border:1px
solid #e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);border-color:#e3e3e3;padding:6px}.forumpost
blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}.forumpost
.header{margin-bottom:3px}.forumpost .picture
img{margin:3px}.forumpost .picture
img.userpicture{margin-left:3px;margin-right:10px}.forumpost .content
.posting.fullpost{margin-top:8px}.forumpost .row .topic,.forumpost .row .content-mask,.forumpost .row
.options{margin-left:48px}.forumpost
.row.side{clear:both}.dir-rtl .forumpost .picture
img.userpicture{margin-left:10px;margin-right:3px}.dir-rtl .forumpost .row .topic,.dir-rtl .forumpost .row .content-mask,.dir-rtl .forumpost .row
.options{margin-left:0;margin-right:48px}.forumpost .row
.left{width:48px}.forumpost .options
.commands{margin-left:0}.forumpost
.subject{font-weight:bold}.forumsearch input[type=text]{margin-bottom:0 !important}#page-mod-forum-discuss
.discussioncontrols{width:auto;margin:0}#page-footer{margin-top:1em;padding:1em
0;border-top:2px solid #ddd}.maincalendar .calendarmonth td,.maincalendar .calendarmonth
th{border:1px
dotted #ddd}.path-grade-report-grader
h1{text-align:inherit}#page-mod-chat-gui_basic
input#message{max-width:100%}#page-mod-data-view
#singleimage{width:auto}.path-mod-data
form{margin-top:10px}.template_heading{margin-top:10px}.breadcrumb-button{float:right;margin-top:4px}.breadcrumb-button
.singlebutton{float:left;margin-left:4px}.dir-rtl .nav-tabs>li,.dir-rtl .nav-pills>li{float:right}.dir-rtl .navbar
.brand{padding:10px
0 10px 20px;float:right}.navbar-inverse .logininfo
a{color:#999}.navbar-inverse .logininfo a:hover{background-color:transparent;color:#fff}.navbar-fixed-top,.navbar-fixed-bottom{z-index:4030}.dir-rtl .breadcrumb-button,.dir-rtl .navbar .btn-navbar{float:left}.dir-rtl .breadcrumb-button
.singlebutton{float:right;margin-right:4px;margin-left:0}.dir-rtl .breadcrumb-button .singlebutton div,.dir-rtl .breadcrumb-button .singlebutton div input[type="submit"]{margin-right:5px;margin-left:0}.ie .row-fluid .desktop-first-column{margin-left:0}.langmenu
form{margin:0}.container-fluid{max-width:1680px;margin:0
auto}canvas{-ms-touch-action:auto}div#dock{display:none}.path-mod-choice .horizontal
.choices{margin:0}.path-mod-choice .horizontal .choices
.option{display:inline-block;padding:10px}.path-mod-choice .results
.data{white-space:normal}.path-mod-lesson
.firstpageoptions{margin:auto;min-width:280px;width:60%}.path-mod-lesson
.centerpadded{padding:5px;text-align:center}.path-mod-wiki .wiki_headingtitle,.path-mod-wiki .midpad,.path-mod-wiki
.wiki_headingtime{text-align:inherit}.path-mod-wiki
.wiki_contentbox{width:100%}.dropdown-menu>li>a{padding:3px
20px 3px 8px}.dir-rtl .dropdown-menu>li>a{padding:3px
8px 3px 20px}.dir-rtl .dropdown-submenu>.dropdown-menu{-webkit-border-radius:6px 0 6px 6px;-moz-border-radius:6px 0 6px 6px;border-radius:6px 0 6px 6px}.path-mod-survey .surveytable>tbody>tr:nth-of-type(odd){background-color:transparent}.path-mod-survey .surveytable>tbody>tr:nth-of-type(even){background-color:#f9f9f9}.path-mod-survey .surveytable .rblock
label{text-align:center}.path-mod-survey .resultgraph,.path-mod-survey .reportsummary,.path-mod-survey .studentreport,.path-mod-survey .reportbuttons,.path-mod-survey
.centerpara{text-align:center}.dir-rtl.path-mod-forum .forumheaderlist thead
.header.lastpost{text-align:left}.dir-rtl.path-mod-forum .forumheaderlist .discussion
.lastpost{text-align:left}.nav
.caret{margin-left:4px}.dir-rtl .nav
.caret{margin-right:4px}.nav
.divider{overflow:hidden;width:0;height:40px;border-left:1px solid #f2f2f2;border-right:1px solid #fff}.navbar-inverse .nav
.divider{border-left-color:#111;border-right-color:#515151}.dropdown-menu
.divider{width:auto;height:1px;border-left:0 none;border-right:0 none}.usermenu
.login{color:#777;line-height:40px}.usermenu .login
a{color:#0070a8}.usermenu .login a:hover,.usermenu .login a:focus{color:#003d5c;text-decoration:underline}.usermenu .moodle-actionmenu .toggle-display{display:block;opacity:1;color:#777;line-height:40px;height:40px}.usermenu .moodle-actionmenu .toggle-display:hover{color:#333}.usermenu .moodle-actionmenu .toggle-display
.userbutton{height:40px;line-height:40px}.usermenu .moodle-actionmenu .toggle-display .userbutton
.avatars{display:inline-block;height:36px;width:36px;vertical-align:middle;margin-right:6px;margin-left:6px}.usermenu .moodle-actionmenu .toggle-display .userbutton .avatars .avatar,.usermenu .moodle-actionmenu .toggle-display .userbutton .avatars
img{display:block}.usermenu .moodle-actionmenu .toggle-display .userbutton
.usertext{display:inline-block;vertical-align:middle;line-height:1em;color:inherit}.usermenu .moodle-actionmenu .toggle-display .userbutton .usertext .meta,.usermenu .moodle-actionmenu .toggle-display .userbutton .usertext
.role{display:block;font-size:12px}.usermenu .moodle-actionmenu .toggle-display .userbutton .usertext .meta .value,.usermenu .moodle-actionmenu .toggle-display .userbutton .usertext .role
.value{font-weight:bold}.usermenu .moodle-actionmenu .toggle-display .userbutton .usertext
.role{font-weight:bold}.usermenu .moodle-actionmenu .toggle-display
.caret{display:none}.usermenu .moodle-actionmenu .menu .menu-action.icon
img{border-radius:0;background:transparent;box-shadow:none}.usermenu .moodle-actionmenu .menu .menu-action.icon:hover
img{background:#fff;border-radius:4px;box-shadow:0 0 16px rgba(0,0,0,0.125)}.usermenu .moodle-actionmenu[data-enhanced] .menu .menu-action.icon img,.usermenu .moodle-actionmenu[data-enhanced] .menu .menu-action.icon:hover
img{border-radius:0;background:transparent;box-shadow:none}.navbar-inverse .usermenu
.login{color:#999}.navbar-inverse .usermenu .login
a{color:#999}.navbar-inverse .usermenu .login a:hover{color:#fff}.navbar-inverse .usermenu .moodle-actionmenu .toggle-display{color:#999}.navbar-inverse .usermenu .moodle-actionmenu .userbutton
.usertext{color:#999}.navbar-inverse .usermenu .moodle-actionmenu .userbutton .usertext
.meta{color:#999}.navbar-inverse .usermenu .moodle-actionmenu .userbutton .usertext .meta
.value{color:#999}.navbar-inverse .usermenu .moodle-actionmenu:hover
.usertext{color:#fff}.navbar-inverse .usermenu .moodle-actionmenu:hover .usertext
.meta{color:#999}.navbar-inverse .usermenu .moodle-actionmenu:hover .usertext .meta
.value{color:#fff}.navbar-inverse .usermenu .moodle-actionmenu[data-enhanced] .toggle-display.textmenu
.caret{border-top-color:#fff}.navbar-inverse .usermenu .moodle-actionmenu .menu .menu-action.icon
img{border-radius:0;background:transparent;box-shadow:none}.navbar-inverse .usermenu .moodle-actionmenu .menu .menu-action.icon:hover
img{background:#333;border-radius:4px;box-shadow:0 0 16px #fff}.navbar-inverse .usermenu .moodle-actionmenu[data-enhanced] .menu .menu-action.icon img,.navbar-inverse .usermenu .moodle-actionmenu[data-enhanced] .menu .menu-action.icon:hover
img{border-radius:0;background:transparent;box-shadow:none}.jsenabled .usermenu .moodle-actionmenu .toggle-display{display:block}.jsenabled .usermenu .moodle-actionmenu .toggle-display.textmenu{padding-left:8px;padding-right:8px}.jsenabled .usermenu .moodle-actionmenu .toggle-display
.caret{display:inline-block;position:relative;top:9px}.jsenabled .usermenu .moodle-actionmenu>.menubar{display:block;margin:0}.jsenabled .usermenu .moodle-actionmenu>.menu{min-width:160px}.jsenabled .usermenu .moodle-actionmenu>.menu
.filler{display:block;*width:100%;height:1px;margin:9px
1px;*margin:-5px 0 5px;overflow:hidden;background-color:#e5e5e5;border-bottom:1px solid #fff}.jsenabled .usermenu .moodle-actionmenu.show{background-color:#e5e5e5}.jsenabled .usermenu .moodle-actionmenu.show
.menu{padding:5px
0;margin:2px
0 0;background-clip:padding-box;-webkit-box-shadow:0 5px 10px rgba(0,0,0,0.2);-moz-box-shadow:0 5px 10px rgba(0,0,0,0.2);box-shadow:0 5px 10px rgba(0,0,0,0.2)}.jsenabled .usermenu .moodle-actionmenu.show .menu:before{content:'';display:inline-block;border-left:7px solid transparent;border-right:7px solid transparent;border-bottom:7px solid #ccc;border-bottom-color:rgba(0,0,0,0.2);position:absolute;top:-7px}.jsenabled .usermenu .moodle-actionmenu.show .menu:after{content:'';display:inline-block;border-left:6px solid transparent;border-right:6px solid transparent;border-bottom:6px solid #fff;position:absolute;top:-6px}.jsenabled .usermenu .moodle-actionmenu.show .menu
a{border-radius:0}.jsenabled .usermenu .moodle-actionmenu.show .menu a:focus{text-decoration:none}.jsenabled .usermenu .moodle-actionmenu.show .menu a:hover{text-decoration:none;background-color:#00699e;background-image:-moz-linear-gradient(top, #0070a8, #005f8f);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#0070a8), to(#005f8f));background-image:-webkit-linear-gradient(top, #0070a8, #005f8f);background-image:-o-linear-gradient(top, #0070a8, #005f8f);background-image:linear-gradient(to bottom, #0070a8, #005f8f);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff0070a8', endColorstr='#ff005f8f', GradientType=0)}.jsenabled .usermenu .moodle-actionmenu.show .menu.align-tr-br{margin-top:2px}.jsenabled .navbar-inverse .usermenu .moodle-actionmenu.show{background-color:#111}.dir-ltr
.usermenu{float:right}.dir-ltr .usermenu>.moodle-actionmenu>.menu:before{right:9px}.dir-ltr .usermenu>.moodle-actionmenu>.menu:after{right:10px}.dir-ltr .usermenu>.moodle-actionmenu>.menubar li
a{text-align:right}.dir-ltr.userloggedinas .usermenu .userbutton .avatars
.avatar.current{left:16px}.dir-rtl
.usermenu{float:left}.dir-rtl .usermenu>.moodle-actionmenu>.menu{margin-right:0}.dir-rtl .usermenu>.moodle-actionmenu>.menu:before{left:9px}.dir-rtl .usermenu>.moodle-actionmenu>.menu:after{left:10px}.dir-rtl .usermenu>.moodle-actionmenu>.menubar li
a{text-align:left}.dir-rtl.userloggedinas .usermenu .userbutton .avatars
.avatar.current{left:-14px}.userloggedinas .usermenu .userbutton .avatars
.avatar{overflow:hidden}.userloggedinas .usermenu .userbutton .avatars
.avatar.current{position:relative;top:4px;left:4px;width:20px;height:20px;margin-top:11px;margin-bottom:-34px;border:1px
solid #fff;border-radius:50%;box-shadow:-2px -2px 16px rgba(0,0,0,0.25)}.userloggedinas .usermenu .userbutton .avatars .avatar
img{width:inherit;height:inherit}.path-mod-quiz #mod_quiz_navblock
.qnbutton{text-decoration:none;font-size:14px;line-height:20px;font-weight:normal;background-color:#fff;background-image:none;height:40px;width:30px;border-radius:3px;border:0;overflow:visible;margin:0
6px 6px 0}.path-mod-quiz #mod_quiz_navblock
span.qnbutton{cursor:default;background-color:#eee;color:#555}.path-mod-quiz #mod_quiz_navblock a.qnbutton:hover,.path-mod-quiz #mod_quiz_navblock a.qnbutton:active,.path-mod-quiz #mod_quiz_navblock a.qnbutton:focus{text-decoration:underline}.path-mod-quiz #mod_quiz_navblock .qnbutton
.thispageholder{border:1px
solid;border-radius:3px;z-index:1}.path-mod-quiz #mod_quiz_navblock .qnbutton.thispage
.thispageholder{border-width:3px}.path-mod-quiz #mod_quiz_navblock .allquestionsononepage .qnbutton.thispage
.thispageholder{border-width:1px}.path-mod-quiz #mod_quiz_navblock .qnbutton.flagged
.thispageholder{background:transparent url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=mod%2Fquiz%2Fflag-on) 15px 0 no-repeat}.path-mod-quiz #mod_quiz_navblock .qnbutton
.trafficlight{border:0;background:#fff none center / 10px no-repeat scroll;height:20px;margin-top:20px;border-radius:0 0 3px 3px}.path-mod-quiz #mod_quiz_navblock .qnbutton.notyetanswered .trafficlight,.path-mod-quiz #mod_quiz_navblock .qnbutton.invalidanswer
.trafficlight{background-color:#fff}.path-mod-quiz #mod_quiz_navblock .qnbutton.invalidanswer
.trafficlight{background-image:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=mod%2Fquiz%2Fwarningtriangle)}.path-mod-quiz #mod_quiz_navblock .qnbutton.correct
.trafficlight{background-image:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=mod%2Fquiz%2Fcheckmark);background-color:#468847}.path-mod-quiz #mod_quiz_navblock .qnbutton.blocked
.trafficlight{background-image:url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Flocked);background-color:#eee}.path-mod-quiz #mod_quiz_navblock .qnbutton.notanswered .trafficlight,.path-mod-quiz #mod_quiz_navblock .qnbutton.incorrect
.trafficlight{background-color:#b94a48}.path-mod-quiz #mod_quiz_navblock .qnbutton.partiallycorrect
.trafficlight{background-image:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=mod%2Fquiz%2Fwhitecircle);background-color:#f89406}.path-mod-quiz #mod_quiz_navblock .qnbutton.complete .trafficlight,.path-mod-quiz #mod_quiz_navblock .qnbutton.answersaved .trafficlight,.path-mod-quiz #mod_quiz_navblock .qnbutton.requiresgrading
.trafficlight{background-color:#999}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax{background-color:#fff}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax .yui-layout-unit div.yui-layout-bd-nohd,.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax .yui-layout-unit div.yui-layout-bd-noft,.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax .yui-layout-unit div.yui-layout-bd,.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax .yui-layout-unit-right,.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax .yui-layout-unit-bottom{border:0}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax .yui-layout-unit-right,.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax .yui-layout-unit-bottom{min-height:20px;padding:19px;margin-bottom:20px;background-color:#f5f5f5;border:1px
solid #e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);border-color:#e3e3e3;border-radius:0}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax .yui-layout-unit-right blockquote,.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax .yui-layout-unit-bottom
blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax .yui-layout-unit div.yui-layout-bd{background-color:transparent}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-input-area table.generaltable,.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-input-area table.generaltable
td.cell{border:0;padding:3px
15px;white-space:nowrap}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-input-area table.generaltable input,.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-input-area table.generaltable td.cell
input{margin:0
10px}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-input-area table.generaltable input#input-message,.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-input-area table.generaltable td.cell input#input-message{width:45%;margin:auto}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-input-area table.generaltable a,.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-input-area table.generaltable td.cell
a{margin:0
5px}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-userlist{padding:10px
5px}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-userlist #users-list{border-top:1px solid #ddd;border-bottom:1px solid #fff}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-userlist #users-list
li{border-top:1px solid #fff;border-bottom:1px solid #ddd;padding:5px
10px}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-userlist #users-list
img{margin-right:8px;border:1px
solid #ccc;border-radius:4px;max-width:none}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-messages{margin:20px
25px}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-messages .chat-event.course-theme{text-align:center;margin:10px
0;font-size:11.9px;color:#777}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-messages .chat-message.course-theme{background-color:#fff;border:1px
dotted #ddd;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;padding:4px
10px;margin:10px
0}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-messages .chat-message.course-theme
.time{float:right;font-size:11px;color:#777}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-messages .mdl-chat-my-entry .chat-message.course-theme{background-color:#f6f6f6}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax #chat-messages .mdl-chat-my-entry .chat-message.course-theme
.user{font-weight:bold}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax.dir-rtl .yui-layout-unit-right{padding:0}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax.dir-rtl .yui-layout-unit div.yui-layout-bd{text-align:right}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax.dir-rtl #chat-userlist #users-list
img{margin-left:8px}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax.dir-rtl #chat-messages .chat-message.course-theme
.time{float:left}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax.dir-rtl #chat-messages .chat-message.course-theme
.user{float:right}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax.dir-rtl #chat-messages .chat-message.course-theme .chat-message-meta{height:20px}.yui-skin-sam .yui-layout.path-mod-chat-gui_ajax.dir-rtl #chat-messages .chat-message.course-theme
.text{text-align:right}#page-report-participation-index .participationselectform div
label{display:inline;margin:0
5px}#page-report-participation-index.dir-ltr .participationselectform div label[for=menuinstanceid]{margin-left:0}#page-report-participation-index.dir-rtl .participationselectform div label[for=menuinstanceid]{margin-right:0}.path-backup .mform
.grouped_settings.section_level{min-height:20px;padding:19px;margin-bottom:20px;background-color:#f5f5f5;border:1px
solid #e3e3e3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);box-shadow:inset 0 1px 1px rgba(0,0,0,0.05);border-color:#e3e3e3;padding:10px
0 0 0;clear:both}.path-backup .mform .grouped_settings.section_level
blockquote{border-color:#ddd;border-color:rgba(0,0,0,0.15)}.path-backup .mform
.grouped_settings{clear:both;overflow:hidden}.path-backup .include_setting,.path-backup .grouped_settings
.normal_setting{display:inline-block}.path-backup .include_setting.section_level
label{font-weight:bold}.path-backup .mform .fitem
.fitemtitle{width:260px}.path-backup .mform .fitem
.felement{margin-left:280px}.path-backup
.notification.dependencies_enforced{text-align:center;color:#b94a48;font-weight:bold}.path-backup
.backup_progress{text-align:center}.path-backup .backup_progress
.backup_stage{color:#999}.path-backup .backup_progress
.backup_stage.backup_stage_current{font-weight:bold;color:inherit}.path-backup .backup_progress
span.backup_stage.backup_stage_complete{color:inherit}#page-backup-restore
.filealiasesfailures{background-color:#f2dede}#page-backup-restore .filealiasesfailures
.aliaseslist{width:90%;margin:.8em auto;background-color:#fff;border:1px
dotted #666}.path-backup .fitem
.smallicon{vertical-align:text-bottom}.backup-restore .backup-section>h2.header,.backup-restore .backup-section .backup-sub-section
h3{display:block;width:100%;padding:0;margin-bottom:20px;font-size:21px;line-height:40px;color:#333;border:0;border-bottom:1px solid #e5e5e5}.backup-restore .backup-section
.noticebox{margin:1em
auto;width:60%;text-align:center}.backup-restore .backup-section.settings-section .detail-pair{width:50%;display:inline-block;*display:inline;*zoom:1}.backup-restore .backup-section.settings-section .detail-pair-label{width:65%}.backup-restore .backup-section.settings-section .detail-pair-value{width:25%}.backup-restore
.activitytable{min-width:500px}.backup-restore .activitytable
.modulename{width:100px}.backup-restore .activitytable
.moduleincluded{width:50px}.backup-restore .activitytable
.userinfoincluded{width:50px}.backup-restore .detail-pair-label{display:inline-block;*display:inline;*zoom:1;width:25%;padding:8px;margin:0;text-align:right;font-weight:bold;vertical-align:top}.backup-restore .detail-pair-value{display:inline-block;*display:inline;*zoom:1;width:65%;padding:8px;margin:0}.backup-restore .detail-pair-value>.sub-detail{display:block;font-size:11.9px;color:#999}.backup-restore>.singlebutton{text-align:right}.path-backup .mform .fgroup
.proceedbutton{float:right;margin-right:5%}.path-backup .mform .fgroup
.oneclickbackup{float:right}.restore-course-search .rcs-results{width:70%;min-width:400px}.restore-course-search .rcs-results
table{width:100%;margin:0;border-width:0}.restore-course-search .rcs-results table .no-overflow{max-width:600px}.restore-course-search .rcs-results
.paging{text-align:left;margin:0;background-color:#eee;padding:3px}.restore-course-category .rcs-results{width:70%;min-width:400px;border:1px
solid #ddd;margin:5px
0}.restore-course-category .rcs-results
table{width:100%;margin:0;border-width:0}.restore-course-category .rcs-results table .no-overflow{max-width:600px}.restore-course-category .rcs-results
.paging{text-align:left;margin:0;background-color:#eee;padding:3px}.path-backup
.wibbler{width:500px;margin:0
auto 10px;border-bottom:1px solid black;border-right:1px solid black;border-left:1px solid black;position:relative;min-height:4px}.path-backup .wibbler
.wibble{position:absolute;left:0;right:0;top:0;height:4px}.path-backup .wibbler
.state0{background:#eee}.path-backup .wibbler
.state1{background:#ddd}.path-backup .wibbler
.state2{background:#ccc}.path-backup .wibbler
.state3{background:#bbb}.path-backup .wibbler
.state4{background:#aaa}.path-backup .wibbler
.state5{background:#999}.path-backup .wibbler
.state6{background:#888}.path-backup .wibbler
.state7{background:#777}.path-backup .wibbler
.state8{background:#666}.path-backup .wibbler
.state9{background:#555}.path-backup .wibbler
.state10{background:#444}.path-backup .wibbler
.state11{background:#333}.path-backup .wibbler
.state12{background:#222}.path-backup
.backup_log{margin-top:2em}.path-backup .backup_log
h2{font-size:1em}.path-backup
.backup_log_contents{border:1px
solid #ddd;padding:10px;height:300px;overflow-y:scroll}.dir-rtl.path-backup .mform .fgroup
.proceedbutton{float:left;margin-left:5%;margin-right:0}.dir-rtl.path-backup .mform .fgroup
.oneclickbackup{float:left}table.flexible,.generaltable{width:100%;margin-bottom:20px}table.flexible th,.generaltable th,table.flexible td,.generaltable
td{padding:8px;line-height:20px;text-align:left;vertical-align:top;border-top:1px solid #ddd}table.flexible th,.generaltable
th{font-weight:bold}table.flexible thead th,.generaltable thead
th{vertical-align:bottom}table.flexible caption+thead tr:first-child th,.generaltable caption+thead tr:first-child th,table.flexible caption+thead tr:first-child td,.generaltable caption+thead tr:first-child td,table.flexible colgroup+thead tr:first-child th,.generaltable colgroup+thead tr:first-child th,table.flexible colgroup+thead tr:first-child td,.generaltable colgroup+thead tr:first-child td,table.flexible thead:first-child tr:first-child th,.generaltable thead:first-child tr:first-child th,table.flexible thead:first-child tr:first-child td,.generaltable thead:first-child tr:first-child
td{border-top:0}table.flexible tbody+tbody,.generaltable tbody+tbody{border-top:2px solid #ddd}table.flexible .table,.generaltable
.table{background-color:#fff}.singlebutton
div{display:inline-block;margin-right:5px;margin-bottom:5px;margin-left:5px}#notice .buttons
.singlebutton{display:inline-block}.continuebutton{text-align:center}p.arrow_button{margin-top:5em;text-align:center}p.arrow_button
#remove{margin:3em
auto 5em}p.arrow_button
input{display:block;width:100%;padding-left:0;padding-right:0;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}#addcontrols{margin-top:30px;text-align:center;margin-bottom:3em}#addcontrols
label{display:inline}#addcontrols input,#removecontrols
input{display:block;width:100%;padding-left:0;padding-right:0;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;margin:auto}.btn-lineup{margin:0
0 10px 5px}input[name="searchwikicontent"]+input[type="submit"],select+input[type="submit"],input[type="text"]+input[type="button"],input[type="password"]+input[type="submit"],input[type="text"]+button,input[type="text"]+input[type="submit"]{margin:0
0 10px 5px}button,input.form-submit,input[type="button"],input[type="submit"],input[type="reset"]{display:inline-block;*display:inline;*zoom:1;padding:4px
12px;margin-bottom:0;font-size:14px;line-height:20px;text-align:center;vertical-align:middle;cursor:pointer;color:#333;text-shadow:0 1px 1px rgba(255,255,255,0.75);background-color:#f5f5f5;background-image:-moz-linear-gradient(top, #fff, #e6e6e6);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#fff), to(#e6e6e6));background-image:-webkit-linear-gradient(top, #fff, #e6e6e6);background-image:-o-linear-gradient(top, #fff, #e6e6e6);background-image:linear-gradient(to bottom, #fff, #e6e6e6);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff', endColorstr='#ffe6e6e6', GradientType=0);border-color:#e6e6e6 #e6e6e6 #bfbfbf;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);*background-color:#e6e6e6;filter:progid:DXImageTransform.Microsoft.gradient(enabled = false);border:1px
solid #ccc;*border:0;border-bottom-color:#b3b3b3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;*margin-left:.3em;-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05);-moz-box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05);box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05)}button:hover,input.form-submit:hover,input[type="button"]:hover,input[type="submit"]:hover,input[type="reset"]:hover,button:focus,input.form-submit:focus,input[type="button"]:focus,input[type="submit"]:focus,input[type="reset"]:focus,button:active,input.form-submit:active,input[type="button"]:active,input[type="submit"]:active,input[type="reset"]:active,button.active,input.form-submit.active,input[type="button"].active,input[type="submit"].active,input[type="reset"].active,button.disabled,input.form-submit.disabled,input[type="button"].disabled,input[type="submit"].disabled,input[type="reset"].disabled,button[disabled],input.form-submit[disabled],input[type="button"][disabled],input[type="submit"][disabled],input[type="reset"][disabled]{color:#333;background-color:#e6e6e6;*background-color:#d9d9d9}button:active,input.form-submit:active,input[type="button"]:active,input[type="submit"]:active,input[type="reset"]:active,button.active,input.form-submit.active,input[type="button"].active,input[type="submit"].active,input[type="reset"].active{background-color:#ccc \9}button:first-child,input.form-submit:first-child,input[type="button"]:first-child,input[type="submit"]:first-child,input[type="reset"]:first-child{*margin-left:0}button:hover,input.form-submit:hover,input[type="button"]:hover,input[type="submit"]:hover,input[type="reset"]:hover,button:focus,input.form-submit:focus,input[type="button"]:focus,input[type="submit"]:focus,input[type="reset"]:focus{color:#333;text-decoration:none;background-position:0 -15px;-webkit-transition:background-position .1s linear;-moz-transition:background-position .1s linear;-o-transition:background-position .1s linear;transition:background-position .1s linear}button:focus,input.form-submit:focus,input[type="button"]:focus,input[type="submit"]:focus,input[type="reset"]:focus{outline:thin dotted #333;outline:5px
auto -webkit-focus-ring-color;outline-offset:-2px}button.active,input.form-submit.active,input[type="button"].active,input[type="submit"].active,input[type="reset"].active,button:active,input.form-submit:active,input[type="button"]:active,input[type="submit"]:active,input[type="reset"]:active{background-image:none;outline:0;-webkit-box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05);-moz-box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05);box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05)}button.disabled,input.form-submit.disabled,input[type="button"].disabled,input[type="submit"].disabled,input[type="reset"].disabled,button[disabled],input.form-submit[disabled],input[type="button"][disabled],input[type="submit"][disabled],input[type="reset"][disabled]{cursor:default;background-image:none;opacity:.65;filter:alpha(opacity=65);-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}button .label,input.form-submit .label,input[type="button"] .label,input[type="submit"] .label,input[type="reset"] .label,button .badge,input.form-submit .badge,input[type="button"] .badge,input[type="submit"] .badge,input[type="reset"] .badge{position:relative;top:-1px}button,input.form-submit,input[type="button"],input[type="submit"],input[type="reset"]{margin:0
0 10px 5px}button.yui3-button.closebutton{background-position:0 0}button.yui3-button.closebutton:hover{background-position:0 0}input.fp-btn-choose{padding:2px
10px;font-size:11.9px;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.user-enroller-panel .uep-search-results .user .options .enrol,.user-enroller-panel .uep-search-results .cohort .options
.enrol{padding:0
6px;font-size:10.5px;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.user-enroller-panel .uep-search-results .user .options .enrol .label,.user-enroller-panel .uep-search-results .cohort .options .enrol .label,.user-enroller-panel .uep-search-results .user .options .enrol .badge,.user-enroller-panel .uep-search-results .cohort .options .enrol
.badge{top:0}.gradetreebox
h4{font-size:14px}.gradetreebox th.cell,.gradetreebox input[type=text]{width:auto}.gradetreebox input[type=text],.gradetreebox
select{margin-bottom:0}.core_grades_notices
.singlebutton{display:inline-block}#page-grade-grading-manage #activemethodselector
label{display:inline-block}#page-grade-grading-manage #activemethodselector
.helptooltip{margin-right:.5em}#page-grade-grading-manage
.actions{display:block;text-align:center;margin-bottom:1em}#page-grade-grading-manage .actions
.action{*display:inline;*zoom:1;padding:4px
12px;margin-bottom:0;font-size:14px;line-height:20px;vertical-align:middle;cursor:pointer;color:#333;text-shadow:0 1px 1px rgba(255,255,255,0.75);background-color:#f5f5f5;background-image:-moz-linear-gradient(top, #fff, #e6e6e6);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#fff), to(#e6e6e6));background-image:-webkit-linear-gradient(top, #fff, #e6e6e6);background-image:-o-linear-gradient(top, #fff, #e6e6e6);background-image:linear-gradient(to bottom, #fff, #e6e6e6);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff', endColorstr='#ffe6e6e6', GradientType=0);border-color:#e6e6e6 #e6e6e6 #bfbfbf;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);*background-color:#e6e6e6;filter:progid:DXImageTransform.Microsoft.gradient(enabled = false);border:1px
solid #ccc;*border:0;border-bottom-color:#b3b3b3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;*margin-left:.3em;-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05);-moz-box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05);box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05);padding:11px
19px;font-size:17.5px;-webkit-border-radius:6px;-moz-border-radius:6px;border-radius:6px;display:inline-block;position:relative;vertical-align:top;width:150px;text-align:center;overflow:hidden;margin:.5em;padding:1em;border:1px
solid #aaa}#page-grade-grading-manage .actions .action:hover,#page-grade-grading-manage .actions .action:focus,#page-grade-grading-manage .actions .action:active,#page-grade-grading-manage .actions .action.active,#page-grade-grading-manage .actions .action.disabled,#page-grade-grading-manage .actions .action[disabled]{color:#333;background-color:#e6e6e6;*background-color:#d9d9d9}#page-grade-grading-manage .actions .action:active,#page-grade-grading-manage .actions
.action.active{background-color:#ccc \9}#page-grade-grading-manage .actions .action:first-child{*margin-left:0}#page-grade-grading-manage .actions .action:hover,#page-grade-grading-manage .actions .action:focus{color:#333;text-decoration:none;background-position:0 -15px;-webkit-transition:background-position .1s linear;-moz-transition:background-position .1s linear;-o-transition:background-position .1s linear;transition:background-position .1s linear}#page-grade-grading-manage .actions .action:focus{outline:thin dotted #333;outline:5px
auto -webkit-focus-ring-color;outline-offset:-2px}#page-grade-grading-manage .actions .action.active,#page-grade-grading-manage .actions .action:active{background-image:none;outline:0;-webkit-box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05);-moz-box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05);box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05)}#page-grade-grading-manage .actions .action.disabled,#page-grade-grading-manage .actions .action[disabled]{cursor:default;background-image:none;opacity:.65;filter:alpha(opacity=65);-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}#page-grade-grading-manage .actions .action .label,#page-grade-grading-manage .actions .action
.badge{position:relative;top:-1px}#page-grade-grading-manage .actions .action .action-icon{display:inline-block;position:relative;height:64px;width:64px}#page-grade-grading-manage .actions .action .action-text{position:relative;top:.4em;font-size:14px}#page-grade-grading-form-rubric-edit .gradingform_rubric_editform
.status{font-size:70%}.gradingform_rubric.editor .addlevel input,.gradingform_rubric.editor .addcriterion
input{background:#fff none no-repeat top left}.dir-rtl #rubric-rubric.gradingform_rubric #rubric-criteria .criterion .level
.score{text-align:right;float:right;margin-left:28px;margin-right:0}.dir-rtl #rubric-rubric.gradingform_rubric #rubric-criteria .criterion .level
.delete{float:left}.dir-rtl #rubric-rubric.gradingform_rubric #rubric-criteria .criterion .level .delete
input{left:0;right:auto}.dir-rtl #rubric-rubric.gradingform_rubric
.addcriterion{margin-right:5px;margin-left:0}.dir-rtl #rubric-rubric.gradingform_rubric .addcriterion
input{padding-right:26px;padding-left:10px;background-position:right 8px top 8px}.dir-rtl #rubric-rubric.gradingform_rubric .options .option
.value{margin-left:0;margin-right:5px}.dir-rtl #rubric-rubric.gradingform_rubric .options .option
input{margin-left:12px;margin-right:5px}#rubric-rubric.gradingform_rubric #rubric-criteria{margin-bottom:1em}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion
.description{vertical-align:top;padding:6px}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .description
textarea{margin-bottom:0;height:115px}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .definition
textarea{width:80%;margin-bottom:0}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion
.score{position:relative;float:left;margin-right:28px}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .score
input{margin-bottom:0}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion
.level{vertical-align:top;padding:6px}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .level
.delete{position:relative;width:32px;height:32px;margin-top:-32px;clear:both;float:right}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .level .delete
input{display:block;position:absolute;right:0;bottom:0;height:24px;width:24px;margin:0}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .level .delete input:hover{background-color:#ddd}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .scorevalue
input{float:none;width:2em}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .scorevalue input.hiddenelement,#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .scorevalue
input.pseudotablink{width:0}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion
.addlevel{vertical-align:middle}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel
input{display:inline-block;*display:inline;*zoom:1;padding:4px
12px;margin-bottom:0;font-size:14px;line-height:20px;text-align:center;vertical-align:middle;cursor:pointer;color:#333;text-shadow:0 1px 1px rgba(255,255,255,0.75);background-color:#f5f5f5;background-image:-moz-linear-gradient(top, #fff, #e6e6e6);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#fff), to(#e6e6e6));background-image:-webkit-linear-gradient(top, #fff, #e6e6e6);background-image:-o-linear-gradient(top, #fff, #e6e6e6);background-image:linear-gradient(to bottom, #fff, #e6e6e6);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff', endColorstr='#ffe6e6e6', GradientType=0);border-color:#e6e6e6 #e6e6e6 #bfbfbf;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);*background-color:#e6e6e6;filter:progid:DXImageTransform.Microsoft.gradient(enabled = false);border:1px
solid #ccc;*border:0;border-bottom-color:#b3b3b3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;*margin-left:.3em;-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05);-moz-box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05);box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05);background-position:0 0;height:30px;margin-right:5px}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input:hover,#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input:focus,#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input:active,#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input.active,#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input.disabled,#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input[disabled]{color:#333;background-color:#e6e6e6;*background-color:#d9d9d9}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input:active,#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel
input.active{background-color:#ccc \9}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input:first-child{*margin-left:0}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input:hover,#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input:focus{color:#333;text-decoration:none;background-position:0 -15px;-webkit-transition:background-position .1s linear;-moz-transition:background-position .1s linear;-o-transition:background-position .1s linear;transition:background-position .1s linear}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input:focus{outline:thin dotted #333;outline:5px
auto -webkit-focus-ring-color;outline-offset:-2px}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input.active,#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input:active{background-image:none;outline:0;-webkit-box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05);-moz-box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05);box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05)}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input.disabled,#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input[disabled]{cursor:default;background-image:none;opacity:.65;filter:alpha(opacity=65);-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input .label,#rubric-rubric.gradingform_rubric #rubric-criteria .criterion .addlevel input
.badge{position:relative;top:-1px}#rubric-rubric.gradingform_rubric
.addcriterion{margin-left:5px;display:inline-block;*display:inline;*zoom:1;padding:4px
12px;margin-bottom:0;font-size:14px;line-height:20px;text-align:center;vertical-align:middle;cursor:pointer;color:#333;text-shadow:0 1px 1px rgba(255,255,255,0.75);background-color:#f5f5f5;background-image:-moz-linear-gradient(top, #fff, #e6e6e6);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#fff), to(#e6e6e6));background-image:-webkit-linear-gradient(top, #fff, #e6e6e6);background-image:-o-linear-gradient(top, #fff, #e6e6e6);background-image:linear-gradient(to bottom, #fff, #e6e6e6);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff', endColorstr='#ffe6e6e6', GradientType=0);border-color:#e6e6e6 #e6e6e6 #bfbfbf;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);*background-color:#e6e6e6;filter:progid:DXImageTransform.Microsoft.gradient(enabled = false);border:1px
solid #ccc;*border:0;border-bottom-color:#b3b3b3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;*margin-left:.3em;-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05);-moz-box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05);box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05);padding:0;margin-bottom:1em}#rubric-rubric.gradingform_rubric .addcriterion:hover,#rubric-rubric.gradingform_rubric .addcriterion:focus,#rubric-rubric.gradingform_rubric .addcriterion:active,#rubric-rubric.gradingform_rubric .addcriterion.active,#rubric-rubric.gradingform_rubric .addcriterion.disabled,#rubric-rubric.gradingform_rubric .addcriterion[disabled]{color:#333;background-color:#e6e6e6;*background-color:#d9d9d9}#rubric-rubric.gradingform_rubric .addcriterion:active,#rubric-rubric.gradingform_rubric
.addcriterion.active{background-color:#ccc \9}#rubric-rubric.gradingform_rubric .addcriterion:first-child{*margin-left:0}#rubric-rubric.gradingform_rubric .addcriterion:hover,#rubric-rubric.gradingform_rubric .addcriterion:focus{color:#333;text-decoration:none;background-position:0 -15px;-webkit-transition:background-position .1s linear;-moz-transition:background-position .1s linear;-o-transition:background-position .1s linear;transition:background-position .1s linear}#rubric-rubric.gradingform_rubric .addcriterion:focus{outline:thin dotted #333;outline:5px
auto -webkit-focus-ring-color;outline-offset:-2px}#rubric-rubric.gradingform_rubric .addcriterion.active,#rubric-rubric.gradingform_rubric .addcriterion:active{background-image:none;outline:0;-webkit-box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05);-moz-box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05);box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05)}#rubric-rubric.gradingform_rubric .addcriterion.disabled,#rubric-rubric.gradingform_rubric .addcriterion[disabled]{cursor:default;background-image:none;opacity:.65;filter:alpha(opacity=65);-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}#rubric-rubric.gradingform_rubric .addcriterion .label,#rubric-rubric.gradingform_rubric .addcriterion
.badge{position:relative;top:-1px}#rubric-rubric.gradingform_rubric .addcriterion
input{margin:0;color:inherit;text-shadow:inherit;border:0
none;line-height:inherit;background:transparent url(/academy/theme/image.php?theme=lambda&component=core&rev=1533780117&image=t%2Fadd) no-repeat 7px 8px;padding-left:26px}#rubric-rubric.gradingform_rubric
.options{clear:both}#rubric-rubric.gradingform_rubric .options .option
label{margin:0;padding:0;font-size:inherit;font-weight:normal;line-height:2em;color:inherit;text-shadow:none;background-color:transparent}#rubric-rubric.gradingform_rubric .options .option
input{margin-left:5px;margin-right:12px}.path-grade-edit-tree .setup-grades
h4{margin:0}.path-grade-edit-tree .setup-grades .column-rowspan{padding:0;width:24px;min-width:24px;max-width:24px}.path-grade-edit-tree .setup-grades .category td.column-name{padding-left:0}.path-grade-edit-tree .setup-grades td.column-name{padding-left:24px}.path-grade-edit-tree .setup-grades .column-name h4
img.icon{padding-left:0}.path-grade-edit-tree .setup-grades .category input[type="text"],.path-grade-edit-tree .setup-grades .category .column-range,.path-grade-edit-tree .setup-grades .categoryitem,.path-grade-edit-tree .setup-grades
.courseitem{font-weight:bold}.path-grade-edit-tree .setup-grades
.emptyrow{display:none}.path-grade-edit-tree .setup-grades
.gradeitemdescription{font-weight:normal;padding-left:24px}.path-grade-edit-tree .setup-grades .column-weight{white-space:nowrap}.path-grade-edit-tree .setup-grades .column-weight.level3{padding-left:37px}.path-grade-edit-tree .setup-grades .column-weight.level4{padding-left:66px}.path-grade-edit-tree .setup-grades .column-weight.level5{padding-left:95px}.path-grade-edit-tree .setup-grades .column-weight.level6{padding-left:124px}.path-grade-edit-tree .setup-grades .column-weight.level7{padding-left:153px}.path-grade-edit-tree .setup-grades .column-weight.level8{padding-left:182px}.path-grade-edit-tree .setup-grades .column-weight.level9{padding-left:211px}.path-grade-edit-tree .setup-grades .column-weight.level10{padding-left:240px}.path-grade-edit-tree .setup-grades .column-range.level2{padding-left:37px}.path-grade-edit-tree .setup-grades .column-range.level3{padding-left:66px}.path-grade-edit-tree .setup-grades .column-range.level4{padding-left:95px}.path-grade-edit-tree .setup-grades .column-range.level5{padding-left:124px}.path-grade-edit-tree .setup-grades .column-range.level6{padding-left:153px}.path-grade-edit-tree .setup-grades .column-range.level7{padding-left:182px}.path-grade-edit-tree .setup-grades .column-range.level8{padding-left:211px}.path-grade-edit-tree .setup-grades .column-range.level9{padding-left:240px}.path-grade-edit-tree .setup-grades .column-range.level10{padding-left:269px}.path-grade-edit-tree .setup-grades.generaltable
.levelodd{background-color:#f9f9f9}.path-grade-edit-tree .setup-grades.generaltable
.leveleven{background-color:transparent}.dir-rtl.path-grade-edit-tree .setup-grades .category td.column-name{padding-right:0}.dir-rtl.path-grade-edit-tree .setup-grades td.column-name{padding-right:24px}.dir-rtl.path-grade-edit-tree .setup-grades .column-name h4
img.icon{padding-left:4px}.dir-rtl.path-grade-edit-tree .setup-grades
.gradeitemdescription{padding-left:0;padding-right:24px}.dir-rtl.path-grade-edit-tree .setup-grades .column-weight.level3{padding-left:0;padding-right:37px}.dir-rtl.path-grade-edit-tree .setup-grades .column-weight.level4{padding-left:0;padding-right:66px}.dir-rtl.path-grade-edit-tree .setup-grades .column-weight.level5{padding-left:0;padding-right:95px}.dir-rtl.path-grade-edit-tree .setup-grades .column-weight.level6{padding-left:0;padding-right:124px}.dir-rtl.path-grade-edit-tree .setup-grades .column-weight.level7{padding-left:0;padding-right:153px}.dir-rtl.path-grade-edit-tree .setup-grades .column-weight.level8{padding-left:0;padding-right:182px}.dir-rtl.path-grade-edit-tree .setup-grades .column-weight.level9{padding-left:0;padding-right:211px}.dir-rtl.path-grade-edit-tree .setup-grades .column-weight.level10{padding-left:0;padding-right:240px}.dir-rtl.path-grade-edit-tree .setup-grades .column-range.level2{padding-left:0;padding-right:37px}.dir-rtl.path-grade-edit-tree .setup-grades .column-range.level3{padding-left:0;padding-right:66px}.dir-rtl.path-grade-edit-tree .setup-grades .column-range.level4{padding-left:0;padding-right:95px}.dir-rtl.path-grade-edit-tree .setup-grades .column-range.level5{padding-left:0;padding-right:124px}.dir-rtl.path-grade-edit-tree .setup-grades .column-range.level6{padding-left:0;padding-right:153px}.dir-rtl.path-grade-edit-tree .setup-grades .column-range.level7{padding-left:0;padding-right:182px}.dir-rtl.path-grade-edit-tree .setup-grades .column-range.level8{padding-left:0;padding-right:211px}.dir-rtl.path-grade-edit-tree .setup-grades .column-range.level9{padding-left:0;padding-right:240px}.dir-rtl.path-grade-edit-tree .setup-grades .column-range.level10{padding-left:0;padding-right:269px}.path-grade-report .gradeparent
table{-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.path-grade-report .gradeparent tr
.cell{background-color:#fff}.path-grade-report .gradeparent table,.path-grade-report .gradeparent
.cell{border-color:#ddd}.path-grade-report .gradeparent tr:nth-of-type(even) .cell,.path-grade-report .gradeparent .floater .cell,.path-grade-report .gradeparent
.avg{background-color:#f9f9f9}.path-grade-report .gradeparent table
.clickable{cursor:pointer}.path-grade-report-user .user-grade{border:none}.path-grade-report-user .user-grade.generaltable
.levelodd{background-color:#f9f9f9}.path-grade-report-user .user-grade.generaltable
.leveleven{background-color:transparent}.has_dock.path-grade-report-grader .gradeparent .sideonly.floating>.cell,.has_dock.path-grade-report-grader .gradeparent .sideonly.floating>.cell,.has_dock.path-grade-report-grader .gradeparent .sideonly.floating>.cell{padding-left:47px}.has_dock.path-grade-report-grader.dir-rtl .gradeparent .sideonly.floating>.cell,.has_dock.path-grade-report-grader.dir-rtl .gradeparent .sideonly.floating>.cell,.has_dock.path-grade-report-grader.dir-rtl .gradeparent .sideonly.floating>.cell{padding-left:5px;padding-right:47px}.content-only.path-grade-report-grader .gradeparent
table{margin-left:42px}.content-only.path-grade-report-grader.dir-rtl .gradeparent
table{margin-left:0;margin-right:42px}.transform-test-heading{font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;font-size:11px;line-height:36px;text-align:center;font-weight:bold;margin:0;padding:0}body.has_dock
#page{padding-left:45px;padding-right:20px}body.has_dock
div#dock{display:inline}#dock{z-index:12000;width:42px;position:fixed;top:0;left:0;height:100%;background-color:transparent;border-right:0 none}#dock
.nothingdocked{visibility:hidden;display:none}#dock
.dockeditem_container{margin-top:68px}#dock .dockeditem
.firstdockitem{margin-top:1em}#dock
.dockedtitle{display:inline-block;*display:inline;*zoom:1;padding:4px
12px;margin-bottom:0;font-size:14px;line-height:20px;text-align:center;vertical-align:middle;color:#333;text-shadow:0 1px 1px rgba(255,255,255,0.75);background-color:#f5f5f5;background-image:-moz-linear-gradient(top, #fff, #e6e6e6);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#fff), to(#e6e6e6));background-image:-webkit-linear-gradient(top, #fff, #e6e6e6);background-image:-o-linear-gradient(top, #fff, #e6e6e6);background-image:linear-gradient(to bottom, #fff, #e6e6e6);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff', endColorstr='#ffe6e6e6', GradientType=0);border-color:#e6e6e6 #e6e6e6 #bfbfbf;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);*background-color:#e6e6e6;filter:progid:DXImageTransform.Microsoft.gradient(enabled = false);border:1px
solid #ccc;*border:0;border-bottom-color:#b3b3b3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;*margin-left:.3em;-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05);-moz-box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05);box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05);display:block;width:36px;margin:3px;padding:0;cursor:pointer}#dock .dockedtitle:hover,#dock .dockedtitle:focus,#dock .dockedtitle:active,#dock .dockedtitle.active,#dock .dockedtitle.disabled,#dock .dockedtitle[disabled]{color:#333;background-color:#e6e6e6;*background-color:#d9d9d9}#dock .dockedtitle:active,#dock
.dockedtitle.active{background-color:#ccc \9}#dock .dockedtitle:first-child{*margin-left:0}#dock .dockedtitle:hover,#dock .dockedtitle:focus{color:#333;text-decoration:none;background-position:0 -15px;-webkit-transition:background-position .1s linear;-moz-transition:background-position .1s linear;-o-transition:background-position .1s linear;transition:background-position .1s linear}#dock .dockedtitle:focus{outline:thin dotted #333;outline:5px
auto -webkit-focus-ring-color;outline-offset:-2px}#dock .dockedtitle.active,#dock .dockedtitle:active{background-image:none;outline:0;-webkit-box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05);-moz-box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05);box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05)}#dock .dockedtitle.disabled,#dock .dockedtitle[disabled]{cursor:default;background-image:none;opacity:.65;filter:alpha(opacity=65);-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}#dock .dockedtitle .label,#dock .dockedtitle
.badge{position:relative;top:-1px}#dock .dockedtitle
h2{font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;font-size:11px;line-height:36px;text-align:center;font-weight:bold;margin:0;padding:0}#dock .dockedtitle
.filterrotate{margin-left:8px}#dock
.controls{position:absolute;bottom:1em;text-align:center;width:100%}#dock .controls
img{cursor:pointer}#dock .editing_move,#dock .moodle-core-dragdrop-draghandle{display:none}#dockeditempanel{min-width:200px;position:relative;left:100%;padding-left:5px}#dockeditempanel.dockitempanel_hidden{display:none}#dockeditempanel
.dockeditempanel_content{background-color:#f5f5f5;width:384px;border:1px
solid #d5d5d5;-webkit-box-shadow:2px 4px 4px 2px #eee;-moz-box-shadow:2px 4px 4px 2px #eee;box-shadow:2px 4px 4px 2px #eee;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}#dockeditempanel
.dockeditempanel_bd{overflow:auto}#dockeditempanel .dockeditempanel_bd>*{margin:1em}#dockeditempanel .dockeditempanel_bd .block_navigation .block_tree
li{overflow:visible}#dockeditempanel
.dockeditempanel_hd{border-bottom:1px solid #fff;padding:.5em 1em}#dockeditempanel .dockeditempanel_hd
h2{display:block;padding:3px
15px;font-size:11px;font-weight:bold;line-height:20px;color:#999;text-shadow:0 1px 0 rgba(255,255,255,0.5);text-transform:uppercase;font-size:1.1em;padding:0;margin:0;float:left;max-width:85%}#dockeditempanel .dockeditempanel_hd
.commands{display:block;text-align:right}#dockeditempanel .dockeditempanel_hd .commands>a,#dockeditempanel .dockeditempanel_hd .commands>span{margin-left:3px;cursor:pointer}#dockeditempanel .dockeditempanel_hd .commands img,#dockeditempanel .dockeditempanel_hd .commands
input{vertical-align:middle;margin-right:1px}#dockeditempanel .dockeditempanel_hd .commands .hidepanelicon
img{cursor:pointer}#dockeditempanel .dockeditempanel_hd .commands
img.actionmenu{width:auto}.dir-rtl.has_dock
#page{padding-left:20px;padding-right:45px}.dir-rtl
#dock{left:auto;right:0}.dir-rtl #dock .dockedtitle
h2{line-height:25px}.dir-rtl
#dockeditempanel{right:100%}.dir-rtl #dockeditempanel .dockeditempanel_hd
.commands{text-align:left}.columns-autoflow-1to1to1{-webkit-column-count:3;-moz-column-count:3;column-count:3;-webkit-column-gap:20px;-moz-column-gap:20px;column-gap:20px}@media (max-width:767px){.columns-autoflow-1to1to1{-webkit-column-count:1;-moz-column-count:1;column-count:1;-webkit-column-gap:0;-moz-column-gap:0;column-gap:0}}@media (min-width:768px) and (max-width:979px){.dir-rtl .row-fluid.rtl-compatible [class*="span"]{float:right;margin-left:0;*margin-left:0;margin-right:2.76243094%;*margin-right:2.70923945%}.dir-rtl .row-fluid.rtl-compatible [class*="span"]:first-child{margin-right:0}}@media (min-width:980px) and (max-width:1199px){.dir-rtl .row-fluid.rtl-compatible [class*="span"]{float:right;margin-left:0;*margin-left:0;margin-right:2.12765957%;*margin-right:2.07446809%}.dir-rtl .row-fluid.rtl-compatible [class*="span"]:first-child{margin-right:0}}@media (min-width:1200px){.dir-rtl .row-fluid.rtl-compatible [class*="span"]{float:right;margin-left:0;*margin-left:0;margin-right:2.56410256%;*margin-right:2.51091107%}.dir-rtl .row-fluid.rtl-compatible [class*="span"]:first-child{margin-right:0}}@-ms-viewport{width:device-width}.hidden{display:none;visibility:hidden}.visible-phone{display:none !important}.visible-tablet{display:none !important}.hidden-desktop{display:none !important}.visible-desktop{display:inherit !important}@media (min-width:768px) and (max-width:979px){.hidden-desktop{display:inherit !important}.visible-desktop{display:none !important}.visible-tablet{display:inherit !important}.hidden-tablet{display:none !important}}@media (max-width:767px){.hidden-desktop{display:inherit !important}.visible-desktop{display:none !important}.visible-phone{display:inherit !important}.hidden-phone{display:none !important}}.visible-print{display:none !important}@media
print{.visible-print{display:inherit !important}.hidden-print{display:none !important}}@media (min-width:1200px){.row{margin-left:-30px;*zoom:1}.row:before,.row:after{display:table;content:"";line-height:0}.row:after{clear:both}[class*="span"]{float:left;min-height:1px;margin-left:30px}.container,.navbar-static-top .container,.navbar-fixed-top .container,.navbar-fixed-bottom
.container{width:1170px}.span12{width:1170px}.span11{width:1070px}.span10{width:970px}.span9{width:870px}.span8{width:770px}.span7{width:670px}.span6{width:570px}.span5{width:470px}.span4{width:370px}.span3{width:270px}.span2{width:170px}.span1{width:70px}.offset12{margin-left:1230px}.offset11{margin-left:1130px}.offset10{margin-left:1030px}.offset9{margin-left:930px}.offset8{margin-left:830px}.offset7{margin-left:730px}.offset6{margin-left:630px}.offset5{margin-left:530px}.offset4{margin-left:430px}.offset3{margin-left:330px}.offset2{margin-left:230px}.offset1{margin-left:130px}.row-fluid{width:100%;*zoom:1}.row-fluid:before,.row-fluid:after{display:table;content:"";line-height:0}.row-fluid:after{clear:both}.row-fluid [class*="span"]{display:block;width:100%;min-height:30px;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;float:left;margin-left:2.56410256%;*margin-left:2.51091107%}.row-fluid [class*="span"]:first-child{margin-left:0}.row-fluid .controls-row [class*="span"]+[class*="span"]{margin-left:2.56410256%}.row-fluid
.span12{width:100%;*width:99.94680851%}.row-fluid
.span11{width:91.45299145%;*width:91.39979996%}.row-fluid
.span10{width:82.90598291%;*width:82.85279142%}.row-fluid
.span9{width:74.35897436%;*width:74.30578287%}.row-fluid
.span8{width:65.81196581%;*width:65.75877432%}.row-fluid
.span7{width:57.26495726%;*width:57.21176578%}.row-fluid
.span6{width:48.71794872%;*width:48.66475723%}.row-fluid
.span5{width:40.17094017%;*width:40.11774868%}.row-fluid
.span4{width:31.62393162%;*width:31.57074013%}.row-fluid
.span3{width:23.07692308%;*width:23.02373159%}.row-fluid
.span2{width:14.52991453%;*width:14.47672304%}.row-fluid
.span1{width:5.98290598%;*width:5.92971449%}.row-fluid
.offset12{margin-left:105.12820513%;*margin-left:105.02182215%}.row-fluid .offset12:first-child{margin-left:102.56410256%;*margin-left:102.45771959%}.row-fluid
.offset11{margin-left:96.58119658%;*margin-left:96.4748136%}.row-fluid .offset11:first-child{margin-left:94.01709402%;*margin-left:93.91071104%}.row-fluid
.offset10{margin-left:88.03418803%;*margin-left:87.92780506%}.row-fluid .offset10:first-child{margin-left:85.47008547%;*margin-left:85.36370249%}.row-fluid
.offset9{margin-left:79.48717949%;*margin-left:79.38079651%}.row-fluid .offset9:first-child{margin-left:76.92307692%;*margin-left:76.81669394%}.row-fluid
.offset8{margin-left:70.94017094%;*margin-left:70.83378796%}.row-fluid .offset8:first-child{margin-left:68.37606838%;*margin-left:68.2696854%}.row-fluid
.offset7{margin-left:62.39316239%;*margin-left:62.28677941%}.row-fluid .offset7:first-child{margin-left:59.82905983%;*margin-left:59.72267685%}.row-fluid
.offset6{margin-left:53.84615385%;*margin-left:53.73977087%}.row-fluid .offset6:first-child{margin-left:51.28205128%;*margin-left:51.1756683%}.row-fluid
.offset5{margin-left:45.2991453%;*margin-left:45.19276232%}.row-fluid .offset5:first-child{margin-left:42.73504274%;*margin-left:42.62865976%}.row-fluid
.offset4{margin-left:36.75213675%;*margin-left:36.64575377%}.row-fluid .offset4:first-child{margin-left:34.18803419%;*margin-left:34.08165121%}.row-fluid
.offset3{margin-left:28.20512821%;*margin-left:28.09874523%}.row-fluid .offset3:first-child{margin-left:25.64102564%;*margin-left:25.53464266%}.row-fluid
.offset2{margin-left:19.65811966%;*margin-left:19.55173668%}.row-fluid .offset2:first-child{margin-left:17.09401709%;*margin-left:16.98763412%}.row-fluid
.offset1{margin-left:11.11111111%;*margin-left:11.00472813%}.row-fluid .offset1:first-child{margin-left:8.54700855%;*margin-left:8.44062557%}input,textarea,.uneditable-input{margin-left:0}.controls-row [class*="span"]+[class*="span"]{margin-left:30px}input.span12,textarea.span12,.uneditable-input.span12{width:1156px}input.span11,textarea.span11,.uneditable-input.span11{width:1056px}input.span10,textarea.span10,.uneditable-input.span10{width:956px}input.span9,textarea.span9,.uneditable-input.span9{width:856px}input.span8,textarea.span8,.uneditable-input.span8{width:756px}input.span7,textarea.span7,.uneditable-input.span7{width:656px}input.span6,textarea.span6,.uneditable-input.span6{width:556px}input.span5,textarea.span5,.uneditable-input.span5{width:456px}input.span4,textarea.span4,.uneditable-input.span4{width:356px}input.span3,textarea.span3,.uneditable-input.span3{width:256px}input.span2,textarea.span2,.uneditable-input.span2{width:156px}input.span1,textarea.span1,.uneditable-input.span1{width:56px}.thumbnails{margin-left:-30px}.thumbnails>li{margin-left:30px}.row-fluid
.thumbnails{margin-left:0}}@media (min-width:768px) and (max-width:979px){.row{margin-left:-20px;*zoom:1}.row:before,.row:after{display:table;content:"";line-height:0}.row:after{clear:both}[class*="span"]{float:left;min-height:1px;margin-left:20px}.container,.navbar-static-top .container,.navbar-fixed-top .container,.navbar-fixed-bottom
.container{width:724px}.span12{width:724px}.span11{width:662px}.span10{width:600px}.span9{width:538px}.span8{width:476px}.span7{width:414px}.span6{width:352px}.span5{width:290px}.span4{width:228px}.span3{width:166px}.span2{width:104px}.span1{width:42px}.offset12{margin-left:764px}.offset11{margin-left:702px}.offset10{margin-left:640px}.offset9{margin-left:578px}.offset8{margin-left:516px}.offset7{margin-left:454px}.offset6{margin-left:392px}.offset5{margin-left:330px}.offset4{margin-left:268px}.offset3{margin-left:206px}.offset2{margin-left:144px}.offset1{margin-left:82px}.row-fluid{width:100%;*zoom:1}.row-fluid:before,.row-fluid:after{display:table;content:"";line-height:0}.row-fluid:after{clear:both}.row-fluid [class*="span"]{display:block;width:100%;min-height:30px;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;float:left;margin-left:2.76243094%;*margin-left:2.70923945%}.row-fluid [class*="span"]:first-child{margin-left:0}.row-fluid .controls-row [class*="span"]+[class*="span"]{margin-left:2.76243094%}.row-fluid
.span12{width:100%;*width:99.94680851%}.row-fluid
.span11{width:91.43646409%;*width:91.3832726%}.row-fluid
.span10{width:82.87292818%;*width:82.81973669%}.row-fluid
.span9{width:74.30939227%;*width:74.25620078%}.row-fluid
.span8{width:65.74585635%;*width:65.69266486%}.row-fluid
.span7{width:57.18232044%;*width:57.12912895%}.row-fluid
.span6{width:48.61878453%;*width:48.56559304%}.row-fluid
.span5{width:40.05524862%;*width:40.00205713%}.row-fluid
.span4{width:31.49171271%;*width:31.43852122%}.row-fluid
.span3{width:22.9281768%;*width:22.87498531%}.row-fluid
.span2{width:14.36464088%;*width:14.31144939%}.row-fluid
.span1{width:5.80110497%;*width:5.74791348%}.row-fluid
.offset12{margin-left:105.52486188%;*margin-left:105.4184789%}.row-fluid .offset12:first-child{margin-left:102.76243094%;*margin-left:102.65604796%}.row-fluid
.offset11{margin-left:96.96132597%;*margin-left:96.85494299%}.row-fluid .offset11:first-child{margin-left:94.19889503%;*margin-left:94.09251205%}.row-fluid
.offset10{margin-left:88.39779006%;*margin-left:88.29140708%}.row-fluid .offset10:first-child{margin-left:85.63535912%;*margin-left:85.52897614%}.row-fluid
.offset9{margin-left:79.83425414%;*margin-left:79.72787116%}.row-fluid .offset9:first-child{margin-left:77.0718232%;*margin-left:76.96544023%}.row-fluid
.offset8{margin-left:71.27071823%;*margin-left:71.16433525%}.row-fluid .offset8:first-child{margin-left:68.50828729%;*margin-left:68.40190431%}.row-fluid
.offset7{margin-left:62.70718232%;*margin-left:62.60079934%}.row-fluid .offset7:first-child{margin-left:59.94475138%;*margin-left:59.8383684%}.row-fluid
.offset6{margin-left:54.14364641%;*margin-left:54.03726343%}.row-fluid .offset6:first-child{margin-left:51.38121547%;*margin-left:51.27483249%}.row-fluid
.offset5{margin-left:45.5801105%;*margin-left:45.47372752%}.row-fluid .offset5:first-child{margin-left:42.81767956%;*margin-left:42.71129658%}.row-fluid
.offset4{margin-left:37.01657459%;*margin-left:36.91019161%}.row-fluid .offset4:first-child{margin-left:34.25414365%;*margin-left:34.14776067%}.row-fluid
.offset3{margin-left:28.45303867%;*margin-left:28.3466557%}.row-fluid .offset3:first-child{margin-left:25.69060773%;*margin-left:25.58422476%}.row-fluid
.offset2{margin-left:19.88950276%;*margin-left:19.78311978%}.row-fluid .offset2:first-child{margin-left:17.12707182%;*margin-left:17.02068884%}.row-fluid
.offset1{margin-left:11.32596685%;*margin-left:11.21958387%}.row-fluid .offset1:first-child{margin-left:8.56353591%;*margin-left:8.45715293%}input,textarea,.uneditable-input{margin-left:0}.controls-row [class*="span"]+[class*="span"]{margin-left:20px}input.span12,textarea.span12,.uneditable-input.span12{width:710px}input.span11,textarea.span11,.uneditable-input.span11{width:648px}input.span10,textarea.span10,.uneditable-input.span10{width:586px}input.span9,textarea.span9,.uneditable-input.span9{width:524px}input.span8,textarea.span8,.uneditable-input.span8{width:462px}input.span7,textarea.span7,.uneditable-input.span7{width:400px}input.span6,textarea.span6,.uneditable-input.span6{width:338px}input.span5,textarea.span5,.uneditable-input.span5{width:276px}input.span4,textarea.span4,.uneditable-input.span4{width:214px}input.span3,textarea.span3,.uneditable-input.span3{width:152px}input.span2,textarea.span2,.uneditable-input.span2{width:90px}input.span1,textarea.span1,.uneditable-input.span1{width:28px}}@media (max-width:767px){body{padding-left:20px;padding-right:20px}.navbar-fixed-top,.navbar-fixed-bottom,.navbar-static-top{margin-left:-20px;margin-right:-20px}.container-fluid{padding:0}.dl-horizontal
dt{float:none;clear:none;width:auto;text-align:left}.dl-horizontal
dd{margin-left:0}.container{width:auto}.row-fluid{width:100%}.row,.thumbnails{margin-left:0}.thumbnails>li{float:none;margin-left:0}[class*="span"],.uneditable-input[class*="span"],.row-fluid [class*="span"]{float:none;display:block;width:100%;margin-left:0;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.span12,.row-fluid
.span12{width:100%;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.row-fluid [class*="offset"]:first-child{margin-left:0}.input-large,.input-xlarge,.input-xxlarge,input[class*="span"],select[class*="span"],textarea[class*="span"],.uneditable-input{display:block;width:100%;min-height:30px;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.input-prepend input,.input-append input,.input-prepend input[class*="span"],.input-append input[class*="span"]{display:inline-block;width:auto}.controls-row [class*="span"]+[class*="span"]{margin-left:0}.modal{position:fixed;top:20px;left:20px;right:20px;width:auto;margin:0}.modal.fade{top:-100px}.modal.fade.in{top:20px}}@media (max-width:480px){.nav-collapse{-webkit-transform:translate3d(0, 0, 0)}.page-header h1
small{display:block;line-height:20px}input[type="checkbox"],input[type="radio"]{border:1px
solid #ccc}.form-horizontal .control-label{float:none;width:auto;padding-top:0;text-align:left}.form-horizontal
.controls{margin-left:0}.form-horizontal .control-list{padding-top:0}.form-horizontal .form-actions{padding-left:10px;padding-right:10px}.media .pull-left,.media .pull-right{float:none;display:block;margin-bottom:10px}.media-object{margin-right:0;margin-left:0}.modal{top:10px;left:10px;right:10px}.modal-header
.close{padding:10px;margin:-10px}.carousel-caption{position:static}}@media (max-width:979px){body{padding-top:0}.navbar-fixed-top,.navbar-fixed-bottom{position:static}.navbar-fixed-top{margin-bottom:20px}.navbar-fixed-bottom{margin-top:20px}.navbar-fixed-top .navbar-inner,.navbar-fixed-bottom .navbar-inner{padding:5px}.navbar
.container{width:auto;padding:0}.navbar
.brand{padding-left:10px;padding-right:10px;margin:0
0 0 -5px}.nav-collapse{clear:both}.nav-collapse
.nav{float:none;margin:0
0 10px}.nav-collapse .nav>li{float:none}.nav-collapse .nav>li>a{margin-bottom:2px}.nav-collapse .nav>.divider-vertical{display:none}.nav-collapse .nav .nav-header{color:#777;text-shadow:none}.nav-collapse .nav>li>a,.nav-collapse .dropdown-menu
a{padding:9px
15px;font-weight:bold;color:#777;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.nav-collapse
.btn{padding:4px
10px 4px;font-weight:normal;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px}.nav-collapse .dropdown-menu li+li
a{margin-bottom:2px}.nav-collapse .nav>li>a:hover,.nav-collapse .nav>li>a:focus,.nav-collapse .dropdown-menu a:hover,.nav-collapse .dropdown-menu a:focus{background-color:#f2f2f2}.navbar-inverse .nav-collapse .nav>li>a,.navbar-inverse .nav-collapse .dropdown-menu
a{color:#999}.navbar-inverse .nav-collapse .nav>li>a:hover,.navbar-inverse .nav-collapse .nav>li>a:focus,.navbar-inverse .nav-collapse .dropdown-menu a:hover,.navbar-inverse .nav-collapse .dropdown-menu a:focus{background-color:#111}.nav-collapse.in .btn-group{margin-top:5px;padding:0}.nav-collapse .dropdown-menu{position:static;top:auto;left:auto;float:none;display:none;max-width:none;margin:0
15px;padding:0;background-color:transparent;border:none;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}.nav-collapse .open>.dropdown-menu{display:block}.nav-collapse .dropdown-menu:before,.nav-collapse .dropdown-menu:after{display:none}.nav-collapse .dropdown-menu
.divider{display:none}.nav-collapse .nav>li>.dropdown-menu:before,.nav-collapse .nav>li>.dropdown-menu:after{display:none}.nav-collapse .navbar-form,.nav-collapse .navbar-search{float:none;padding:10px
15px;margin:10px
0;border-top:1px solid #f2f2f2;border-bottom:1px solid #f2f2f2;-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,.1), 0 1px 0 rgba(255,255,255,.1);-moz-box-shadow:inset 0 1px 0 rgba(255,255,255,.1), 0 1px 0 rgba(255,255,255,.1);box-shadow:inset 0 1px 0 rgba(255,255,255,.1), 0 1px 0 rgba(255,255,255,.1)}.navbar-inverse .nav-collapse .navbar-form,.navbar-inverse .nav-collapse .navbar-search{border-top-color:#111;border-bottom-color:#111}.navbar .nav-collapse .nav.pull-right{float:none;margin-left:0}.nav-collapse,.nav-collapse.collapse{overflow:hidden;height:0}.navbar .btn-navbar{display:block}.navbar-static .navbar-inner{padding-left:10px;padding-right:10px}}@media (min-width:980px){.nav-collapse.collapse{height:auto !important;overflow:visible !important}}@media (min-width:980px){.dir-rtl .navbar .nav.pull-right,.dir-rtl .navbar
.logininfo{float:left}.dir-rtl .navbar
.nav{float:right}.dir-rtl .navbar .nav>li{float:right}}@media (min-width:980px){a[id]:empty::before,a[name]:empty::before{display:inline-block;position:relative;content:'';padding-top:40px;margin-top:-40px;vertical-align:top}}@media (min-width:980px) and (max-width:1199px){.form-item .form-label,.mform .fitem div.fitemtitle,.userprofile dl.list dt,.form-horizontal .control-label{width:200px}.form-item .form-setting,.form-item .form-description,.mform .fitem .felement,#page-mod-forum-search .c1,.mform .fdescription.required,.userprofile dl.list dd,.form-horizontal
.controls{margin-left:220px}.dir-rtl .form-item .form-setting,.dir-rtl .form-item .form-description,.dir-rtl .mform .fitem .felement,.dir-rtl .mform .fdescription.required,.dir-rtl .userprofile dl.list dd,.dir-rtl .form-horizontal
.controls{margin-right:220px}#page-mod-forum-search.dir-lrt
.c1{margin-right:220px}.path-admin .buttons,.form-buttons{padding-left:220px}}@media (max-width:767px){.file-picker .fp-repo-area{width:100%;height:auto;max-height:220px;y-scroll:auto;float:none;border:0}.file-picker .fp-repo-items{width:100%;float:none;margin-left:0}.file-picker .fp-login-form .fp-login-input
label{text-align:left}.dir-rtl .file-picker .fp-login-form .fp-login-input
label{text-align:right}.file-picker .fp-content form
td{display:block;width:100%;text-align:left}.dir-rtl .file-picker .fp-content form
td{text-align:right}.fp-content .mdl-right{text-align:left}.dir-rtl .fp-content .mdl-right{text-align:right}.fp-repo-items .fp-navbar{border-top:1px solid #bbb}.dir-rtl .userprofile dl.list dt,.dir-rtl .userprofile dl.list
dd{float:none;text-align:right;margin-right:0}.fp-formset
div{height:auto}}@media (min-width:1200px){.path-question #id_answerhdr
div.fitem_feditor{padding-right:6px}.loginbox.twocolumns
.loginpanel{margin-left:0}.loginbox.twocolumns .loginpanel,.loginbox.twocolumns
.signuppanel{width:48.71794872%;*width:48.66475723%}.form-item .form-label,.mform .fitem div.fitemtitle,.userprofile dl.list dt,.form-horizontal .control-label{width:245px}.form-item .form-setting,.form-item .form-description,.mform .fitem .felement,#page-mod-forum-search .c1,.mform .fdescription.required,.userprofile dl.list dd,.form-horizontal
.controls{margin-left:265px}.dir-rtl .form-item .form-setting,.dir-rtl .form-item .form-description,.dir-rtl .mform .fitem .felement,.dir-rtl .mform .fdescription.required,.dir-rtl .userprofile dl.list dd,.dir-rtl .form-horizontal
.controls{margin-right:165px}.dir-rtl #page-mod-forum-search
.c1{margin-right:265px}.dir-rtl .form-item .form-label,.dir-rtl .mform .fitem div.fitemtitle,.dir-rtl .userprofile dl.list dt,.dir-rtl .form-horizontal .control-label{width:145px}.path-admin .buttons,.form-buttons{padding-left:265px}.dir-rtl .path-admin .buttons,.dir-rtl .form-buttons{padding-right:265px}.empty-region-side-post.used-region-side-pre #region-main.span8,.jsenabled.docked-region-side-post.used-region-side-pre #region-main.span8{width:74.35897436%;*width:74.30578287%}.empty-region-side-post.used-region-side-pre #block-region-side-pre.span4,.jsenabled.docked-region-side-post.used-region-side-pre #block-region-side-pre.span4{width:23.07692308%;*width:23.02373159%}}@media (min-width:980px){.loginbox.twocolumns
.loginpanel{margin-left:0}.loginbox.twocolumns .loginpanel,.loginbox.twocolumns
.signuppanel{width:48.61794872%;*width:48.66475723%}}@media (min-width:768px) and (max-width:979px){.loginbox.twocolumns
.loginpanel{margin-left:0}.loginbox.twocolumns .loginpanel,.loginbox.twocolumns
.signuppanel{width:48.61878453%;*width:48.56559304%}.empty-region-side-post.used-region-side-pre #region-main.span8,.jsenabled.docked-region-side-post.used-region-side-pre #region-main.span8{width:74.30939227%;*width:74.25620078%}.empty-region-side-post.used-region-side-pre #block-region-side-pre.span4,.jsenabled.docked-region-side-post.used-region-side-pre #block-region-side-pre.span4{width:22.9281768%;*width:22.87498531%}}@media (max-width:767px){.loginbox.twocolumns .loginpanel,.loginbox.twocolumns
.signuppanel{display:block;float:none;width:100%;margin-left:0;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}#page-mod-quiz-edit div.quizcontents,.questionbankwindow.block{width:100%;float:none}#page-mod-quiz-edit #block-region-side-pre,#page-mod-quiz-edit #block-region-side-post{clear:both}}@media (max-width:480px){.nav-tabs>li{float:none}.nav-tabs>li>a{margin-right:0}.nav-tabs{border-bottom:0}.nav-tabs>li>a{border:1px
solid #ddd;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0}.nav-tabs>.active>a,.nav-tabs>.active>a:hover{border:1px
solid #ddd}.nav-tabs>li:first-child>a{-webkit-border-top-right-radius:4px;-moz-border-radius-topright:4px;border-top-right-radius:4px;-webkit-border-top-left-radius:4px;-moz-border-radius-topleft:4px;border-top-left-radius:4px}.nav-tabs>li:last-child>a{-webkit-border-bottom-right-radius:4px;-moz-border-radius-bottomright:4px;border-bottom-right-radius:4px;-webkit-border-bottom-left-radius:4px;-moz-border-radius-bottomleft:4px;border-bottom-left-radius:4px}.nav-tabs>li>a:hover,.nav-tabs>li>a:focus{border-color:#ddd;z-index:2}.fp-content-center{display:block;vertical-align:top}.course-content ul.topics li.section,.course-content ul.topics li.section .content,.course-content ul.weeks li.section .content,.course-content ul.weeks li.section,.course-content
ul.section{margin-right:0;margin-left:0;padding:0}.activityinstance{display:block}.editing .course-content .section
.activity{margin-bottom:.2em;padding-bottom:.2em;border-bottom:thin solid #eee}.course-content .section .activity
.commands{text-align:right}.jsenabled .choosercontainer #chooseform
.alloptions{max-width:100%}.jsenabled .choosercontainer #chooseform .instruction,.jsenabled .choosercontainer #chooseform
.typesummary{position:static}.que
.info{float:none;width:auto}.que
.content{margin:0}.path-mod-choice .horizontal .choices
.option{display:block}.path-mod-forum .forumsearch
#search{width:120px}.path-mod-forum .forumheaderlist
.picture{display:none}}@media (min-width:768px){.row-fluid .desktop-first-column{margin-left:0}#page-navbar .breadcrumb-button{display:inline}}@media (max-width:767px){.row-fluid .desktop-first-column{clear:both}}@media (max-width:767px){.form-item .form-label,.mform .fitem
div.fitemtitle{float:none;width:auto;padding-top:0;text-align:left}.form-item .form-label
label{display:inline-block;margin-right:.5em}.form-item .form-setting .form-checkbox{margin-top:0}.form-label span.form-shortname{display:inline-block}.form-item .form-setting,.mform .fitem .felement,.path-backup .mform .fitem .felement,.mform .fdescription.required,.form-item .form-description{margin-left:0}table#form td.submit,.form-buttons,#fitem_id_submitbutton,.fp-content-center form+div,#fgroup_id_buttonar,.form-horizontal .form-actions,.fitem_fsubmit
.felement.fsubmit{padding-left:10px;padding-right:10px}#helppopupbox{width:auto !important;left:0 !important}}@media (min-width:768px) and (max-width:979px){.block_calendar_month .content,.block .minicalendar
td{padding-left:0;padding-right:0}}.dir-rtl .dropdown-menu{right:0;left:auto;margin-right:0}.dir-rtl .navbar .nav>li>.dropdown-menu:before{right:9px;left:auto}.dir-rtl .navbar .nav>li>.dropdown-menu:after{right:10px;left:auto}.dir-rtl .dropdown-submenu>a:after{margin-right:0;margin-left:-10px;float:left;border-right-color:#ccc;border-left-color:transparent;border-width:5px 5px 5px 0}.dir-rtl .dropdown-submenu>.dropdown-menu{right:100%;left:auto}@media (max-width:979px){.nav-collapse{height:0}.nav-collapse .nav>li>a{color:#333}.nav-collapse .nav>li>a:hover,.nav-collapse .nav>li>a:focus,.nav-collapse .dropdown-menu a:hover,.nav-collapse .dropdown-menu a:focus,.nav-collapse .dropdown-submenu a:hover,.nav-collapse .dropdown-submenu a:focus,.nav-collapse .dropdown-submenu a:active,.nav-collapse .dropdown-menu>li>a:hover,.nav-collapse .dropdown-menu>li>a:focus,.nav-collapse .dropdown-submenu:hover>a,.nav-collapse .dropdown-submenu:focus>a{background-image:none;color:#333}.nav-collapse.in{height:auto}.nav-collapse.in .usermenu .moodle-actionmenu[data-enhanced] .toggle-display{display:none}.nav-collapse.in .usermenu .moodle-actionmenu[data-enhanced] .menu{display:block}.nav-collapse.in .usermenu .moodle-actionmenu[data-enhanced] .menu
li{margin:0
.5em}.path-mod-data .box>table>tbody>tr>td{display:block}.path-mod-forum .forumheaderlist thead
.header{font-weight:normal;font-size:12px}.path-mod-forum .forumheaderlist .discussion .author,.path-mod-forum .forumheaderlist .discussion .replies,.path-mod-forum .forumheaderlist .discussion
.lastpost{font-size:12px}.path-mod-forum .forumheaderlist .discussion .replies .unread
a{padding:0}.navbar .nav-collapse.in{border-top:1px solid #d4d4d4}.navbar .nav-collapse.in.pull-left,.navbar .nav-collapse.in.pull-right{float:none}.navbar .nav-collapse.in>.nav{margin:0}.navbar .nav-collapse.in>.nav>li>a{padding-left:20px;border-radius:0}.navbar .nav-collapse.in>.nav .dropdown-menu{margin:0
0 0 15px}.navbar .nav-collapse.in>.nav .dropdown-menu li>a{border-radius:0}.navbar .nav-collapse.in .nav .dropdown-submenu .dropdown-toggle:after,.navbar .nav-collapse.in .nav .dropdown-menu .dropdown-submenu .dropdown-toggle:after{float:none;display:inline-block;width:0;height:0;vertical-align:top;border-top:4px solid #000;border-right:4px solid transparent;border-left:4px solid transparent;content:"";border-top-color:#d4d4d4;margin-left:4px;margin-top:8px}.navbar .nav-collapse.in .nav .dropdown-submenu.open>a,.navbar .nav-collapse.in .nav .dropdown-menu .dropdown-submenu.open>a{background-color:#f2f2f2}.navbar .nav-collapse.in .nav .dropdown-submenu:hover .dropdown-menu,.navbar .nav-collapse.in .nav .dropdown-menu .dropdown-submenu:hover .dropdown-menu{display:none}.navbar .nav-collapse.in .nav .dropdown-submenu:hover.open>a,.navbar .nav-collapse.in .nav .dropdown-menu .dropdown-submenu:hover.open>a{background-color:#f2f2f2}.navbar .nav-collapse.in .nav .dropdown-submenu:hover.open>.dropdown-menu,.navbar .nav-collapse.in .nav .dropdown-menu .dropdown-submenu:hover.open>.dropdown-menu,.navbar .nav-collapse.in .nav .dropdown-submenu:hover.open .open>.dropdown-menu,.navbar .nav-collapse.in .nav .dropdown-menu .dropdown-submenu:hover.open .open>.dropdown-menu{display:block}.navbar .nav-collapse.in .nav .divider,.navbar .nav-collapse.in .nav .dropdown-menu
.divider{width:auto;display:block;height:0;margin:4px
1px;border-left:0 none;border-right:0 none;border-top:1px solid #d4d4d4;border-bottom:1px solid #fff}.navbar-inverse .nav-collapse.in{border-top-color:#252525}.navbar-inverse .nav-collapse.in .nav .dropdown-submenu .dropdown-toggle:after,.navbar-inverse .nav-collapse.in .nav .dropdown-menu .dropdown-submenu .dropdown-toggle:after{border-top-color:#252525}.navbar-inverse .nav-collapse.in .nav .dropdown-submenu.open>a,.navbar-inverse .nav-collapse.in .nav .dropdown-menu .dropdown-submenu.open>a{background-color:#111}.navbar-inverse .nav-collapse.in .nav .dropdown-submenu:hover.open>a,.navbar-inverse .nav-collapse.in .nav .dropdown-menu .dropdown-submenu:hover.open>a{background-color:#111}.navbar-inverse .nav-collapse.in .nav .divider,.navbar-inverse .nav-collapse.in .nav .dropdown-menu
.divider{width:auto;display:block;height:0;margin:4px
1px;border-top:1px solid #111;border-bottom:1px solid #515151}.navbar-inverse .nav-collapse.in .nav>li>a:hover,.navbar-inverse .nav-collapse.in .nav>li>a:focus{color:#fff}.navbar-inverse .nav-collapse.in .dropdown-menu a:hover,.navbar-inverse .nav-collapse.in .dropdown-menu a:focus{color:#fff}.navbar-inverse .nav-collapse.in .dropdown-menu a>li>a:hover,.navbar-inverse .nav-collapse.in .dropdown-menu a>li>a:focus{color:#fff}.navbar-inverse .nav-collapse.in .dropdown-submenu a:hover,.navbar-inverse .nav-collapse.in .dropdown-submenu a:focus,.navbar-inverse .nav-collapse.in .dropdown-submenu a:active{color:#fff}.dir-rtl .navbar .nav-collapse.in>.nav{margin:0}.dir-rtl .navbar .nav-collapse.in>.nav>li>a{padding-left:0;padding-right:20px}.dir-rtl .navbar .nav-collapse.in>.nav .dropdown-menu{margin:0
15px 0 0}.dir-rtl .navbar .nav-collapse.in .dropdown-menu>li>a{padding:9px
15px}.dir-rtl .navbar .nav-collapse.in .nav .dropdown-submenu .dropdown-toggle:after,.dir-rtl .navbar .nav-collapse.in .nav .dropdown-menu .dropdown-submenu .dropdown-toggle:after{margin-left:0;margin-right:4px}}@media (max-width:767px){#filesskin .yui3-panel,#filesskin .file-picker.fp-generallayout{width:100%;left:0}.userprofile dl.list
dt{float:none;clear:none;width:auto;text-align:left}.userprofile dl.list
dd{margin-left:0}#page-mod-wiki-create .mform .fitem
div.fitemtitle{float:left}.container{width:auto}.row-fluid{width:100%}.row-fluid .span8.pull-right,.row-fluid .span9.pull-right{float:none}.row{margin-left:0}[class*="span"],.row-fluid [class*="span"]{float:none;display:block;width:100%;margin-left:0;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.empty-region-side-post.used-region-side-pre #block-region-side-pre.span4,.jsenabled.docked-region-side-post.used-region-side-pre #block-region-side-pre.span4,.empty-region-side-post.used-region-side-pre #region-main.span8,.jsenabled.docked-region-side-post.used-region-side-pre #region-main.span8{width:100%;*width:99.94680851%}.row-fluid
.span12{width:100%;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.row-fluid [class*="offset"]:first-child{margin-left:0}div[role=main]{margin-bottom:1em}.coursebox .info .name
a{background-position:0 13px}.category-browse .coursebox .info .name
a{background-position:0 13px}}@media (min-width:1200px) and (max-width:1600px){#course-category-listings.columns-3{background-color:transparent;border:0}#course-category-listings.columns-3 #category-listing,#course-category-listings.columns-3 #course-listing{width:48.71794872%;*width:48.66475723%;margin-left:2.56410256%;*margin-left:2.51091107%}#course-category-listings.columns-3 #category-listing:first-child,#course-category-listings.columns-3 #course-listing:first-child{margin-left:0}#course-category-listings.columns-3 #course-detail{width:100%;*width:99.94680851%;margin:1em
0 0}}@media (max-width:1199px){.path-question #id_answerhdr
div.fitem{padding-right:6px;padding-left:4px}#course-category-listings.columns-3{background-color:transparent;border:0}#course-category-listings.columns-3 #category-listing,#course-category-listings.columns-3 #course-listing,#course-category-listings.columns-3 #course-detail{width:100%;*width:99.94680851%;margin:0
0 1em 0}#page-mod-forum-discuss
.discussioncontrols{text-align:right}#page-mod-forum-discuss .discussioncontrols
.discussioncontrol{float:none;width:auto;display:inline-block;margin:0
3px .5em}#page-mod-forum-discuss .discussioncontrols .discussioncontrol select,#page-mod-forum-discuss .discussioncontrols .discussioncontrol
input{margin-bottom:0}#page-mod-forum-discuss .discussioncontrols
.discussioncontrol.movediscussion{margin-right:0;padding-right:0}#page-mod-forum-discuss.dir-rtl
.discussioncontrols{text-align:left}}@media (max-width:768px){.fp-forminset .control-group
.controls{margin-left:0}.dir-rtl .fp-formset .control-group label.control-label{text-align:right;float:none}.dir-rtl .fp-forminset .control-group label.control-label{text-align:right;float:none}.dir-rtl .fp-forminset .control-group
.controls{margin-right:0}}body.behat-site .navbar-fixed-top{position:absolute}.phpinfo table,.phpinfo th,.phpinfo
h2{margin:auto;text-align:left}.phpinfo
h2{width:600px}.phpinfo .e,.phpinfo .v,.phpinfo
.h{border:1px
solid #000;font-size:.8em;vertical-align:baseline;color:#000;background-color:#ccc}.phpinfo
.e{background-color:#ccf;font-weight:bold}.phpinfo
.h{background-color:#99c;font-weight:bold}#page-footer
.performanceinfo{margin:10px
20%}#page-footer .performanceinfo
span{display:block}#page-footer
.validators{margin-top:40px;padding-top:5px;border-top:1px dotted gray}#page-footer .validators
ul{margin:0;padding:0;list-style-type:none}#page-footer .validators ul
li{display:inline;margin-right:10px;margin-left:10px}#page-footer .performanceinfo
.cachesused{margin-top:1em}#page-footer .performanceinfo .cachesused .cache-stats-heading,#page-footer .performanceinfo .cachesused .cache-total-stats{font-weight:bold;font-size:110%;margin-top:.3em}#page-footer .performanceinfo .cachesused .cache-definition-stats{margin:.3em;display:inline-block;vertical-align:top;background-color:#f5f5f5}#page-footer .performanceinfo .cachesused .cache-definition-stats .cache-definition-stats-heading
span{display:inline-block;cursor:default}#page-footer .performanceinfo .cachesused .cache-definition-stats .cache-store-stats{padding:0
1.3em}#page-footer .performanceinfo .cachesused .cache-definition-stats .cache-store-stats.nohits{background-color:#f2dede}#page-footer .performanceinfo .cachesused .cache-definition-stats .cache-store-stats.lowhits{background-color:#fcf8e3}#page-footer .performanceinfo .cachesused .cache-definition-stats .cache-store-stats.hihits{background-color:#dff0d8}#page-footer,#page-footer .validators,#page-footer .purgecaches,#page-footer
.performanceinfo{text-align:center}table#explaincaps tbody>tr:nth-child(odd)>td,table#defineroletable tbody>tr:nth-child(odd)>td,table.grading-report tbody>tr:nth-child(odd)>td,table#listdirectories tbody>tr:nth-child(odd)>td,table.rolecaps tbody>tr:nth-child(odd)>td,table.userenrolment tbody>tr:nth-child(odd)>td,table#form tbody>tr:nth-child(odd)>td,form#movecourses table tbody>tr:nth-child(odd)>td,#page-admin-course-index .editcourse tbody>tr:nth-child(odd)>td,.forumheaderlist tbody>tr:nth-child(odd)>td,table.flexible tbody>tr:nth-child(odd)>td,.generaltable tbody>tr:nth-child(odd)>td,table#explaincaps tbody>tr:nth-child(odd)>th,table#defineroletable tbody>tr:nth-child(odd)>th,table.grading-report tbody>tr:nth-child(odd)>th,table#listdirectories tbody>tr:nth-child(odd)>th,table.rolecaps tbody>tr:nth-child(odd)>th,table.userenrolment tbody>tr:nth-child(odd)>th,table#form tbody>tr:nth-child(odd)>th,form#movecourses table tbody>tr:nth-child(odd)>th,#page-admin-course-index .editcourse tbody>tr:nth-child(odd)>th,.forumheaderlist tbody>tr:nth-child(odd)>th,table.flexible tbody>tr:nth-child(odd)>th,.generaltable tbody>tr:nth-child(odd)>th{background-color:#f9f9f9}table
caption{font-size:24px;font-weight:bold;line-height:42px;text-align:left}.dir-rtl table#explaincaps td,.dir-rtl table#defineroletable td,.dir-rtl table.grading-report td,.dir-rtl table#listdirectories td,.dir-rtl table.rolecaps td,.dir-rtl table.userenrolment td,.dir-rtl table#form td,.dir-rtl form#movecourses table td,.dir-rtl .forumheaderlist td,.dir-rtl table.flexible td,.dir-rtl .generaltable td,.dir-rtl .generaltable thead:first-child tr:first-child td,.dir-rtl table#explaincaps th,.dir-rtl table#defineroletable th,.dir-rtl table.grading-report th,.dir-rtl table#listdirectories th,.dir-rtl table.rolecaps th,.dir-rtl table.userenrolment th,.dir-rtl table#form th,.dir-rtl form#movecourses table th,.dir-rtl .forumheaderlist th,.dir-rtl table.flexible th,.dir-rtl .generaltable th,.dir-rtl .generaltable thead:first-child tr:first-child
th{text-align:right}.dir-rtl table
caption{text-align:right}#page-admin-course-index.dir-rtl .editcourse td,#page-admin-course-index.dir-rtl .editcourse
th{text-align:right}#page-report-loglive-index .generaltable th,#page-admin-report-log-index .generaltable th,#page-report-log-user .generaltable th,#page-admin-user table th,.environmenttable th,.category_subcategories th,.rcs-results th,table#listdirectories th,#page-report-loglive-index .generaltable td,#page-admin-report-log-index .generaltable td,#page-report-log-user .generaltable td,#page-admin-user table td,.environmenttable td,.category_subcategories td,.rcs-results td,table#listdirectories
td{padding:4px
5px}.user-enroller-panel .uep-search-results .users tbody tr:hover>td,.user-enroller-panel .uep-search-results .cohorts tbody tr:hover>td,table.grading-report tbody tr:hover>td,.forumheaderlist tbody tr:hover>td,.generaltable tbody tr:hover>td,table.flexible tbody tr:hover>td,.category_subcategories tbody tr:hover>td,table#modules tbody tr:hover>td,table#permissions tbody tr:hover>td,.user-enroller-panel .uep-search-results .users tbody tr:hover>th,.user-enroller-panel .uep-search-results .cohorts tbody tr:hover>th,table.grading-report tbody tr:hover>th,.forumheaderlist tbody tr:hover>th,.generaltable tbody tr:hover>th,table.flexible tbody tr:hover>th,.category_subcategories tbody tr:hover>th,table#modules tbody tr:hover>th,table#permissions tbody tr:hover>th{background-color:#f5f5f5}div[id^="bar_pbar_"]{overflow:hidden !important;height:20px !important;margin-bottom:20px !important;background-color:#f7f7f7 !important;background-image:-moz-linear-gradient(top, #f5f5f5, #f9f9f9) !important;background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#f5f5f5), to(#f9f9f9)) !important;background-image:-webkit-linear-gradient(top, #f5f5f5, #f9f9f9) !important;background-image:-o-linear-gradient(top, #f5f5f5, #f9f9f9) !important;background-image:linear-gradient(to bottom, #f5f5f5, #f9f9f9) !important;background-repeat:repeat-x !important;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#fff5f5f5', endColorstr='#fff9f9f9', GradientType=0) !important;-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,0.1) !important;-moz-box-shadow:inset 0 1px 2px rgba(0,0,0,0.1) !important;box-shadow:inset 0 1px 2px rgba(0,0,0,0.1) !important;-webkit-border-radius:4px !important;-moz-border-radius:4px !important;border-radius:4px !important;border:none !important}div[id^="progress_pbar_"]{height:100% !important;color:#fff !important;float:left !important;font-size:12px !important;text-align:center !important;text-shadow:0 -1px 0 rgba(0,0,0,0.25) !important;background-color:#0e90d2 !important;background-image:-moz-linear-gradient(top, #149bdf, #0480be) !important;background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#149bdf), to(#0480be)) !important;background-image:-webkit-linear-gradient(top, #149bdf, #0480be) !important;background-image:-o-linear-gradient(top, #149bdf, #0480be) !important;background-image:linear-gradient(to bottom, #149bdf, #0480be) !important;background-repeat:repeat-x !important;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff149bdf', endColorstr='#ff0480be', GradientType=0) !important;-webkit-box-shadow:inset 0 -1px 0 rgba(0,0,0,0.15) !important;-moz-box-shadow:inset 0 -1px 0 rgba(0,0,0,0.15) !important;box-shadow:inset 0 -1px 0 rgba(0,0,0,0.15) !important;-webkit-box-sizing:border-box !important;-moz-box-sizing:border-box !important;box-sizing:border-box !important;-webkit-transition:width .6s ease !important;-moz-transition:width .6s ease !important;-o-transition:width .6s ease !important;transition:width .6s ease !important;padding-top:0 !important;border:none !important}input.form-submit,input#id_submitbutton,input#id_submitbutton2,.path-admin .buttons input[type="submit"],td.submit
input{color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#005aa8;background-image:-moz-linear-gradient(top, #0070a8, #0038a8);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#0070a8), to(#0038a8));background-image:-webkit-linear-gradient(top, #0070a8, #0038a8);background-image:-o-linear-gradient(top, #0070a8, #0038a8);background-image:linear-gradient(to bottom, #0070a8, #0038a8);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff0070a8', endColorstr='#ff0038a8', GradientType=0);border-color:#0038a8 #0038a8 #001e5c;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);*background-color:#0038a8;filter:progid:DXImageTransform.Microsoft.gradient(enabled = false)}input.form-submit:hover,input#id_submitbutton:hover,input#id_submitbutton2:hover,.path-admin .buttons input[type="submit"]:hover,td.submit input:hover,input.form-submit:focus,input#id_submitbutton:focus,input#id_submitbutton2:focus,.path-admin .buttons input[type="submit"]:focus,td.submit input:focus,input.form-submit:active,input#id_submitbutton:active,input#id_submitbutton2:active,.path-admin .buttons input[type="submit"]:active,td.submit input:active,input.form-submit.active,input#id_submitbutton.active,input#id_submitbutton2.active,.path-admin .buttons input[type="submit"].active,td.submit input.active,input.form-submit.disabled,input#id_submitbutton.disabled,input#id_submitbutton2.disabled,.path-admin .buttons input[type="submit"].disabled,td.submit input.disabled,input.form-submit[disabled],input#id_submitbutton[disabled],input#id_submitbutton2[disabled],.path-admin .buttons input[type="submit"][disabled],td.submit input[disabled]{color:#fff;background-color:#0038a8;*background-color:#002f8f}input.form-submit:active,input#id_submitbutton:active,input#id_submitbutton2:active,.path-admin .buttons input[type="submit"]:active,td.submit input:active,input.form-submit.active,input#id_submitbutton.active,input#id_submitbutton2.active,.path-admin .buttons input[type="submit"].active,td.submit
input.active{background-color:#002775 \9}input.form-submit .caret,input#id_submitbutton .caret,input#id_submitbutton2 .caret,.path-admin .buttons input[type="submit"] .caret,td.submit input
.caret{border-top-color:#fff;border-bottom-color:#fff}#notice .singlebutton+.singlebutton input,.submit.buttons input[name="cancel"]{display:inline-block;*display:inline;*zoom:1;padding:4px
12px;margin-bottom:0;font-size:14px;line-height:20px;text-align:center;vertical-align:middle;cursor:pointer;color:#333;text-shadow:0 1px 1px rgba(255,255,255,0.75);background-color:#f5f5f5;background-image:-moz-linear-gradient(top, #fff, #e6e6e6);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#fff), to(#e6e6e6));background-image:-webkit-linear-gradient(top, #fff, #e6e6e6);background-image:-o-linear-gradient(top, #fff, #e6e6e6);background-image:linear-gradient(to bottom, #fff, #e6e6e6);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffffff', endColorstr='#ffe6e6e6', GradientType=0);border-color:#e6e6e6 #e6e6e6 #bfbfbf;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);*background-color:#e6e6e6;filter:progid:DXImageTransform.Microsoft.gradient(enabled = false);border:1px
solid #ccc;*border:0;border-bottom-color:#b3b3b3;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;*margin-left:.3em;-webkit-box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05);-moz-box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05);box-shadow:inset 0 1px 0 rgba(255,255,255,.2), 0 1px 2px rgba(0,0,0,.05)}#notice .singlebutton+.singlebutton input:hover,.submit.buttons input[name="cancel"]:hover,#notice .singlebutton+.singlebutton input:focus,.submit.buttons input[name="cancel"]:focus,#notice .singlebutton+.singlebutton input:active,.submit.buttons input[name="cancel"]:active,#notice .singlebutton+.singlebutton input.active,.submit.buttons input[name="cancel"].active,#notice .singlebutton+.singlebutton input.disabled,.submit.buttons input[name="cancel"].disabled,#notice .singlebutton+.singlebutton input[disabled],.submit.buttons input[name="cancel"][disabled]{color:#333;background-color:#e6e6e6;*background-color:#d9d9d9}#notice .singlebutton+.singlebutton input:active,.submit.buttons input[name="cancel"]:active,#notice .singlebutton+.singlebutton input.active,.submit.buttons input[name="cancel"].active{background-color:#ccc \9}#notice .singlebutton+.singlebutton input:first-child,.submit.buttons input[name="cancel"]:first-child{*margin-left:0}#notice .singlebutton+.singlebutton input:hover,.submit.buttons input[name="cancel"]:hover,#notice .singlebutton+.singlebutton input:focus,.submit.buttons input[name="cancel"]:focus{color:#333;text-decoration:none;background-position:0 -15px;-webkit-transition:background-position .1s linear;-moz-transition:background-position .1s linear;-o-transition:background-position .1s linear;transition:background-position .1s linear}#notice .singlebutton+.singlebutton input:focus,.submit.buttons input[name="cancel"]:focus{outline:thin dotted #333;outline:5px
auto -webkit-focus-ring-color;outline-offset:-2px}#notice .singlebutton+.singlebutton input.active,.submit.buttons input[name="cancel"].active,#notice .singlebutton+.singlebutton input:active,.submit.buttons input[name="cancel"]:active{background-image:none;outline:0;-webkit-box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05);-moz-box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05);box-shadow:inset 0 2px 4px rgba(0,0,0,.15), 0 1px 2px rgba(0,0,0,.05)}#notice .singlebutton+.singlebutton input.disabled,.submit.buttons input[name="cancel"].disabled,#notice .singlebutton+.singlebutton input[disabled],.submit.buttons input[name="cancel"][disabled]{cursor:default;background-image:none;opacity:.65;filter:alpha(opacity=65);-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}#notice .singlebutton+.singlebutton input .label,.submit.buttons input[name="cancel"] .label,#notice .singlebutton+.singlebutton input .badge,.submit.buttons input[name="cancel"] .badge{position:relative;top:-1px}#notice .singlebutton+.singlebutton input,.submit.buttons input[name="cancel"]{margin:0
0 10px 5px}input[id$="_clearbutton"],input[type="reset"]{color:#fff;text-shadow:0 -1px 0 rgba(0,0,0,0.25);background-color:#faa732;background-image:-moz-linear-gradient(top, #fbb450, #f89406);background-image:-webkit-gradient(linear, 0 0, 0 100%, from(#fbb450), to(#f89406));background-image:-webkit-linear-gradient(top, #fbb450, #f89406);background-image:-o-linear-gradient(top, #fbb450, #f89406);background-image:linear-gradient(to bottom, #fbb450, #f89406);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#fffbb450', endColorstr='#fff89406', GradientType=0);border-color:#f89406 #f89406 #ad6704;border-color:rgba(0,0,0,0.1) rgba(0,0,0,0.1) rgba(0,0,0,0.25);*background-color:#f89406;filter:progid:DXImageTransform.Microsoft.gradient(enabled = false)}input[id$="_clearbutton"]:hover,input[type="reset"]:hover,input[id$="_clearbutton"]:focus,input[type="reset"]:focus,input[id$="_clearbutton"]:active,input[type="reset"]:active,input[id$="_clearbutton"].active,input[type="reset"].active,input[id$="_clearbutton"].disabled,input[type="reset"].disabled,input[id$="_clearbutton"][disabled],input[type="reset"][disabled]{color:#fff;background-color:#f89406;*background-color:#df8505}input[id$="_clearbutton"]:active,input[type="reset"]:active,input[id$="_clearbutton"].active,input[type="reset"].active{background-color:#c67605 \9}input[id$="_clearbutton"] .caret,input[type="reset"] .caret{border-top-color:#fff;border-bottom-color:#fff}.camera_wrap img,
.camera_wrap ol, .camera_wrap ul, .camera_wrap li,
.camera_wrap table, .camera_wrap tbody, .camera_wrap tfoot, .camera_wrap thead, .camera_wrap tr, .camera_wrap th, .camera_wrap td
.camera_thumbs_wrap a, .camera_thumbs_wrap img,
.camera_thumbs_wrap ol, .camera_thumbs_wrap ul, .camera_thumbs_wrap li,
.camera_thumbs_wrap table, .camera_thumbs_wrap tbody, .camera_thumbs_wrap tfoot, .camera_thumbs_wrap thead, .camera_thumbs_wrap tr, .camera_thumbs_wrap th, .camera_thumbs_wrap
td{background:none;border:0;font:inherit;font-size:100%;margin:0;padding:0;vertical-align:baseline;list-style:none}.camera_wrap{display:none;float:left;position:relative;z-index:0;margin-top:10px}.camera_wrap
img{max-width:none!important}.camera_fakehover{height:100%;min-height:475px;position:relative;width:100%;z-index:1}.camera_wrap{width:100%}.camera_src{display:none}.cameraCont,.cameraContents{height:100%;position:relative;width:100%;z-index:1}.cameraSlide{bottom:0;left:0;position:absolute;right:0;top:0;width:100%}.cameraContent{bottom:0;display:none;left:0;position:absolute;right:0;top:0;width:100%}.camera_target{bottom:0;height:100%;left:0;overflow:hidden;position:absolute;right:0;text-align:left;top:0;width:100%;z-index:0}.camera_overlayer{bottom:0;height:100%;left:0;overflow:hidden;position:absolute;right:0;top:0;width:100%;z-index:0}.camera_target_content{bottom:0;left:0;overflow:hidden;position:absolute;right:0;top:0;z-index:2}.camera_target_content
.camera_link{background:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=slider%2Fblank);display:block;height:100%;text-decoration:none}.camera_loader{background:#fff url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=slider%2Fcamera-loader) no-repeat center;background:rgba(255, 255, 255, 0.9) url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=slider%2Fcamera-loader) no-repeat center;border:1px
solid #fff;-webkit-border-radius:18px;-moz-border-radius:18px;border-radius:18px;height:36px;left:50%;overflow:hidden;position:absolute;margin:-18px 0 0 -18px;top:50%;width:36px;z-index:3}.camera_bar{bottom:0;left:0;overflow:hidden;position:absolute;right:0;top:0;z-index:3}.camera_thumbs_wrap.camera_left .camera_bar, .camera_thumbs_wrap.camera_right
.camera_bar{height:100%;position:absolute;width:auto}.camera_thumbs_wrap.camera_bottom .camera_bar, .camera_thumbs_wrap.camera_top
.camera_bar{height:auto;position:absolute;width:100%}.camera_nav_cont{height:65px;overflow:hidden;position:absolute;right:9px;top:15px;width:120px;z-index:4}.camera_caption{bottom:0;position:absolute}.camerarelative{overflow:hidden;position:relative}.imgFake{cursor:pointer}.camera_prevThumbs{bottom:4px;cursor:pointer;left:0;position:absolute;top:4px;visibility:hidden;width:30px;z-index:10}.camera_prevThumbs
div{background:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=slider%2Fcamera_skins) no-repeat -160px 0;display:block;height:40px;margin-top:-20px;position:absolute;top:50%;width:30px}.camera_nextThumbs{bottom:4px;cursor:pointer;position:absolute;right:0;top:4px;visibility:hidden;width:30px;z-index:10}.camera_nextThumbs
div{background:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=slider%2Fcamera_skins) no-repeat -190px 0;display:block;height:40px;margin-top:-20px;position:absolute;top:50%;width:30px}.camera_command_wrap
.hideNav{display:none}.camera_command_wrap{left:0;position:relative;right:0;z-index:4}.camera_wrap .camera_pag
.camera_pag_ul{list-style:none;margin:0;padding:0;text-align:right}.camera_wrap .camera_pag .camera_pag_ul
li{-webkit-border-radius:8px;-moz-border-radius:8px;border-radius:8px;cursor:pointer;display:inline-block;height:16px;margin:20px
5px;position:relative;text-align:left;text-indent:-9999px;width:16px}.camera_commands_emboss .camera_pag .camera_pag_ul
li{-moz-box-shadow:0px 1px 0px rgba(255,255,255,1),
inset 0px 1px 1px rgba(0,0,0,0.2);-webkit-box-shadow:0px 1px 0px rgba(255,255,255,1),
inset 0px 1px 1px rgba(0,0,0,0.2);box-shadow:0px 1px 0px rgba(255,255,255,1),
inset 0px 1px 1px rgba(0,0,0,0.2)}.camera_wrap .camera_pag .camera_pag_ul li>span{-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px;height:8px;left:4px;overflow:hidden;position:absolute;top:4px;width:8px}.camera_commands_emboss .camera_pag .camera_pag_ul li:hover>span{-moz-box-shadow:0px 1px 0px rgba(255,255,255,1),
inset 0px 1px 1px rgba(0,0,0,0.2);-webkit-box-shadow:0px 1px 0px rgba(255,255,255,1),
inset 0px 1px 1px rgba(0,0,0,0.2);box-shadow:0px 1px 0px rgba(255,255,255,1),
inset 0px 1px 1px rgba(0,0,0,0.2)}.camera_wrap .camera_pag .camera_pag_ul li.cameracurrent>span{-moz-box-shadow:0;-webkit-box-shadow:0;box-shadow:0}.camera_pag_ul li
img{display:none;position:absolute}.camera_pag_ul
.thumb_arrow{border-left:4px solid transparent;border-right:4px solid transparent;border-top:4px solid;top:0;left:50%;margin-left:-4px;position:absolute}.camera_prev,.camera_next,.camera_commands{cursor:pointer;height:40px;margin-top:-20px;position:absolute;top:50%;width:40px;z-index:2}.camera_prev{left:0}.camera_prev>span{background:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=slider%2Fcamera_skins) no-repeat 0 0;display:block;height:40px;width:40px}.camera_next{right:0}.camera_next>span{background:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=slider%2Fcamera_skins) no-repeat -40px 0;display:block;height:40px;width:40px}.camera_commands{right:41px}.camera_commands>.camera_play{background:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=slider%2Fcamera_skins) no-repeat -80px 0;height:40px;width:40px}.camera_commands>.camera_stop{background:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=slider%2Fcamera_skins) no-repeat -120px 0;display:block;height:40px;width:40px}.camera_wrap .camera_pag .camera_pag_ul
li{-webkit-border-radius:8px;-moz-border-radius:8px;border-radius:8px;cursor:pointer;display:inline-block;height:16px;margin:20px
5px;position:relative;text-indent:-9999px;width:16px}.camera_thumbs_cont{-webkit-border-bottom-right-radius:4px;-webkit-border-bottom-left-radius:4px;-moz-border-radius-bottomright:4px;-moz-border-radius-bottomleft:4px;border-bottom-right-radius:4px;border-bottom-left-radius:4px;overflow:hidden;position:relative;width:100%}.camera_commands_emboss
.camera_thumbs_cont{-moz-box-shadow:0px 1px 0px rgba(255,255,255,1),
inset 0px 1px 1px rgba(0,0,0,0.2);-webkit-box-shadow:0px 1px 0px rgba(255,255,255,1),
inset 0px 1px 1px rgba(0,0,0,0.2);box-shadow:0px 1px 0px rgba(255,255,255,1),
inset 0px 1px 1px rgba(0,0,0,0.2)}.camera_thumbs_cont>div{float:left;width:100%}.camera_thumbs_cont
ul{overflow:hidden;padding:3px
4px 8px;position:relative;text-align:center}.camera_thumbs_cont ul
li{display:inline;padding:0
4px}.camera_thumbs_cont ul li>img{border:1px
solid;cursor:pointer;margin-top:5px;vertical-align:bottom}.camera_clear{display:block;clear:both}.showIt{display:none}.camera_clear{clear:both;display:block;height:1px;margin:-1px 0 25px;position:relative}.pattern_1
.camera_overlayer{background:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=slider%2Fpatterns%2Fpattern1) repeat}.pattern_2
.camera_overlayer{background:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=slider%2Fpatterns%2Fpattern2) repeat}.pattern_3
.camera_overlayer{background:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=slider%2Fpatterns%2Fpattern3) repeat}.pattern_4
.camera_overlayer{background:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=slider%2Fpatterns%2Fpattern4) repeat}.camera_wrap .camera_pag .camera_pag_ul
li{background:#b7b7b7}.camera_wrap .camera_pag .camera_pag_ul li:hover>span{background:#b7b7b7}.camera_wrap .camera_pag .camera_pag_ul li.cameracurrent>span{background:#434648}.camera_pag_ul li
img{border:4px
solid #e6e6e6;-moz-box-shadow:0px 3px 6px rgba(0,0,0,.5);-webkit-box-shadow:0px 3px 6px rgba(0,0,0,.5);box-shadow:0px 3px 6px rgba(0,0,0,.5)}.camera_pag_ul
.thumb_arrow{border-top-color:#e6e6e6}.camera_prevThumbs,.camera_nextThumbs,.camera_prev,.camera_next,.camera_commands,.camera_thumbs_cont{background:#f4f4f4;background:rgba(244, 244, 244, 0.75)}.camera_wrap .camera_pag .camera_pag_ul
li{background:#b7b7b7}.camera_thumbs_cont ul li>img{border-color:1px solid #000}.cameraContents .camera_caption
h1{background:#609;color:#fff;text-shadow:0 0 1px rgba(0, 0, 0, 0.5);display:block;font-size:2.2em;line-height:1.5em;margin-right:5%;padding-left:10px}.cameraContents .camera_caption
span{background:none repeat scroll 0 0 #609;background:none repeat scroll 0 0 rgba(0, 0, 0, 0.5);color:#fff;text-shadow:0 0 1px rgba(0, 0, 0, 0.5);display:block;font-size:14px;line-height:24px;margin-left:5%;padding:15px
20px;border-left:4px solid #609}.cameraContents .camera_caption span
a{color:#fff}.cameraContents .camera_caption
div{background:none;margin-bottom:20px}.camera_caption{left:4%;width:40%;display:inline}.bx-wrapper{position:relative;padding:0;*zoom:1}.bx-wrapper
img{max-width:100%;display:block}.bx-wrapper .bx-viewport{padding:0
3px 3px 0}.bx-viewport{-webkit-transform:translatez(0);-moz-transform:translatez(0);-ms-transform:translatez(0);-o-transform:translatez(0);transform:translatez(0)}.bx-heading{border-bottom:1px solid #e5e5e5;line-height:36px;margin-top:0}.bx-wrapper .bx-loading{min-height:50px;background:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=bxslider%2Fbx_loader) center center no-repeat #fff;height:100%;width:100%;position:absolute;top:0;left:0;z-index:2000}.bx-next{background-color:#609;color:#fff !important;display:inline-block;font-size:26px;font-weight:600;padding:3px
1px;position:absolute;right:0;text-align:center;top:0;width:30px}.bx-prev{background-color:#609;color:#fff !important;display:inline-block;font-size:26px;font-weight:600;padding:3px
1px;position:absolute;right:36px;text-align:center;top:0;width:30px}.bx-next:hover,.bx-prev:hover{background-color:#406}@media(max-width:1279px){.camera_fakehover{min-height:425px}}@media(max-width:979px){.camera_caption{display:inline;left:4%;width:60%}.camera_fakehover{min-height:375px}.cameraContents .camera_caption
h1{font-size:2em;line-height:1.4em}.cameraContents .camera_caption
span{line-height:20px;padding:10px
20px}}@media(max-width:767px){.camera_caption{display:inline;left:5%;width:90%}.camera_fakehover{min-height:300px}.cameraContents .camera_caption
h1{font-size:1.8em;line-height:1.3em}.cameraContents .camera_caption
span{font-size:13px}}@font-face{font-family:'FontAwesome';src:url('../fonts/fontawesome-webfont.eot?v=4.7.0');src:url('../fonts/fontawesome-webfont.eot?#iefix&v=4.7.0') format('embedded-opentype'),url('../fonts/fontawesome-webfont.woff2?v=4.7.0') format('woff2'),url('../fonts/fontawesome-webfont.woff?v=4.7.0') format('woff'),url('../fonts/fontawesome-webfont.ttf?v=4.7.0') format('truetype'),url('../fonts/fontawesome-webfont.svg?v=4.7.0#fontawesomeregular') format('svg');font-weight:normal;font-style:normal}.fa{display:inline-block;font:normal normal normal 14px/1 FontAwesome;font-size:inherit;text-rendering:auto;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.fa-lg{font-size:1.33333333em;line-height:.75em;vertical-align:-15%}.fa-2x{font-size:2em}.fa-3x{font-size:3em}.fa-4x{font-size:4em}.fa-5x{font-size:5em}.fa-fw{width:1.28571429em;text-align:center}.fa-ul{padding-left:0;margin-left:2.14285714em;list-style-type:none}.fa-ul>li{position:relative}.fa-li{position:absolute;left:-2.14285714em;width:2.14285714em;top:.14285714em;text-align:center}.fa-li.fa-lg{left:-1.85714286em}.fa-border{padding:.2em .25em .15em;border:solid .08em #eee;border-radius:.1em}.fa-pull-left{float:left}.fa-pull-right{float:right}.fa.fa-pull-left{margin-right:.3em}.fa.fa-pull-right{margin-left:.3em}.pull-right{float:right}.pull-left{float:left}.fa.pull-left{margin-right:.3em}.fa.pull-right{margin-left:.3em}.fa-spin{-webkit-animation:fa-spin 2s infinite linear;animation:fa-spin 2s infinite linear}.fa-pulse{-webkit-animation:fa-spin 1s infinite steps(8);animation:fa-spin 1s infinite steps(8)}@-webkit-keyframes fa-spin{0%{-webkit-transform:rotate(0deg);transform:rotate(0deg)}100%{-webkit-transform:rotate(359deg);transform:rotate(359deg)}}@keyframes fa-spin{0%{-webkit-transform:rotate(0deg);transform:rotate(0deg)}100%{-webkit-transform:rotate(359deg);transform:rotate(359deg)}}.fa-rotate-90{-ms-filter:"progid:DXImageTransform.Microsoft.BasicImage(rotation=1)";-webkit-transform:rotate(90deg);-ms-transform:rotate(90deg);transform:rotate(90deg)}.fa-rotate-180{-ms-filter:"progid:DXImageTransform.Microsoft.BasicImage(rotation=2)";-webkit-transform:rotate(180deg);-ms-transform:rotate(180deg);transform:rotate(180deg)}.fa-rotate-270{-ms-filter:"progid:DXImageTransform.Microsoft.BasicImage(rotation=3)";-webkit-transform:rotate(270deg);-ms-transform:rotate(270deg);transform:rotate(270deg)}.fa-flip-horizontal{-ms-filter:"progid:DXImageTransform.Microsoft.BasicImage(rotation=0,mirror=1)";-webkit-transform:scale(-1,1);-ms-transform:scale(-1,1);transform:scale(-1,1)}.fa-flip-vertical{-ms-filter:"progid:DXImageTransform.Microsoft.BasicImage(rotation=2, mirror=1)";-webkit-transform:scale(1, -1);-ms-transform:scale(1, -1);transform:scale(1, -1)}:root .fa-rotate-90,:root .fa-rotate-180,:root .fa-rotate-270,:root .fa-flip-horizontal,:root .fa-flip-vertical{filter:none}.fa-stack{position:relative;display:inline-block;width:2em;height:2em;line-height:2em;vertical-align:middle}.fa-stack-1x,.fa-stack-2x{position:absolute;left:0;width:100%;text-align:center}.fa-stack-1x{line-height:inherit}.fa-stack-2x{font-size:2em}.fa-inverse{color:#fff}.fa-glass:before{content:"\f000"}.fa-music:before{content:"\f001"}.fa-search:before{content:"\f002"}.fa-envelope-o:before{content:"\f003"}.fa-heart:before{content:"\f004"}.fa-star:before{content:"\f005"}.fa-star-o:before{content:"\f006"}.fa-user:before{content:"\f007"}.fa-film:before{content:"\f008"}.fa-th-large:before{content:"\f009"}.fa-th:before{content:"\f00a"}.fa-th-list:before{content:"\f00b"}.fa-check:before{content:"\f00c"}.fa-remove:before,.fa-close:before,.fa-times:before{content:"\f00d"}.fa-search-plus:before{content:"\f00e"}.fa-search-minus:before{content:"\f010"}.fa-power-off:before{content:"\f011"}.fa-signal:before{content:"\f012"}.fa-gear:before,.fa-cog:before{content:"\f013"}.fa-trash-o:before{content:"\f014"}.fa-home:before{content:"\f015"}.fa-file-o:before{content:"\f016"}.fa-clock-o:before{content:"\f017"}.fa-road:before{content:"\f018"}.fa-download:before{content:"\f019"}.fa-arrow-circle-o-down:before{content:"\f01a"}.fa-arrow-circle-o-up:before{content:"\f01b"}.fa-inbox:before{content:"\f01c"}.fa-play-circle-o:before{content:"\f01d"}.fa-rotate-right:before,.fa-repeat:before{content:"\f01e"}.fa-refresh:before{content:"\f021"}.fa-list-alt:before{content:"\f022"}.fa-lock:before{content:"\f023"}.fa-flag:before{content:"\f024"}.fa-headphones:before{content:"\f025"}.fa-volume-off:before{content:"\f026"}.fa-volume-down:before{content:"\f027"}.fa-volume-up:before{content:"\f028"}.fa-qrcode:before{content:"\f029"}.fa-barcode:before{content:"\f02a"}.fa-tag:before{content:"\f02b"}.fa-tags:before{content:"\f02c"}.fa-book:before{content:"\f02d"}.fa-bookmark:before{content:"\f02e"}.fa-print:before{content:"\f02f"}.fa-camera:before{content:"\f030"}.fa-font:before{content:"\f031"}.fa-bold:before{content:"\f032"}.fa-italic:before{content:"\f033"}.fa-text-height:before{content:"\f034"}.fa-text-width:before{content:"\f035"}.fa-align-left:before{content:"\f036"}.fa-align-center:before{content:"\f037"}.fa-align-right:before{content:"\f038"}.fa-align-justify:before{content:"\f039"}.fa-list:before{content:"\f03a"}.fa-dedent:before,.fa-outdent:before{content:"\f03b"}.fa-indent:before{content:"\f03c"}.fa-video-camera:before{content:"\f03d"}.fa-photo:before,.fa-image:before,.fa-picture-o:before{content:"\f03e"}.fa-pencil:before{content:"\f040"}.fa-map-marker:before{content:"\f041"}.fa-adjust:before{content:"\f042"}.fa-tint:before{content:"\f043"}.fa-edit:before,.fa-pencil-square-o:before{content:"\f044"}.fa-share-square-o:before{content:"\f045"}.fa-check-square-o:before{content:"\f046"}.fa-arrows:before{content:"\f047"}.fa-step-backward:before{content:"\f048"}.fa-fast-backward:before{content:"\f049"}.fa-backward:before{content:"\f04a"}.fa-play:before{content:"\f04b"}.fa-pause:before{content:"\f04c"}.fa-stop:before{content:"\f04d"}.fa-forward:before{content:"\f04e"}.fa-fast-forward:before{content:"\f050"}.fa-step-forward:before{content:"\f051"}.fa-eject:before{content:"\f052"}.fa-chevron-left:before{content:"\f053"}.fa-chevron-right:before{content:"\f054"}.fa-plus-circle:before{content:"\f055"}.fa-minus-circle:before{content:"\f056"}.fa-times-circle:before{content:"\f057"}.fa-check-circle:before{content:"\f058"}.fa-question-circle:before{content:"\f059"}.fa-info-circle:before{content:"\f05a"}.fa-crosshairs:before{content:"\f05b"}.fa-times-circle-o:before{content:"\f05c"}.fa-check-circle-o:before{content:"\f05d"}.fa-ban:before{content:"\f05e"}.fa-arrow-left:before{content:"\f060"}.fa-arrow-right:before{content:"\f061"}.fa-arrow-up:before{content:"\f062"}.fa-arrow-down:before{content:"\f063"}.fa-mail-forward:before,.fa-share:before{content:"\f064"}.fa-expand:before{content:"\f065"}.fa-compress:before{content:"\f066"}.fa-plus:before{content:"\f067"}.fa-minus:before{content:"\f068"}.fa-asterisk:before{content:"\f069"}.fa-exclamation-circle:before{content:"\f06a"}.fa-gift:before{content:"\f06b"}.fa-leaf:before{content:"\f06c"}.fa-fire:before{content:"\f06d"}.fa-eye:before{content:"\f06e"}.fa-eye-slash:before{content:"\f070"}.fa-warning:before,.fa-exclamation-triangle:before{content:"\f071"}.fa-plane:before{content:"\f072"}.fa-calendar:before{content:"\f073"}.fa-random:before{content:"\f074"}.fa-comment:before{content:"\f075"}.fa-magnet:before{content:"\f076"}.fa-chevron-up:before{content:"\f077"}.fa-chevron-down:before{content:"\f078"}.fa-retweet:before{content:"\f079"}.fa-shopping-cart:before{content:"\f07a"}.fa-folder:before{content:"\f07b"}.fa-folder-open:before{content:"\f07c"}.fa-arrows-v:before{content:"\f07d"}.fa-arrows-h:before{content:"\f07e"}.fa-bar-chart-o:before,.fa-bar-chart:before{content:"\f080"}.fa-twitter-square:before{content:"\f081"}.fa-facebook-square:before{content:"\f082"}.fa-camera-retro:before{content:"\f083"}.fa-key:before{content:"\f084"}.fa-gears:before,.fa-cogs:before{content:"\f085"}.fa-comments:before{content:"\f086"}.fa-thumbs-o-up:before{content:"\f087"}.fa-thumbs-o-down:before{content:"\f088"}.fa-star-half:before{content:"\f089"}.fa-heart-o:before{content:"\f08a"}.fa-sign-out:before{content:"\f08b"}.fa-linkedin-square:before{content:"\f08c"}.fa-thumb-tack:before{content:"\f08d"}.fa-external-link:before{content:"\f08e"}.fa-sign-in:before{content:"\f090"}.fa-trophy:before{content:"\f091"}.fa-github-square:before{content:"\f092"}.fa-upload:before{content:"\f093"}.fa-lemon-o:before{content:"\f094"}.fa-phone:before{content:"\f095"}.fa-square-o:before{content:"\f096"}.fa-bookmark-o:before{content:"\f097"}.fa-phone-square:before{content:"\f098"}.fa-twitter:before{content:"\f099"}.fa-facebook-f:before,.fa-facebook:before{content:"\f09a"}.fa-github:before{content:"\f09b"}.fa-unlock:before{content:"\f09c"}.fa-credit-card:before{content:"\f09d"}.fa-feed:before,.fa-rss:before{content:"\f09e"}.fa-hdd-o:before{content:"\f0a0"}.fa-bullhorn:before{content:"\f0a1"}.fa-bell:before{content:"\f0f3"}.fa-certificate:before{content:"\f0a3"}.fa-hand-o-right:before{content:"\f0a4"}.fa-hand-o-left:before{content:"\f0a5"}.fa-hand-o-up:before{content:"\f0a6"}.fa-hand-o-down:before{content:"\f0a7"}.fa-arrow-circle-left:before{content:"\f0a8"}.fa-arrow-circle-right:before{content:"\f0a9"}.fa-arrow-circle-up:before{content:"\f0aa"}.fa-arrow-circle-down:before{content:"\f0ab"}.fa-globe:before{content:"\f0ac"}.fa-wrench:before{content:"\f0ad"}.fa-tasks:before{content:"\f0ae"}.fa-filter:before{content:"\f0b0"}.fa-briefcase:before{content:"\f0b1"}.fa-arrows-alt:before{content:"\f0b2"}.fa-group:before,.fa-users:before{content:"\f0c0"}.fa-chain:before,.fa-link:before{content:"\f0c1"}.fa-cloud:before{content:"\f0c2"}.fa-flask:before{content:"\f0c3"}.fa-cut:before,.fa-scissors:before{content:"\f0c4"}.fa-copy:before,.fa-files-o:before{content:"\f0c5"}.fa-paperclip:before{content:"\f0c6"}.fa-save:before,.fa-floppy-o:before{content:"\f0c7"}.fa-square:before{content:"\f0c8"}.fa-navicon:before,.fa-reorder:before,.fa-bars:before{content:"\f0c9"}.fa-list-ul:before{content:"\f0ca"}.fa-list-ol:before{content:"\f0cb"}.fa-strikethrough:before{content:"\f0cc"}.fa-underline:before{content:"\f0cd"}.fa-table:before{content:"\f0ce"}.fa-magic:before{content:"\f0d0"}.fa-truck:before{content:"\f0d1"}.fa-pinterest:before{content:"\f0d2"}.fa-pinterest-square:before{content:"\f0d3"}.fa-google-plus-square:before{content:"\f0d4"}.fa-google-plus:before{content:"\f0d5"}.fa-money:before{content:"\f0d6"}.fa-caret-down:before{content:"\f0d7"}.fa-caret-up:before{content:"\f0d8"}.fa-caret-left:before{content:"\f0d9"}.fa-caret-right:before{content:"\f0da"}.fa-columns:before{content:"\f0db"}.fa-unsorted:before,.fa-sort:before{content:"\f0dc"}.fa-sort-down:before,.fa-sort-desc:before{content:"\f0dd"}.fa-sort-up:before,.fa-sort-asc:before{content:"\f0de"}.fa-envelope:before{content:"\f0e0"}.fa-linkedin:before{content:"\f0e1"}.fa-rotate-left:before,.fa-undo:before{content:"\f0e2"}.fa-legal:before,.fa-gavel:before{content:"\f0e3"}.fa-dashboard:before,.fa-tachometer:before{content:"\f0e4"}.fa-comment-o:before{content:"\f0e5"}.fa-comments-o:before{content:"\f0e6"}.fa-flash:before,.fa-bolt:before{content:"\f0e7"}.fa-sitemap:before{content:"\f0e8"}.fa-umbrella:before{content:"\f0e9"}.fa-paste:before,.fa-clipboard:before{content:"\f0ea"}.fa-lightbulb-o:before{content:"\f0eb"}.fa-exchange:before{content:"\f0ec"}.fa-cloud-download:before{content:"\f0ed"}.fa-cloud-upload:before{content:"\f0ee"}.fa-user-md:before{content:"\f0f0"}.fa-stethoscope:before{content:"\f0f1"}.fa-suitcase:before{content:"\f0f2"}.fa-bell-o:before{content:"\f0a2"}.fa-coffee:before{content:"\f0f4"}.fa-cutlery:before{content:"\f0f5"}.fa-file-text-o:before{content:"\f0f6"}.fa-building-o:before{content:"\f0f7"}.fa-hospital-o:before{content:"\f0f8"}.fa-ambulance:before{content:"\f0f9"}.fa-medkit:before{content:"\f0fa"}.fa-fighter-jet:before{content:"\f0fb"}.fa-beer:before{content:"\f0fc"}.fa-h-square:before{content:"\f0fd"}.fa-plus-square:before{content:"\f0fe"}.fa-angle-double-left:before{content:"\f100"}.fa-angle-double-right:before{content:"\f101"}.fa-angle-double-up:before{content:"\f102"}.fa-angle-double-down:before{content:"\f103"}.fa-angle-left:before{content:"\f104"}.fa-angle-right:before{content:"\f105"}.fa-angle-up:before{content:"\f106"}.fa-angle-down:before{content:"\f107"}.fa-desktop:before{content:"\f108"}.fa-laptop:before{content:"\f109"}.fa-tablet:before{content:"\f10a"}.fa-mobile-phone:before,.fa-mobile:before{content:"\f10b"}.fa-circle-o:before{content:"\f10c"}.fa-quote-left:before{content:"\f10d"}.fa-quote-right:before{content:"\f10e"}.fa-spinner:before{content:"\f110"}.fa-circle:before{content:"\f111"}.fa-mail-reply:before,.fa-reply:before{content:"\f112"}.fa-github-alt:before{content:"\f113"}.fa-folder-o:before{content:"\f114"}.fa-folder-open-o:before{content:"\f115"}.fa-smile-o:before{content:"\f118"}.fa-frown-o:before{content:"\f119"}.fa-meh-o:before{content:"\f11a"}.fa-gamepad:before{content:"\f11b"}.fa-keyboard-o:before{content:"\f11c"}.fa-flag-o:before{content:"\f11d"}.fa-flag-checkered:before{content:"\f11e"}.fa-terminal:before{content:"\f120"}.fa-code:before{content:"\f121"}.fa-mail-reply-all:before,.fa-reply-all:before{content:"\f122"}.fa-star-half-empty:before,.fa-star-half-full:before,.fa-star-half-o:before{content:"\f123"}.fa-location-arrow:before{content:"\f124"}.fa-crop:before{content:"\f125"}.fa-code-fork:before{content:"\f126"}.fa-unlink:before,.fa-chain-broken:before{content:"\f127"}.fa-question:before{content:"\f128"}.fa-info:before{content:"\f129"}.fa-exclamation:before{content:"\f12a"}.fa-superscript:before{content:"\f12b"}.fa-subscript:before{content:"\f12c"}.fa-eraser:before{content:"\f12d"}.fa-puzzle-piece:before{content:"\f12e"}.fa-microphone:before{content:"\f130"}.fa-microphone-slash:before{content:"\f131"}.fa-shield:before{content:"\f132"}.fa-calendar-o:before{content:"\f133"}.fa-fire-extinguisher:before{content:"\f134"}.fa-rocket:before{content:"\f135"}.fa-maxcdn:before{content:"\f136"}.fa-chevron-circle-left:before{content:"\f137"}.fa-chevron-circle-right:before{content:"\f138"}.fa-chevron-circle-up:before{content:"\f139"}.fa-chevron-circle-down:before{content:"\f13a"}.fa-html5:before{content:"\f13b"}.fa-css3:before{content:"\f13c"}.fa-anchor:before{content:"\f13d"}.fa-unlock-alt:before{content:"\f13e"}.fa-bullseye:before{content:"\f140"}.fa-ellipsis-h:before{content:"\f141"}.fa-ellipsis-v:before{content:"\f142"}.fa-rss-square:before{content:"\f143"}.fa-play-circle:before{content:"\f144"}.fa-ticket:before{content:"\f145"}.fa-minus-square:before{content:"\f146"}.fa-minus-square-o:before{content:"\f147"}.fa-level-up:before{content:"\f148"}.fa-level-down:before{content:"\f149"}.fa-check-square:before{content:"\f14a"}.fa-pencil-square:before{content:"\f14b"}.fa-external-link-square:before{content:"\f14c"}.fa-share-square:before{content:"\f14d"}.fa-compass:before{content:"\f14e"}.fa-toggle-down:before,.fa-caret-square-o-down:before{content:"\f150"}.fa-toggle-up:before,.fa-caret-square-o-up:before{content:"\f151"}.fa-toggle-right:before,.fa-caret-square-o-right:before{content:"\f152"}.fa-euro:before,.fa-eur:before{content:"\f153"}.fa-gbp:before{content:"\f154"}.fa-dollar:before,.fa-usd:before{content:"\f155"}.fa-rupee:before,.fa-inr:before{content:"\f156"}.fa-cny:before,.fa-rmb:before,.fa-yen:before,.fa-jpy:before{content:"\f157"}.fa-ruble:before,.fa-rouble:before,.fa-rub:before{content:"\f158"}.fa-won:before,.fa-krw:before{content:"\f159"}.fa-bitcoin:before,.fa-btc:before{content:"\f15a"}.fa-file:before{content:"\f15b"}.fa-file-text:before{content:"\f15c"}.fa-sort-alpha-asc:before{content:"\f15d"}.fa-sort-alpha-desc:before{content:"\f15e"}.fa-sort-amount-asc:before{content:"\f160"}.fa-sort-amount-desc:before{content:"\f161"}.fa-sort-numeric-asc:before{content:"\f162"}.fa-sort-numeric-desc:before{content:"\f163"}.fa-thumbs-up:before{content:"\f164"}.fa-thumbs-down:before{content:"\f165"}.fa-youtube-square:before{content:"\f166"}.fa-youtube:before{content:"\f167"}.fa-xing:before{content:"\f168"}.fa-xing-square:before{content:"\f169"}.fa-youtube-play:before{content:"\f16a"}.fa-dropbox:before{content:"\f16b"}.fa-stack-overflow:before{content:"\f16c"}.fa-instagram:before{content:"\f16d"}.fa-flickr:before{content:"\f16e"}.fa-adn:before{content:"\f170"}.fa-bitbucket:before{content:"\f171"}.fa-bitbucket-square:before{content:"\f172"}.fa-tumblr:before{content:"\f173"}.fa-tumblr-square:before{content:"\f174"}.fa-long-arrow-down:before{content:"\f175"}.fa-long-arrow-up:before{content:"\f176"}.fa-long-arrow-left:before{content:"\f177"}.fa-long-arrow-right:before{content:"\f178"}.fa-apple:before{content:"\f179"}.fa-windows:before{content:"\f17a"}.fa-android:before{content:"\f17b"}.fa-linux:before{content:"\f17c"}.fa-dribbble:before{content:"\f17d"}.fa-skype:before{content:"\f17e"}.fa-foursquare:before{content:"\f180"}.fa-trello:before{content:"\f181"}.fa-female:before{content:"\f182"}.fa-male:before{content:"\f183"}.fa-gittip:before,.fa-gratipay:before{content:"\f184"}.fa-sun-o:before{content:"\f185"}.fa-moon-o:before{content:"\f186"}.fa-archive:before{content:"\f187"}.fa-bug:before{content:"\f188"}.fa-vk:before{content:"\f189"}.fa-weibo:before{content:"\f18a"}.fa-renren:before{content:"\f18b"}.fa-pagelines:before{content:"\f18c"}.fa-stack-exchange:before{content:"\f18d"}.fa-arrow-circle-o-right:before{content:"\f18e"}.fa-arrow-circle-o-left:before{content:"\f190"}.fa-toggle-left:before,.fa-caret-square-o-left:before{content:"\f191"}.fa-dot-circle-o:before{content:"\f192"}.fa-wheelchair:before{content:"\f193"}.fa-vimeo-square:before{content:"\f194"}.fa-turkish-lira:before,.fa-try:before{content:"\f195"}.fa-plus-square-o:before{content:"\f196"}.fa-space-shuttle:before{content:"\f197"}.fa-slack:before{content:"\f198"}.fa-envelope-square:before{content:"\f199"}.fa-wordpress:before{content:"\f19a"}.fa-openid:before{content:"\f19b"}.fa-institution:before,.fa-bank:before,.fa-university:before{content:"\f19c"}.fa-mortar-board:before,.fa-graduation-cap:before{content:"\f19d"}.fa-yahoo:before{content:"\f19e"}.fa-google:before{content:"\f1a0"}.fa-reddit:before{content:"\f1a1"}.fa-reddit-square:before{content:"\f1a2"}.fa-stumbleupon-circle:before{content:"\f1a3"}.fa-stumbleupon:before{content:"\f1a4"}.fa-delicious:before{content:"\f1a5"}.fa-digg:before{content:"\f1a6"}.fa-pied-piper-pp:before{content:"\f1a7"}.fa-pied-piper-alt:before{content:"\f1a8"}.fa-drupal:before{content:"\f1a9"}.fa-joomla:before{content:"\f1aa"}.fa-language:before{content:"\f1ab"}.fa-fax:before{content:"\f1ac"}.fa-building:before{content:"\f1ad"}.fa-child:before{content:"\f1ae"}.fa-paw:before{content:"\f1b0"}.fa-spoon:before{content:"\f1b1"}.fa-cube:before{content:"\f1b2"}.fa-cubes:before{content:"\f1b3"}.fa-behance:before{content:"\f1b4"}.fa-behance-square:before{content:"\f1b5"}.fa-steam:before{content:"\f1b6"}.fa-steam-square:before{content:"\f1b7"}.fa-recycle:before{content:"\f1b8"}.fa-automobile:before,.fa-car:before{content:"\f1b9"}.fa-cab:before,.fa-taxi:before{content:"\f1ba"}.fa-tree:before{content:"\f1bb"}.fa-spotify:before{content:"\f1bc"}.fa-deviantart:before{content:"\f1bd"}.fa-soundcloud:before{content:"\f1be"}.fa-database:before{content:"\f1c0"}.fa-file-pdf-o:before{content:"\f1c1"}.fa-file-word-o:before{content:"\f1c2"}.fa-file-excel-o:before{content:"\f1c3"}.fa-file-powerpoint-o:before{content:"\f1c4"}.fa-file-photo-o:before,.fa-file-picture-o:before,.fa-file-image-o:before{content:"\f1c5"}.fa-file-zip-o:before,.fa-file-archive-o:before{content:"\f1c6"}.fa-file-sound-o:before,.fa-file-audio-o:before{content:"\f1c7"}.fa-file-movie-o:before,.fa-file-video-o:before{content:"\f1c8"}.fa-file-code-o:before{content:"\f1c9"}.fa-vine:before{content:"\f1ca"}.fa-codepen:before{content:"\f1cb"}.fa-jsfiddle:before{content:"\f1cc"}.fa-life-bouy:before,.fa-life-buoy:before,.fa-life-saver:before,.fa-support:before,.fa-life-ring:before{content:"\f1cd"}.fa-circle-o-notch:before{content:"\f1ce"}.fa-ra:before,.fa-resistance:before,.fa-rebel:before{content:"\f1d0"}.fa-ge:before,.fa-empire:before{content:"\f1d1"}.fa-git-square:before{content:"\f1d2"}.fa-git:before{content:"\f1d3"}.fa-y-combinator-square:before,.fa-yc-square:before,.fa-hacker-news:before{content:"\f1d4"}.fa-tencent-weibo:before{content:"\f1d5"}.fa-qq:before{content:"\f1d6"}.fa-wechat:before,.fa-weixin:before{content:"\f1d7"}.fa-send:before,.fa-paper-plane:before{content:"\f1d8"}.fa-send-o:before,.fa-paper-plane-o:before{content:"\f1d9"}.fa-history:before{content:"\f1da"}.fa-circle-thin:before{content:"\f1db"}.fa-header:before{content:"\f1dc"}.fa-paragraph:before{content:"\f1dd"}.fa-sliders:before{content:"\f1de"}.fa-share-alt:before{content:"\f1e0"}.fa-share-alt-square:before{content:"\f1e1"}.fa-bomb:before{content:"\f1e2"}.fa-soccer-ball-o:before,.fa-futbol-o:before{content:"\f1e3"}.fa-tty:before{content:"\f1e4"}.fa-binoculars:before{content:"\f1e5"}.fa-plug:before{content:"\f1e6"}.fa-slideshare:before{content:"\f1e7"}.fa-twitch:before{content:"\f1e8"}.fa-yelp:before{content:"\f1e9"}.fa-newspaper-o:before{content:"\f1ea"}.fa-wifi:before{content:"\f1eb"}.fa-calculator:before{content:"\f1ec"}.fa-paypal:before{content:"\f1ed"}.fa-google-wallet:before{content:"\f1ee"}.fa-cc-visa:before{content:"\f1f0"}.fa-cc-mastercard:before{content:"\f1f1"}.fa-cc-discover:before{content:"\f1f2"}.fa-cc-amex:before{content:"\f1f3"}.fa-cc-paypal:before{content:"\f1f4"}.fa-cc-stripe:before{content:"\f1f5"}.fa-bell-slash:before{content:"\f1f6"}.fa-bell-slash-o:before{content:"\f1f7"}.fa-trash:before{content:"\f1f8"}.fa-copyright:before{content:"\f1f9"}.fa-at:before{content:"\f1fa"}.fa-eyedropper:before{content:"\f1fb"}.fa-paint-brush:before{content:"\f1fc"}.fa-birthday-cake:before{content:"\f1fd"}.fa-area-chart:before{content:"\f1fe"}.fa-pie-chart:before{content:"\f200"}.fa-line-chart:before{content:"\f201"}.fa-lastfm:before{content:"\f202"}.fa-lastfm-square:before{content:"\f203"}.fa-toggle-off:before{content:"\f204"}.fa-toggle-on:before{content:"\f205"}.fa-bicycle:before{content:"\f206"}.fa-bus:before{content:"\f207"}.fa-ioxhost:before{content:"\f208"}.fa-angellist:before{content:"\f209"}.fa-cc:before{content:"\f20a"}.fa-shekel:before,.fa-sheqel:before,.fa-ils:before{content:"\f20b"}.fa-meanpath:before{content:"\f20c"}.fa-buysellads:before{content:"\f20d"}.fa-connectdevelop:before{content:"\f20e"}.fa-dashcube:before{content:"\f210"}.fa-forumbee:before{content:"\f211"}.fa-leanpub:before{content:"\f212"}.fa-sellsy:before{content:"\f213"}.fa-shirtsinbulk:before{content:"\f214"}.fa-simplybuilt:before{content:"\f215"}.fa-skyatlas:before{content:"\f216"}.fa-cart-plus:before{content:"\f217"}.fa-cart-arrow-down:before{content:"\f218"}.fa-diamond:before{content:"\f219"}.fa-ship:before{content:"\f21a"}.fa-user-secret:before{content:"\f21b"}.fa-motorcycle:before{content:"\f21c"}.fa-street-view:before{content:"\f21d"}.fa-heartbeat:before{content:"\f21e"}.fa-venus:before{content:"\f221"}.fa-mars:before{content:"\f222"}.fa-mercury:before{content:"\f223"}.fa-intersex:before,.fa-transgender:before{content:"\f224"}.fa-transgender-alt:before{content:"\f225"}.fa-venus-double:before{content:"\f226"}.fa-mars-double:before{content:"\f227"}.fa-venus-mars:before{content:"\f228"}.fa-mars-stroke:before{content:"\f229"}.fa-mars-stroke-v:before{content:"\f22a"}.fa-mars-stroke-h:before{content:"\f22b"}.fa-neuter:before{content:"\f22c"}.fa-genderless:before{content:"\f22d"}.fa-facebook-official:before{content:"\f230"}.fa-pinterest-p:before{content:"\f231"}.fa-whatsapp:before{content:"\f232"}.fa-server:before{content:"\f233"}.fa-user-plus:before{content:"\f234"}.fa-user-times:before{content:"\f235"}.fa-hotel:before,.fa-bed:before{content:"\f236"}.fa-viacoin:before{content:"\f237"}.fa-train:before{content:"\f238"}.fa-subway:before{content:"\f239"}.fa-medium:before{content:"\f23a"}.fa-yc:before,.fa-y-combinator:before{content:"\f23b"}.fa-optin-monster:before{content:"\f23c"}.fa-opencart:before{content:"\f23d"}.fa-expeditedssl:before{content:"\f23e"}.fa-battery-4:before,.fa-battery:before,.fa-battery-full:before{content:"\f240"}.fa-battery-3:before,.fa-battery-three-quarters:before{content:"\f241"}.fa-battery-2:before,.fa-battery-half:before{content:"\f242"}.fa-battery-1:before,.fa-battery-quarter:before{content:"\f243"}.fa-battery-0:before,.fa-battery-empty:before{content:"\f244"}.fa-mouse-pointer:before{content:"\f245"}.fa-i-cursor:before{content:"\f246"}.fa-object-group:before{content:"\f247"}.fa-object-ungroup:before{content:"\f248"}.fa-sticky-note:before{content:"\f249"}.fa-sticky-note-o:before{content:"\f24a"}.fa-cc-jcb:before{content:"\f24b"}.fa-cc-diners-club:before{content:"\f24c"}.fa-clone:before{content:"\f24d"}.fa-balance-scale:before{content:"\f24e"}.fa-hourglass-o:before{content:"\f250"}.fa-hourglass-1:before,.fa-hourglass-start:before{content:"\f251"}.fa-hourglass-2:before,.fa-hourglass-half:before{content:"\f252"}.fa-hourglass-3:before,.fa-hourglass-end:before{content:"\f253"}.fa-hourglass:before{content:"\f254"}.fa-hand-grab-o:before,.fa-hand-rock-o:before{content:"\f255"}.fa-hand-stop-o:before,.fa-hand-paper-o:before{content:"\f256"}.fa-hand-scissors-o:before{content:"\f257"}.fa-hand-lizard-o:before{content:"\f258"}.fa-hand-spock-o:before{content:"\f259"}.fa-hand-pointer-o:before{content:"\f25a"}.fa-hand-peace-o:before{content:"\f25b"}.fa-trademark:before{content:"\f25c"}.fa-registered:before{content:"\f25d"}.fa-creative-commons:before{content:"\f25e"}.fa-gg:before{content:"\f260"}.fa-gg-circle:before{content:"\f261"}.fa-tripadvisor:before{content:"\f262"}.fa-odnoklassniki:before{content:"\f263"}.fa-odnoklassniki-square:before{content:"\f264"}.fa-get-pocket:before{content:"\f265"}.fa-wikipedia-w:before{content:"\f266"}.fa-safari:before{content:"\f267"}.fa-chrome:before{content:"\f268"}.fa-firefox:before{content:"\f269"}.fa-opera:before{content:"\f26a"}.fa-internet-explorer:before{content:"\f26b"}.fa-tv:before,.fa-television:before{content:"\f26c"}.fa-contao:before{content:"\f26d"}.fa-500px:before{content:"\f26e"}.fa-amazon:before{content:"\f270"}.fa-calendar-plus-o:before{content:"\f271"}.fa-calendar-minus-o:before{content:"\f272"}.fa-calendar-times-o:before{content:"\f273"}.fa-calendar-check-o:before{content:"\f274"}.fa-industry:before{content:"\f275"}.fa-map-pin:before{content:"\f276"}.fa-map-signs:before{content:"\f277"}.fa-map-o:before{content:"\f278"}.fa-map:before{content:"\f279"}.fa-commenting:before{content:"\f27a"}.fa-commenting-o:before{content:"\f27b"}.fa-houzz:before{content:"\f27c"}.fa-vimeo:before{content:"\f27d"}.fa-black-tie:before{content:"\f27e"}.fa-fonticons:before{content:"\f280"}.fa-reddit-alien:before{content:"\f281"}.fa-edge:before{content:"\f282"}.fa-credit-card-alt:before{content:"\f283"}.fa-codiepie:before{content:"\f284"}.fa-modx:before{content:"\f285"}.fa-fort-awesome:before{content:"\f286"}.fa-usb:before{content:"\f287"}.fa-product-hunt:before{content:"\f288"}.fa-mixcloud:before{content:"\f289"}.fa-scribd:before{content:"\f28a"}.fa-pause-circle:before{content:"\f28b"}.fa-pause-circle-o:before{content:"\f28c"}.fa-stop-circle:before{content:"\f28d"}.fa-stop-circle-o:before{content:"\f28e"}.fa-shopping-bag:before{content:"\f290"}.fa-shopping-basket:before{content:"\f291"}.fa-hashtag:before{content:"\f292"}.fa-bluetooth:before{content:"\f293"}.fa-bluetooth-b:before{content:"\f294"}.fa-percent:before{content:"\f295"}.fa-gitlab:before{content:"\f296"}.fa-wpbeginner:before{content:"\f297"}.fa-wpforms:before{content:"\f298"}.fa-envira:before{content:"\f299"}.fa-universal-access:before{content:"\f29a"}.fa-wheelchair-alt:before{content:"\f29b"}.fa-question-circle-o:before{content:"\f29c"}.fa-blind:before{content:"\f29d"}.fa-audio-description:before{content:"\f29e"}.fa-volume-control-phone:before{content:"\f2a0"}.fa-braille:before{content:"\f2a1"}.fa-assistive-listening-systems:before{content:"\f2a2"}.fa-asl-interpreting:before,.fa-american-sign-language-interpreting:before{content:"\f2a3"}.fa-deafness:before,.fa-hard-of-hearing:before,.fa-deaf:before{content:"\f2a4"}.fa-glide:before{content:"\f2a5"}.fa-glide-g:before{content:"\f2a6"}.fa-signing:before,.fa-sign-language:before{content:"\f2a7"}.fa-low-vision:before{content:"\f2a8"}.fa-viadeo:before{content:"\f2a9"}.fa-viadeo-square:before{content:"\f2aa"}.fa-snapchat:before{content:"\f2ab"}.fa-snapchat-ghost:before{content:"\f2ac"}.fa-snapchat-square:before{content:"\f2ad"}.fa-pied-piper:before{content:"\f2ae"}.fa-first-order:before{content:"\f2b0"}.fa-yoast:before{content:"\f2b1"}.fa-themeisle:before{content:"\f2b2"}.fa-google-plus-circle:before,.fa-google-plus-official:before{content:"\f2b3"}.fa-fa:before,.fa-font-awesome:before{content:"\f2b4"}.fa-handshake-o:before{content:"\f2b5"}.fa-envelope-open:before{content:"\f2b6"}.fa-envelope-open-o:before{content:"\f2b7"}.fa-linode:before{content:"\f2b8"}.fa-address-book:before{content:"\f2b9"}.fa-address-book-o:before{content:"\f2ba"}.fa-vcard:before,.fa-address-card:before{content:"\f2bb"}.fa-vcard-o:before,.fa-address-card-o:before{content:"\f2bc"}.fa-user-circle:before{content:"\f2bd"}.fa-user-circle-o:before{content:"\f2be"}.fa-user-o:before{content:"\f2c0"}.fa-id-badge:before{content:"\f2c1"}.fa-drivers-license:before,.fa-id-card:before{content:"\f2c2"}.fa-drivers-license-o:before,.fa-id-card-o:before{content:"\f2c3"}.fa-quora:before{content:"\f2c4"}.fa-free-code-camp:before{content:"\f2c5"}.fa-telegram:before{content:"\f2c6"}.fa-thermometer-4:before,.fa-thermometer:before,.fa-thermometer-full:before{content:"\f2c7"}.fa-thermometer-3:before,.fa-thermometer-three-quarters:before{content:"\f2c8"}.fa-thermometer-2:before,.fa-thermometer-half:before{content:"\f2c9"}.fa-thermometer-1:before,.fa-thermometer-quarter:before{content:"\f2ca"}.fa-thermometer-0:before,.fa-thermometer-empty:before{content:"\f2cb"}.fa-shower:before{content:"\f2cc"}.fa-bathtub:before,.fa-s15:before,.fa-bath:before{content:"\f2cd"}.fa-podcast:before{content:"\f2ce"}.fa-window-maximize:before{content:"\f2d0"}.fa-window-minimize:before{content:"\f2d1"}.fa-window-restore:before{content:"\f2d2"}.fa-times-rectangle:before,.fa-window-close:before{content:"\f2d3"}.fa-times-rectangle-o:before,.fa-window-close-o:before{content:"\f2d4"}.fa-bandcamp:before{content:"\f2d5"}.fa-grav:before{content:"\f2d6"}.fa-etsy:before{content:"\f2d7"}.fa-imdb:before{content:"\f2d8"}.fa-ravelry:before{content:"\f2d9"}.fa-eercast:before{content:"\f2da"}.fa-microchip:before{content:"\f2db"}.fa-snowflake-o:before{content:"\f2dc"}.fa-superpowers:before{content:"\f2dd"}.fa-wpexplorer:before{content:"\f2de"}.fa-meetup:before{content:"\f2e0"}.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border:0}.sr-only-focusable:active,.sr-only-focusable:focus{position:static;width:auto;height:auto;margin:0;overflow:visible;clip:auto}html{height:100%;min-height:100%}body{background:url(//www.opsecprofessionals.org/academy/pluginfile.php?file=%2F1%2Ftheme_lambda%2Fpagebackground%2F1533780117%2Fbckg.png) repeat fixed 0 0;background-size:auto;position:relative;font-size:13px;font-weight:400;line-height:25px;text-shadow:none !important;color:#555;padding-top:35px}body.pagelayout-login.login_lambda{background:url(//www.opsecprofessionals.org/academy/pluginfile.php?file=%2F1%2Ftheme_lambda%2Fpagebackground%2F1533780117%2Fbckg.png) repeat fixed 0 0;background-size:auto}#wrapper{width:90%;max-width:1600px;margin:0
auto;background:#fff;border-top:4px solid #609}h1, h2, h3, h4, h5, h6,
.back-to-top,
.socials p,
#socialheading,
.forumpost
.subject{font-family:"Open Sans",sans-serif;font-weight:700 !important;color:#555}body,
.block_login input[type="submit"],input,button,select,textarea{font-family:"Open Sans",sans-serif}select,textarea,input[type="text"],input[type="password"],input[type="datetime"],input[type="datetime-local"],input[type="date"],input[type="month"],input[type="time"],input[type="week"],input[type="number"],input[type="email"],input[type="url"],input[type="search"],input[type="tel"],input[type="color"],.uneditable-input{border-radius:2px}h3{font-size:24px}h6{text-transform:uppercase}a, a:visited, a.active, a:focus, #page-mod-scorm-player .breadcrumb-button
a{color:#C69F00;text-decoration:none}a:hover{color:#222;transition:all 0.3s ease 0.1s;text-decoration:none}.block ul.block_tree a, .breadcrumb a, .instancename, .block_book_toc li a, .block_site_main_menu li a, .navbottom .booknext, .navbottom .bookprev, .navbottom
.bookexit{color:#555}.sitetopic .section .activity:hover, .course-content .section .activity:hover{background:none}.section .activity
.editing_move{z-index:1}#page{padding-top:10px}img.iconsmall{height:inherit;margin:0;vertical-align:inherit;width:inherit}.bor{height:20px;margin:0px;margin-bottom:20px;background:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=bg%2Fdot) repeat-x}.topbor{height:20px;margin-bottom:10px;background:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=bg%2Fdot) repeat-x}.side-pre{border:1px
solid #333}.span12#move{margin-top:-30px}.mform fieldset.collapsible legend
a.fheader{margin-left:0}.form-item .form-label, .mform .fitem div.fitemtitle, .userprofile dl.list dt, .form-horizontal .control-label{width:180px}.form-item .form-setting, .form-item .form-description, .mform .fitem .felement, #page-mod-forum-search .c1, .mform .fdescription.required, .userprofile dl.list dd, .form-horizontal
.controls{margin-left:200px}fieldset.coursesearchbox{display:none}.moodle-dialogue-base .moodle-dialogue-wrap .moodle-dialogue-hd, .moodle-dialogue-base .moodle-dialogue-wrap .moodle-dialogue-hd.yui3-widget-hd{background:none repeat scroll 0 0 #F2F2F2}#page-mod-forum-discuss
.discussioncontrols{margin:5px}.empty-region-side-pre #block-region-side-pre, .empty-region-side-post #block-region-side-post{display:block}.back-to-top [class^="icon-"]{font-size:3em}.back-to-top{position:fixed;bottom:2em;left:92%;display:none;text-align:center;font:11px/100%;text-transform:uppercase;text-decoration:none;color:#609}.back-to-top
p{display:none}.back-to-top:hover{color:#406;text-decoration:none}#page-header{padding:12px
0}#page-header>.container-fluid>.row-fluid{display:flex}h2.main,#pageheading{font-size:1.4em;line-height:35px;color:#777;border-bottom:1px solid #e1e1e1}h1#title{color:#609;font-size:2.1em}.title-text{display:flex;flex-direction:column;height:100%;justify-content:center}h2#subtitle{font-size:1em;margin-top:-24px;letter-spacing: .15em;white-space:nowrap}#page-navbar{margin-top:0;position:relative;z-index:0}.lambda-shadow{display:block;margin:0
auto -30px;max-width:100%;opacity:0.45}.breadcrumb-button input[type="submit"]{background:#609;color:#fff;text-shadow:none;border:0px
none}.breadcrumb-button input[type="submit"]:hover{background:#406}.breadcrumb-button
a{color:#fff}.login-header{display:flex !important;flex-direction:column;justify-content:center}#block-login{padding:15px
0 2px}#block-login label,#submit{display:inline-block;font-size:1.2em;height:34px;margin:0;text-align:center}#block-login label#user, #block-login
label#pass{position:absolute;color:#666;background:#eee;width:36px}#block-login label#user .fa, #block-login label#pass
.fa{margin-top:8px}#block-login input[type="text"], #block-login input[type="password"]{background:#fff none repeat scroll 0 0;border:1px
solid #e9e9e9;border-radius:0;box-shadow:none;color:#646464;display:inline-block;height:34px;margin:0;padding:0
2px 0 40px;width:160px}#submit{border-radius:0;box-shadow:none;padding:0;background:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=bg%2Flogin) no-repeat 50% 50% #281a70;width:38px}#submit:hover,#submit:focus{transition:all 0.3s ease 0.1s;background:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=bg%2Flogin) no-repeat 50% 50% #322984}#submit-caption{color:#fff}input{padding-left:40px}#block-login:active>#block-login:before{background-position:100px 100px}.profileblock
.forgotpass{font-size:12.5px;text-align:right}.pagelayout-frontpage
.singinprovider{float:right}#loggedin-user{float:right}.jsenabled .usermenu .moodle-actionmenu .toggle-display.textmenu{padding-left:0;padding-right:0;position:relative;z-index:100}.jsenabled .moodle-actionmenu[data-enhance] .toggle-display.textmenu{margin-left:0}.jsenabled .usermenu .moodle-actionmenu.show
.menu{padding:4px}.moodle-actionmenu.show[data-enhanced] .menu.align-tr-br{top:90%}.moodle-actionmenu.show[data-enhanced] .menu{border:1px
solid #dedede;border-radius:2px;box-shadow:0 5px 10px rgba(0, 0, 0, 0.2);padding:5px}.moodle-actionmenu.show[data-enhanced] .menu
a{color:#555;padding:0
0 0 28px}.jsenabled .usermenu .moodle-actionmenu > .menu
.filler{margin:2px}.moodle-actionmenu.show[data-enhanced] .menu .iconsmall, .moodle-actionmenu.show[data-enhanced] .menu
.smallicon{height:12px;margin:2px
0 2px -24px;padding:4px;width:12px}.jsenabled .usermenu .moodle-actionmenu.show .menu a:hover{background-image:none;background-color:#e5e5e5;color:#555}.usermenu .moodle-actionmenu .toggle-display .userbutton
.avatars{display:none !important}.usermenu .moodle-actionmenu .toggle-display .userbutton
.usertext{max-width:350px}.jsenabled .usermenu .moodle-actionmenu.show{background-color:initial}.profileblock{padding:5px
0}.profileblock
.usermenu{float:left}.profileblock
.welcome_userpicture{float:right;margin-left:15px;position:relative}#loggedin-user
.usertext{color:#609;font-size:1.35em;font-weight:bold;line-height:1.15em;word-wrap:break-word}.breadcrumb{padding:0px;color:#555;font-size:12.5px;background:transparent;margin:0px}.breadcrumb-button{margin-top:-4px}ul.breadcrumb
span.divider{display:none}.breadcrumb>li{display:inline}ul.breadcrumb li:after{content:"\f105";font-family:FontAwesome;font-size:1.1em;margin:0px
6px 0px 3px;color:#bbb}ul.breadcrumb li:last-child:after{content:none}.navbar{margin-bottom:0px;background-image:none;padding:0
20px}.navbar
a{-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;transition:all 0.2s ease-out}.navbar a:hover{-webkit-transition:all 0.2s;-moz-transition:all 0.2s;-o-transition:all 0.2s;transition:all 0.2s}.navbar-inner{background:#609;border:0;padding-left:0;padding-right:0;border-radius:0;filter:none !important;background-image:none !important}.navbar
.brand{color:#fff;text-shadow:none;line-height:30px;font-size:1em;background:#609}.navbar .brand:hover{background:#406}.navbar .nav>li>a{color:#fff;text-shadow:none;padding:10px
18px}.navbar
.nav{margin:0}.navbar .nav>li{line-height:30px}.navbar .nav>li>a:focus,.navbar .nav>li>a:hover,.navbar .nav>.active>a,.navbar .nav>.active>a:hover,.navbar .nav>.active>a:focus, .navbar .nav li.dropdown.open > .dropdown-toggle, .navbar .nav li.dropdown.active > .dropdown-toggle, .navbar .nav li.dropdown.open.active>.dropdown-toggle{color:#fff;text-decoration:none;background-color:#406}.navbar .btn-navbar{background-color:#609;background-image:none;background-repeat:repeat-x;border-color:#609;box-shadow:none;color:#fff;float:right;margin-left:5px;margin-right:-10px;margin-top:7px;padding:10px;text-shadow:none}.navbar .btn-navbar:hover, .navbar .btn-navbar:focus, .navbar .btn-navbar:active, .navbar .btn-navbar.active, .navbar .btn-navbar.disabled, .navbar .btn-navbar[disabled]{background-color:#406;color:#fff}.navbar .dropdown-menu > li > a:hover, .navbar .dropdown-menu>li>a:focus{background-image:none;background-color:#406;color:#fff !important}.navbar .dropdown-submenu:hover>a,.dropdown-submenu:focus>a{background-image:none;background-color:#f4f4f4;color:#444}.navbar .dropdown-submenu:hover>a:after,.dropdown-submenu:focus>a:after{border-color:transparent transparent transparent #ccc}.navbar .dropdown-submenu>.dropdown-menu{border-radius:0}.navbar
.caret{border-top-color:#fff !important;border-bottom-color:#fff !important}.path-mod-data .navbar
form{margin-top:0}.navbar
#search{margin-right:-20px;overflow:hidden;position:relative;float:right;padding:0}.navbar #search
input{background:#609;border:none;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;color:#fff;margin:0;padding:10px;height:50px;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;float:left;font-size:0.975em;font-style:italic}.navbar #search input:focus{-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}.navbar #search input[type="submit"]{display:inline-block;float:left;background:#609 url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=bg%2Ficon-search) no-repeat center center;width:50px;height:50px;-webkit-transition:all 0.3s ease;-moz-transition:all 0.3s ease;-o-transition:all 0.3s ease;transition:all 0.3s ease}.navbar #search input[type="submit"]:hover{background:#406 url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=bg%2Ficon-search) no-repeat center center}.navbar .nav .dropdown-toggle
.caret{margin-top:13px}.navbar .dropdown-menu{border:0px;border-radius:0;background-color:#f4f4f4}.navbar .nav>li>.dropdown-menu:before{border-bottom:7px solid transparent}.navbar .nav>li>.dropdown-menu:after{border-bottom:4px solid transparent}.navbar .dropdown-menu>li>a{color:#444;border-top:1px solid rgba(250, 250, 250, 0.1);border-bottom:1px solid rgba(0, 0, 0, 0.2);padding:8px
20px}.navbar .dropdown-menu>li>a:hover,.dropdown-menu>li>a:focus,.dropdown-menu>li>a:active{color:#444}.navbar .dropdown-menu{padding:0px;margin-left:-2px;margin-top:0px;border-bottom:4px solid #609}.slidershadow{height:auto;max-width:100%;vertical-align:middle;position:relative;z-index:0}.nav
.divider{border-left:1px solid rgba(166, 166, 166, 0.25);border-right:1px solid rgba(33, 33, 33, 0.25);height:50px;overflow:hidden;width:0}.nav .dropdown-menu
.divider{border-left:0 none;border-right:0 none;height:1px;margin:0;width:auto}.navbar .open>.dropdown-menu{overflow:visible !important}.course-content ul
li.section.main{border-bottom:0px none;background:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=bg%2Fdot) bottom repeat-x;padding:10px
0 !important}.course-content
.current{background-color:#FCF8E3 !important}.course-content .current
.content{background-color:#fff}.section .label .contentwithoutlink, .section .label
.activityinstance{padding-right:0}.section .activity
.activityinstance{padding-right:16px}.path-site li.activity > div, .path-course-view li.activity>div{padding:0}.path-course-view
.completionprogress{float:inherit;z-index:900}#page-course-index-category
.generalbox.info{border:none}.no-overflow{overflow:auto;padding-bottom:1px}.empty-region-side-pre.empty-region-side-post .mod-indent-outer .no-overflow{overflow:inherit}.mod-indent-outer .no-overflow, .mod-indent .no-overflow{overflow:auto}.firstword{color:#609 !important;margin-right:-5px}.left.side{display:none}.editing
.left.side{display:inline}.label,.badge{font-weight:normal}table.flexible,.generaltable{display:block;overflow-x:auto}table.flexible th, .generaltable th, table.flexible td, .generaltable
td{padding:4px;vertical-align:middle}.path-grade-report-grader
.gradeparent{line-height:1.4em}.path-grade-report-grader .gradeparent
.floating{display:block !important}.path-grade-report-grader .gradeparent
.floater{display:none}.path-grade-report .gradeparent tr
.cell{border-radius:0}.path-grade-report-grader .gradeparent .heading .cell, .path-grade-report-grader .gradeparent .avg .cell, .path-grade-report-grader .gradeparent
.user.cell{font-size:inherit}.path-grade-report .floating
.iconsmall.sorticon{height:12px;width:12px}.gradingtable
input{width:100px}.gradingform_rubric.view{float:none;overflow:visible;height:inherit;width:inherit}.gradingform_rubric{max-width:unset}.path-mod-assign .gradingtable tr:nth-child(2n+1).unselectedrow
td{background-color:#f9f9f9}.ygtvtable
td{background-color:rgba(0, 0, 0, 0) !important}td.ygtvcell{padding:0
!important}.ygtvcontent
a{display:block;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.course-content ul.topics li.section .content, .course-content ul.weeks li.section
.content{margin-left:8px;margin-right:8px}.course-content ul.ctopics li.section .content
.toggle{border-radius:2px;margin-bottom:8px}.course-content ul.topics li#section-0{padding-top:0 !important}.course-content ul
li.section.main{border:medium none}a.dimmed
.instancename{color:#999}.buttons li.section.hidden
.summary{opacity:1 !important}.buttons li.section.hidden .summary>div{opacity:0.5}.ctopics.topics .content .toggle h3.sectionname, .ctopics.topics .content .toggle h3.section-title{background:transparent none repeat scroll 0 0;border:medium none;cursor:pointer;font-size:16px;padding:0}.course-content .single-section .section-navigation
.title{background:rgba(0, 0, 0, 0) none repeat scroll 0 0 !important;color:#555 !important;font-size:24px !important;line-height:30px !important;margin-bottom:unset;padding:0
!important}.course-content .single-section .section-navigation .title:after{background:#609 none repeat scroll 0 0;border-radius:4px;content:"";display:block;height:4px;margin:20px
auto;position:relative;width:50px}#section_footer>a#next_section{float:right}#section_footer>a#previous_section{float:left}#section_footer>a#previous_section,#section_footer>a#next_section{color:#555;font-weight:bold;line-height:27px}#section_footer > a#previous_section .nav_icon .fa, #section_footer > a#next_section .nav_icon
.fa{background:#609 none repeat scroll 0 0;color:#fff;font-size:1.4em;padding:6px
8px}#section_footer>a#previous_section{float:left;width:40%}#section_footer>a#next_section{float:right;text-align:right;width:40%}#section_footer{margin-top:20px}.course-content ul li.section.main.section-summary{background:rgba(0, 0, 0, 0) none repeat scroll 0 0;border:1px
solid #eee;margin:25px
0}.section-summary-activities.mdl-right{background:#fafafa none repeat scroll 0 0;border-bottom:1px solid #eee;border-top:1px solid #eee}.course-content .section.main.section-summary .content
h3{font-size:18px}.course-content .section-summary .section-title::before{color:#609;content:"\f0da";font-family:FontAwesome;margin-right:6px}.coursebox{border:medium none;border-bottom:1px solid #e5e5e5;margin-bottom:25px;padding-bottom:35px}.coursebox > .info > .coursename
a{background-image:none;padding-left:0}.courses .coursebox:hover,  .courses
.coursebox.even{background-color:transparent}.coursebox .content .teachers, .coursebox .content .courseimage, .coursebox .content
.coursefile{width:unset}.coursebox > .info > .coursename, .coursebox .content .teachers, .coursebox .content .courseimage, .coursebox .content
.coursefile{clear:unset;float:unset}.coursebox .content .summary, .coursebox .content
.coursecat{width:98%;float:unset;padding-top:0.5em}.coursebox .content
.courseimage{float:left;margin-right:2em;background-position:center center;background-size:cover}@media (min-width: 1187px){.coursebox .content
.courseimage{height:225px;width:325px}}@media (max-width: 1186px){.coursebox .content
.courseimage{height:200px;width:290px}}@media (max-width: 980px){.coursebox .content
.courseimage{height:150px;width:220px}.coursebox .content .summary, .coursebox .content
.coursecat{padding-top:0}}@media (max-width: 580px){.coursebox .content
.courseimage{height:250px;width:100%;float:unset}}.coursebox .content h3.coursename a, .coursebox .content h3.coursename a:hover, .course_category_tree .category.with_children h3.categoryname
a{color:#555;font-size:20px}.coursebox .content .summary.dimmed, .coursebox .content .summary.dimmed h3.coursename a, .course_category_tree .category.with_children.dimmed_category h3.categoryname
a{color:#999}.coursebox .content .course-btn .btn.btn-primary{margin-top:0.75em}.coursebox>.info>.coursename{display:none}.coursebox.collapsed>.info>.coursename{display:block}.course_category_tree .collapsible-actions{margin-bottom:25px;background:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=bg%2Fcategory-bg) no-repeat bottom left;height:80px;padding:15px;border-bottom:1px solid #e2e2e2;margin-top:-1em}.collapsible-actions
.collapseexpand{color:#fff}.course_category_tree .collapsible-actions::before{border-radius:50%;color:#fff;content:"\f115";float:left;font-family:FontAwesome;font-size:3.5em;height:75px;line-height:75px;text-align:center;width:75px;border:3px
solid #fff}.course_category_tree .category>.info{background-color:transparent;border:medium none;border-radius:4px;box-shadow:none}.course_category_tree .category.with_children.collapsed>.info>.categoryname{border-bottom:1px dotted #ccc}.coursebox.collapsed>.info>.coursename{display:inline-block;font-size:1.25em}.courses
.coursebox.collapsed{border:none;border-bottom:1px dotted #ccc}.coursebox > .info > .coursename a::before, .coursebox > .info > .name a::before{background-color:#f2f2f2;border-radius:50%;color:#555;content:"\f090";display:block;float:left;font-family:FontAwesome;height:1.35em;line-height:1.35em;margin-right:0.5em;margin-top:-0.2em;padding-top:0.1em;text-align:center;width:1.5em}.course_category_tree.category-browse-0{margin-bottom:25px}.navtop.navtext .chaptername span.arrow, .navbottom.navtext .chaptername
span.arrow{display:none}.navtext.navtop,.navtext.navbottom{border-top:1px solid #e2e2e2;line-height:40px;margin-top:25px;padding-top:10px}.navtext.navtop a.booknext::after, .navtext.navbottom a.booknext:after{content:"\f105";font-family:fontawesome;font-size:1.5em;font-weight:bold;color:#fff;margin:0
10px;background:#609;padding:6px
12px}.navtext.navtop a.bookprev::before, .navtext.navbottom a.bookprev:before{content:"\f104";font-family:fontawesome;font-size:1.5em;font-weight:bold;color:#fff;margin:0
10px;background:#609;padding:6px
12px}.path-mod-book #region-main>div>h2{font-size:32px;line-height:32px;margin-bottom:0;margin-right:10px}.path-mod-book .generalbox.book_content>h3{background:rgba(0, 0, 0, 0) url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=bg%2Fblock-divider) repeat-x scroll left bottom;color:#999;font-size:24px;line-height:40px;margin-bottom:25px;margin-top:0}.path-mod-book .generalbox.book_content>h3:after{background:#609 none repeat scroll 0 0;content:"";display:block;height:3px;margin-top:15px;max-width:75px;padding:0;width:50%}.path-mod-book
.navtop{display:none}.navimages>a>img{background:#609;padding:6px
!important}.path-mod-page #region-main>div>h2{background:rgba(0, 0, 0, 0) url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=bg%2Fblock-divider) repeat-x scroll left bottom;font-size:32px;line-height:32px;margin-bottom:15px}.path-mod-page #region-main>div>h2:after{background:#609 none repeat scroll 0 0;content:"";display:block;height:3px;margin-top:15px;max-width:75px;padding:0;width:50%}body#page-mod-assign-grader{position:static}.path-mod-assign [data-region="grading-navigation-panel"], .path-mod-assign [data-region="grade-actions"]{background:#fff none repeat scroll 0 0}.path-mod-assign .fullwidth[data-region="grade-panel"]{background:rgba(235, 235, 235, 0.75) none repeat scroll 0 0;width:98%;margin:0
auto}.path-mod-assign [data-region="grade-actions-panel"]{bottom:-2px}.path-mod-assign [data-region="user-selector"] .alignment{margin-top:0}@media (max-width: 767px){.path-mod-assign [data-region="user-info"]{display:block !important;padding-left:10px}.path-mod-assign [data-region="grading-navigation-panel"]{line-height:20px}.path-mod-assign [data-region="grade-actions-panel"]{bottom:-15px;position:absolute;top:unset}.path-mod-assign [data-region="user-selector"]{display:none}.path-mod-assign .fullwidth[data-region="grade-panel"]{top:10em}}@media (min-width:481px) and (max-width: 767px){body#page-mod-assign-grader, body#page-mod-assign-grader
#page{padding:0}.path-mod-assign [data-region="grading-navigation-panel"]{background:#fff none repeat scroll 0 0;margin:0
auto;width:98%}}.submissionstatustable .submissionstatussubmitted, .submissionstatustable .earlysubmission , .submissionstatustable .submissionstatus, .submissionstatustable
.submissiongraded{margin:3px
0;padding:4px}.path-mod-assign div[data-region="assignment-info"]{line-height:1.5em}.block{background:#F2F2F2;padding:12px;border:1px
solid #efefef;margin-bottom:10px;box-shadow:none;border-radius:2px}.block
.content{padding:6px}.block .content
hr{border:medium none;margin:5px
0;background:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=bg%2Fblock-divider) repeat-x scroll left bottom}.block
#icon{margin-right:5px;color:#999}.hidden-blocks{background:#e3ecf4 none repeat scroll 0 0;border-radius:2px;padding:10px;margin:10px
0px 10px 0px}.pagelayout-report .hidden-blocks{background:#fff none repeat scroll 0 0;border:medium none}.hidden-blocks
h4{border-bottom:1px solid #ccd4db;color:#5cacf2;margin-bottom:8px;margin-top:0;padding-bottom:8px;text-align:left}.hidden-blocks
.block{float:right;width:250px;margin-left:10px}.block .header .title h2,
.block
h3.main{font-size:1.15em;color:#666;line-height:26px;font-weight:700;padding:7px
0;text-transform:none;display:inline}.block .header .title h2, .block
h3{text-shadow:none}#page-footer .block .header .title h2:before{display:none}#page-footer .block .header .title h2:after{background-color:#609;content:"";display:block;height:1px;position:relative;top:6px;width:100px}.block .header
.title{padding-left:0px;padding-bottom:5px;background:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=bg%2Fblock-divider) repeat-x scroll left bottom}.block .header
.block_action{padding:1px}.block .header .block_action
input{padding-left:0}.block.hidden .header .title h2,
.block.hidden h3.main,
.block.hidden .header
.title{border-bottom:none;margin-bottom:0px}.block_quiz_results{text-align:left}.block_rss_client
.decription{height:auto;padding-bottom:0px;margin-bottom:0px}.block_rss_client
.content{padding:0px}.block_rss_client
.footer{text-align:right;padding-top:5px}.block_rss_client .content
ul.list{margin-top:10px !important}.block_rss_client .content ul.list
li{background:rgba(255, 255, 255, 0.5) none repeat scroll 0 0}#page-footer .block_rss_client .content ul.list
li{margin-top:10px}#page-footer .block_rss_client .content ul.list
li{background:rgba(255, 255, 255, 0.2) none repeat scroll 0 0;border:1px
solid rgba(255, 255, 255, 0.1);padding:5px
10px}.block_login input[type="text"],
.block_login input[type="password"]{width:95% !important}.block .header .title .commands, .block_adminblock .content, .block
.footer{padding:0}#page-footer ul.menubar, #greyboxright
ul.menubar{float:right;margin:-25px 0}.user-enroller-panel{z-index:999}#site-news-forum,#frontpage-course-list,#frontpage-category-combo,#frontpage-category-names{background:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=bg%2Fdot) left top repeat-x;background-size:20px 3px;padding-top:20px}#region-main
.block{background:transparent none repeat scroll 0 0;padding:0;border:medium none}#region-main .block .header
.title{background:#f4f4f4 none repeat scroll 0 0;box-shadow:0 0 0 1px rgba(0, 0, 0, 0.1) inset;padding:4px
8px;margin-bottom:10px}#region-main .block .header .title
h2{padding:0
0 0 6px}#region-main .block .header .title h2:before{border-radius:0;font-size:1.4em;margin:-4px 0 0 -8px;padding:3px}#region-main .block
.content{margin:0
0 30px;padding:0
0 20px}#region-main .block.block_course_overview
.coursebox{border:1px
dashed #e2e2e2;border-width:0 0 1px 0;padding:0}#region-main .block.block_course_overview .content
h2.title{background:transparent none repeat scroll 0 0;box-shadow:none;font-size:1.2em;line-height:2em;margin-bottom:5px;margin-top:0;padding:0
0 5px 0}#region-main .block.block_course_overview .content h2.title
a{color:#555}#region-main .block.block_course_overview .content h2.title
a.dimmed{color:#999}#region-main .block.block_course_overview
.content{padding-left:10px}#region-main .block.block_course_overview .content h2.title:before{content:"\f054";display:inline-block;font-family:FontAwesome;color:#609;padding-right:6px}#region-main .block.block_course_overview .content
.activity_info{margin-left:15px}#region-main .block.block_course_overview .content .profilepicture
img{border-right:3px solid #609;margin-right:10px;padding-right:20px}#region-main .block.block_course_overview .content
.welcome_area{border-bottom:3px dashed #609;margin-bottom:20px}.forumpost{background-color:#f9f9f9;border:1px
solid #e3e3e3;border-image:none;border-radius:0;border-style:solid;border-left:2px solid #609;box-shadow:none}.forumpost .picture
img.userpicture{border-radius:50%;height:auto;width:45px}.forumpost .author::before{color:#609;content:"\f0a9";display:block;float:left;font-family:FontAwesome;width:1.5em}.forumpost .row
.left{width:58px}.comment-message
.picture{float:unset;width:60px}#page-footer{background:#323A45;margin-top:10px;font-size:1em;padding-top:10px;padding-bottom:0;color:#bdc3c7;border-top:3px solid #609;text-align:left}#page-footer .content a, #page-footer .footerlinks
a{color:#609}.helplink{float:right;padding-right:20px}.helplink
a{color:orange !important}#page-footer .footnote a,
#page-footer .footnote a:visited{color:#609 !important}#page-footer .footnote a:hover{color:#406 !important;text-decoration:none}#page-footer
.container{margin-right:auto;margin-left:auto}#page-footer
.copy{padding-left:20px;float:left}#page-footer
.footnote{float:left;color:#bdc3c2;margin-left:20px}#page-footer
.span4{padding:30px;padding-top:0px;padding-bottom:0px}#page-footer
hr{display:none}#page-footer h5, #page-footer
h6{color:#bdc3c7}#page-footer ul,
#greyboxright
ul{list-style-type:none !important;margin:0px;margin-top:-10px;margin-bottom:10px}#page-footer ul li,
#greyboxright ul
li{padding:4px
0px;padding-left:0px}#page-footer .tree_item.branch:before{color: [setting:maincolor]]}.footerlinks{line-height:15px;background:#292F38;border-top:1px solid #444;padding:10px
0}#page-footer
.block{border:0px
none;background:transparent;width:100%;padding:0px}#page-footer .block .header .title
h2{color:#f2f2f2}#page-footer .block .header
.block_action{display:none !important}#page-footer .block .header
.title{border-bottom:1px solid #bdc3c7;background:none}#page-footer .block .minicalendar
td.weekend{color:#f2f2f2}.myprofileitem.picture{width:100px;height:100px;margin:10px
auto;background:#eee;border:5px
solid #fff;box-shadow:0px 0px 3px #aaa;text-align:center;-webkit-transition:border 1s ease;-moz-transition:border 1s ease;-o-transition:border 1s ease;transition:border 1s ease}.myprofileitem.picture:hover{-webkit-transition:border 1s ease;-moz-transition:border 1s ease;-o-transition:border 1s ease;transition:border 1s ease;border:5px
solid #609}img.profilepicture{width:120px;height:120px}.page-context-header .header-button-group a
img.iconsmall{display:none}.page-context-header .btn-group.header-button-group{float:unset}.userprofile .profile_tree
section.node_category{border:none}.userprofile .profile_tree section.node_category h3, #page-report-outline-user .section
h2{border-bottom:1px solid #ddd;padding-bottom:6px}.page-context-header .page-header-image
img{border-right:3px solid #609;margin-right:10px;padding-right:20px}.page-context-header .page-header-headings{margin-top:25px}.page-context-header{border-bottom:3px dashed #609;margin-bottom:10px;padding-bottom:10px}#page-report-outline-user
.section{border:medium none}#page-user-profile .node_category .editprofile, .path-user .node_category .editprofile, #page-user-profile .node_category .viewmore, .path-user .node_category
.viewmore{text-align:unset}#page-mod-quiz-edit
div.quizcontents{clear:left;display:block;float:left;width:67%}#quizcontentsblock form.quizsavegradesform
label{display:inline}.points
label{font-size:12px;line-height:1em}#page-mod-quiz-edit div.question div.content
div.points{right:50px;margin-top:0;position:static;max-width:100%}#page-mod-quiz-edit div.question div.content .questionname, #categoryquestions
.questionname{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}#categoryquestions .questiontext
p{overflow:hidden;text-overflow:ellipsis}#categoryquestions
.checkbox{padding-left:10px}#categoryquestions .radio input[type="radio"], #categoryquestions .checkbox input[type="checkbox"]{float:inherit;margin-left:-15px}#page-mod-quiz-edit div.questionbank
.categoryquestionscontainer{margin:0}#categoryquestions
.qtype{text-align:left;width:20px}.que{max-width:95%}.que
.info{background-color:#f2f2f2;border:1px
solid #ddd;float:none;margin-bottom:5px;padding:2px
5px 10px;width:auto}.que
.content{margin:0}.que
.formulation{background:#fff none repeat scroll 0 0;border:medium none;border-radius:0}.que .formulation
.qtext{font-size:1.1em}.que
h3.no{margin-right:50px;font-size:1.2em;text-transform:capitalize;display:inline-block}.que
span.qno{font-size:1.2em}.que .info>div{font-size:1em;display:inline-block;margin-right:25px}.que .info > div.state, .que .info>div.grade{font-size:0.9em}.que .info > div.questionflag, .que .info>div.editquestion{font-weight:bold}.block .header .title h2:before{border-radius:3px;color:#FFF;display:block;float:left;font-family:FontAwesome;font-size:1.35em;height:1.35em;margin-left:-0.35em;margin-right:0.5em;margin-top:-0.2em;padding-top:0.1em;text-align:center;width:1.5em;background-color:#609;content:"\f069"}.block_html .header .title h2:before{background-color:#8EC63F;content:"\f05a"}.block_news_items .header .title h2:before{background-color:#29A294;content:"\f0a1"}.block_navigation .header .title h2:before{background-color:#609;content:"\f0e8"}.block_calendar_upcoming .header .title h2:before,
.block_calendar_month .header .title h2:before{background-color:#609;content:"\f073"}.block_course_list .header .title h2:before{background-color:#ffce00;content:"\f108"}.block_completionstatus .header .title h2:before,
.block_selfcompletion .header .title h2:before{background-color:#76b900;content:"\f0e4"}.block_rss_client .header .title h2:before{background-color:#008ecd;content:"\f09e"}.block_rss_plus .header .title h2:before{background-color:#ff9500;content:"\f09e"}.block_blog_menu .header .title h2:before{background-color:#ff9500;content:"\f02d"}.block_quiz_results .header .title h2:before{background-color:#008ecd;content:"\f080"}.block_quiz_navblock .header .title h2:before{background-color:#76b900;content:"\f126"}.block_glossary_random .header .title h2:before{background-color:#008ecd;content:"\f0eb"}.block_book_toc .header .title h2:before{background-color:#76b900;content:"\f097"}.block_participants .header .title h2:before,
.block_online_users .header .title h2:before{background-color:#92499e;content:"\f0c0"}.block_section_links .header .title h2:before{background-color:#EB3D00;content:"\f02e"}.block_activity_modules .header .title h2:before{background-color:#EB3D00;content:"\f12e"}.block_comments .header .title h2:before{background-color:#ffce00;content:"\f075"}.block_settings .header .title h2:before,
.block_admin_bookmarks .header .title h2:before{background-color:#609;content:"\f085"}.block_blog_tags .header .title h2:before,
.block_tags .header .title h2:before{background-color:#ff9f00;content:"\f02c"}.block_private_files .header .title h2:before{background-color:#38B9EC;content:"\f114"}.block_block_mentees .header .title h2:before{background-color:#76B900;content:"\f0c0"}.block_messages .header .title h2:before{background-color:#ffce00;content:"\f0e0"}.block_community .header .title h2:before{background-color:#ffce00;content:"\f0ac"}.block_login .header .title h2:before{background-color:#ffce00;content:"\f007"}.block_recent_activity .header .title h2:before{background-color:#38B9EC;content:"\f017"}.block_search_forums .header .title h2:before{background-color:#ffce00;content:"\f0e6"}.block_myprofile .header .title h2:before{background-color:#EB3D00;content:"\f007"}.block_adminblock .header .title h2:before{background-color:#76B900;content:"\f0fe"}.block_feedback .header .title h2:before{background-color:#ffce00;content:"\f087"}.block_flickr .header .title h2:before{background-color:#ff3096;content:"\f03e"}.block_youtube .header .title h2:before{background-color:#EB3D00;content:"\f145"}.block_course_badges .header .title h2:before{background-color:#29a294;content:"\f091"}.block_twitter_search .header .title h2:before{background-color:#008ecd;content:"\f099"}.block_heritage .header .title h2:before{background-color:#3e647e;content:"\f02d"}.block_graph_stats .header .title h2:before{background-color:#38B9EC;content:"\f012"}.block_wikipedia .header .title h2:before{background-color:#29A294;content:"\f002"}.block_site_main_menu .header .title h2:before{background-color:#609;content:"\f14e"}.block_badges .header .title h2:before{background-color:#a11d21;content:"\f0a3"}.nav-tabs>li,.nav-pills>li{float:none;display:inline-block;*display:inline;zoom:1}.nav-tabs,.nav-pills{text-align:center}.nav>.disabled>a{color:#555;background:#fff}.nav>.disabled>a:hover{border:1px
solid #eee}.nav-tabs>li>a{color:#fff;cursor:default;background-color:#609;border:1px
solid #eee;border-bottom-color:transparent}.nav-tabs>li>a:hover{background-color:#406}.yui3-skin-sam .yui3-tab-label{background:#f2f2f2 none repeat scroll 0 0}.yui3-skin-sam .yui3-tab-label:hover, .yui3-skin-sam .yui3-tab-label:focus{background:#dfdfdf none repeat scroll 0 0}.yui3-skin-sam .yui3-tab-selected .yui3-tab-label, .yui3-skin-sam .yui3-tab-selected .yui3-tab-label:focus, .yui3-skin-sam .yui3-tab-selected .yui3-tab-label:hover{background:#dfdfdf none repeat scroll 0 0;color:#000}.yui3-skin-sam .yui3-tabview-panel{background:#fafafa none repeat scroll 0 0}.container-fluid.socials-header{padding-left:0;padding-right:0}.socials-header
.socials{background-color:#fbfbfb;border-bottom:1px solid #e9e9e9}.socials-header .social_icons.pull-right{padding-right:20px}.socials-header
.social_contact{padding-left:20px}#page-footer .social_icons.pull-right{padding-right:15px}.socials-header .socials .social_contact
i{color:#609;font-size:1.35em;line-height:35px}.socials .social_contact
a.social_contact_web{padding-right:20px}#page-footer .socials .social_contact
i{font-size:1.25em;padding:0
0 0 20px}.socials-header .socials .social_icons
a.social{color:#609;float:left;font-size:1.35em;height:35px;line-height:35px;position:relative;text-align:center;width:40px}#page-footer .footerlinks .socials .social_icons
a.social{color:#292F38}#page-footer .socials .social_icons
a.social{background:#609;border-radius:2px;display:inline-block;float:left;font-size:1.25em;height:25px;line-height:25px;margin:0
5px;text-align:center;text-decoration:none;transition:all 0.25s ease 0s;width:25px}.block .social_icons
a.social{background:#999;color:#E5E5E5;border-radius:2px;display:inline-block;float:left;font-size:1.25em;height:25px;line-height:25px;margin:0
5px;text-align:center;text-decoration:none;width:25px}#page-footer .block .social_icons
a.social{color:#323A45}.social_icons
a.social{transition:background 0.3s ease 0s, color 0.3s ease 0s}a.social.fa-facebook:hover{color:#fff !important;background:#3B5998 !important}a.social.fa-twitter:hover{color:#fff !important;background:#00ACED !important}a.social.fa-youtube:hover{color:#fff !important;background:#CB3429 !important}a.social.fa-google-plus:hover{color:#fff !important;background:#DD4B39 !important}a.social.fa-instagram:hover{color:#fff !important;background:#517FA4 !important}a.social.fa-flickr:hover{color:#fff !important;background:#FF0084 !important}a.social.fa-pinterest:hover{color:#fff !important;background:#CB2027 !important}a.social.fa-linkedin:hover{color:#fff !important;background:#007BB6 !important}.loginbox
.loginsub{max-width:500px;text-align:left}.loginbox
.loginerrors{background-color:#F2DEDE;padding:10px
25px}.loginbox
#login{background:#eee none repeat scroll 0 0;padding:25px
25px 45px;position:relative}.loginbox
.loginform{margin-top:0;overflow:auto;width:100% !important}.loginbox .loginform .form-label{float:none;padding-top:5px;text-align:left;width:auto}.loginbox .loginform .form-input{background:#fff none repeat scroll 0 0;float:none;padding:8px;width:auto}.loginbox .loginform .form-input
input{border:medium none;box-shadow:none;margin:0;padding:0;width:100%}.loginbox
.rememberpass{margin:15px
0 0}.loginbox
#loginbtn{margin:20px
auto;width:100%}.loginbox
.forgetpass{background-color:#ddd;bottom:0;left:0;padding:8px
0;position:absolute;width:100%}.loginbox .forgetpass>a{padding-left:25px}.loginbox .loginpanel
.desc{font-style:italic;margin-top:20px;text-align:left}.loginbox .desc
.helptooltip{padding-left:5px}.loginbox .guestsub, .loginbox .forgotsub, .loginbox
.potentialidps{margin:12px
0}.loginbox .loginpanel h2, .loginbox .loginpanel
.subcontent{max-width:500px}.loginbox.clearfix.onecolumn{margin:0
auto;max-width:520px}.useralerts [class^="icon-stack"]{float:left;vertical-align:middle;margin-right:10px}.useralerts
.title{font-weight:bold;margin-right:10px}.alert{border-radius:2px;padding:8px}.alert.alert-info.demo{color:#555;margin-top:20px}.course-content ul.topics li.section .left, .course-content ul.topics li.section
.right{padding:0;text-align:left;width:inherit}.carousel-control{width:40px !important;text-align:center !important}.carousel-caption{color:#fefefe}.carousel-caption
h3{color:#fefefe;margin-top:0}.panel{background-color:#fff;border:1px
solid transparent;border-radius:4px;box-shadow:0 1px 1px rgba(0,0,0,0.05);margin-bottom:20px}.panel-heading{border-bottom:1px solid transparent;border-top-left-radius:3px;border-top-right-radius:3px;padding:1px
8px}.panel-body{padding:8px}.panel-default{border-color:#ddd}.panel-default>.panel-heading{background-color:#f5f5f5;border-color:#ddd;color:#777 !important}.panel-primary{border-color:#428bca}.panel-primary>.panel-heading{background-color:#428bca;border-color:#428bca}.panel-primary>.panel-heading>.panel-title{color:#fff !important}.panel-success{border-color:#d6e9c6}.panel-success>.panel-heading{background-color:#dff0d8;border-color:#d6e9c6}.panel-success>.panel-heading>.panel-title{color:#3c763d !important}.panel-info{border-color:#bce8f1}.panel-info>.panel-heading{background-color:#d9edf7;border-color:#bce8f1}.panel-info>.panel-heading>.panel-title{color:#31708f !important}.panel-warning{border-color:#faebcc}.panel-warning>.panel-heading{background-color:#fcf8e3;border-color:#faebcc}.panel-warning>.panel-heading>.panel-title{color:#8a6d3b !important}.panel-danger{border-color:#ebccd1}.panel-danger>.panel-heading{background-color:#f2dede;border-color:#ebccd1}.panel-danger>.panel-heading>.panel-title{color:#a94442}.panel-group>.panel{margin-bottom:4px}.collapsing{height:0;overflow:hidden;position:relative;transition:height 0.35s ease 0s}.nav-tabs,.nav-pills{text-align:left !important}#scorm_toc{height:100%;overflow-x:hidden;overflow-y:scroll}.carousel.slide.no-indicators .carousel-indicators
li{background-color:transparent !important}.course-content ul.ctopics li.section .content .toggle, .course-content ul.ctopics li.section
.content.sectionhidden{border-radius:2px !important}.pagelayout-frontpage .section .activity .mod-indent-outer{padding-left:0}.site-topic ul.section, .course-content ul.section,ul.section{margin:0}.section .activity .mod-indent-outer{padding-left:0}.section .activity
.editing_move{left:-24px}.course-content ul.topics li.section
.summary{margin-left:0}.moodle-actionmenu.show[data-enhanced] .menu a:hover{background-color:#e5e5e5;border-radius:0;color:#333}#adminsettings
h3{color:#555;font-size:1.4em}.path-site .span12 li.activity > div, .path-course-view .span12 li.activity>div{padding:0}.editing .section .activity .contentwithoutlink, .editing .section .activity
.activityinstance{padding-right:100px}.span12 .section .label .contentwithoutlink, span12 .section .label
.activityinstance{padding-right:0}#section_footer
.nav_icon{margin-bottom:-25px}.container-fluid{max-width:none}.container-fluid.full{padding-left:0;padding-right:0}.section .activity
.actions{background:rgba(255,255,255,0.8)}.responsive-video
iframe{position:absolute;top:0;left:0;width:100%;height:100%}.responsive-video{position:relative;padding-bottom:56.25%;padding-top:0px;height:0;overflow:hidden}.message
.messagearea{border-left:medium none;padding-left:0;width:70%}body.ie7 #block-login input[type=text], body.ie7 #block-login input[type=password]{font-family:sans-serif !important;width:157px !important}body.ie8 #block-login input[type=text], body.ie8 #block-login input[type=password]{font-family:sans-serif !important}body#page-mod-feedback-print
#page{background:#fff none repeat scroll 0 0;margin:0
auto;max-width:95%;padding:0
15px}.section
.activity.modtype_label.label{padding:2px}@media(max-width:979px){.navbar .nav-divider-left, .navbar .nav-divider-right{display:none}.navbar .nav>li>a{border:none}.nav-collapse .dropdown-menu li + li
a{margin-bottom:0}.navbar .nav-collapse > .nav .dropdown-menu{margin:0
0 0 15px}.nav-collapse .nav > li > a, .nav-collapse .dropdown-menu
a{font-weight:normal}.navbar .nav-collapse.active{border-top:medium none}.navbar
.brand{margin:0}.navbar .container-fluid{padding:0}.navbar .btn-navbar{margin-right:10px}.navbar #search
input{background:none repeat scroll 0 0 rgba(250, 250, 250, 0.1)}.navbar
#search{margin-right:0}.navbar .nav-collapse.active .nav .dropdown-submenu:hover .dropdown-menu, .navbar .nav-collapse.active .nav .dropdown-menu .dropdown-submenu:hover .dropdown-menu{display:inherit}.nav-collapse .dropdown-submenu>.dropdown-menu{display:block}.navbar .dropdown-menu{border-bottom:none}.nav>.dropdown>.dropdown-menu{border-bottom 4px solid #609}}@media (min-width:768px) and (max-width: 899px){#block-login label#user, #block-login
label#pass{display:none}#block-login input[type="text"], #block-login input[type="password"]{padding:0
2px 0 4px;width:130px}}@media(max-width:767px){.navbar{padding:0}body{padding-left:10px;padding-right:10px}#wrapper{width:100%;max-width:inherit}#page{padding:0
10px}#page-header>.container-fluid>.row-fluid{display:block}.login-header{flex-direction:row}.logo-header{text-align:center}a.logo
img{margin-bottom:10px}.form-item .form-setting, .form-item .form-description, .mform .fitem .felement, #page-mod-forum-search
.c1{margin-left:0}}@media(max-width:480px){body{background:#fff none repeat scroll 0 0;padding-left:0;padding-right:0;padding-top:0}.formulation input[type="text"], .formulation
select{max-width:212px}}@media(max-width:366px){#block-login{padding:0;margin:0
auto;width:205px}#block-login
input#inputName{display:block;margin-bottom:5px;width:201px}}@media(max-width:1150px){.path-admin-theme #admindeviceselector td
img{max-width:400px}}@media(max-width:1000px){.path-admin-theme #admindeviceselector td
img{max-width:300px}}@media(max-width:850px){.path-admin-theme #admindeviceselector td
img{max-width:200px}}@media(max-width:600px){.path-admin-theme #admindeviceselector td
img{max-width:200px}.path-admin-theme #admindeviceselector td
h3{font-size:14px}}.bx-wrapper{direction:ltr}.dir-rtl
.camera_wrap{direction:ltr}.dir-rtl .cameraContents .camera_caption
h1{padding:0
10px}.dir-rtl
.camera_caption{display:inline;left:auto;right:4%;width:40%}.dir-rtl .cameraContents .camera_caption
span{border-left:none;border-right:4px solid #609}.dir-rtl #loggedin-user{float:left}.dir-rtl #block-login input[type="text"], .dir-rtl #block-login input[type="password"]{padding:0
40px 0 2px}.dir-rtl .loginbox .loginform .form-label{float:inherit;text-align:right}.dir-rtl #region-main .block.block_course_overview .content h2.title:before{content:"\f104";padding-right:0px;padding-left:6px}.dir-rtl .content
h3.sectionname{border-color:#eee #609 #eee #eee;border-width:1px 3px 1px 1px;padding:8px
4px 8px 0}.dir-rtl #region-main .block .header .title h2:before{margin:-4px -8px 0 8px}.dir-rtl .block .header .title h2:before{float:right;margin-left:10px;margin-right:0}.dir-rtl
.coursebox{border-color:#eee #609 #eee #eee;border-width:1px 2px 1px 1px}.dir-rtl .coursebox > .info > .coursename
a{padding-right:0}.dir-rtl .coursebox > .info > .coursename a:before, .dir-rtl .coursebox > .info > .name a:before{margin-left:0.5em;margin-right:0;float:right}.dir-rtl .mform fieldset.collapsible legend
a.fheader{margin-right:0}.dir-rtl .navbar
.brand{float:right;padding:10px
20px;margin:0
-20px 0 0}@media(max-width:979px){.dir-rtl .navbar
.brand{margin:0}}.dir-rtl .navbar
#search{float:left;margin-left:-20px;margin-right:0}.dir-rtl .blocknumber_box
.blocknumber_icon{float:right;margin-left:20px}.dir-rtl
.blocknumber_box{text-align:right}.dir-rtl .bx-prev{left:36px;right:inherit}.dir-rtl .bx-next{left:0;right:inherit}.dir-rtl .profileblock
ul.nav{margin-right:0}.dir-rtl .spotlight-full{margin-left:-27px !important;margin-right:-55px !important}.dir-rtl.content-only #region-main.span9, .dir-rtl.empty-region-side-pre #region-bs-main-and-pre.span9, .dir-rtl.empty-region-side-post #region-bs-main-and-post.span9{width:100%}.dir-rtl.empty-region-side-pre.used-region-side-post #region-bs-main-and-post, .dir-rtl.empty-region-side-post.used-region-side-pre #region-bs-main-and-pre{width:74.359%}.dir-rtl.empty-region-side-post.used-region-side-pre #region-main.span8{width:74.359% !important}@media(max-width:767px){.dir-rtl .spotlight-full{margin-left:-17px !important;margin-right:-45px !important}}a.logo
img{max-height:90px}@media(max-width:767px){a.logo
img{max-height:75px}}@media(max-width:480px){a.logo
img{max-height:60px}}.navbar #search
input{background:#fff;border:solid;-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;color:#609;margin:0;padding:10px;height:50px;-webkit-border-radius:0;-moz-border-radius:0;border-radius:0;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;float:left;font-size:0.975em;font-style:italic}@font-face{font-family:'FontAwesome';src:url(/academy/theme/font.php?theme=lambda&component=theme&rev=1533780117&font=fontawesome-webfont.eot);src:url(/academy/theme/font.php?theme=lambda&component=theme&rev=1533780117&font=fontawesome-webfont.eot%3F%23iefix) format('embedded-opentype'),
url(/academy/theme/font.php?theme=lambda&component=theme&rev=1533780117&font=fontawesome-webfont.woff) format('woff'),
url(/academy/theme/font.php?theme=lambda&component=theme&rev=1533780117&font=fontawesome-webfont.ttf) format('truetype'),
url(/academy/theme/font.php?theme=lambda&component=theme&rev=1533780117&font=fontawesome-webfont.svg%23fontawesomeregular) format('svg');font-weight:normal;font-style:normal}a.readmore:before{font-family:FontAwesome;content:"\f101";padding-right:2px}blockquote{border-left:4px solid #609}blockquote footer:before, blockquote small:before, blockquote .small:before{content:"- "}blockquote
p{padding-left:28px}blockquote
footer{color:#777}blockquote:before{color:#bbb;content:"\f10e";float:left;font-family:FontAwesome;font-size:1.5em;margin-right:8px}.maincolor{color:#609}.plus{font-size:1.05em}.main-heading{font-size:45.5px;font-weight:bold !important;line-height:57px}.row-fluid.frontpage{margin-bottom:40px;margin-top:40px}.fa-ul{list-style-type:none !important}.divider.line-01:after{background:#609 none repeat scroll 0 0;content:"";display:block;height:3px;max-width:75px;padding:0;width:50%}.divider.line-01{background:rgba(0, 0, 0, 0) url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=bg%2Fblock-divider) repeat-x scroll left bottom;margin:20px
0}.divider.line-02:before{background:#609 none repeat scroll 0 0;bottom:0;content:"";height:2px;max-width:100%;position:absolute;width:150px}.divider.line-02:after{background:#609 none repeat scroll 0 0;bottom:-10px;content:"";height:2px;max-width:100%;position:absolute;width:150px}.divider.line-02{height:1px;margin-bottom:30px;position:relative}.divider.line-03{background:#609 none repeat scroll 0 0;border-radius:4px;content:"";display:block;height:4px;margin:20px
auto;position:relative;width:50px}.divider-page{margin-top:0 !important}.prom-box{padding:10px
20px;position:relative;margin-bottom:15px}.prom-box
ul{margin-left:55px;list-style:square}.prom-box-default h1, .prom-box-default h2, .prom-box-default h3, .prom-box-default h4, .prom-box-default
h5{margin-top:0;color:#666}.prom-box-default{background-color:#f4f4f4;border-left:6px solid #609}.prom-box-warning h1, .prom-box-warning h2, .prom-box-warning h3, .prom-box-warning h4, .prom-box-warning
h5{margin-top:0;color:#F0AD4E}.prom-box-warning{background-color:#FCF8F2;border-left:6px solid #F0AD4E}.prom-box-danger h1,.prom-box-danger h2,.prom-box-danger h3, .prom-box-danger h4, .prom-box-danger
h5{margin-top:0;color:#D9534F}.prom-box-danger{background-color:#FDF7F7;border-left:6px solid #D9534F}.prom-box-info h1,.prom-box-info h2,.prom-box-info h3, .prom-box-info h4, .prom-box-info
h5{margin-top:0;color:#5BC0DE}.prom-box-info{background-color:#F4F8FA;border-left:6px solid #5BC0DE}.shadow1{-webkit-box-shadow:0 10px 6px -6px #aaa;-moz-box-shadow:0 10px 6px -6px #aaa;box-shadow:0 10px 6px -6px #aaa}.shadow2:after{background-attachment:scroll;background-clip:border-box;background-color:transparent;background-image:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=bg%2Fshadow);background-origin:padding-box;background-position:center bottom;background-repeat:no-repeat;background-size:100% 100%;content:"";height:10px;left:0;position:absolute;top:100%;width:100%}.caption-hover{background:#FFF;border:none;box-shadow:3px 3px 2px #ddd;cursor:default;float:left;height:150px;overflow:hidden;position:relative;text-align:center}.caption-hover
.mask{height:100%;left:0;overflow:hidden;position:absolute;top:0;line-height:1.5em;width:100%}.caption-hover
img{display:block;position:relative;height:110px !important;width:240px !important;margin:0
!important}.caption-hover
h2{color:#FFF;font-size:1.15em;margin:0;position:relative;text-align:center;text-transform:uppercase}.caption-hover
p{color:#FFF;padding:0
10px;margin:0
0 10px;position:relative;text-align:center}.caption-hover
a.info{background:#333;border-radius:3px;color:#FFF;display:inline-block;padding:7px
14px;text-decoration:none;text-transform:uppercase}.caption-hover
.mask{margin:110px
0;transition:all 0.3s ease-in-out 0s;-moz-transition:all 0.3s ease-in-out 0s;-webkit-transition:all 0.3s ease-in-out 0s}.caption-hover:hover
.mask{margin:0}.green{background-color:#8EC63F}.purple{background-color:#92499E}.orange{background-color:#F1592A}.lightblue{background-color:#38B9EC}.yellow{background-color:#fdb53f}.turquoise{background-color:#29A294}.iconbox-end{clear:both;margin-bottom:10px}.iconbox{float:left;padding:0
10px;text-align:center;margin-bottom:25px}.iconbox
.iconcircle{border:1px
solid #609;border-radius:50%;height:80px;line-height:100px;margin:0
auto;width:80px;transition:all 0.7s}.iconbox:hover>.iconcircle{border:1px
solid #fff;background:#609;transition:all 0.7s}.iconbox .iconcircle
.fa{color:#609;font-size:3em;transition:all 0.7s}.iconbox:hover>.iconcircle>.fa{color:#fff;transition:all 0.7s}.iconbox .iconbox-content{text-align:center;word-wrap:break-word}.text-box{background:#f4f4f4;padding:15px}.text-box-heading{font-size:2em;padding:10px
12px;background:#281a70;color:#fff}.text-box .arrow-down{width:0;height:0;border-left:10px solid transparent;border-right:10px solid transparent;border-top:10px solid #281a70;font-size:0;line-height:0;margin-left:7%}.text-box-headindg:after{top:100%;left:50%;border:solid transparent;content:" ";height:0;width:0;position:absolute;pointer-events:none;border-color:rgba(15,213,28,0);border-top-color:#0fd51c;border-width:15px;margin-left:-15px}.image-box{border:1px
solid #eee;margin-bottom:20px}.image-box
img{margin:0;padding:0;border:none}.image-box .image-box-content{padding:15px}.blocknumber_box{padding-bottom:25px;text-align:left}.blocknumber_box h1, .blocknumber_box h2, .blocknumber_box h3, .blocknumber_box h4, .blocknumber_box h5, .blocknumber_box
h6{margin-top:0}.blocknumber_box
.blocknumber_icon{background:none repeat scroll 0 0 #609;border-radius:50%;color:#fff;float:left;font-size:20px;height:32px;line-height:32px;margin-right:20px;text-align:center;width:32px}.blocknumber_box
.blocknumber_content{overflow:hidden;padding-top:4px}.row-fluid.colored{display:flex}.row-fluid.colored>[class*="span"]{background:#fbfbfb none repeat scroll 0 0;margin:0
!important;padding:30px
!important}.row-fluid.colored>.span3{width:25% !important}.row-fluid.colored>.span4{width:33.33% !important}.row-fluid.colored>.span5{width:41.66% !important}.row-fluid.colored>.span6{width:50% !important}.row-fluid.colored>.span7{width:58.33% !important}.row-fluid.colored>.span8{width:66.66% !important}.row-fluid.colored>.span9{width:75% !important}@media(max-width:767px){.row-fluid.colored{display:block}.row-fluid.colored>[class*="span"]{width:100% !important}}.row-fluid.colored>[class*="span"]:hover{background:#efefef none repeat scroll 0 0 !important}.row-fluid.colored>[class*="span"]:nth-child(2n){background:#f4f4f4 none repeat scroll 0 0}.headline{border:medium none;margin-bottom:10px;box-shadow:0 0 0 1px rgba(0, 0, 0, 0.1) inset;font-weight:bold;padding:8px
8px 0}.headline-v1{background:#f4f4f4}.headline-v2{background:#609;color:#fff}.headline-v3{background:#609;color:#fff}.headline
.fa{font-size:1.25em;margin:-8px 8px 0 -8px;padding:10px}.headline-v1
.fa{background:none repeat scroll 0 0 #609;color:#fff}.headline-v2
.fa{background:none repeat scroll 0 0 #406;color:#fff}.headline-v3
.fa{background:none repeat scroll 0 0 #609;color:#fff}.content
h3.sectionname{padding:8px
0;background:#f4f4f4;color:#666;border-color:#EEE #EEEEEE #EEE #660099;border-style:solid;border-width:1px 1px 1px 3px;padding-left:4px;margin-top:0;font-size:1.4em;line-height:20px}.course-content .single-section .section-navigation
.title{clear:both;font-size:1.2em;font-family:"Open Sans";line-height:1.2em;padding:8px
0;margin-bottom:10px;background:#609;border:medium none;color:#fff;padding-left:2px;font-weight:normal}#section-0 .content>h3.sectionname{border-bottom:2px solid #609;border-left:none;border-top:1px solid #e1e1e1;font-size:1.75em;line-height:25px;box-shadow:inset 0 1px 0 rgba(256,256,256,0.35)}.course-pano.wrapper{position:relative;height:175px;overflow:hidden;position:relative;background:#f4f4f4;box-shadow:0px 0px 0px 1px rgba(0, 0, 0, 0.1) inset}.course-pano.title{height:135px;left:0;padding:20px;top:0;position:absolute}.course-pano.title
h2{margin-top:20px;margin-bottom:20px;color:#fff !important}.course-pano.title h2>span{background:#609;padding:4px
8px;font-size:0.95em}.course-pano.title
h4{color:#fff !important;margin-left:15px}.course-pano.title h4>span{background:none repeat scroll 0 0 rgba(0, 0, 0, 0.5);border-left:4px solid #609;padding:8px;display:inline-block;font-size:0.8em}@media(max-width:979px){.course-pano.title
h2{margin-bottom:5px;margin-top:10px}.course-pano.title h2>span{font-size:0.8em}.course-pano.title h4>span{font-size:0.7em}}@media(max-width:767px){.course-pano.title
h2{margin-top:5px}.course-pano.title h2>span{font-size:0.7em}.course-pano.title
h4{margin-left:0}.course-pano.title h4>span{font-size:0.63em}}.course-pano>img{bottom:0;height:100%;margin:0
!important;min-height:175px;object-fit:cover;position:absolute;width:100%}.ie .course-pano>img{display:block;height:175px;left:50%;margin:0
!important;max-width:none;position:absolute;transform:translateX(-50%);width:auto}.ie.ie9 .course-pano>img{left:50%;-ms-transform:translateX(-50%)}.ie.ie8 .course-pano>img{left:0;transform:none}.ie.ie8 .course-pano.title h4>span{background:none repeat scroll 0 0 #609}.spotlight{padding:10px;font-size:1.1em;margin:25px
0;position:relative}.spotlight-v1{background:none repeat scroll 0 0 #609}.spotlight-v1 h1, .spotlight-v1 h2, .spotlight-v1 h3, .spotlight-v1 h4, .spotlight-v1 h5, .spotlight-v1 h6, spotlight-v1
p{color:#fff}.spotlight-v1.spotlight-full{padding-top:15px;padding-bottom:15px}.spotlight-v1 .btn-primary{border:2px
solid #fff;text-decoration:none}.spotlight-v2{background:none repeat scroll 0 0 #f8f8f8;border-bottom:2px solid #609;border-top:1px solid #e1e1e1;color:#333}.spotlight-v2.shadow2:after{margin-top:2px}.spotlight-v3,.spotlight-v4,.spotlight-v5{background-attachment:fixed;background-color:#323a45;background-size:cover}.spotlight-v3{background-image:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=bg%2Fspotlight-3-bg)}.spotlight-v4{background-image:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=bg%2Fspotlight-4-bg)}.spotlight-v5{background-image:url(/academy/theme/image.php?theme=lambda&component=theme&rev=1533780117&image=bg%2Fspotlight-5-bg)}.spotlight-v3, .spotlight-v3 h1, .spotlight-v3 h2, .spotlight-v3 h3, .spotlight-v3 h4, .spotlight-v3 h5, .spotlight-v3 h6, spotlight-v3 p,
.spotlight-v4, .spotlight-v4 h1, .spotlight-v4 h2, .spotlight-v4 h3, .spotlight-v4 h4, .spotlight-v4 h5, .spotlight-v4 h6, spotlight-v4
p{color:#fff}.spotlight-v5, .spotlight-v5 h1, .spotlight-v5 h2, .spotlight-v5 h3, .spotlight-v5 h4, .spotlight-v5 h5, .spotlight-v5 h6, spotlight-v5
p{color:#555}.spotlight-full{margin-left:-22px;margin-right:-22px;margin-top:25px;padding:30px}.spotlight-v1.arrow-top{border-top:1px solid #406}.spotlight-v1.arrow-top:before{background-color:#609;border-top:1px solid #406;border-left:1px solid #406;top:-15px;content:"";height:30px;left:50%;margin-left:-15px;position:absolute;-ms-transform:rotate(45deg);-webkit-transform:rotate(45deg);transform:rotate(45deg);width:30px}.spotlight-v1.arrow-bottom{border-bottom:1px solid #406}.spotlight-v1.arrow-bottom:after{background-color:#609;border-bottom:1px solid #406;border-right:1px solid #406;bottom:-15px;content:"";height:30px;left:50%;margin-left:-15px;position:absolute;-ms-transform:rotate(45deg);-webkit-transform:rotate(45deg);transform:rotate(45deg);width:30px}@media(max-width:767px){.spotlight-full{margin-left:-13px;margin-right:-13px;padding:0
30px}}button, .btn, .btn-default, input.form-submit, input[type="button"], input[type="submit"], input[type="reset"], input.form-submit, input#id_submitbutton, input#id_submitbutton2, .path-admin .buttons input[type="submit"], td.submit input, .submit.buttons input[name="cancel"], #notice .singlebutton + .singlebutton
input{background-image:none;background-color:#281a70;color:#fff;border:none;border-radius:2px;text-shadow:none;padding:6px
18px;box-shadow:0 -1px 0 rgba(0,0,0,0.1) inset}button a, .btn a, button a:visited, .btn a:visited, a.btn, a.btn:visited, #page-footer .content a.btn, #page-footer .footerlinks
a.btn{color:#fff}button:hover, button:focus, button:active, .btn:hover, .btn-default:hover, .btn-default:focus, .btn-default:active, .btn-default.active,  .open .dropdown-toggle.btn-default , input.form-submit:hover, input[type="button"]:hover, input[type="submit"]:hover, input[type="reset"]:hover, button:focus, input.form-submit:focus, input[type="button"]:focus, input[type="submit"]:focus, input[type="reset"]:focus, button.active, input.form-submit.active, input.active[type="button"], input.active[type="submit"], input.active[type="reset"], button:active, input.form-submit:active, input[type="button"]:active, input[type="submit"]:active, input[type="reset"]:active, input.form-submit:hover, input#id_submitbutton:hover, input#id_submitbutton2:hover, .path-admin .buttons input[type="submit"]:hover, td.submit input:hover, input.form-submit:focus, input#id_submitbutton:focus, input#id_submitbutton2:focus, .path-admin .buttons input[type="submit"]:focus, td.submit input:focus, input.form-submit:active, input#id_submitbutton:active, input#id_submitbutton2:active, .path-admin .buttons input[type="submit"]:active, td.submit input:active, input.form-submit.active, input#id_submitbutton.active, input#id_submitbutton2.active, .path-admin .buttons input.active[type="submit"], td.submit input.active, input.form-submit.disabled, input#id_submitbutton.disabled, input#id_submitbutton2.disabled, .path-admin .buttons input.disabled[type="submit"], td.submit input.disabled, input.form-submit[disabled], input#id_submitbutton[disabled], input#id_submitbutton2[disabled], .path-admin .buttons input[type="submit"][disabled], td.submit input[disabled], #notice .singlebutton + .singlebutton input:hover{background-color:#322984;color:#fff;transition:all 0.3s ease 0.1s}.btn-primary{background-color:#609}.btn-primary:hover,.btn-primary:focus,.btn-primary:active,.btn-primary.active,.btn-primary.disabled,.btn-primary[disabled]{background-color:#406 !important;color:#fff;transition:all 0.3s ease 0.1s}.btn-success{background-color:#5bb75b}.btn-success:hover,.btn-success:focus,.btn-success:active,.btn-success.active{background-color:#51a351 !important;color:#fff;transition:all 0.3s ease 0.1s}.btn-info{background-color:#38B9EC !important}.btn-info:hover,.btn-info:focus,.btn-info:active,.btn-info.active,.btn-info.disabled,.btn-info[disabled]{background-color:#29A7D8 !important;color:#fff;transition:all 0.3s ease 0.1s}.btn-warning{background-color:#FFD50E !important}.btn-warning:hover,.btn-warning:focus,.btn-warning:active,.btn-warning.active,.btn-warning.disabled,.btn-warning[disabled]{background-color:#EDC202 !important;color:#fff;transition:all 0.3s ease 0.1s}.btn-danger, .btn-cancel, .submit.buttons input[name="cancel"], #notice .singlebutton + .singlebutton
input{background-color:#c23a34 !important}.btn-danger:hover, .btn-danger:focus, .btn-danger:active, .btn-cancel:hover, .btn-cancel:focus, .btn-cancel:active, .submit.buttons input[name="cancel"]:hover, .submit.buttons input[name="cancel"]:focus, .submit.buttons input[name="cancel"]:active, #notice .singlebutton + .singlebutton input:hover, #notice .singlebutton + .singlebutton input:focus, #notice .singlebutton + .singlebutton input:active{background-color:#b82d27 !important;color:#fff;transition:all 0.3s ease 0.1s}ul.list-style-1 li, ul.list-style-2 li, ul.list-style-3
li{list-style:none outside none}ul.list-style-1 li:before{font-family:FontAwesome;content:"\f061";display:inline-block;margin:0
0 0 -18px;padding-right:6px}ul.list-style-2 li:before{font-family:FontAwesome;content:"\f00c";display:inline-block;margin:0
0 0 -18px;padding-right:6px}ul.list-style-3 li:before{font-family:FontAwesome;content:"\f138";display:inline-block;margin:0
0 0 -18px;padding-right:6px}ul.list-style-1.colored li:before, ul.list-style-2.colored li:before, ul.list-style-3.colored li:before{color:#609}table#greyboxright{background:#F9F9F9;border:1px
solid #EEE;border-bottom:3px solid #EEE;margin-left:20px;float:right}table#greybox{background:#F9F9F9;border:1px
solid #EEE;border-bottom:3px solid #EEE;margin-top:30px}table#greyboxleft{background:#F9F9F9;border:1px
solid #EEE;border-bottom:3px solid #EEE;margin-right:20px;float:left}table#greyboxright td,
table#greyboxleft
td{padding:10px;padding-top:0px;max-width:360px}table#greybox
td{padding:20px}table#greyboxright h2,
table#greyboxleft
h2{border-bottom:1px solid #EEE;padding-bottom:8px;font-size:1.2em;line-height:17px}.course-summary-heading{background:#609;color:#fff;padding:2px;margin-bottom:10px}.bs-example{background-color:#fff;border-color:#ddd;border-radius:2px 2px 0 0;border-width:1px;border-style:solid;box-shadow:none;margin:0
0 15px;padding:45px
15px 15px;position:relative}.bs-example:after{background-color:#f6f6f6;border:1px
solid #ddd;border-radius:4px 0;color:#959595;content:"Example";font-size:12px;font-weight:bold;left:-1px;padding:3px
7px;position:absolute;top:-1px}.bs-example+pre{margin:-16px 0 15px;border-radius:0 0 2px 2px}.bs-example
table{margin-bottom:0}.nt{color:#d44950}.s{color:#2f6f9f}.na{color:#333}.text-muted{color:#999}.text-danger{color:#c23a34}.label-danger,.badge-danger{background-color:#c23a34}.show-grid [class*="span"]{background-color:#eee;border-radius:3px;line-height:40px;min-height:40px;text-align:center}.show-grid{margin-bottom:20px;margin-top:10px}.panel{border-radius:0}.panel .panel-heading
a{font-size:1.15em;line-height:2em}.panel .panel-heading a:before{background:#609;color:#fff;content:"\f107";float:left;font-family:'FontAwesome';font-size:1.2em;margin:-1px 5px 0 -8px;padding:1px;text-align:center;width:33px}.panel .panel-heading a.collapsed:before{content:"\f105"}.panel-primary>.panel-heading{background-color:#f9bf3b;border-color:#f9bf3b}.panel-primary{border-color:#f9bf3b}.panel-primary>.panel-heading>.panel-title{color:#fff !important;margin:0}.nav-tabs>li.active{border-bottom:1px solid #fff;border-top:2px solid #609;margin-bottom:-1px;margin-top:-2px}.nav-tabs>.active>a,.nav-tabs>.active>a:hover,.nav-tabs>.active>a:focus{background-color:#fff;color:#555;cursor:default;border-radius:0;border:medium none}.nav-tabs>li{margin-bottom:0}.nav-tabs>li>a{border:medium none;background-color:#f4f4f4;color:#555}.nav-tabs>li>a:hover{background-color:#e2e2e2}.nav-tabs>li>a,.nav-pills>li>a{margin-right:0}.nav-tabs{background:none repeat scroll 0 0 #f4f4f4;border-top:2px solid #ccc;border-left:1px solid #dfdfdf;border-right:1px solid #dfdfdf;border-bottom:none;margin-bottom:0}.tab-content{border:1px
solid #dfdfdf;padding:8px}tr.danger>td,.table>thead>tr.danger>th,.table>tbody>tr.danger>th,.table>tfoot>tr.danger>th{background-color:#f2dede}tr.warning>td,.table>thead>tr.warning>th,.table>tbody>tr.warning>th,.table>tfoot>tr.warning>th{background-color:#fcf8e3}tr.info>td,.table>thead>tr.info>th,.table>tbody>tr.info>th,.table>tfoot>tr.info>th{background-color:#d9edf7}tr.success>td,.table>thead>tr.success>th,.table>tbody>tr.success>th,.table>tfoot>tr.success>th{background-color:#dff0d8}tr.active>td,.table>thead>tr.active>th,.table>tbody>tr.active>th,.table>tfoot>tr.active>th{background-color:#f5f5f5}a.singinprovider .social-button::before{background-color:rgba(0, 0, 0, 0.15);margin:-7px 10px -7px -7px;padding:7px;text-indent:0;vertical-align:bottom;font-size:20px;position:relative;top:0;display:inline-block;font-family:"FontAwesome";font-style:normal;font-variant:normal;font-weight:normal;min-width:24px;line-height:unset;;text-align:center;content:"\f090"}a.singinprovider .social-button{text-align:center;background:#ccc;display:inline-block;text-align:left;min-width:185px;color:#fff;padding:7px;border:1px
solid rgba(0,0,0,0.1);border-radius:3px;transition:background-color 0.15s}a.singinprovider .social-button.google::before{content:"\f0d5"}a.singinprovider .social-button.google{background-color:#dc4e41}a.singinprovider .social-button.google:hover{background-color:#c23321}a.singinprovider .social-button.dropbox::before{content:"\f16b"}a.singinprovider .social-button.dropbox{background-color:#1087dd}a.singinprovider .social-button.dropbox:hover{background-color:#0d6aad}a.singinprovider .social-button.battlenet::before{content:"\f11b"}a.singinprovider .social-button.battlenet{background-color:#00b6ff}.social-button.battlenet:hover{background-color:#006a9b}a.singinprovider .social-button.facebook::before{content:"\f09a"}a.singinprovider .social-button.facebook{background-color:#3b5998}a.singinprovider .social-button.facebook:hover{background-color:#2d4373}a.singinprovider .social-button.github::before{content:"\f09b"}a.singinprovider .social-button.github{background-color:#555}a.singinprovider .social-button.github:hover{background-color:#2b2b2b}a.singinprovider .social-button.linkedin::before{content:"\f0e1"}a.singinprovider .social-button.linkedin{background-color:#007bb6}a.singinprovider .social-button.linkedin:hover{background-color:#005983}a.singinprovider .social-button.microsoft::before{content:"\f17a"}a.singinprovider .social-button.microsoft{background-color:#2672ec}a.singinprovider .social-button.microsoft:hover{background-color:#125acd}a.singinprovider .social-button.vk::before{content:"\f189"}a.singinprovider .social-button.vk{background-color:#587ea3}a.singinprovider .social-button.vk:hover{background-color:#466482}.pagelayout-login .profileblock
a.singinprovider{display:none !important}.pagelayout-login
.forgotpass.oauth2{display:none}